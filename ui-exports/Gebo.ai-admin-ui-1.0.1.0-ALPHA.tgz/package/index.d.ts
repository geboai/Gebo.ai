/**
 * Generated bundle index. Do not edit.
 */
/// <amd-module name="@Gebo.ai/admin-ui" />
export * from './public-api';
