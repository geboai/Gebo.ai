import { FormGroup } from "@angular/forms";
import { FileSystemSharesSettingControllerService, GeboFastWorkFolderSetupControllerService } from "@Gebo.ai/gebo-ai-rest-api";
import { AbstractStatusService, BaseWizardSectionComponent, browsePathObservableCallback, loadRootsObservableCallback, SetupWizardComunicationService } from "@Gebo.ai/reusable-ui";
import { Observable } from "rxjs";
import * as i0 from "@angular/core";
/**
 * Service that checks whether the work folder setup is enabled in the system.
 * Extends AbstractStatusService to provide status information about the work folder configuration.
 */
export declare class WorkFolderWizardEnabledService extends AbstractStatusService {
    private workFolderFastSetupService;
    /**
     * Creates an instance of WorkFolderWizardEnabledService.
     * @param workFolderFastSetupService - Service for interacting with work folder setup API
     */
    constructor(workFolderFastSetupService: GeboFastWorkFolderSetupControllerService);
    /**
     * Overrides the base getBooleanStatus method to check if work directory setup is enabled.
     * @returns An Observable that emits true if the work directory setup is enabled, false otherwise
     */
    getBooleanStatus(): Observable<boolean>;
    static ɵfac: i0.ɵɵFactoryDeclaration<WorkFolderWizardEnabledService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<WorkFolderWizardEnabledService>;
}
/**
 * Service that checks whether the work folder has been successfully set up.
 * Extends AbstractStatusService to provide status information about the work folder setup completion.
 */
export declare class WorkFolderWizardStatusService extends AbstractStatusService {
    private workFolderFastSetupService;
    /**
     * Creates an instance of WorkFolderWizardStatusService.
     * @param workFolderFastSetupService - Service for interacting with work folder setup API
     */
    constructor(workFolderFastSetupService: GeboFastWorkFolderSetupControllerService);
    /**
     * Overrides the base getBooleanStatus method to check if work directory setup is completed.
     * @returns An Observable that emits true if the work directory is set up, false otherwise
     */
    getBooleanStatus(): Observable<boolean>;
    static ɵfac: i0.ɵɵFactoryDeclaration<WorkFolderWizardStatusService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<WorkFolderWizardStatusService>;
}
/**
 * Component that implements the UI for the work folder configuration wizard.
 * Extends BaseWizardSectionComponent to integrate with the wizard framework.
 * Provides functionality to view, browse, and set up work directories.
 */
export declare class WorkFolderWizardComponent extends BaseWizardSectionComponent {
    private workFolderFastSetupService;
    private fileSystemSharesSettingControllerService;
    /**
     * Flag indicating if the work folder configuration is enabled
     */
    enabled: boolean;
    /**
     * Form group for capturing the work directory path
     */
    formGroup: FormGroup;
    /**
     * Observable callback for loading root filesystem nodes
     */
    loadRootsObservable: loadRootsObservableCallback;
    /**
     * Observable callback for browsing filesystem paths
     */
    browsePathObservable: browsePathObservableCallback;
    /**
     * Creates an instance of WorkFolderWizardComponent.
     * @param setupWizardComunicationService - Service for wizard communication
     * @param workFolderFastSetupService - Service for work folder setup operations
     * @param fileSystemSharesSettingControllerService - Service for filesystem operations
     */
    constructor(setupWizardComunicationService: SetupWizardComunicationService, workFolderFastSetupService: GeboFastWorkFolderSetupControllerService, fileSystemSharesSettingControllerService: FileSystemSharesSettingControllerService);
    /**
     * Loads current work folder configuration data from the backend.
     * Overrides the base reloadData method to fetch both enabled status and setup status.
     */
    reloadData(): void;
    /**
     * Saves the configured work folder path to the backend.
     * Updates the UI with any messages or errors returned from the backend.
     */
    saveWorkFolder(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<WorkFolderWizardComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<WorkFolderWizardComponent, "gebo-work-folder-wizard-component", never, {}, {}, never, never, false, never>;
}
//# sourceMappingURL=work-folder-wizard.component.d.ts.map