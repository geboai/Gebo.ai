/**
 * This Source Code is subject to the terms of the
 * Gebo.ai community version Mozilla Public License Version 2.0 (MPL-2.0) — With Data Protection Clauses
 * If a copy of the LICENCE was not distributed with this file, You can obtain one at
 * https://gebo.ai/gebo-ai-community-version-mozilla-public-license-version-2-0-mpl-2-0-with-data-protection-clauses/
 * and https://mozilla.org/MPL/2.0/.
 * Copyright (c) 2025+ Gebo.ai
 */
import { GeboAIEntitiesSettingWizardConfiguration } from "@Gebo.ai/reusable-ui";
/**
 * Configuration array that defines the wizard flow for creating a knowledge base.
 * Each object in the array represents a step in the wizard with navigation logic
 * between steps, including how data is passed between steps.
 */
export declare const KNOWLEDGEBASE_WIZARD: GeboAIEntitiesSettingWizardConfiguration[];
//# sourceMappingURL=wizards-navigation.d.ts.map