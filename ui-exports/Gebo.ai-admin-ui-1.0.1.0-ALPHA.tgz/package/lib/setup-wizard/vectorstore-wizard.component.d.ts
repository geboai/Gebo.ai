import { FormGroup } from "@angular/forms";
import { ComponentVectorStoreStatus, GeboFastVectorStoreSetupControllerService } from "@Gebo.ai/gebo-ai-rest-api";
import { AbstractStatusService, BaseWizardSectionComponent, SetupWizardComunicationService } from "@Gebo.ai/reusable-ui";
import { Observable } from "rxjs";
import * as i0 from "@angular/core";
/**
 * Service for managing vector store setup status within the wizard flow.
 * Extends AbstractStatusService to provide standardized status checking methods.
 * Communicates with the backend API to check if vector store is properly configured.
 */
export declare class VectorStoreWizardService extends AbstractStatusService {
    private vectorStoreFastSetupService;
    constructor(vectorStoreFastSetupService: GeboFastVectorStoreSetupControllerService);
    /**
     * Overrides the parent method to check if the vector store is set up.
     * Retrieves the vector store status from the API and maps the response to a boolean.
     *
     * @returns Observable<boolean> that emits true if the vector store is set up, false otherwise
     */
    getBooleanStatus(): Observable<boolean>;
    static ɵfac: i0.ɵɵFactoryDeclaration<VectorStoreWizardService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<VectorStoreWizardService>;
}
/**
 * Component for configuring vector store settings in a wizard-style interface.
 * Provides UI controls for setting up different vector store providers like Qdrant.
 * Extends BaseWizardSectionComponent to integrate with the overall setup wizard flow.
 */
export declare class VectorStoreWizardComponent extends BaseWizardSectionComponent {
    private vectorStoreFastSetupService;
    /**
     * Form group for vector store configuration with nested form groups for
     * different vector store providers (Redis, Qdrant)
     */
    formGroup: FormGroup;
    /**
     * Current status of the vector store configuration
     */
    vectorStoreStatus?: ComponentVectorStoreStatus;
    /**
     * Available vector store products that can be configured
     * Currently only includes Qdrant, with others commented out
     */
    vectorStoreProducts: {
        code: ComponentVectorStoreStatus.ProductEnum;
        label: string;
        description: string;
    }[];
    /**
     * Currently selected vector store product
     */
    product?: ComponentVectorStoreStatus.ProductEnum;
    /**
     * Creates an instance of VectorStoreWizardComponent.
     *
     * @param setupWizardComunicationService Service for communicating with the setup wizard
     * @param vectorStoreFastSetupService Service for interacting with vector store setup API
     */
    constructor(setupWizardComunicationService: SetupWizardComunicationService, vectorStoreFastSetupService: GeboFastVectorStoreSetupControllerService);
    /**
     * Loads the current vector store configuration from the backend.
     * Updates the form with the retrieved values and sets the component state.
     * Overrides the parent method to provide specific implementation.
     */
    reloadData(): void;
    /**
     * Handles changes to the selected vector store product.
     * Enables/disables the appropriate configuration form groups based on selection.
     *
     * @param value The selected vector store product enum value
     */
    productChange(value: ComponentVectorStoreStatus.ProductEnum): void;
    /**
     * Sends the vector store configuration to the backend API.
     * Updates the component state based on the API response.
     * Handles user feedback messages from the API.
     */
    updateVectorStoreConfig(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<VectorStoreWizardComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<VectorStoreWizardComponent, "gebo-vectorstore-wizard-component", never, {}, {}, never, never, false, never>;
}
//# sourceMappingURL=vectorstore-wizard.component.d.ts.map