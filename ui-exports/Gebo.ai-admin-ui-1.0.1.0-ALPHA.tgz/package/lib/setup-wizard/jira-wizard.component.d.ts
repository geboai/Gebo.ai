import { GeboModulesConfigControllerService, GJiraSystem, JiraSystemsControllerService } from "@Gebo.ai/gebo-ai-rest-api";
import { AbstractStatusService, BaseWizardSectionComponent, GeboUIActionRoutingService, SetupWizardComunicationService } from "@Gebo.ai/reusable-ui";
import { Observable } from "rxjs";
import { GeboRootInstalledModuleService } from "./abstract-module-installed.service";
import * as i0 from "@angular/core";
/**
 * Service that checks the status of Jira systems.
 * Extends AbstractStatusService to provide a standardized way to check if any Jira systems are configured.
 */
export declare class JiraStatusService extends AbstractStatusService {
    private confluenceControllerService;
    constructor(confluenceControllerService: JiraSystemsControllerService);
    /**
     * Retrieves the status of Jira systems.
     * @returns An Observable that emits true if at least one Jira system is configured, false otherwise.
     */
    getBooleanStatus(): Observable<boolean>;
    static ɵfac: i0.ɵɵFactoryDeclaration<JiraStatusService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<JiraStatusService>;
}
/**
 * Service that verifies if the Jira module is installed.
 * Extends GeboRootInstalledModuleService to handle module-specific installation checks.
 */
export declare class JiraInstalledModuleService extends GeboRootInstalledModuleService {
    protected moduleCode: string;
    constructor(geboModulesConfigService: GeboModulesConfigControllerService);
    static ɵfac: i0.ɵɵFactoryDeclaration<JiraInstalledModuleService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<JiraInstalledModuleService>;
}
/**
 * Component that provides a wizard interface for setting up and managing Jira systems.
 * Extends BaseWizardSectionComponent to integrate with the overall setup wizard flow.
 * Allows users to create, view, and edit Jira system configurations.
 */
export declare class JiraWizardComponent extends BaseWizardSectionComponent {
    private confluenceControllerService;
    private geboUIActionsRouter;
    createConfluenceWindowOpen: boolean;
    systems: GJiraSystem[];
    constructor(setupWizardComunicationService: SetupWizardComunicationService, confluenceControllerService: JiraSystemsControllerService, geboUIActionsRouter: GeboUIActionRoutingService);
    /**
     * Reloads the Jira systems data from the backend.
     * Updates the systems array and sets the completion status based on whether any systems exist.
     * Sets loading state during the data fetch operation.
     */
    reloadData(): void;
    /**
     * Opens the edit dialog for a specific Jira system.
     * Uses the GeboUIActionRoutingService to route the edit action.
     * @param value The Jira system to edit
     */
    editJiraSystem(value: GJiraSystem): void;
    /**
     * Opens the dialog for creating a new Jira system.
     */
    createJiraSystem(): void;
    /**
     * Closes the create/edit dialog and refreshes the data.
     */
    closeDialog(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<JiraWizardComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<JiraWizardComponent, "gebo-jira-wizard-component", never, {}, {}, never, never, false, never>;
}
