import { LLMSSetupConfiguration, LLMSSetupConfigurationData, UserControllerService } from "@Gebo.ai/gebo-ai-rest-api";
import { BaseWizardSectionComponent, SetupWizardComunicationService } from "@Gebo.ai/reusable-ui";
import { LLMSetupWizardService } from "./llms-setup-wizard.service";
import * as i0 from "@angular/core";
/**
 * Component responsible for the LLM setup wizard.
 * Extends BaseWizardSectionComponent from the reusable UI library.
 * Provides UI and functionality for configuring LLMs in the system.
 */
export declare class LLMSetupWizardComponent extends BaseWizardSectionComponent {
    private userService;
    private llmsSetupWizardService;
    /**
     * Array to store configured LLM models fetched from the backend.
     */
    protected actualProvidersConfiguration?: LLMSSetupConfigurationData;
    protected currentIndex: number;
    protected autoSettingsConfigurations?: LLMSSetupConfiguration[];
    /**
     * Constructor initializes services required for LLM setup functionality.
     */
    constructor(setupWizardComunicationService: SetupWizardComunicationService, userService: UserControllerService, llmsSetupWizardService: LLMSetupWizardService);
    /**
     * Reloads data for the wizard component by fetching current LLM configurations.
     * Retrieves:
     * - Setup completion status
     * - Configured chat models
     * - Configured embedding models
     * - Current user info
     * Updates the component state based on the retrieved data.
     */
    reloadData(): void;
    onVendorConfigurationChanged(changedFlag: boolean, index: number): void;
    onAutomaticSetupDone(): void;
    /**
     * Submits the LLM setup form data to the backend service.
     * Creates new LLM configurations based on user input.
     * On successful setup, closes the wizard.
     */
    setupLLMS(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<LLMSetupWizardComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<LLMSetupWizardComponent, "gebo-llms-wizard-component", never, {}, {}, never, never, false, never>;
}
