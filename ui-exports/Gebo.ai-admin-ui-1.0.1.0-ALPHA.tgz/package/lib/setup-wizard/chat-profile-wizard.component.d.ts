import { FormGroup } from "@angular/forms";
import { DataPage, FunctionsLookupControllerService, GChatProfileConfiguration, GeboAdminChatProfilesConfigurationControllerService, GeboFastChatProfileStatusControllerService, GKnowledgeBase, KnowledgeBaseControllerService, PageGChatProfileConfiguration, PromptTemplatesControllerService } from "@Gebo.ai/gebo-ai-rest-api";
import { AbstractStatusService, BaseWizardSectionComponent, GeboUIActionRoutingService, SetupWizardComunicationService } from "@Gebo.ai/reusable-ui";
import { PaginatorState } from "primeng/paginator";
import { Observable } from "rxjs";
import * as i0 from "@angular/core";
/**
 * AI generated comments
 *
 * This module provides functionality for managing chat profiles in the Gebo.ai application.
 * It includes a service for checking chat profile setup status and a component for a chat profile setup wizard.
 */
/**
 * Service that extends AbstractStatusService to check if chat profiles are set up
 * in the system. This is used to determine if this step in the setup wizard is complete.
 */
export declare class ChatProfileStatusService extends AbstractStatusService {
    private chatProfileStatusService;
    constructor(chatProfileStatusService: GeboFastChatProfileStatusControllerService);
    /**
     * Overrides the base method to fetch the chat profile setup status
     * from the backend service and convert it to a boolean value.
     *
     * @returns An Observable<boolean> indicating whether chat profiles are set up
     */
    getBooleanStatus(): Observable<boolean>;
    static ɵfac: i0.ɵɵFactoryDeclaration<ChatProfileStatusService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ChatProfileStatusService>;
}
/**
 * Component that implements a wizard interface for creating and managing chat profiles.
 * Extends BaseWizardSectionComponent to integrate with the overall setup wizard flow.
 * Allows users to view existing chat profiles, create new ones, and modify existing ones.
 */
export declare class ChatProfileWizardComponent extends BaseWizardSectionComponent {
    private chatProfilesService;
    private knowledgeBaseService;
    private functionsLookupService;
    private promptTemplatesControllerService;
    private geboUIActionRoutingService;
    /**
     * Pagination configuration for chat profiles list
     */
    page: DataPage;
    /**
     * Contains the paginated chat profiles data from the backend
     */
    chatProfiles?: PageGChatProfileConfiguration;
    /**
     * Stores the available functions that can be enabled for chat profiles
     */
    private functions;
    /**
     * Stores the default prompt configuration to use for new chat profiles
     */
    private defaultPrompt?;
    /**
     * Getter that returns the chat profile content from the paginated response,
     * or an empty array if no content is available
     */
    get rows(): GChatProfileConfiguration[];
    /**
     * List of knowledge bases available in the system for selection
     */
    knowledgeBases: GKnowledgeBase[];
    /**
     * Form group for the chat profile creation form
     */
    formGroup: FormGroup;
    /**
     * Initializes the component with required services
     */
    constructor(setupWizardComunicationService: SetupWizardComunicationService, chatProfilesService: GeboAdminChatProfilesConfigurationControllerService, knowledgeBaseService: KnowledgeBaseControllerService, functionsLookupService: FunctionsLookupControllerService, promptTemplatesControllerService: PromptTemplatesControllerService, geboUIActionRoutingService: GeboUIActionRoutingService);
    /**
     * Initializes the component by loading knowledge bases, function trees, and default prompts
     * Overrides the parent class method to add additional initialization logic
     */
    ngOnInit(): void;
    /**
     * Helper method to flatten the tree structure of functions into a simple array
     *
     * @param data Array of ToolCategoriesTree objects representing the function hierarchy
     * @returns Array of ToolReference objects representing all available functions
     */
    private serializeFunctions;
    /**
     * Loads chat profile data from the backend service
     * Overrides the parent class method
     */
    reloadData(): void;
    /**
     * Handles pagination events from the PrimeNG paginator
     *
     * @param evt The paginator state containing page number and page size
     */
    onPageChange(evt: PaginatorState): void;
    /**
     * Opens the edit dialog for an existing chat profile
     *
     * @param data The chat profile configuration to edit
     */
    editChatProfile(data: GChatProfileConfiguration): void;
    /**
     * Creates a new chat profile based on the selected knowledge base
     * and routes to the appropriate handler via the action routing service
     */
    newChatProfile(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ChatProfileWizardComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ChatProfileWizardComponent, "gebo-ai-chat-profile-wizard-component", never, {}, {}, never, never, false, never>;
}
