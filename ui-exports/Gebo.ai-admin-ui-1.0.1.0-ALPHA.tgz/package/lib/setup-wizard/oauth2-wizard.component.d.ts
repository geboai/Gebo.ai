import { AuthProvidersControllerService, Oauth2ClientAuthorizativeInfo, Oauth2ModuleStatusControllerService } from "@Gebo.ai/gebo-ai-rest-api";
import { AbstractStatusService, BaseWizardSectionComponent, GeboUIActionRoutingService, SetupWizardComunicationService } from "@Gebo.ai/reusable-ui";
import { Observable } from "rxjs";
import * as i0 from "@angular/core";
export declare class Oauth2SetupWizardService extends AbstractStatusService {
    private oauth2ProvidersService;
    constructor(oauth2ProvidersService: AuthProvidersControllerService);
    getBooleanStatus(): Observable<boolean>;
    static ɵfac: i0.ɵɵFactoryDeclaration<Oauth2SetupWizardService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<Oauth2SetupWizardService>;
}
export declare class Oauth2SetupEnabledService extends AbstractStatusService {
    private geboOauth2ClientService;
    constructor(geboOauth2ClientService: Oauth2ModuleStatusControllerService);
    getBooleanStatus(): Observable<boolean>;
    static ɵfac: i0.ɵɵFactoryDeclaration<Oauth2SetupEnabledService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<Oauth2SetupEnabledService>;
}
export declare class Oauth2WizardComponent extends BaseWizardSectionComponent {
    private oauth2ProvidersService;
    private geboUIActionRoutingService;
    providers: Oauth2ClientAuthorizativeInfo[];
    constructor(setupWizardComunicationService: SetupWizardComunicationService, oauth2ProvidersService: AuthProvidersControllerService, geboUIActionRoutingService: GeboUIActionRoutingService);
    reloadData(): void;
    newOauth2(): void;
    editOauth2(info: Oauth2ClientAuthorizativeInfo): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<Oauth2WizardComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<Oauth2WizardComponent, "oauth2-wizard-component", never, {}, {}, never, never, false, never>;
}
//# sourceMappingURL=oauth2-wizard.component.d.ts.map