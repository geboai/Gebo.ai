import * as i0 from "@angular/core";
import * as i1 from "./llms-setup-wizard.component";
import * as i2 from "./setup-wizards.component";
import * as i3 from "./vectorstore-wizard.component";
import * as i4 from "./work-folder-wizard.component";
import * as i5 from "./shared-filesystem-wizard.component";
import * as i6 from "./knowledge-base-wizard.component";
import * as i7 from "./chat-profile-wizard.component";
import * as i8 from "./users-wizard.component";
import * as i9 from "./confluence-wizard.component";
import * as i10 from "./sharepoint-wizard.component";
import * as i11 from "./google-workspace-wizard.component";
import * as i12 from "./jira-wizard.component";
import * as i13 from "./oauth2-wizard.component";
import * as i14 from "./graphrag-wizard.component";
import * as i15 from "./llms-setup-components/llms-vendor-configuration.component";
import * as i16 from "./llms-setup-components/llms-vendor-modeltype.component";
import * as i17 from "./google-search-wizard.component";
import * as i18 from "./deep-search-wizard.component";
import * as i19 from "./rag-autotune-wizard.component";
import * as i20 from "./llms-setup-components/easy-vendor-configuration.component";
import * as i21 from "@angular/common";
import * as i22 from "@angular/forms";
import * as i23 from "@Gebo.ai/reusable-ui";
import * as i24 from "primeng/dialog";
import * as i25 from "primeng/radiobutton";
import * as i26 from "primeng/fieldset";
import * as i27 from "primeng/panel";
import * as i28 from "primeng/blockui";
import * as i29 from "primeng/togglebutton";
import * as i30 from "primeng/button";
import * as i31 from "primeng/inputtext";
import * as i32 from "primeng/table";
import * as i33 from "primeng/checkbox";
import * as i34 from "../admin-ui/gebo-ai-admin.module";
import * as i35 from "primeng/paginator";
import * as i36 from "primeng/textarea";
import * as i37 from "primeng/accordion";
import * as i38 from "primeng/selectbutton";
import * as i39 from "primeng/tabview";
/**
 * @NgModule for Gebo.ai setup wizards
 * This module bundles all the setup wizard components, services, and dependencies.
 * It provides a structured approach to setting up the Gebo.ai application through
 * multiple sequential wizard sections that guide users through the configuration process.
 * Each wizard section is registered with the WIZARD_SECTION injection token.
 */
export declare class GeboSetupWizardsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<GeboSetupWizardsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<GeboSetupWizardsModule, [typeof i1.LLMSetupWizardComponent, typeof i2.SetupWizardsComponent, typeof i3.VectorStoreWizardComponent, typeof i4.WorkFolderWizardComponent, typeof i5.SharedFilesystemWizardComponent, typeof i6.KnowledgeBaseWizardComponent, typeof i7.ChatProfileWizardComponent, typeof i8.UsersWizardComponent, typeof i9.ConfluenceWizardComponent, typeof i10.SharepointWizardComponent, typeof i11.GoogleWorkspacesWizardComponent, typeof i12.JiraWizardComponent, typeof i13.Oauth2WizardComponent, typeof i14.GraphRagWizardComponent, typeof i15.GeboAILLMSVendorConfiguration, typeof i16.GeboAILlmsVendorModelTypeConfig, typeof i17.GeboAIGoogleSearchWizardComponent, typeof i18.GeboAIDeepSearchWizardComponent, typeof i19.GeboAIRagAutotuneWizardComponent, typeof i20.GeboAIEasyVendorConfigurationComponent], [typeof i21.CommonModule, typeof i22.ReactiveFormsModule, typeof i22.FormsModule, typeof i23.SetupWizardPanelModule, typeof i24.DialogModule, typeof i23.EditableListboxModule, typeof i25.RadioButtonModule, typeof i26.FieldsetModule, typeof i27.PanelModule, typeof i28.BlockUIModule, typeof i29.ToggleButtonModule, typeof i30.ButtonModule, typeof i31.InputTextModule, typeof i23.GeboAINotificationsModule, typeof i32.TableModule, typeof i33.CheckboxModule, typeof i23.VFilesystemSelectorModule, typeof i23.ProjectAddContextMenuModule, typeof i34.GeboAiAdminModule, typeof i35.PaginatorModule, typeof i36.TextareaModule, typeof i23.GeboAIFieldTranslationContainerModule, typeof i37.AccordionModule, typeof i23.TranslableModule, typeof i38.SelectButtonModule, typeof i39.TabViewModule, typeof i23.GeboAIApiKeyModule, typeof i23.GeboAINotificationsModule], [typeof i2.SetupWizardsComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<GeboSetupWizardsModule>;
}
