import * as i0 from "@angular/core";
import * as i1 from "./llms-setup-wizard.component";
import * as i2 from "./setup-wizards.component";
import * as i3 from "./vectorstore-wizard.component";
import * as i4 from "./work-folder-wizard.component";
import * as i5 from "./shared-filesystem-wizard.component";
import * as i6 from "./knowledge-base-wizard.component";
import * as i7 from "./chat-profile-wizard.component";
import * as i8 from "./users-wizard.component";
import * as i9 from "./confluence-wizard.component";
import * as i10 from "./sharepoint-wizard.component";
import * as i11 from "./google-workspace-wizard.component";
import * as i12 from "./jira-wizard.component";
import * as i13 from "./oauth2-wizard.component";
import * as i14 from "./graphrag-wizard.component";
import * as i15 from "./llms-setup-components/llms-vendor-configuration.component";
import * as i16 from "./llms-setup-components/llms-vendor-modeltype.component";
import * as i17 from "./google-search-wizard.component";
import * as i18 from "./deep-search-wizard.component";
import * as i19 from "./rag-autotune-wizard.component";
import * as i20 from "./llms-setup-components/easy-vendor-configuration.component";
import * as i21 from "./agent-setup-wizard.component";
import * as i22 from "@angular/common";
import * as i23 from "@angular/forms";
import * as i24 from "@Gebo.ai/reusable-ui";
import * as i25 from "primeng/dialog";
import * as i26 from "primeng/radiobutton";
import * as i27 from "primeng/fieldset";
import * as i28 from "primeng/panel";
import * as i29 from "primeng/blockui";
import * as i30 from "primeng/togglebutton";
import * as i31 from "primeng/button";
import * as i32 from "primeng/inputtext";
import * as i33 from "primeng/table";
import * as i34 from "primeng/checkbox";
import * as i35 from "../admin-ui/gebo-ai-admin.module";
import * as i36 from "primeng/paginator";
import * as i37 from "primeng/textarea";
import * as i38 from "primeng/accordion";
import * as i39 from "primeng/selectbutton";
import * as i40 from "primeng/tabview";
/**
 * @NgModule for Gebo.ai setup wizards
 * This module bundles all the setup wizard components, services, and dependencies.
 * It provides a structured approach to setting up the Gebo.ai application through
 * multiple sequential wizard sections that guide users through the configuration process.
 * Each wizard section is registered with the WIZARD_SECTION injection token.
 */
export declare class GeboSetupWizardsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<GeboSetupWizardsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<GeboSetupWizardsModule, [typeof i1.LLMSetupWizardComponent, typeof i2.SetupWizardsComponent, typeof i3.VectorStoreWizardComponent, typeof i4.WorkFolderWizardComponent, typeof i5.SharedFilesystemWizardComponent, typeof i6.KnowledgeBaseWizardComponent, typeof i7.ChatProfileWizardComponent, typeof i8.UsersWizardComponent, typeof i9.ConfluenceWizardComponent, typeof i10.SharepointWizardComponent, typeof i11.GoogleWorkspacesWizardComponent, typeof i12.JiraWizardComponent, typeof i13.Oauth2WizardComponent, typeof i14.GraphRagWizardComponent, typeof i15.GeboAILLMSVendorConfiguration, typeof i16.GeboAILlmsVendorModelTypeConfig, typeof i17.GeboAIGoogleSearchWizardComponent, typeof i18.GeboAIDeepSearchWizardComponent, typeof i19.GeboAIRagAutotuneWizardComponent, typeof i20.GeboAIEasyVendorConfigurationComponent, typeof i21.GeboAIAgentSetupWizardComponent], [typeof i22.CommonModule, typeof i23.ReactiveFormsModule, typeof i23.FormsModule, typeof i24.SetupWizardPanelModule, typeof i25.DialogModule, typeof i24.EditableListboxModule, typeof i26.RadioButtonModule, typeof i27.FieldsetModule, typeof i28.PanelModule, typeof i29.BlockUIModule, typeof i30.ToggleButtonModule, typeof i31.ButtonModule, typeof i32.InputTextModule, typeof i24.GeboAINotificationsModule, typeof i33.TableModule, typeof i34.CheckboxModule, typeof i24.VFilesystemSelectorModule, typeof i24.ProjectAddContextMenuModule, typeof i35.GeboAiAdminModule, typeof i36.PaginatorModule, typeof i37.TextareaModule, typeof i24.GeboAIFieldTranslationContainerModule, typeof i38.AccordionModule, typeof i24.TranslableModule, typeof i39.SelectButtonModule, typeof i40.TabViewModule, typeof i24.GeboAIApiKeyModule, typeof i24.GeboAINotificationsModule], [typeof i2.SetupWizardsComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<GeboSetupWizardsModule>;
}
