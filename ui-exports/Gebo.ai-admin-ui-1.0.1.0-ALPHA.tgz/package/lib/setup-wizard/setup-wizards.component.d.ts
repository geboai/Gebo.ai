/**
 * This Source Code is subject to the terms of the
 * Gebo.ai community version Mozilla Public License Version 2.0 (MPL-2.0) — With Data Protection Clauses
 * If a copy of the LICENCE was not distributed with this file, You can obtain one at
 * https://gebo.ai/gebo-ai-community-version-mozilla-public-license-version-2-0-mpl-2-0-with-data-protection-clauses/
 * and https://mozilla.org/MPL/2.0/.
 * Copyright (c) 2025+ Gebo.ai
 */
/**
 * AI generated comments
 *
 * This component manages the setup wizard functionality in the Gebo.ai application.
 * It handles displaying setup steps, tracking setup status, and managing the wizard's
 * visibility and completion state.
 */
import { EventEmitter, OnInit } from "@angular/core";
import { SetupStatus } from "@Gebo.ai/reusable-ui";
import { ConfirmationService } from "primeng/api";
import { ActivatedRoute } from "@angular/router";
import * as i0 from "@angular/core";
export declare class SetupWizardsComponent implements OnInit {
    private confirmService;
    private activatedRoute;
    /** Controls the visibility of the setup wizard */
    visible: boolean;
    /** Tracks the current setup status (complete, incomplete) */
    private actualSetupStatus?;
    /** Current step ID from the route parameters */
    stepId?: string;
    /** Event emitted when the setup wizard is closed */
    closeSetup: EventEmitter<boolean>;
    /** Event emitted when the setup status changes */
    setupStatusRefresh: EventEmitter<SetupStatus>;
    /**
     * Initializes the component with required services
     * @param confirmService Service to handle confirmation dialogs
     * @param activatedRoute Service to access the current route parameters
     */
    constructor(confirmService: ConfirmationService, activatedRoute: ActivatedRoute);
    /**
     * Lifecycle hook that initializes the component
     * Subscribes to route parameters to get the current step ID
     */
    ngOnInit(): void;
    /**
     * Handles the setup status refresh event
     * Updates the current status and emits the updated status to parent components
     * @param data The updated setup status
     */
    setupStatusRefreshed(data: SetupStatus): void;
    /**
     * Handles the close event for the setup wizard
     * If setup is incomplete, displays a confirmation dialog
     * Otherwise, immediately closes the wizard
     * @param data Event data from the close event
     */
    onClose(data: any): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<SetupWizardsComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SetupWizardsComponent, "gebo-setup-wizards", never, { "visible": { "alias": "visible"; "required": false; }; }, { "closeSetup": "closeSetup"; "setupStatusRefresh": "setupStatusRefresh"; }, never, never, false, never>;
}
//# sourceMappingURL=setup-wizards.component.d.ts.map