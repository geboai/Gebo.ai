import { ConfluenceSystemsControllerService, GConfluenceSystem, GeboModulesConfigControllerService } from "@Gebo.ai/gebo-ai-rest-api";
import { AbstractStatusService, BaseWizardSectionComponent, GeboUIActionRoutingService, SetupWizardComunicationService } from "@Gebo.ai/reusable-ui";
import { Observable } from "rxjs";
import { GeboRootInstalledModuleService } from "./abstract-module-installed.service";
import * as i0 from "@angular/core";
/**
 * Service responsible for checking the status of Confluence systems.
 * Extends AbstractStatusService to implement status checking functionality.
 */
export declare class ConfuenceStatusService extends AbstractStatusService {
    private confluenceControllerService;
    constructor(confluenceControllerService: ConfluenceSystemsControllerService);
    /**
     * Returns an Observable of boolean indicating whether any Confluence systems are configured.
     * Returns true if at least one Confluence system exists, false otherwise.
     * @returns Observable<boolean> - Status of Confluence systems
     */
    getBooleanStatus(): Observable<boolean>;
    static ɵfac: i0.ɵɵFactoryDeclaration<ConfuenceStatusService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ConfuenceStatusService>;
}
/**
 * Service that manages the installation status of the Confluence module.
 * Extends GeboRootInstalledModuleService with Confluence-specific module code.
 */
export declare class ConfluenceInstalledModuleService extends GeboRootInstalledModuleService {
    protected moduleCode: string;
    constructor(geboModulesConfigService: GeboModulesConfigControllerService);
    static ɵfac: i0.ɵɵFactoryDeclaration<ConfluenceInstalledModuleService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ConfluenceInstalledModuleService>;
}
/**
 * Component that provides a wizard interface for configuring Confluence systems.
 * Allows viewing existing Confluence systems, creating new ones, and editing existing ones.
 */
export declare class ConfluenceWizardComponent extends BaseWizardSectionComponent {
    private confluenceControllerService;
    private geboUIActionsRouter;
    createConfluenceWindowOpen: boolean;
    systems: GConfluenceSystem[];
    constructor(setupWizardComunicationService: SetupWizardComunicationService, confluenceControllerService: ConfluenceSystemsControllerService, geboUIActionsRouter: GeboUIActionRoutingService);
    /**
     * Reloads Confluence systems data from the server.
     * Sets loading state during data fetch and updates completion status based on results.
     */
    reloadData(): void;
    /**
     * Opens the edit dialog for a Confluence system.
     * Uses the GeboUIActionRouter to handle the editing action.
     * @param value - The Confluence system to edit
     */
    editConfluenceSystem(value: GConfluenceSystem): void;
    /**
     * Opens the dialog for creating a new Confluence system.
     * Sets the createConfluenceWindowOpen flag to true to trigger dialog display.
     */
    createConfluenceSystem(): void;
    /**
     * Closes the Confluence system creation dialog and reloads the data.
     */
    closeDialog(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ConfluenceWizardComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ConfluenceWizardComponent, "gebo-confluence-wizard-component", never, {}, {}, never, never, false, never>;
}
