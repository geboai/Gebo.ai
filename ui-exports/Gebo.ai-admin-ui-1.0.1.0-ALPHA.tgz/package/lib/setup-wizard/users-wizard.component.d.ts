import { UserInfos, UsersAdminControllerService } from "@Gebo.ai/gebo-ai-rest-api";
import { BaseWizardSectionComponent, GeboUIActionRoutingService, SetupWizardComunicationService } from "@Gebo.ai/reusable-ui";
import * as i0 from "@angular/core";
/**
 * Component responsible for managing users within the setup wizard.
 * This component displays a list of users and provides options to create new users
 * or edit existing ones. It communicates with the backend via the UsersAdminControllerService
 * and handles UI actions through the GeboUIActionRoutingService.
 */
export declare class UsersWizardComponent extends BaseWizardSectionComponent {
    private usersController;
    private geboUIActionRoutingService;
    /**
     * Array to store the user information retrieved from the backend.
     */
    users: UserInfos[];
    /**
     * Initializes the component with required services.
     * @param setupWizardComunicationService Service for communication within the setup wizard
     * @param usersController Service for making API calls to manage users
     * @param geboUIActionRoutingService Service for routing UI actions
     */
    constructor(setupWizardComunicationService: SetupWizardComunicationService, usersController: UsersAdminControllerService, geboUIActionRoutingService: GeboUIActionRoutingService);
    /**
     * Overrides the parent method to load user data from the backend.
     * Sets loading state to true while fetching data and updates the users array
     * when data is received.
     */
    reloadData(): void;
    /**
     * Triggers the edit functionality for an existing user.
     * @param ui The user information object to be edited
     */
    editUser(ui: UserInfos): void;
    /**
     * Initiates the creation of a new user by opening the user edit window
     * with an empty user object.
     */
    createUser(): void;
    /**
     * Opens the user editing window with the provided user data.
     * Creates a GeboUIActionRequest to either open an existing user or
     * create a new one, then routes this action through the GeboUIActionRoutingService.
     * Reloads the user data when the action is completed.
     *
     * @param data The user data to be edited, or an empty object for a new user
     */
    private openUserWindow;
    static ɵfac: i0.ɵɵFactoryDeclaration<UsersWizardComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<UsersWizardComponent, "gebo-ai-users-wizard-component", never, {}, {}, never, never, false, never>;
}
