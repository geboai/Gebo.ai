import { GeboModulesConfigControllerService, GGoogleDriveSystem, GoogleDriveSystemsControllerService } from "@Gebo.ai/gebo-ai-rest-api";
import { AbstractStatusService, BaseWizardSectionComponent, GeboUIActionRoutingService, SetupWizardComunicationService } from "@Gebo.ai/reusable-ui";
import { Observable } from "rxjs";
import { GeboRootInstalledModuleService } from "./abstract-module-installed.service";
import * as i0 from "@angular/core";
/**
 * Service that provides status information about Google Workspace connections.
 * Extends AbstractStatusService to integrate with the Gebo status monitoring system.
 * Determines if there are any configured Google Drive systems available.
 */
export declare class GoogleWorkspacesStatusService extends AbstractStatusService {
    private googleDriveControllerService;
    constructor(googleDriveControllerService: GoogleDriveSystemsControllerService);
    /**
     * Returns an Observable boolean indicating whether any Google Drive systems are configured.
     * Returns true if at least one Google Drive system exists, false otherwise.
     * @returns Observable<boolean> - True if at least one Google Drive system exists
     */
    getBooleanStatus(): Observable<boolean>;
    static ɵfac: i0.ɵɵFactoryDeclaration<GoogleWorkspacesStatusService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<GoogleWorkspacesStatusService>;
}
/**
 * Service to handle the installation status of the Google Workspaces module.
 * Extends the GeboRootInstalledModuleService to provide specific functionality for the Google Drive module.
 * Used to check if the Google Drive module is installed and configured in the system.
 */
export declare class GoogleWorkspacesInstalledModuleService extends GeboRootInstalledModuleService {
    protected moduleCode: string;
    constructor(geboModulesConfigService: GeboModulesConfigControllerService);
    static ɵfac: i0.ɵɵFactoryDeclaration<GoogleWorkspacesInstalledModuleService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<GoogleWorkspacesInstalledModuleService>;
}
/**
 * Component that provides a wizard interface for setting up Google Workspace integration.
 * This component allows users to view, create, and edit Google Drive system configurations.
 * It extends BaseWizardSectionComponent to integrate with the overall setup wizard flow.
 */
export declare class GoogleWorkspacesWizardComponent extends BaseWizardSectionComponent {
    private googleDriveControllerService;
    private geboUIActionsRouter;
    createGoogleDriveWorkspacesWindowOpen: boolean;
    systems: GGoogleDriveSystem[];
    constructor(setupWizardComunicationService: SetupWizardComunicationService, googleDriveControllerService: GoogleDriveSystemsControllerService, geboUIActionsRouter: GeboUIActionRoutingService);
    /**
     * Reloads the Google Drive systems data from the backend.
     * Updates the systems array and determines if setup is completed based on if any systems exist.
     * Sets loading state appropriately during the data fetch operation.
     */
    reloadData(): void;
    /**
     * Opens the edit interface for an existing Google Drive system.
     * Routes a UI action request to open the system for editing.
     * @param value - The GGoogleDriveSystem to edit
     */
    editSystem(value: GGoogleDriveSystem): void;
    /**
     * Opens the dialog for creating a new Google Drive system.
     * Sets the createGoogleDriveWorkspacesWindowOpen flag to true to display the creation dialog.
     */
    createSystem(): void;
    /**
     * Closes the Google Drive system creation dialog.
     * Reloads the data to refresh the systems list after the dialog is closed.
     */
    closeDialog(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<GoogleWorkspacesWizardComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<GoogleWorkspacesWizardComponent, "gebo-google-workspace-wizard-component", never, {}, {}, never, never, false, never>;
}
//# sourceMappingURL=google-workspace-wizard.component.d.ts.map