import { GeboContentProcessRow, GeboFastKnowledgeBaseSetupControllerService, GeboKnowledgeBaseSetupStatus, JobLauncherControllerService } from "@Gebo.ai/gebo-ai-rest-api";
import { AbstractStatusService, BaseWizardSectionComponent, GeboUIActionRoutingService, SetupWizardComunicationService } from "@Gebo.ai/reusable-ui";
import { ConfirmationService } from "primeng/api";
import { Observable } from "rxjs";
import * as i0 from "@angular/core";
/**
 * Service responsible for providing the setup status of a knowledge base.
 * Extends AbstractStatusService to integrate with the application's status tracking system.
 */
export declare class KnowledgeBasePresentService extends AbstractStatusService {
    private knowledgeBaseService;
    /**
     * Creates an instance of KnowledgeBasePresentService.
     * @param knowledgeBaseService - Service for retrieving knowledge base setup information
     */
    constructor(knowledgeBaseService: GeboFastKnowledgeBaseSetupControllerService);
    /**
     * Retrieves the setup status of the knowledge base as a boolean.
     * Overrides the abstract method from the parent class.
     * @returns An Observable that emits true if the knowledge base is set up, false otherwise
     */
    getBooleanStatus(): Observable<boolean>;
    static ɵfac: i0.ɵɵFactoryDeclaration<KnowledgeBasePresentService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<KnowledgeBasePresentService>;
}
/**
 * Component that provides a wizard interface for setting up and managing knowledge bases.
 * Extends BaseWizardSectionComponent to integrate with the application's wizard system.
 */
export declare class KnowledgeBaseWizardComponent extends BaseWizardSectionComponent {
    private knowledgeBaseService;
    private JobLauncherControllerService;
    private confirmationService;
    private actionsRoutingService;
    /**
     * Collection of content process rows to be displayed in the wizard
     */
    rows: GeboContentProcessRow[];
    /**
     * Current status of the knowledge base setup process
     */
    status?: GeboKnowledgeBaseSetupStatus;
    /**
     * Creates an instance of KnowledgeBaseWizardComponent.
     * @param setupWizardComunicationService - Service for communicating with the wizard framework
     * @param knowledgeBaseService - Service for retrieving and managing knowledge base information
     * @param JobLauncherControllerService - Service for launching background jobs
     * @param confirmationService - Service for displaying confirmation dialogs
     * @param actionsRoutingService - Service for routing UI actions
     */
    constructor(setupWizardComunicationService: SetupWizardComunicationService, knowledgeBaseService: GeboFastKnowledgeBaseSetupControllerService, JobLauncherControllerService: JobLauncherControllerService, confirmationService: ConfirmationService, actionsRoutingService: GeboUIActionRoutingService);
    /**
     * Reloads the component data by fetching the latest content process rows and setup status.
     * Overrides the abstract method from the parent class.
     */
    reloadData(): void;
    /**
     * Initiates the creation of a new knowledge base through the UI action routing system.
     * Sets up a knowledge base with default accessibility to all.
     */
    newKnowledgeBase(): void;
    /**
     * Opens an existing knowledge base for editing.
     * @param row - The content process row containing the knowledge base to edit
     */
    editKnowledgeBase(row: GeboContentProcessRow): void;
    /**
     * Opens an existing project for editing.
     * @param row - The content process row containing the project to edit
     */
    editProject(row: GeboContentProcessRow): void;
    /**
     * Initiates the creation of a new project associated with a knowledge base.
     * @param row - The content process row containing the knowledge base to associate with the new project
     */
    newProject(row: GeboContentProcessRow): void;
    /**
     * Initiates the creation of a new data source for a project.
     * @param row - The content process row containing the project to associate with the new data source
     */
    newDataSource(row: GeboContentProcessRow): void;
    /**
     * Opens an existing data source for editing.
     * @param row - The content process row containing the data source to edit
     */
    editDataSource(row: GeboContentProcessRow): void;
    /**
     * Extracts the entity name from a fully qualified class name.
     * @param className - The fully qualified class name
     * @returns The simple entity name (last part of the class name)
     * @throws Error if the class name is undefined
     */
    entityName(className: string | undefined): string;
    /**
     * Publishes a data source to the knowledge base after user confirmation.
     * Creates a job to process the data source and monitors its status.
     * @param row - The content process row containing the data source to publish
     */
    publish(row: GeboContentProcessRow): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<KnowledgeBaseWizardComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<KnowledgeBaseWizardComponent, "gebo-knowledge-base-wizard-component", never, {}, {}, never, never, false, never>;
}
//# sourceMappingURL=knowledge-base-wizard.component.d.ts.map