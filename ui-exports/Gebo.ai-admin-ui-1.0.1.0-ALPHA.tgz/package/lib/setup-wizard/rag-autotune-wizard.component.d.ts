import { OnChanges, OnInit } from "@angular/core";
import { AutotuneVectorStoreInfo, GeboAdminRagAutotuneControllerService } from "@Gebo.ai/gebo-ai-rest-api";
import { AbstractStatusService, BaseWizardSectionComponent, SetupWizardComunicationService } from "@Gebo.ai/reusable-ui";
import { Observable } from "rxjs";
import * as i0 from "@angular/core";
export declare class RagAutotuneStatusService extends AbstractStatusService {
    private ragAutoTuneService;
    constructor(ragAutoTuneService: GeboAdminRagAutotuneControllerService);
    getBooleanStatus(): Observable<boolean>;
    static ɵfac: i0.ɵɵFactoryDeclaration<RagAutotuneStatusService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<RagAutotuneStatusService>;
}
export declare class GeboAIRagAutotuneWizardComponent extends BaseWizardSectionComponent implements OnInit, OnChanges {
    private ragAutoTuneService;
    protected autotunedVectorStores: AutotuneVectorStoreInfo[];
    constructor(setupWizardComunicationService: SetupWizardComunicationService, ragAutoTuneService: GeboAdminRagAutotuneControllerService);
    reloadData(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<GeboAIRagAutotuneWizardComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<GeboAIRagAutotuneWizardComponent, "gebo-ai-rag-autotune-component", never, {}, {}, never, never, false, never>;
}
