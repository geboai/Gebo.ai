import { DeepSearchConfig, GeboDeepSearchAdminControllerService } from "@Gebo.ai/gebo-ai-rest-api";
import { BaseWizardSectionComponent, GeboUIActionRoutingService, SetupWizardComunicationService } from "@Gebo.ai/reusable-ui";
import * as i0 from "@angular/core";
export declare class GeboAIDeepSearchWizardComponent extends BaseWizardSectionComponent {
    private deepSearchAdminService;
    private actionRouter;
    protected deepSearchConfig: DeepSearchConfig[];
    constructor(setupWizardComunicationService: SetupWizardComunicationService, deepSearchAdminService: GeboDeepSearchAdminControllerService, actionRouter: GeboUIActionRoutingService);
    reloadData(): void;
    protected editDeepSearchConfig(data: DeepSearchConfig): void;
    protected createDeepSearchConfig(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<GeboAIDeepSearchWizardComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<GeboAIDeepSearchWizardComponent, "gebo-ai-deep-search-wizard-component", never, {}, {}, never, never, false, never>;
}
//# sourceMappingURL=deep-search-wizard.component.d.ts.map