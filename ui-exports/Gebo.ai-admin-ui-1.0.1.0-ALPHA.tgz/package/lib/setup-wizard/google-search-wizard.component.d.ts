import { FormGroup } from "@angular/forms";
import { GGoogleSearchApiCredentials, GoogleSearchConfig, GoogleSearchConfigurationControllerService } from "@Gebo.ai/gebo-ai-rest-api";
import { AbstractStatusService, BaseWizardSectionComponent, SetupWizardComunicationService } from "@Gebo.ai/reusable-ui";
import { Observable } from "rxjs";
import * as i0 from "@angular/core";
export declare class GoogleSearcStatusService extends AbstractStatusService {
    private geboGoogleSearchService;
    constructor(geboGoogleSearchService: GoogleSearchConfigurationControllerService);
    /**
     * Returns an Observable of boolean indicating whether any Confluence systems are configured.
     * Returns true if at least one Confluence system exists, false otherwise.
     * @returns Observable<boolean> - Status of Confluence systems
     */
    getBooleanStatus(): Observable<boolean>;
    static ɵfac: i0.ɵɵFactoryDeclaration<GoogleSearcStatusService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<GoogleSearcStatusService>;
}
export declare class GeboAIGoogleSearchWizardComponent extends BaseWizardSectionComponent {
    private geboGoogleSearchService;
    protected googleSearchConfig?: GoogleSearchConfig;
    protected googleSearchCredentials: GGoogleSearchApiCredentials[];
    protected formGroup: FormGroup;
    constructor(setupWizardComunicationService: SetupWizardComunicationService, geboGoogleSearchService: GoogleSearchConfigurationControllerService);
    reloadData(): void;
    protected createGoogleSearchCredentials(): void;
    protected saveGoogleSearchCredentials(): void;
    protected deleteCredentials(credenntials: GGoogleSearchApiCredentials): void;
    protected doCancel(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<GeboAIGoogleSearchWizardComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<GeboAIGoogleSearchWizardComponent, "gebo-ai-google-search-wizard-component", never, {}, {}, never, never, false, never>;
}
