import { GBaseObject, GeboAgentAdminControllerService } from "@Gebo.ai/gebo-ai-rest-api";
import { BaseWizardSectionComponent, GeboUIActionRoutingService, SetupWizardComunicationService } from "@Gebo.ai/reusable-ui";
import * as i0 from "@angular/core";
export declare class GeboAIAgentSetupWizardComponent extends BaseWizardSectionComponent {
    private geboAgentsService;
    private geboUIRoutingService;
    protected agentsConfig: GBaseObject[];
    constructor(setupWizardComunicationService: SetupWizardComunicationService, geboAgentsService: GeboAgentAdminControllerService, geboUIRoutingService: GeboUIActionRoutingService);
    reloadData(): void;
    protected addAgent(): void;
    protected openAgent(agentConfig: GBaseObject): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<GeboAIAgentSetupWizardComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<GeboAIAgentSetupWizardComponent, "gebo-ai-agent-setup-wizard-component", never, {}, {}, never, never, false, never>;
}
