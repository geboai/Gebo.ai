import { GBaseObject, GeboAgentAdminControllerService } from "@Gebo.ai/gebo-ai-rest-api";
import { AbstractStatusService, BaseWizardSectionComponent, GeboUIActionRoutingService, SetupWizardComunicationService } from "@Gebo.ai/reusable-ui";
import { Observable } from "rxjs";
import * as i0 from "@angular/core";
export declare class AgentStatusService extends AbstractStatusService {
    private geboAgentsService;
    constructor(geboAgentsService: GeboAgentAdminControllerService);
    /**
     * Overrides the base method to fetch the chat profile setup status
     * from the backend service and convert it to a boolean value.
     *
     * @returns An Observable<boolean> indicating whether chat profiles are set up
     */
    getBooleanStatus(): Observable<boolean>;
    static ɵfac: i0.ɵɵFactoryDeclaration<AgentStatusService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<AgentStatusService>;
}
export declare class GeboAIAgentSetupWizardComponent extends BaseWizardSectionComponent {
    private geboAgentsService;
    private geboUIRoutingService;
    protected agentsConfig: GBaseObject[];
    constructor(setupWizardComunicationService: SetupWizardComunicationService, geboAgentsService: GeboAgentAdminControllerService, geboUIRoutingService: GeboUIActionRoutingService);
    reloadData(): void;
    protected addAgent(): void;
    protected openAgent(agentConfig: GBaseObject): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<GeboAIAgentSetupWizardComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<GeboAIAgentSetupWizardComponent, "gebo-ai-agent-setup-wizard-component", never, {}, {}, never, never, false, never>;
}
