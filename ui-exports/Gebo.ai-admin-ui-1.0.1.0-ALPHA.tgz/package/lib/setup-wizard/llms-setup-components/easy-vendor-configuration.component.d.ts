import { EventEmitter, OnChanges, OnInit, SimpleChanges } from "@angular/core";
import { FormGroup } from "@angular/forms";
import { GeboFastLlmsSetupControllerService, GUserMessage, LLMModelPresetChoice, LLMSModelsPresets, LLMSSetupConfiguration, LLMSSetupConfigurationData, LLMSVendorInfo, SecretInfo } from "@Gebo.ai/gebo-ai-rest-api";
import { IOperationStatus } from "@Gebo.ai/reusable-ui";
import { Observable } from "rxjs";
import * as i0 from "@angular/core";
interface PresetSummary {
    type: LLMSModelsPresets.TypeEnum;
    mainUse?: LLMModelPresetChoice.UsesEnum;
    presetChoices?: LLMModelPresetChoice[];
    choice?: string;
}
export declare class GeboAIEasyVendorConfigurationComponent implements OnInit, OnChanges {
    private geboFastLLMSSetupService;
    autoSettingsConfigurations?: LLMSSetupConfiguration[];
    actualProvidersConfiguration?: LLMSSetupConfigurationData;
    llmsAutoSettingSuccessfull: EventEmitter<boolean>;
    llmsAutoSettingErrors: EventEmitter<GUserMessage[]>;
    protected choosableVendors: LLMSVendorInfo[];
    protected vendorSetupMetaInfos?: LLMSSetupConfiguration;
    protected presetsSummary: PresetSummary[];
    protected formGroup: FormGroup;
    protected loading: boolean;
    protected vendorId?: string;
    protected secretContext?: string;
    protected secretDescription?: string;
    protected validateCredentials: (credentials: SecretInfo) => Observable<IOperationStatus<any>>;
    constructor(geboFastLLMSSetupService: GeboFastLlmsSetupControllerService);
    ngOnInit(): void;
    ngOnChanges(changes: SimpleChanges): void;
    protected doAutoConfigure(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<GeboAIEasyVendorConfigurationComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<GeboAIEasyVendorConfigurationComponent, "gebo-ai-llms-easy-vendor-configuration-component", never, { "autoSettingsConfigurations": { "alias": "autoSettingsConfigurations"; "required": false; }; "actualProvidersConfiguration": { "alias": "actualProvidersConfiguration"; "required": false; }; }, { "llmsAutoSettingSuccessfull": "llmsAutoSettingSuccessfull"; "llmsAutoSettingErrors": "llmsAutoSettingErrors"; }, never, never, false, never>;
}
export {};
