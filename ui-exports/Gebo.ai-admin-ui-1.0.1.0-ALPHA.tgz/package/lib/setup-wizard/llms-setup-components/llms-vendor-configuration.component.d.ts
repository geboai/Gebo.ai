import { EventEmitter, OnChanges, OnInit, SimpleChanges } from "@angular/core";
import { GeboFastLlmsSetupControllerService, LLMExistingConfiguration, LLMSSetupConfiguration } from "@Gebo.ai/gebo-ai-rest-api";
import { GeboUIActionRoutingService } from "@Gebo.ai/reusable-ui";
import * as i0 from "@angular/core";
export declare class GeboAILLMSVendorConfiguration implements OnInit, OnChanges {
    private setupService;
    private geboUIRouterService;
    protected openModalCreateModel: boolean;
    vendorConfiguration?: LLMSSetupConfiguration;
    vendorConfigurationChanged: EventEmitter<boolean>;
    protected loading: boolean;
    constructor(setupService: GeboFastLlmsSetupControllerService, geboUIRouterService: GeboUIActionRoutingService);
    ngOnInit(): void;
    ngOnChanges(changes: SimpleChanges): void;
    openModal(): void;
    doModify(configuration: LLMExistingConfiguration): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<GeboAILLMSVendorConfiguration, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<GeboAILLMSVendorConfiguration, "gebo-ai-llms-vendor-configuration", never, { "vendorConfiguration": { "alias": "vendorConfiguration"; "required": false; }; }, { "vendorConfigurationChanged": "vendorConfigurationChanged"; }, never, never, false, never>;
}
//# sourceMappingURL=llms-vendor-configuration.component.d.ts.map