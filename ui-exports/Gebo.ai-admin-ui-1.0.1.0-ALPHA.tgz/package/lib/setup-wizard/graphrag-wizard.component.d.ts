import { GeboNeo4jModuleSetupControllerService, GraphRagConfigurationControllerService, GraphRagExtractionConfig } from "@Gebo.ai/gebo-ai-rest-api";
import { AbstractInstalledModuleService, AbstractStatusService, BaseWizardSectionComponent, GeboUIActionRoutingService, SetupWizardComunicationService } from "@Gebo.ai/reusable-ui";
import { Observable } from "rxjs";
import * as i0 from "@angular/core";
export declare class Neo4jModuleEnabledService extends AbstractInstalledModuleService {
    private geboNeo4jModuleService;
    getInstalledModule(): Observable<boolean>;
    constructor(geboNeo4jModuleService: GeboNeo4jModuleSetupControllerService);
    static ɵfac: i0.ɵɵFactoryDeclaration<Neo4jModuleEnabledService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<Neo4jModuleEnabledService>;
}
export declare class GraphRagStatusService extends AbstractStatusService {
    private geboNeo4jModuleService;
    private graphRagConfigService;
    constructor(geboNeo4jModuleService: GeboNeo4jModuleSetupControllerService, graphRagConfigService: GraphRagConfigurationControllerService);
    /**
     * Returns an Observable boolean indicating whether any default graph rag config exists.
     * @returns Observable<boolean> - True if at least one default graph rag configuration exists
     */
    getBooleanStatus(): Observable<boolean>;
    static ɵfac: i0.ɵɵFactoryDeclaration<GraphRagStatusService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<GraphRagStatusService>;
}
export declare class GraphRagWizardComponent extends BaseWizardSectionComponent {
    private graphRagConfigService;
    private actionRouter;
    protected defaultConfigurations: GraphRagExtractionConfig[];
    constructor(setupWizardComunicationService: SetupWizardComunicationService, graphRagConfigService: GraphRagConfigurationControllerService, actionRouter: GeboUIActionRoutingService);
    reloadData(): void;
    protected createConfig(): void;
    protected editConfig(data: GraphRagExtractionConfig): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<GraphRagWizardComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<GraphRagWizardComponent, "gebo-ai-graphrag-setup-component", never, {}, {}, never, never, false, never>;
}
