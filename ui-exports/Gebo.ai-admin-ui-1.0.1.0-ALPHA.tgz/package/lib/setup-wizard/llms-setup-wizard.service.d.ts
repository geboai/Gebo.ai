import { ComponentLLMSStatus, GeboFastLlmsSetupControllerService, LLMSSetupConfigurationData } from "@Gebo.ai/gebo-ai-rest-api";
import { AbstractStatusService } from "@Gebo.ai/reusable-ui";
import { Observable } from "rxjs";
import * as i0 from "@angular/core";
/**
 * AI generated comments
 *
 * Service that manages the setup and status of Large Language Models (LLMs) in the application.
 * This service extends AbstractStatusService to provide status information about LLM setup
 * and handles communication with the backend API to configure LLMs.
 */
export declare class LLMSetupWizardService extends AbstractStatusService {
    private statusService;
    /**
     * Initializes a new instance of the LLMSetupWizardService.
     * @param statusService The service used to interact with the LLMS setup API endpoints
     */
    constructor(statusService: GeboFastLlmsSetupControllerService);
    /**
     * Overrides the getBooleanStatus method from AbstractStatusService.
     * Gets a boolean observable indicating whether LLMS is set up successfully.
     * @returns An Observable<boolean> that resolves to true if LLMS is set up
     */
    getBooleanStatus(): Observable<boolean>;
    /**
     * Gets the detailed status of the LLMS setup.
     * @returns An Observable of ComponentLLMSStatus containing detailed information about the LLMS setup state
     */
    getLLMSSetupStatus(): Observable<ComponentLLMSStatus>;
    getActualLLMSConfiguration(): Observable<LLMSSetupConfigurationData>;
    static ɵfac: i0.ɵɵFactoryDeclaration<LLMSetupWizardService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<LLMSetupWizardService>;
}
