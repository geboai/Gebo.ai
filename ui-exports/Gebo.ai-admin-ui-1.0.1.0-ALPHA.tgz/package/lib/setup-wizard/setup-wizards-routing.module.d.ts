import * as i0 from "@angular/core";
import * as i1 from "@angular/common";
import * as i2 from "./setup-wizards.module";
import * as i3 from "@angular/router";
/**
 * NgModule that provides routing functionality for the GeboAi setup wizard feature.
 * This module imports CommonModule for common Angular directives,
 * GeboSetupWizardsModule for the wizard components, and configures
 * child routes using RouterModule.forChild.
 */
export declare class GeboAiSetupRoutingModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<GeboAiSetupRoutingModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<GeboAiSetupRoutingModule, never, [typeof i1.CommonModule, typeof i2.GeboSetupWizardsModule, typeof i3.RouterModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<GeboAiSetupRoutingModule>;
}
//# sourceMappingURL=setup-wizards-routing.module.d.ts.map