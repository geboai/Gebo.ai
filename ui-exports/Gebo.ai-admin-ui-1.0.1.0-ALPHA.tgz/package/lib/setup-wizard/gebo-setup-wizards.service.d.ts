import { SetupStatus, SetupWizardService } from "@Gebo.ai/reusable-ui";
import { Observable } from "rxjs";
import * as i0 from "@angular/core";
/**
 * Injectable service that wraps the SetupWizardService to provide
 * application-specific setup wizard functionality. This service acts as
 * a facade for the underlying SetupWizardService, providing a more
 * specific interface for Gebo.ai applications.
 */
export declare class GeboSetupWizardService {
    private service;
    /**
     * Creates an instance of GeboSetupWizardService.
     * @param service - The underlying SetupWizardService to be wrapped
     */
    constructor(service: SetupWizardService);
    /**
     * Retrieves the global setup status of the application.
     * This method delegates to the underlying SetupWizardService.
     * @returns An Observable that emits the current SetupStatus
     */
    getGlobalSetupStatus(): Observable<SetupStatus>;
    static ɵfac: i0.ɵɵFactoryDeclaration<GeboSetupWizardService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<GeboSetupWizardService>;
}
//# sourceMappingURL=gebo-setup-wizards.service.d.ts.map