import { FileSystemSharesSettingControllerService, GFileSystemShareReference } from "@Gebo.ai/gebo-ai-rest-api";
import { AbstractStatusService, BaseWizardSectionComponent, browsePathObservableCallback, loadRootsObservableCallback, SetupWizardComunicationService } from "@Gebo.ai/reusable-ui";
import { Observable } from "rxjs";
import { FormGroup } from "@angular/forms";
import { ConfirmationService } from "primeng/api";
import * as i0 from "@angular/core";
/**
 * Service that checks if shared filesystem is already configured.
 * Extends AbstractStatusService to provide status monitoring capabilities.
 * Determines if any shared filesystem configurations already exist.
 */
export declare class SharedFilesystemAlreadySetupService extends AbstractStatusService {
    private sharedFilesystemConfigService;
    constructor(sharedFilesystemConfigService: FileSystemSharesSettingControllerService);
    /**
     * Overrides the parent method to check if any shared filesystem references are configured.
     * Returns an Observable that emits true if at least one share is configured.
     * @returns Observable<boolean> indicating whether shared filesystem is already set up
     */
    getBooleanStatus(): Observable<boolean>;
    static ɵfac: i0.ɵɵFactoryDeclaration<SharedFilesystemAlreadySetupService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<SharedFilesystemAlreadySetupService>;
}
/**
 * Service that checks if the shared filesystem feature is enabled in the system.
 * Extends AbstractStatusService to provide status monitoring capabilities.
 */
export declare class SharedFilesystemEnabledService extends AbstractStatusService {
    private sharedFilesystemConfigService;
    constructor(sharedFilesystemConfigService: FileSystemSharesSettingControllerService);
    /**
     * Overrides the parent method to check if shared filesystem feature is enabled.
     * @returns Observable<boolean> indicating whether the feature is enabled
     */
    getBooleanStatus(): Observable<boolean>;
    static ɵfac: i0.ɵɵFactoryDeclaration<SharedFilesystemEnabledService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<SharedFilesystemEnabledService>;
}
/**
 * Interface extending GFileSystemShareReference to track if a file system share is in use.
 * Adds a notUsed flag to indicate if the share is not being used by any part of the system.
 */
interface ExtendedGFileSystemShareReference extends GFileSystemShareReference {
    notUsed?: boolean;
}
/**
 * Component for configuring shared filesystem in the setup wizard.
 * Provides UI for enabling/disabling shared filesystem functionality and managing filesystem shares.
 * Allows users to add, view, and delete filesystem references.
 */
export declare class SharedFilesystemWizardComponent extends BaseWizardSectionComponent {
    private sharedFilesystemConfigService;
    private confirmService;
    /** Flag indicating if the shared filesystem setting is enabled */
    settingEnabled: boolean;
    /** Collection of filesystem shares configured in the system */
    shares?: ExtendedGFileSystemShareReference[];
    /** Form for adding new filesystem shares */
    formGroup: FormGroup;
    /**
     * Callback to load root filesystem nodes
     * Used for browsing the filesystem hierarchy
     */
    loadRootsObservable: loadRootsObservableCallback;
    /**
     * Callback to browse filesystem paths
     * @param param Parameters for browsing a specific path
     */
    browsePathObservable: browsePathObservableCallback;
    constructor(setupWizardComunicationService: SetupWizardComunicationService, sharedFilesystemConfigService: FileSystemSharesSettingControllerService, confirmService: ConfirmationService);
    /**
     * Reloads the component data from the backend services.
     * Updates the settings status and fetches all configured filesystem shares.
     * Also checks which shares are in use and marks unused ones.
     */
    reloadData(): void;
    /**
     * Saves a new filesystem path reference to the configuration.
     * Takes the form values and sends them to the backend service.
     */
    saveNewPath(): void;
    /** Flag to control the visibility of the add folder dialog */
    addFolderOpened: boolean;
    /**
     * Opens the dialog for adding a new folder reference
     */
    openAddFolderDialog(): void;
    /**
     * Deletes a filesystem path reference from the configuration.
     * Shows a confirmation dialog before deletion.
     * @param share The filesystem share reference to delete
     */
    deletePath(share: ExtendedGFileSystemShareReference): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<SharedFilesystemWizardComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SharedFilesystemWizardComponent, "gebo-shared-filesystem-wizard-component", never, {}, {}, never, never, false, never>;
}
export {};
//# sourceMappingURL=shared-filesystem-wizard.component.d.ts.map