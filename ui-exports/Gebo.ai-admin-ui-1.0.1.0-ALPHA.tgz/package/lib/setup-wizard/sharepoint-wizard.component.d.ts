import { GeboModulesConfigControllerService, GSharepointContentManagementSystem, SharepointSystemsControllerService } from "@Gebo.ai/gebo-ai-rest-api";
import { AbstractStatusService, BaseWizardSectionComponent, GeboUIActionRoutingService, SetupWizardComunicationService } from "@Gebo.ai/reusable-ui";
import { Observable } from "rxjs";
import { GeboRootInstalledModuleService } from "./abstract-module-installed.service";
import * as i0 from "@angular/core";
/**
 * Service that checks the status of SharePoint integration.
 * Extends AbstractStatusService to provide status information about SharePoint systems.
 * The status is determined by checking if any SharePoint systems are registered.
 */
export declare class SharepointStatusService extends AbstractStatusService {
    private sharePointControllerService;
    constructor(sharePointControllerService: SharepointSystemsControllerService);
    /**
     * Retrieves the boolean status of SharePoint integration.
     * @returns An Observable that emits true if at least one SharePoint system is configured, false otherwise.
     */
    getBooleanStatus(): Observable<boolean>;
    static ɵfac: i0.ɵɵFactoryDeclaration<SharepointStatusService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<SharepointStatusService>;
}
/**
 * Service that manages the installation status of the SharePoint module.
 * Extends GeboRootInstalledModuleService to handle module-specific operations.
 */
export declare class SharepointInstalledModuleService extends GeboRootInstalledModuleService {
    /**
     * The unique identifier for the SharePoint module
     */
    protected moduleCode: string;
    constructor(geboModulesConfigService: GeboModulesConfigControllerService);
    static ɵfac: i0.ɵɵFactoryDeclaration<SharepointInstalledModuleService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<SharepointInstalledModuleService>;
}
/**
 * Component that provides a wizard interface for SharePoint configuration.
 * Extends BaseWizardSectionComponent to integrate with the setup wizard flow.
 * Allows users to view, create, and edit SharePoint system connections.
 */
export declare class SharepointWizardComponent extends BaseWizardSectionComponent {
    private sharepointControllerService;
    private geboUIActionsRouter;
    /**
     * Flag that controls the visibility of the SharePoint creation dialog
     */
    createSharepointWindowOpen: boolean;
    /**
     * List of configured SharePoint systems
     */
    systems: GSharepointContentManagementSystem[];
    constructor(setupWizardComunicationService: SetupWizardComunicationService, sharepointControllerService: SharepointSystemsControllerService, geboUIActionsRouter: GeboUIActionRoutingService);
    /**
     * Loads or refreshes SharePoint systems data from the backend.
     * Updates the systems array and determines if setup is completed.
     * Sets loading flags appropriately during the process.
     */
    reloadData(): void;
    /**
     * Opens the edit dialog for a specific SharePoint system.
     * Routes an action to the appropriate handler using the action routing service.
     * @param value The SharePoint system to edit
     */
    editSharepointSystem(value: GSharepointContentManagementSystem): void;
    /**
     * Opens the dialog for creating a new SharePoint system.
     * Sets the createSharepointWindowOpen flag to show the creation dialog.
     */
    createSharepointSystem(): void;
    /**
     * Closes the SharePoint creation dialog and reloads the data.
     * This ensures the list of systems is updated after potential changes.
     */
    closeDialog(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<SharepointWizardComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SharepointWizardComponent, "gebo-sharepoint-wizard-component", never, {}, {}, never, never, false, never>;
}
