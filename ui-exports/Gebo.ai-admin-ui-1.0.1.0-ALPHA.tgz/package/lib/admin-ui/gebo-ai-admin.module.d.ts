import { ModuleWithProviders } from "@angular/core";
import * as i0 from "@angular/core";
import * as i1 from "./gebo-ai-admin.component";
import * as i2 from "./main-panels/build-packaging-systems/build-packaging-systems.component";
import * as i3 from "./main-panels/chat-profiles/chat-profiles.component";
import * as i4 from "./main-panels/company-systems/systems.component";
import * as i5 from "./main-panels/knowledge-bases/knowledge-bases.component";
import * as i6 from "./main-panels/llms-systems/llms-systems.component";
import * as i7 from "./entity-editors/gebo-ai-git-admin/gebo-ai-git-system-admin.component";
import * as i8 from "./entity-editors/gebo-ai-git-admin/gebo-ai-git-endpoint-admin.component";
import * as i9 from "./entity-editors/gebo-ai-knowledgebase-admin/gebo-ai-knowledgebase-admin.component";
import * as i10 from "./entity-editors/gebo-ai-knowledgebase-admin/gebo-ai-knowledgebase-tree.component";
import * as i11 from "./entity-editors/gebo-ai-knowledgebase-admin/gebo-ai-project-admin.component";
import * as i12 from "./entity-editors/gebo-ai-secrets-admin/gebo-ai-secrets-admin-list.component";
import * as i13 from "./entity-editors/gebo-ai-secrets-admin/gebo-ai-secrets-admin-edit.component";
import * as i14 from "./entity-editors/controls/build-systems-chooser/build-systems-chooser.component";
import * as i15 from "./entity-editors/gebo-ai-job-status-viewer/gebo-ai-job-status-viewer.component";
import * as i16 from "./main-panels/logs-view/logs-view.component";
import * as i17 from "./entity-editors/gebo-ai-job-status-viewer/log-table.component";
import * as i18 from "./entity-editors/gebo-ai-filesystems-admin/gebo-ai-filesystem-endpoint.component";
import * as i19 from "./entity-editors/gebo-ai-models-admin/gebo-ai-openai-chatmodel-admin.component";
import * as i20 from "./entity-editors/gebo-ai-models-admin/gebo-ai-openai-embedmodel-admin.component";
import * as i21 from "./entity-editors/gebo-ai-models-admin/gebo-ai-test-chat.component";
import * as i22 from "./entity-editors/gebo-ai-models-admin/gebo-ai-ollama-chatmodel-admin.component";
import * as i23 from "./entity-editors/gebo-ai-models-admin/gebo-ai-ollama-embedmodel-admin.component";
import * as i24 from "./entity-editors/gebo-ai-chat-profile-admin/gebo-ai-chat-profile-admin.component";
import * as i25 from "./entity-editors/gebo-ai-prompt-admin/gebo-ai-prompt-admin.component";
import * as i26 from "./main-panels/users-management/users-management.component";
import * as i27 from "./entity-editors/gebo-ai-users-admin/gebo-ai-user.component";
import * as i28 from "./entity-editors/gebo-ai-users-admin/gebo-ai-group.component";
import * as i29 from "./entity-editors/controls/access-control-group/access-control-group.component";
import * as i30 from "./entity-editors/controls/prompt-wizard/prompt-wizard.component";
import * as i31 from "./entity-editors/controls/advanced-settings-chatmodel-group/advanced-settings-chatmodel-group.component";
import * as i32 from "./entity-editors/gebo-ai-uploads-admin/gebo-ai-uploads-endpoint.component";
import * as i33 from "./main-panels/ancestor-panel/ancestor-admin-panel.component";
import * as i34 from "./entity-editors/gebo-ai-filesystems-admin/gebo-ai-shared-filesystems.component";
import * as i35 from "./entity-editors/gebo-ai-filesystems-admin/gebo-ai-filesystem-share-reference-admin.component";
import * as i36 from "./entity-editors/gebo-ai-google-search-admin/gebo-ai-google-search-account.component";
import * as i37 from "./entity-editors/gebo-ai-models-admin/gebo-ai-anthropic-chatmodel-admin.component";
import * as i38 from "./main-panels/gebo-dashboard/gebo-dashboard.component";
import * as i39 from "./main-panels/gebo-dashboard/gebo-embedded-piechart.component";
import * as i40 from "./main-panels/gebo-dashboard/gebo-embedding-stats-panel.component";
import * as i41 from "./entity-editors/gebo-ai-google-workspaces-admin/gebo-ai-google-workspace-access.component";
import * as i42 from "./entity-editors/gebo-ai-google-workspaces-admin/gebo-ai-google-drive-admin.component";
import * as i43 from "./entity-editors/gebo-ai-google-workspaces-admin/gebo-ai-google-drive-endpoint-admin.component";
import * as i44 from "./entity-editors/gebo-ai-atlassian-admin/gebo-ai-confluence-system-admin.component";
import * as i45 from "./entity-editors/gebo-ai-atlassian-admin/gebo-ai-confluence-endpoint.component";
import * as i46 from "./entity-editors/gebo-ai-atlassian-admin/gebo-ai-confluence-system-fast.component";
import * as i47 from "./entity-editors/gebo-ai-models-admin/gebo-ai-generic-openai-api-chatmodel-admin.component";
import * as i48 from "./entity-editors/gebo-ai-models-admin/gebo-ai-generic-openai-api-embedmodel-admin.component";
import * as i49 from "./entity-editors/gebo-ai-models-admin/gebo-ai-google-vertex-chatmodel-admin.component";
import * as i50 from "./entity-editors/gebo-ai-models-admin/gebo-ai-google-vertex-embedmodel-admin.component";
import * as i51 from "./entity-editors/gebo-ai-models-admin/gebo-ai-mistralai-chatmodel-admin.component";
import * as i52 from "./entity-editors/gebo-ai-models-admin/gebo-ai-mistralai-embedmodel-admin.component";
import * as i53 from "./entity-editors/controls/standard-chat-model-settings/standard-chat-model-settings.component";
import * as i54 from "./entity-editors/gebo-ai-sharepoint-admin/gebo-ai-sharepoint-endpoint.component";
import * as i55 from "./entity-editors/gebo-ai-sharepoint-admin/gebo-ai-sharepoint-system-admin.component";
import * as i56 from "./entity-editors/gebo-ai-sharepoint-admin/gebo-ai-sharepoint-system-fast.component";
import * as i57 from "./entity-editors/gebo-ai-google-workspaces-admin/gebo-ai-google-drive-fast.component";
import * as i58 from "./entity-editors/gebo-ai-atlassian-admin/gebo-ai-jira-endpoint.component";
import * as i59 from "./entity-editors/gebo-ai-atlassian-admin/gebo-ai-jira-system-admin.component";
import * as i60 from "./entity-editors/gebo-ai-atlassian-admin/gebo-ai-jira-system-fast.component";
import * as i61 from "./entity-editors/gebo-ai-models-admin/gebo-ai-deepseek-chatmodel-admin.component";
import * as i62 from "./entity-editors/gebo-ai-oauth2-admin/gebo-ai-oauth2-registration.component";
import * as i63 from "./entity-editors/gebo-ai-models-admin/gebo-ai-azure-openai-embedmodel-admin.component";
import * as i64 from "./entity-editors/gebo-ai-models-admin/gebo-ai-azure-openai-chatmodel-admin.component";
import * as i65 from "./entity-editors/gebo-graph-rag-extraction-config-admin/graph-rag-extraction-config.component";
import * as i66 from "./entity-editors/gebo-ai-job-status-viewer/graphic-visualizer.component";
import * as i67 from "./entity-editors/controls/graphrag-config/graphrag-config.component";
import * as i68 from "./entity-editors/gebo-deep-search-admin/gebo-deep-search-admin.component";
import * as i69 from "./entity-editors/gebo-ai-models-admin/gebo-ai-generic-openai-api-ranker-admin.component";
import * as i70 from "./entity-editors/gebo-ai-users-admin/gebo-ai-change-user-password.component";
import * as i71 from "@angular/common";
import * as i72 from "@angular/forms";
import * as i73 from "primeng/overlaypanel";
import * as i74 from "primeng/listbox";
import * as i75 from "primeng/textarea";
import * as i76 from "primeng/chip";
import * as i77 from "primeng/fieldset";
import * as i78 from "primeng/multiselect";
import * as i79 from "primeng/paginator";
import * as i80 from "primeng/calendar";
import * as i81 from "primeng/fileupload";
import * as i82 from "primeng/inputnumber";
import * as i83 from "primeng/password";
import * as i84 from "@Gebo.ai/reusable-ui";
import * as i85 from "primeng/menu";
import * as i86 from "primeng/tabview";
import * as i87 from "primeng/accordion";
import * as i88 from "primeng/table";
import * as i89 from "primeng/blockui";
import * as i90 from "primeng/button";
import * as i91 from "primeng/tree";
import * as i92 from "primeng/dialog";
import * as i93 from "primeng/panel";
import * as i94 from "primeng/inputtext";
import * as i95 from "primeng/checkbox";
import * as i96 from "primeng/treeselect";
import * as i97 from "primeng/chart";
import * as i98 from "primeng/radiobutton";
import * as i99 from "primeng/select";
import * as i100 from "primeng/dropdown";
import * as i101 from "primeng/selectbutton";
/**
 * GeboAiAdminModule is the main Angular NgModule for the Gebo.ai administration interface.
 *
 * This module brings together all components, services, and dependencies needed for the admin UI:
 * - Imports Angular and third-party UI modules (PrimeNG, Gebo.ai reusable components)
 * - Declares all administrative components for various systems (Git, Knowledgebase, Models, etc.)
 * - Provides necessary services for tree searching and UI notifications
 * - Exports components that need to be available to any consuming modules
 *
 * The module structure reflects a comprehensive admin interface for managing AI resources,
 * including knowledge bases, model configurations, integration endpoints, and user management.
 */
export declare class GeboAiAdminModule {
    static forRoot(): ModuleWithProviders<GeboAiAdminModule>;
    static ɵfac: i0.ɵɵFactoryDeclaration<GeboAiAdminModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<GeboAiAdminModule, [typeof i1.GeboAiAdminComponent, typeof i2.BuildPackagingSystemsComponent, typeof i3.ChatProfilesComponent, typeof i4.SystemsComponent, typeof i5.KnowledgeBasesComponent, typeof i6.LlmsSystemsComponent, typeof i7.GeboAiGitSystemAdminComponent, typeof i8.GeboAiGitEndpointAdminComponent, typeof i9.GeboAiKnowledgeBaseAdminComponent, typeof i10.GeboAiKnowledgeBaseTreeComponent, typeof i11.GeboAiProjectAdminComponent, typeof i12.GeboAiSecretsAdminListComponent, typeof i13.GeboAiSecretsAdminEditComponent, typeof i14.BuildSystemsChooserComponent, typeof i15.GeboAIJobStatusViewerComponent, typeof i16.GeboAiLogsViewComponent, typeof i17.LogTableComponent, typeof i18.GeboAIFileSystemEndpointComponent, typeof i19.GeboAIOpenAIChatModelAdminComponent, typeof i20.GeboAIOpenAIEmbedModelAdminComponent, typeof i21.GeboAITestChatComponent, typeof i22.GeboAIOllamaChatModelAdminComponent, typeof i23.GeboAIOllamaEmbedModelAdminComponent, typeof i24.GeboAIChatProfileAdminComponent, typeof i25.GeboAIPromptAdminComponent, typeof i26.GeboAIUsersManagementComponent, typeof i27.GeboAIUserComponent, typeof i28.GeboAIGroupComponent, typeof i29.GeboAIAccessControlComponent, typeof i30.GeboAIPromptWizardComponent, typeof i31.GeboAIAdvancedChatModelGroupComponent, typeof i32.GeboAIUploadsEndpointComponent, typeof i33.AncestorPanelComponent, typeof i34.GeboAISharedFilesystemsComponent, typeof i35.GeboAIGFileSystemShareReferenceAdminComponent, typeof i36.GeboAIGoogleSearchAccountComponent, typeof i37.GeboAIAnthropicChatModelAdminComponent, typeof i38.GeboAIDashboardComponent, typeof i39.GeboAiEmbeddedDocumentsPiechartComponent, typeof i40.GeboAIEmbeddingStatsPanelComponent, typeof i41.GeboAIGoogleWorkspaceAccessComponent, typeof i42.GeboAiGoogleDriveSystemAdminComponent, typeof i43.GeboAiGoogleDriveProjectEndpointAdminComponent, typeof i44.GeboAIConfluenceAdminComponent, typeof i45.GeboAIConfluenceEndpointComponent, typeof i46.GeboAIConfluenceSystemFastComponent, typeof i47.GeboAIGenericOpenAIAPIChatModelAdminComponent, typeof i48.GeboAIGenericOpenAIAPIEmbedModelAdminComponent, typeof i49.GeboAIGoogleVertexChatModelAdminComponent, typeof i50.GeboAIGoogleVertexEmbedModelAdminComponent, typeof i51.GeboAIMistralAIChatModelAdminComponent, typeof i52.GeboAIMistralAIEmbedModelAdminComponent, typeof i53.GeboAIStandardChatModelSettings, typeof i54.GeboAISharepointEndpointComponent, typeof i55.GeboAISharepointAdminComponent, typeof i56.GeboAISharepointSystemFastComponent, typeof i57.GeboAIGoogleDriveFastComponent, typeof i58.GeboAIJiraEndpointComponent, typeof i59.GeboAIJiraAdminComponent, typeof i60.GeboAIJiraSystemFastComponent, typeof i61.GeboAIDeepseekChatModelAdminComponent, typeof i62.GeboAIOauth2RegistrationComponent, typeof i63.GeboAIAzureOpenAIEmbedModelAdminComponent, typeof i64.GeboAIAzureOpenAIChatModelAdminComponent, typeof i65.GeboAIGraphRagExtractionConfigComponent, typeof i66.GeboAIJobGraphicVisualizerComponent, typeof i67.GeboAIGraphragConfigComponent, typeof i68.GeboAIDeepSearchConfigAdminComponent, typeof i69.GeboAIGenericOpenaAIAPiRankerAdminComponent, typeof i70.GeboAIChangeUserPasswordComponent], [typeof i71.CommonModule, typeof i72.FormsModule, typeof i73.OverlayPanelModule, typeof i74.ListboxModule, typeof i75.TextareaModule, typeof i76.ChipModule, typeof i77.FieldsetModule, typeof i78.MultiSelectModule, typeof i79.PaginatorModule, typeof i80.CalendarModule, typeof i81.FileUploadModule, typeof i82.InputNumberModule, typeof i83.PasswordModule, typeof i84.GeboAiRelationListModule, typeof i72.ReactiveFormsModule, typeof i85.MenuModule, typeof i86.TabViewModule, typeof i87.AccordionModule, typeof i88.TableModule, typeof i89.BlockUIModule, typeof i90.ButtonModule, typeof i91.TreeModule, typeof i92.DialogModule, typeof i93.PanelModule, typeof i84.GeboUIArchitectureModule, typeof i94.InputTextModule, typeof i95.CheckboxModule, typeof i84.EditableListboxModule, typeof i84.GeboAIReusableChatModule, typeof i84.GeboAIContentViewerModule, typeof i84.GeboAIChooseLLMFunctionsModule, typeof i84.BrowseContentModule, typeof i96.TreeSelectModule, typeof i84.VFilesystemSelectorModule, typeof i84.TranslableModule, typeof i84.GeboAIContentReindexModule, typeof i84.ProjectAddContextMenuModule, typeof i97.ChartModule, typeof i98.RadioButtonModule, typeof i84.GeboAIFileTypesModule, typeof i99.SelectModule, typeof i100.DropdownModule, typeof i84.GeboOauth2SecretModule, typeof i84.GeboAIContentSelectionFilterModule, typeof i84.GeboAIFieldTranslationContainerModule, typeof i101.SelectButtonModule, typeof i84.GeboAINotificationsModule, typeof i84.GeboAIChatModelUseModule], [typeof i1.GeboAiAdminComponent, typeof i2.BuildPackagingSystemsComponent, typeof i3.ChatProfilesComponent, typeof i4.SystemsComponent, typeof i5.KnowledgeBasesComponent, typeof i6.LlmsSystemsComponent, typeof i7.GeboAiGitSystemAdminComponent, typeof i8.GeboAiGitEndpointAdminComponent, typeof i9.GeboAiKnowledgeBaseAdminComponent, typeof i10.GeboAiKnowledgeBaseTreeComponent, typeof i11.GeboAiProjectAdminComponent, typeof i12.GeboAiSecretsAdminListComponent, typeof i13.GeboAiSecretsAdminEditComponent, typeof i14.BuildSystemsChooserComponent, typeof i15.GeboAIJobStatusViewerComponent, typeof i16.GeboAiLogsViewComponent, typeof i17.LogTableComponent, typeof i18.GeboAIFileSystemEndpointComponent, typeof i19.GeboAIOpenAIChatModelAdminComponent, typeof i20.GeboAIOpenAIEmbedModelAdminComponent, typeof i21.GeboAITestChatComponent, typeof i22.GeboAIOllamaChatModelAdminComponent, typeof i23.GeboAIOllamaEmbedModelAdminComponent, typeof i24.GeboAIChatProfileAdminComponent, typeof i25.GeboAIPromptAdminComponent, typeof i26.GeboAIUsersManagementComponent, typeof i27.GeboAIUserComponent, typeof i28.GeboAIGroupComponent, typeof i29.GeboAIAccessControlComponent, typeof i30.GeboAIPromptWizardComponent, typeof i31.GeboAIAdvancedChatModelGroupComponent, typeof i32.GeboAIUploadsEndpointComponent, typeof i33.AncestorPanelComponent, typeof i34.GeboAISharedFilesystemsComponent, typeof i35.GeboAIGFileSystemShareReferenceAdminComponent, typeof i36.GeboAIGoogleSearchAccountComponent, typeof i37.GeboAIAnthropicChatModelAdminComponent, typeof i38.GeboAIDashboardComponent, typeof i39.GeboAiEmbeddedDocumentsPiechartComponent, typeof i40.GeboAIEmbeddingStatsPanelComponent, typeof i41.GeboAIGoogleWorkspaceAccessComponent, typeof i42.GeboAiGoogleDriveSystemAdminComponent, typeof i43.GeboAiGoogleDriveProjectEndpointAdminComponent, typeof i44.GeboAIConfluenceAdminComponent, typeof i45.GeboAIConfluenceEndpointComponent, typeof i46.GeboAIConfluenceSystemFastComponent, typeof i47.GeboAIGenericOpenAIAPIChatModelAdminComponent, typeof i48.GeboAIGenericOpenAIAPIEmbedModelAdminComponent, typeof i49.GeboAIGoogleVertexChatModelAdminComponent, typeof i50.GeboAIGoogleVertexEmbedModelAdminComponent, typeof i51.GeboAIMistralAIChatModelAdminComponent, typeof i52.GeboAIMistralAIEmbedModelAdminComponent, typeof i53.GeboAIStandardChatModelSettings, typeof i54.GeboAISharepointEndpointComponent, typeof i55.GeboAISharepointAdminComponent, typeof i56.GeboAISharepointSystemFastComponent, typeof i57.GeboAIGoogleDriveFastComponent, typeof i58.GeboAIJiraEndpointComponent, typeof i59.GeboAIJiraAdminComponent, typeof i60.GeboAIJiraSystemFastComponent, typeof i61.GeboAIDeepseekChatModelAdminComponent, typeof i62.GeboAIOauth2RegistrationComponent, typeof i63.GeboAIAzureOpenAIEmbedModelAdminComponent, typeof i64.GeboAIAzureOpenAIChatModelAdminComponent, typeof i65.GeboAIGraphRagExtractionConfigComponent, typeof i66.GeboAIJobGraphicVisualizerComponent, typeof i67.GeboAIGraphragConfigComponent, typeof i68.GeboAIDeepSearchConfigAdminComponent, typeof i69.GeboAIGenericOpenaAIAPiRankerAdminComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<GeboAiAdminModule>;
}
