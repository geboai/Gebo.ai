import * as i0 from "@angular/core";
import * as i1 from "@angular/common";
import * as i2 from "./gebo-ai-admin.module";
import * as i3 from "@angular/router";
/**
 * Routing module for the GeboAi Admin feature.
 * This module imports required dependencies and configures child routes
 * for the GeboAi Admin feature area.
 */
export declare class GeboAiAdminRoutingModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<GeboAiAdminRoutingModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<GeboAiAdminRoutingModule, never, [typeof i1.CommonModule, typeof i2.GeboAiAdminModule, typeof i3.RouterModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<GeboAiAdminRoutingModule>;
}
//# sourceMappingURL=gebo-ai-admin-routing.module.d.ts.map