import * as i0 from "@angular/core";
export declare class AncestorPanelComponent {
    /**
     * Reloads the currently viewed data in the panel.
     * This method is intended to be overridden by child components
     * to implement specific data refresh functionality.
     */
    reloadViewedData(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<AncestorPanelComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<AncestorPanelComponent, "gebo-ai-ancestor-admin-panel", never, {}, {}, never, never, false, never>;
}
//# sourceMappingURL=ancestor-admin-panel.component.d.ts.map