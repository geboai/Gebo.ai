/**
 * This Source Code is subject to the terms of the
 * Gebo.ai community version Mozilla Public License Version 2.0 (MPL-2.0) — With Data Protection Clauses
 * If a copy of the LICENCE was not distributed with this file, You can obtain one at
 * https://gebo.ai/gebo-ai-community-version-mozilla-public-license-version-2-0-mpl-2-0-with-data-protection-clauses/
 * and https://mozilla.org/MPL/2.0/.
 * Copyright (c) 2025+ Gebo.ai
 */
/**
 * AI generated comments
 *
 * This file contains the ChatProfilesComponent which is responsible for managing chat profiles
 * and prompts in the Gebo.ai system. The component provides functionality to view, create,
 * and edit both chat profiles and prompts with pagination support.
 */
import { OnInit } from "@angular/core";
import { DataPage, GChatProfileConfiguration, GeboAdminChatProfilesConfigurationControllerService, GeboAdminPromptsControllerService, PageGChatProfileConfiguration } from "@Gebo.ai/gebo-ai-rest-api";
import { GeboUIActionRoutingService } from "@Gebo.ai/reusable-ui";
import { PaginatorState } from "primeng/paginator";
import { AncestorPanelComponent } from "../ancestor-panel/ancestor-admin-panel.component";
import * as i0 from "@angular/core";
/**
 * ChatProfilesComponent manages the display and manipulation of chat profiles and prompts.
 * It extends the AncestorPanelComponent and implements OnInit interface for initialization.
 * This component handles loading, displaying, creating, and editing of chat profiles and prompts
 * with pagination support.
 */
export declare class ChatProfilesComponent extends AncestorPanelComponent implements OnInit {
    private geboPromptAdminService;
    private geboChatProfilesAdminService;
    private geboUIActionEventService;
    /**
     * Overrides the parent's reloadViewedData method to refresh both prompts and chat profiles data.
     */
    reloadViewedData(): void;
    /**
     * Pagination configuration for prompts list.
     */
    promptsPage: DataPage;
    /**
     * Pagination configuration for chat profiles list.
     */
    profilesPage: DataPage;
    /**
     * Flag indicating whether prompts are currently being loaded.
     */
    loadingPrompts: boolean;
    /**
     * Container for chat profiles data retrieved from the server.
     */
    chatprofiles: PageGChatProfileConfiguration;
    /**
     * Flag indicating whether chat profiles are currently being loaded.
     */
    loadingChatProfiles: boolean;
    /**
     * Constructor initializes services needed for managing chat profiles and prompts.
     *
     * @param geboPromptAdminService Service for handling prompt configurations
     * @param geboChatProfilesAdminService Service for handling chat profile configurations
     * @param geboUIActionEventService Service for routing UI actions
     */
    constructor(geboPromptAdminService: GeboAdminPromptsControllerService, geboChatProfilesAdminService: GeboAdminChatProfilesConfigurationControllerService, geboUIActionEventService: GeboUIActionRoutingService);
    /**
     * Initialize the component by loading both prompts and chat profiles data.
     */
    ngOnInit(): void;
    /**
     * Loads prompt configurations from the server using the configured pagination.
     * Sets the loading flag during the operation.
     */
    private loadPrompts;
    /**
     * Opens the edit interface for a specific chat profile configuration.
     * Refreshes chat profiles list after the edit operation completes.
     *
     * @param v The chat profile configuration to edit
     */
    editChatProfile(v: GChatProfileConfiguration): void;
    /**
     * Creates a new chat profile with default settings and opens the edit interface.
     * Refreshes chat profiles list after the creation operation completes.
     */
    newChatProfile(): void;
    /**
     * Handles pagination changes for prompts list and reloads the data accordingly.
     *
     * @param p The new paginator state
     */
    onPromptPageChange(p: PaginatorState): void;
    /**
     * Handles pagination changes for chat profiles list and reloads the data accordingly.
     *
     * @param p The new paginator state
     */
    onChatProfilePageChange(p: PaginatorState): void;
    /**
     * Loads chat profile configurations from the server using the configured pagination.
     * Sets the loading flag during the operation.
     */
    private loadChatProfiles;
    static ɵfac: i0.ɵɵFactoryDeclaration<ChatProfilesComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ChatProfilesComponent, "chat-profiles-component", never, {}, {}, never, never, false, never>;
}
