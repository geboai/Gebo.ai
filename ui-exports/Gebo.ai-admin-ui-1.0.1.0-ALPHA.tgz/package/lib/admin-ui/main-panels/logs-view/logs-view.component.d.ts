/**
 * This Source Code is subject to the terms of the
 * Gebo.ai community version Mozilla Public License Version 2.0 (MPL-2.0) — With Data Protection Clauses
 * If a copy of the LICENCE was not distributed with this file, You can obtain one at
 * https://gebo.ai/gebo-ai-community-version-mozilla-public-license-version-2-0-mpl-2-0-with-data-protection-clauses/
 * and https://mozilla.org/MPL/2.0/.
 * Copyright (c) 2025+ Gebo.ai
 */
/**
 * AI generated comments
 *
 * This component is responsible for displaying logs within the Gebo.ai application.
 * It extends the AncestorPanelComponent and handles the loading of endpoint data
 * for displaying in a tabbed interface.
 */
import { OnInit } from "@angular/core";
import { GeboAngularFormGroupMetaInfoControllerService, JobLauncherControllerService, LogViewControllerService } from "@Gebo.ai/gebo-ai-rest-api";
import { GeboUIActionRoutingService } from "@Gebo.ai/reusable-ui";
import { AncestorPanelComponent } from "../ancestor-panel/ancestor-admin-panel.component";
import * as i0 from "@angular/core";
export declare class GeboAiLogsViewComponent extends AncestorPanelComponent implements OnInit {
    private jobLauncherControllerService;
    private logsControllerService;
    private geboUIActionRoutingService;
    private geboFormGroupControllerService;
    /**
     * Overrides the parent method to reload viewed data.
     * Fetches form group meta information and filters for endpoint types,
     * populating the endpoint tabs array with the retrieved data.
     * Sets loading state during the operation.
     */
    reloadViewedData(): void;
    /**
     * Flag indicating whether data is currently being loaded
     */
    loading: boolean;
    /**
     * Constructor initializes necessary services for the logs view component
     *
     * @param jobLauncherControllerService Service for launching jobs
     * @param logsControllerService Service for accessing log data
     * @param geboUIActionRoutingService Service for UI action routing
     * @param geboFormGroupControllerService Service for handling form group meta information
     */
    constructor(jobLauncherControllerService: JobLauncherControllerService, logsControllerService: LogViewControllerService, geboUIActionRoutingService: GeboUIActionRoutingService, geboFormGroupControllerService: GeboAngularFormGroupMetaInfoControllerService);
    /**
     * Array to store endpoint tab information including display label and associated class name
     */
    endpointTabs: {
        label: string;
        className: string;
    }[];
    /**
     * Lifecycle hook that is called after component initialization
     * Triggers the data loading process
     */
    ngOnInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<GeboAiLogsViewComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<GeboAiLogsViewComponent, "gebo-ai-logs-view-component", never, {}, {}, never, never, false, never>;
}
//# sourceMappingURL=logs-view.component.d.ts.map