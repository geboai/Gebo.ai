/**
 * This Source Code is subject to the terms of the
 * Gebo.ai community version Mozilla Public License Version 2.0 (MPL-2.0) — With Data Protection Clauses
 * If a copy of the LICENCE was not distributed with this file, You can obtain one at
 * https://gebo.ai/gebo-ai-community-version-mozilla-public-license-version-2-0-mpl-2-0-with-data-protection-clauses/
 * and https://mozilla.org/MPL/2.0/.
 * Copyright (c) 2025+ Gebo.ai
 */
/**
 * AI generated comments
 * This file contains the SystemsComponent which manages the integration of content management systems
 * and file system shares within the Gebo.ai application. It extends the AncestorPanelComponent and
 * provides functionality to view, create, and manage different system integrations.
 */
import { OnInit } from "@angular/core";
import { FormGroup } from "@angular/forms";
import { CompanySystemsControllerService, FileSystemSharesSettingControllerService, GContentManagementSystem, GGitContentManagementSystem, SharedFilesystemUIConfig } from "@Gebo.ai/gebo-ai-rest-api";
import { GeboUIActionRoutingService } from "@Gebo.ai/reusable-ui";
import { AncestorPanelComponent } from "../ancestor-panel/ancestor-admin-panel.component";
import * as i0 from "@angular/core";
/**
 * SystemsComponent is responsible for managing content management systems and file sharing configurations.
 * This component provides interfaces to view, add, and edit Git servers, Google search configurations,
 * and filesystem configurations. It extends AncestorPanelComponent to maintain hierarchy consistency.
 */
export declare class SystemsComponent extends AncestorPanelComponent implements OnInit {
    private companySystemsControllerService;
    private fileSystemSharesSettingControllerService;
    private actionServices;
    /**
     * Overrides the parent method to reload system data when needed
     */
    reloadViewedData(): void;
    /** Array to store content management systems */
    systems: GContentManagementSystem[];
    /** Configuration for shared filesystem UI */
    filesystemUIConfig?: SharedFilesystemUIConfig;
    /** Flag to indicate loading state */
    loading: boolean;
    /** Flag to control filesystem configuration window visibility */
    showFilesystemConfigurationWindow: boolean;
    /** Form group for collecting Git server information */
    formGroup: FormGroup;
    /**
     * Constructor initializes the component with required services
     * @param companySystemsControllerService Service to interact with company systems API
     * @param fileSystemSharesSettingControllerService Service to interact with filesystem shares API
     * @param actionServices Service for routing UI actions
     */
    constructor(companySystemsControllerService: CompanySystemsControllerService, fileSystemSharesSettingControllerService: FileSystemSharesSettingControllerService, actionServices: GeboUIActionRoutingService);
    /**
     * Initializes the component and loads systems data
     */
    ngOnInit(): void;
    /**
     * Loads content management systems and filesystem configuration data
     * by making parallel API calls and joins the results
     */
    loadSystems(): void;
    /**
     * Resets the systems by reloading data from the server
     */
    resetSystems(): void;
    /**
     * Opens a dialog to create a new Git server integration
     * Routes a new action event to create a Git content management system
     */
    newGitServer(): void;
    /**
     * Opens a dialog to edit an existing Git server integration
     * @param data The Git content management system data to be edited
     */
    editGitServer(data: GGitContentManagementSystem): void;
    /**
     * Opens Google Search API configuration dialog
     * Configures Google search integration with the system
     */
    openGoogleSearchConfiguration(): void;
    /**
     * Shows the filesystem configuration window
     * Controls the visibility of the filesystem configuration interface
     */
    openFilesystemsConfiguration(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<SystemsComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SystemsComponent, "systems-component", never, {}, {}, never, never, false, never>;
}
//# sourceMappingURL=systems.component.d.ts.map