/**
 * This Source Code is subject to the terms of the
 * Gebo.ai community version Mozilla Public License Version 2.0 (MPL-2.0) — With Data Protection Clauses
 * If a copy of the LICENCE was not distributed with this file, You can obtain one at
 * https://gebo.ai/gebo-ai-community-version-mozilla-public-license-version-2-0-mpl-2-0-with-data-protection-clauses/
 * and https://mozilla.org/MPL/2.0/.
 * Copyright (c) 2025+ Gebo.ai
 */
/**
 * AI generated comments
 * This file contains the GeboAIUsersManagementComponent which handles the management of users and user groups.
 * It extends AncestorPanelComponent and implements OnInit and OnChanges interfaces.
 */
import { OnChanges, OnInit, SimpleChanges } from "@angular/core";
import { DataPage, EditableUser, PageUserInfos, PageUsersGroup, UserInfos, UsersAdminControllerService, UsersGroup } from "@Gebo.ai/gebo-ai-rest-api";
import { GeboUIActionRoutingService } from "@Gebo.ai/reusable-ui";
import { PaginatorState } from "primeng/paginator";
import { AncestorPanelComponent } from "../ancestor-panel/ancestor-admin-panel.component";
import * as i0 from "@angular/core";
/**
 * Component for managing users and user groups in the Gebo.ai application.
 * This component provides functionality to view, create, and edit users and groups.
 */
export declare class GeboAIUsersManagementComponent extends AncestorPanelComponent implements OnInit, OnChanges {
    private geboAiUserAdminControllerService;
    private actionServices;
    /**
     * Overrides the parent method to reload both users and groups data
     */
    reloadViewedData(): void;
    loadingUsers: boolean;
    loadingGroups: boolean;
    usersPage: DataPage;
    groupsPage: DataPage;
    usersPaged: PageUserInfos;
    groupsPaged: PageUsersGroup;
    searchUsername: string;
    searchName: string;
    searchSourname: string;
    searchRole: string;
    rolesList: string[];
    /**
     * Constructor for the component
     * @param geboAiUserAdminControllerService Service for user administration operations
     * @param actionServices Service for routing UI actions
     */
    constructor(geboAiUserAdminControllerService: UsersAdminControllerService, actionServices: GeboUIActionRoutingService);
    /**
     * Initializes the component by loading users and groups data
     */
    ngOnInit(): void;
    /**
     * Resets the active page to 0 and reloads the users list using the current search filters.
     */
    searchUsers(): void;
    /**
     * Fetches users data from the server based on current pagination settings and search filters
     * Sets loadingUsers flag while operation is in progress
     */
    private loadUsers;
    /**
     * Fetches groups data from the server based on current pagination settings
     * Sets loadingGroups flag while operation is in progress
     */
    private loadGroups;
    /**
     * Lifecycle hook that is called when any data-bound property of a directive changes
     * @param changes Object containing all changed properties with current and previous values
     */
    ngOnChanges(changes: SimpleChanges): void;
    editedUser?: EditableUser;
    editedUserMode?: "EDIT" | "NEW";
    openUserEditing: boolean;
    /**
     * Prepares the component to create a new user
     * Initializes a new user object with default role and opens the editing UI
     */
    newUser(): void;
    /**
     * Opens user editing UI for an existing user
     * @param u User information to edit
     */
    editUser(u: UserInfos): void;
    /**
     * Handles the event when user editing is complete
     * @param evt Event data from the user editing operation
     */
    editedUserChange(evt: any): void;
    /**
     * Initiates the creation of a new user group
     * Uses the action routing service to trigger the appropriate UI flow
     */
    newGroup(): void;
    /**
     * Opens editing UI for an existing user group
     * @param g The group to edit
     */
    editGroup(g: UsersGroup): void;
    /**
     * Handles pagination changes for the users list
     * @param p New paginator state
     */
    onUsersPageChange(p: PaginatorState): void;
    /**
     * Handles pagination changes for the groups list
     * @param p New paginator state
     */
    onGroupsPageChange(p: PaginatorState): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<GeboAIUsersManagementComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<GeboAIUsersManagementComponent, "users-management-component", never, {}, {}, never, never, false, never>;
}
//# sourceMappingURL=users-management.component.d.ts.map