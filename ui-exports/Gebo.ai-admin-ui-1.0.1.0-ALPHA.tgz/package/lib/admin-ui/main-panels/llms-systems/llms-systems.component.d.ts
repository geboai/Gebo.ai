/**
 * This Source Code is subject to the terms of the
 * Gebo.ai community version Mozilla Public License Version 2.0 (MPL-2.0) — With Data Protection Clauses
 * If a copy of the LICENCE was not distributed with this file, You can obtain one at
 * https://gebo.ai/gebo-ai-community-version-mozilla-public-license-version-2-0-mpl-2-0-with-data-protection-clauses/
 * and https://mozilla.org/MPL/2.0/.
 * Copyright (c) 2025+ Gebo.ai
 */
import { OnInit } from "@angular/core";
import { FormGroup } from "@angular/forms";
import { ChatModelsControllerService, ConfigurationEntry, EmbeddingModelsControllersService, GChatModelType, GEmbeddingModelType, GenericOpenAIAPIRankerModelConfig, GenericOpenAiRankerModelsConfigurationControllerService, GenericOpenAIRankerModelTypeConfig } from "@Gebo.ai/gebo-ai-rest-api";
import { GeboUIActionRoutingService } from "@Gebo.ai/reusable-ui";
import { AncestorPanelComponent } from "../ancestor-panel/ancestor-admin-panel.component";
import * as i0 from "@angular/core";
/**
 * AI generated comments
 * LlmsSystemsComponent handles the management of Language Learning Models (LLMs) systems
 * in the application. It provides functionality to view, create, and edit chat and embedding
 * model configurations. The component extends AncestorPanelComponent and uses Angular reactive forms
 * to manage user inputs for model selection.
 */
export declare class LlmsSystemsComponent extends AncestorPanelComponent implements OnInit {
    private chatModelsControllerService;
    private embeddingModelsControllerService;
    private genericOpenAIRerankerService;
    private geboUIActionRouter;
    chatModels: ConfigurationEntry[];
    embeddingModels: ConfigurationEntry[];
    rerankerModels: GenericOpenAIAPIRankerModelConfig[];
    chatModelsTypes: GChatModelType[];
    embeddingModelsTypes: GEmbeddingModelType[];
    rerankerModelsTypes: GenericOpenAIRankerModelTypeConfig[];
    /**
     * Overrides the parent method to reload data when the panel needs to refresh
     */
    reloadViewedData(): void;
    loading: boolean;
    /**
     * Form group to manage the user's model type selections for chat and embedding models
     */
    createChoices: FormGroup;
    /**
     * Initializes the component with required services
     *
     * @param chatModelsControllerService Service for chat model operations
     * @param embeddingModelsControllerService Service for embedding model operations
     * @param geboUIActionRouter Service for routing UI actions
     */
    constructor(chatModelsControllerService: ChatModelsControllerService, embeddingModelsControllerService: EmbeddingModelsControllersService, genericOpenAIRerankerService: GenericOpenAiRankerModelsConfigurationControllerService, geboUIActionRouter: GeboUIActionRoutingService);
    /**
     * Configures a new chat model based on the user's selection
     * Creates a new model configuration and routes a NEW action request
     */
    protected configureChatModel(): void;
    /**
     * Configures a new embedding model based on the user's selection
     * Creates a new model configuration and routes a NEW action request
     */
    protected configureEmbeddingModel(): void;
    protected configureRerankerModel(): void;
    /**
     * Opens the edit interface for a chat model configuration
     *
     * @param model The model configuration entry to edit
     */
    protected editModel(model: ConfigurationEntry): void;
    /**
     * Opens the edit interface for an embedding model configuration
     *
     * @param model The model configuration entry to edit
     */
    protected editEmbeddingModel(model: ConfigurationEntry): void;
    protected editRerankerModel(model: GenericOpenAIAPIRankerModelConfig): void;
    /**
     * Loads all required data from the API services using forkJoin to combine multiple requests
     * Updates the component's state with the fetched data upon completion
     */
    protected loadData(): void;
    /**
     * Angular lifecycle hook that initializes the component by loading data
     */
    ngOnInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<LlmsSystemsComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<LlmsSystemsComponent, "llms-systems-component", never, {}, {}, never, never, false, never>;
}
//# sourceMappingURL=llms-systems.component.d.ts.map