/**
 * This Source Code is subject to the terms of the
 * Gebo.ai community version Mozilla Public License Version 2.0 (MPL-2.0) — With Data Protection Clauses
 * If a copy of the LICENCE was not distributed with this file, You can obtain one at
 * https://gebo.ai/gebo-ai-community-version-mozilla-public-license-version-2-0-mpl-2-0-with-data-protection-clauses/
 * and https://mozilla.org/MPL/2.0/.
 * Copyright (c) 2025+ Gebo.ai
 */
/**
 * AI generated comments
 *
 * This component is responsible for displaying embedding statistics in a panel format.
 * It provides functionality to view hierarchical data about embeddings, with the ability
 * to drill down into categories for more detailed information.
 */
import { OnChanges, OnInit, SimpleChanges } from "@angular/core";
import { GeboCoreAnalisysControllerService } from "@Gebo.ai/gebo-ai-rest-api";
import { TotalHistogramBar } from "./graphics-data";
import * as i0 from "@angular/core";
export declare class GeboAIEmbeddingStatsPanelComponent implements OnInit, OnChanges {
    private geboStatsService;
    /** Indicates whether data is currently being loaded */
    loading: boolean;
    /** Determines if this instance is the root component in a hierarchy */
    isRoot?: boolean;
    /** Reference to the parent histogram bar when in drill-down mode */
    parent?: TotalHistogramBar | null | undefined;
    /** Contains the top-level histogram data to be displayed */
    rootValue: TotalHistogramBar[];
    /** Tracks whether drill-down data is currently being shown */
    drilldownShowed: boolean;
    /**
     * Constructor initializes the component with required services
     * @param geboStatsService Service to fetch embedding statistics data
     */
    constructor(geboStatsService: GeboCoreAnalisysControllerService);
    /**
     * Lifecycle hook that responds to input property changes.
     * If this is the root component, it loads the top-level knowledge base categories.
     * @param changes The changes that occurred on the input properties
     */
    ngOnChanges(changes: SimpleChanges): void;
    /**
     * Lifecycle hook for component initialization
     */
    ngOnInit(): void;
    /**
     * Fetches and displays drill-down data for a selected histogram bar
     * When a user selects a category, this method retrieves more detailed subcategories
     * @param value The histogram bar selected for drill-down
     */
    drillDown(value: TotalHistogramBar): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<GeboAIEmbeddingStatsPanelComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<GeboAIEmbeddingStatsPanelComponent, "gebo-ai-embedding-stats-panel", never, { "isRoot": { "alias": "isRoot"; "required": false; }; "parent": { "alias": "parent"; "required": false; }; "rootValue": { "alias": "rootValue"; "required": false; }; }, {}, never, never, false, never>;
}
