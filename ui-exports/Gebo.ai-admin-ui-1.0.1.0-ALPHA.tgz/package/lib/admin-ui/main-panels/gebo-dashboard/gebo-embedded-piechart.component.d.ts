/**
 * This Source Code is subject to the terms of the
 * Gebo.ai community version Mozilla Public License Version 2.0 (MPL-2.0) — With Data Protection Clauses
 * If a copy of the LICENCE was not distributed with this file, You can obtain one at
 * https://gebo.ai/gebo-ai-community-version-mozilla-public-license-version-2-0-mpl-2-0-with-data-protection-clauses/
 * and https://mozilla.org/MPL/2.0/.
 * Copyright (c) 2025+ Gebo.ai
 */
/**
 * AI generated comments
 * This file contains a component that renders a pie chart for embedded documents.
 * It transforms input data from EmbeddingData format into a format compatible with
 * the pie chart visualization.
 */
import { EventEmitter, OnChanges, SimpleChanges } from "@angular/core";
import { EmbeddingData } from "./graphics-data";
import { GStatsHolder } from "@Gebo.ai/gebo-ai-rest-api";
import * as i0 from "@angular/core";
/**
 * TypeScript interface defining the structure for pie chart data.
 * Consists of labels array and datasets array with configuration options
 * for customizing the chart appearance.
 */
export type NGPieChart = {
    labels: string[];
    datasets: {
        label: string;
        data: number[];
        backgroundColor?: string[];
        borderColor?: string[];
        borderWith?: number;
    }[];
};
/**
 * Component responsible for displaying embedded document data as a pie chart.
 * Takes EmbeddingData as input and transforms it into a format suitable for
 * pie chart visualization. Provides drill-down capability through EventEmitter.
 */
export declare class GeboAiEmbeddedDocumentsPiechartComponent implements OnChanges {
    /**
     * Responds to changes in the input properties.
     * Transforms the input data (EmbeddingData) into a structured format (NGPieChart)
     * that can be rendered by the pie chart library.
     *
     * @param changes Object containing all changed properties with current and previous values
     */
    ngOnChanges(changes: SimpleChanges): void;
    /**
     * Configuration options for the pie chart appearance.
     * Sets the legend style to use point style with black color for labels.
     */
    pieOptions: {
        plugins: {
            legend: {
                labels: {
                    usePointStyle: boolean;
                    color: string;
                };
            };
        };
    };
    /**
     * Holds the processed chart data ready for rendering
     */
    pieChartData?: NGPieChart;
    /**
     * Input property receiving the embedding data to be visualized
     */
    item?: EmbeddingData;
    /**
     * Output event emitter for drill-down functionality
     * Emits a GStatsHolder object when a segment of the chart is selected for detailed view
     */
    drillDown: EventEmitter<GStatsHolder>;
    static ɵfac: i0.ɵɵFactoryDeclaration<GeboAiEmbeddedDocumentsPiechartComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<GeboAiEmbeddedDocumentsPiechartComponent, "gebo-ai-embedded-documents-piechart", never, { "item": { "alias": "item"; "required": false; }; }, { "drillDown": "drillDown"; }, never, never, false, never>;
}
//# sourceMappingURL=gebo-embedded-piechart.component.d.ts.map