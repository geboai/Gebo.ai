/**
 * This Source Code is subject to the terms of the
 * Gebo.ai community version Mozilla Public License Version 2.0 (MPL-2.0) — With Data Protection Clauses
 * If a copy of the LICENCE was not distributed with this file, You can obtain one at
 * https://gebo.ai/gebo-ai-community-version-mozilla-public-license-version-2-0-mpl-2-0-with-data-protection-clauses/
 * and https://mozilla.org/MPL/2.0/.
 * Copyright (c) 2025+ Gebo.ai
 */
/**
 * AI generated comments
 *
 * This file defines the GeboAiAdminComponent which serves as the main administrative interface for Gebo.ai.
 * It handles user authentication, setup status management, and interfaces with various admin panels.
 */
import { OnInit } from "@angular/core";
import { ActivatedRoute, Router } from "@angular/router";
import { UserControllerService, UserInfo } from "@Gebo.ai/gebo-ai-rest-api";
import { GeboUIActionRoutingService, SetupWizardService, SetupStatus, GeboAIPluggableModulesConfigService, GeboAIEnabledModulesConfig } from "@Gebo.ai/reusable-ui";
import { AncestorPanelComponent } from "./main-panels/ancestor-panel/ancestor-admin-panel.component";
import * as i0 from "@angular/core";
/**
 * Main admin component for the Gebo.ai application
 * Handles user authentication, setup workflow, and navigation between admin panels
 * Provides an interface for managing the application's configuration and modules
 */
export declare class GeboAiAdminComponent implements OnInit {
    private geboAIModulesService;
    private actionServices;
    private userInfoService;
    private setupWizardService;
    private router;
    private activatedRoute;
    /** Indicates if the component is in a loading state */
    loading: boolean;
    /** References to the child ancestor panel components for controlling their behavior */
    child1?: AncestorPanelComponent;
    child2?: AncestorPanelComponent;
    child3?: AncestorPanelComponent;
    child4?: AncestorPanelComponent;
    child5?: AncestorPanelComponent;
    child6?: AncestorPanelComponent;
    child7?: AncestorPanelComponent;
    /** Current authenticated user information */
    user?: UserInfo;
    /** Current setup status: complete, incomplete, or full */
    private setupStatus?;
    /** Flag indicating if the setup window has been opened */
    private setupWindowOpened;
    /** Flag indicating if the setup window has been abandoned/dismissed */
    private setupWindowAbandoned;
    /** Severity level for the setup button UI styling (danger for incomplete setup) */
    setupButtonSeverity: any;
    /** Configuration for enabled Gebo AI modules */
    geboConfig: GeboAIEnabledModulesConfig | undefined;
    /**
     * Computed property that determines if the setup window should be visible
     * @returns true if the setup window should be displayed
     */
    get setupWindowVisible(): boolean;
    /**
     * Constructor initializes all required services for the admin component
     */
    constructor(geboAIModulesService: GeboAIPluggableModulesConfigService, actionServices: GeboUIActionRoutingService, userInfoService: UserControllerService, setupWizardService: SetupWizardService, router: Router, activatedRoute: ActivatedRoute);
    /**
     * Stores the current setup status and abandonment state in local storage
     */
    private storeStatus;
    /**
     * Initializes the component, loads user information, setup status, and handles query parameters
     * Redirects non-admin users to the chat page
     */
    ngOnInit(): void;
    /**
     * Updates the setup status based on the status provided by the setup wizard
     * Updates UI elements accordingly
     * @param status The current setup status
     */
    onSetupStatus(status: SetupStatus): void;
    /**
     * Opens the setup wizard window and resets the abandoned flag
     */
    openSetupWindow(): void;
    /**
     * Hides the setup wizard and marks it as abandoned
     */
    hideSetup(): void;
    /**
     * Called when a specific panel tab is activated
     * Reloads data for the activated child panel component
     * @param index The index of the activated panel
     */
    activatedIndex(index: number | string): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<GeboAiAdminComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<GeboAiAdminComponent, "gebo-ai-admin-component", never, {}, {}, never, never, false, never>;
}
