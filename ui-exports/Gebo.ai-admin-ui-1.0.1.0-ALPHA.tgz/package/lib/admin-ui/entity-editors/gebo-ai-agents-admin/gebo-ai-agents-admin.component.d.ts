import { Injector } from "@angular/core";
import { FormGroup } from "@angular/forms";
import { ChatModelsControllerService, ConfigurationEntry, GAgentConfig, GBaseChatModelConfig, GBaseObject, GeboAgentAdminControllerService, GPromptTemplateConfig } from "@Gebo.ai/gebo-ai-rest-api";
import { BaseEntityEditingComponent, GeboFormGroupsService, GeboUIActionRoutingService, GeboUIOutputForwardingService } from "@Gebo.ai/reusable-ui";
import { ConfirmationService } from "primeng/api";
import { Observable } from "rxjs";
import * as i0 from "@angular/core";
export declare class GeboAIAgentsAdminComponent extends BaseEntityEditingComponent<GAgentConfig> {
    private agentsAdminService;
    private geboChatModelsService;
    protected entityName: string;
    formGroup: FormGroup<any>;
    protected chatModelsData: ConfigurationEntry[];
    protected agentTypes: GBaseObject[];
    protected promptLoadingObservable: Observable<GPromptTemplateConfig[]>;
    protected defaultChatModel?: ConfigurationEntry;
    protected isChooseChatModel: boolean;
    protected thinkingOptions: {
        code: GBaseChatModelConfig.ThinkingEnum;
        description: string;
    }[];
    constructor(injector: Injector, geboFormGroupsService: GeboFormGroupsService, confirmationService: ConfirmationService, geboUIActionRoutingService: GeboUIActionRoutingService, outputForwardingService: GeboUIOutputForwardingService, agentsAdminService: GeboAgentAdminControllerService, geboChatModelsService: ChatModelsControllerService);
    /**
     * Adds or removes the required validator for a form control
     *
     * @param ctrlName Name of the form control
     * @param required Whether the control should be required
     */
    private setControlRequired;
    /**
   * Enables or disables a form control and sets its required status accordingly
   *
   * @param ctrlName Name of the form control
   * @param enabled Whether the control should be enabled
   */
    private setControlEnabledAndRequired;
    ngOnInit(): void;
    findByCode(code: string): Observable<GAgentConfig | null>;
    save(value: GAgentConfig): Observable<GAgentConfig>;
    insert(value: GAgentConfig): Observable<GAgentConfig>;
    delete(value: GAgentConfig): Observable<boolean>;
    canBeDeleted(value: GAgentConfig): Observable<{
        canBeDeleted: boolean;
        message: string;
    }>;
    static ɵfac: i0.ɵɵFactoryDeclaration<GeboAIAgentsAdminComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<GeboAIAgentsAdminComponent, "gebo-ai-agent-admin-component", never, {}, {}, never, never, false, never>;
}
