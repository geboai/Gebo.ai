/**
 * This Source Code is subject to the terms of the
 * Gebo.ai community version Mozilla Public License Version 2.0 (MPL-2.0) — With Data Protection Clauses
 * If a copy of the LICENCE was not distributed with this file, You can obtain one at
 * https://gebo.ai/gebo-ai-community-version-mozilla-public-license-version-2-0-mpl-2-0-with-data-protection-clauses/
 * and https://mozilla.org/MPL/2.0/.
 * Copyright (c) 2025+ Gebo.ai
 */
/**
 * AI generated comments
 *
 * This file contains the GeboAISharepointEndpointComponent, which is responsible for managing
 * SharePoint project endpoints in the Gebo.ai application. The component extends BaseEntityEditingComponent
 * to provide editing functionality for SharePoint endpoints, including creating, updating, and deleting operations.
 */
import { Injector } from "@angular/core";
import { FormGroup } from "@angular/forms";
import { GProject, JobLauncherControllerService, ProjectsControllerService, GConfluenceSystem, SecretInfo, SecretsControllerService, GSharepointProjectEndpoint, SharepointBrowsingControllerService, SharepointSystemsControllerService, GSharepointContentManagementSystem } from "@Gebo.ai/gebo-ai-rest-api";
import { BaseEntityEditingComponent, GeboAIFileType, GeboFormGroupsService, GeboUIActionRequest, GeboUIActionRoutingService, GeboUIOutputForwardingService } from "@Gebo.ai/reusable-ui";
import { ConfirmationService } from "primeng/api";
import { Observable } from "rxjs";
import { loadRootsObservableCallback, browsePathObservableCallback } from "@Gebo.ai/reusable-ui";
import * as i0 from "@angular/core";
/**
 * Component for managing SharePoint endpoints within the Gebo.ai system.
 * This component provides the UI and logic needed for creating, editing, and managing
 * SharePoint project endpoints, including connection to SharePoint systems, browsing paths,
 * and configuring synchronization settings.
 */
export declare class GeboAISharepointEndpointComponent extends BaseEntityEditingComponent<GSharepointProjectEndpoint> {
    private sharepointControllerService;
    private sharepointBrowsing;
    private secretControllerService;
    private projectsController;
    private JobLauncherControllerService;
    private actionsRouter;
    /**
     * The entity name used for identification in the component
     */
    protected entityName: string;
    /**
     * The handshake code used for authentication in file uploads
     */
    handShakeCode?: string;
    /**
     * Flag to control whether the project can be modified
     */
    cantModifyProject: boolean;
    /**
     * Observable that provides a list of available projects
     */
    projectsObservable: Observable<GProject[]>;
    /**
     * The form group containing all controls for the SharePoint endpoint configuration
     */
    formGroup: FormGroup<any>;
    /**
     * Flag indicating if the endpoint is published
     */
    published: boolean;
    /**
     * List of available SharePoint server systems
     */
    sharepointServersData: GSharepointContentManagementSystem[];
    /**
     * Action request configuration for creating a new SharePoint server
     */
    newsharepointServerRequest: GeboUIActionRequest;
    /**
     * The current identity context for SharePoint
     */
    private actualIdentityContext;
    /**
     * Flag indicating if there are no accounts or systems available
     */
    noAccountsAndSystems: boolean;
    /**
     * The most recently selected SharePoint system code
     */
    private lastConfluenceSystemCode;
    /**
     * Available secret identities for SharePoint connections
     */
    identities: SecretInfo[];
    /**
     * Callback for loading root nodes in SharePoint system
     */
    loadRootsObservable: loadRootsObservableCallback;
    /**
     * Callback for browsing paths in SharePoint system
     */
    browsePathObservable: browsePathObservableCallback;
    /**
     * List of available file types for SharePoint
     */
    fileTypesList: GeboAIFileType[];
    /**
     * Constructor initializing the component with required services and setting up subscriptions
     * for form control changes and SharePoint browsing capabilities.
     */
    constructor(injector: Injector, geboFormGroupsService: GeboFormGroupsService, sharepointControllerService: SharepointSystemsControllerService, sharepointBrowsing: SharepointBrowsingControllerService, secretControllerService: SecretsControllerService, projectsController: ProjectsControllerService, JobLauncherControllerService: JobLauncherControllerService, actionsRouter: GeboUIActionRoutingService, confirmService: ConfirmationService, outputForwardingService?: GeboUIOutputForwardingService);
    /**
     * Checks if there are any backend processes running for the given reference
     * @param reference The object reference to check for running jobs
     * @returns An observable that emits true if jobs are running, false otherwise
     */
    protected checkBackendProcessing(reference: {
        className?: string;
        code?: string;
    }): Observable<boolean>;
    /**
     * Initializes the component and checks for existing accounts and systems
     */
    ngOnInit(): void;
    /**
     * Checks for and loads existing SharePoint accounts and systems
     * @param system Optional system to set as the selected system after loading
     */
    checkExistentAccountAndSystem(system?: GConfluenceSystem): void;
    /**
     * Handles special processing when new data is provided to the component
     * @param actualValue The new SharePoint endpoint data
     */
    protected onNewData(actualValue: GSharepointProjectEndpoint): void;
    /**
     * Handles special processing when existing data is loaded into the component
     * @param actualValue The loaded SharePoint endpoint data
     */
    protected onLoadedPersistentData(actualValue: GSharepointProjectEndpoint): void;
    /**
     * Fetches a SharePoint endpoint by its code
     * @param code The code of the endpoint to find
     * @returns An observable with the found endpoint or null
     */
    findByCode(code: string): Observable<GSharepointProjectEndpoint | null>;
    /**
     * Saves an existing SharePoint endpoint
     * @param value The endpoint data to save
     * @returns An observable with the saved endpoint
     */
    save(value: GSharepointProjectEndpoint): Observable<GSharepointProjectEndpoint>;
    /**
     * Inserts a new SharePoint endpoint
     * @param value The endpoint data to insert
     * @returns An observable with the inserted endpoint
     */
    insert(value: GSharepointProjectEndpoint): Observable<GSharepointProjectEndpoint>;
    /**
     * Deletes a SharePoint endpoint
     * @param value The endpoint to delete
     * @returns An observable indicating success or failure
     */
    delete(value: GSharepointProjectEndpoint): Observable<boolean>;
    /**
     * Checks if a SharePoint endpoint can be deleted
     * @param value The endpoint to check
     * @returns An observable with deletion status and message
     */
    canBeDeleted(value: GSharepointProjectEndpoint): Observable<{
        canBeDeleted: boolean;
        message: string;
    }>;
    /**
     * Performs a save and publish operation on the endpoint
     */
    doSaveAndPublish(): void;
    /**
     * Publishes the SharePoint endpoint by creating a background job
     */
    doPublish(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<GeboAISharepointEndpointComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<GeboAISharepointEndpointComponent, "gebo-ai-sharepoint-endpoint-component", never, { "cantModifyProject": { "alias": "cantModifyProject"; "required": false; }; }, {}, never, never, false, never>;
}
