/**
 * This Source Code is subject to the terms of the
 * Gebo.ai community version Mozilla Public License Version 2.0 (MPL-2.0) — With Data Protection Clauses
 * If a copy of the LICENCE was not distributed with this file, You can obtain one at
 * https://gebo.ai/gebo-ai-community-version-mozilla-public-license-version-2-0-mpl-2-0-with-data-protection-clauses/
 * and https://mozilla.org/MPL/2.0/.
 * Copyright (c) 2025+ Gebo.ai
 */
/**
 * AI generated comments
 * This module provides a component for quickly creating a new Sharepoint/OneDrive system connection.
 * It manages a form for collecting Sharepoint connection details and credentials, and handles
 * the submission process to the backend service.
 */
import { EventEmitter, OnInit } from "@angular/core";
import { FormGroup } from "@angular/forms";
import { GConfluenceSystem, GSharepointContentManagementSystem, SharepointSystemsControllerService, UserControllerService } from "@Gebo.ai/gebo-ai-rest-api";
import { ToastMessageOptions } from "primeng/api";
import * as i0 from "@angular/core";
/**
 * Component for rapid creation of Sharepoint system connections in the Gebo.ai platform.
 * Provides a form interface for users to enter Sharepoint connection details including
 * base URI and OAuth2 credentials. Currently supports cloud version of Sharepoint.
 * The component communicates with backend services to create the system connection
 * and emits events to notify parent components of the result.
 */
export declare class GeboAISharepointSystemFastComponent implements OnInit {
    private sharepointSystemsService;
    private userControllerService;
    /** Flag to indicate if an API operation is in progress */
    loading: boolean;
    /**
     * Form group that manages the Sharepoint system configuration inputs, including:
     * - description: A human-readable name for the system
     * - baseUri: The base URL of the Sharepoint instance
     * - oauth2Credentials: Contains tenant ID, client ID and secret for OAuth authentication
     * - sharepointVersion: The version of Sharepoint being connected to
     */
    formGroup: FormGroup;
    /** Collection of messages to display to the user after operations */
    userMessages: ToastMessageOptions[];
    /** Available Sharepoint versions for selection in the form */
    sharepointVersions: {
        code: GSharepointContentManagementSystem.SharepointVersionEnum;
        description: string;
    }[];
    /** Currently selected Sharepoint version, defaults to cloud version */
    currentSharepointVersion?: GSharepointContentManagementSystem.SharepointVersionEnum;
    /** Event emitter that fires when a new Sharepoint system is successfully created */
    newSharepointSystemEvent: EventEmitter<GConfluenceSystem>;
    /** Event emitter that fires when the user cancels the creation process */
    cancelAction: EventEmitter<boolean>;
    /**
     * Constructor initializes the component with necessary services and sets default values
     *
     * @param sharepointSystemsService Service to handle Sharepoint system API operations
     * @param userControllerService Service to handle user-related operations
     */
    constructor(sharepointSystemsService: SharepointSystemsControllerService, userControllerService: UserControllerService);
    get oauth2Credentials(): FormGroup;
    get customAttributes(): FormGroup;
    /**
     * Conditionally enables or disables a form control based on the provided parameter
     *
     * @param ctrlName The name of the control to enable or disable
     * @param enabled Boolean value indicating whether to enable (true) or disable (false) the control
     */
    setEnabled(ctrlName: string, enabled: boolean): void;
    /**
     * Lifecycle hook that is called after component initialization.
     * Currently contains no implementation.
     */
    ngOnInit(): void;
    /**
     * Submits the form data to create a new Sharepoint system configuration.
     * Collects form values, calls the API service, and emits the result to parent components.
     * Sets loading state during the operation and processes any error messages received.
     */
    doInsert(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<GeboAISharepointSystemFastComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<GeboAISharepointSystemFastComponent, "gebo-ai-sharepoint-system-fast-component", never, {}, { "newSharepointSystemEvent": "newSharepointSystemEvent"; "cancelAction": "cancelAction"; }, never, never, false, never>;
}
//# sourceMappingURL=gebo-ai-sharepoint-system-fast.component.d.ts.map