/**
 * This Source Code is subject to the terms of the
 * Gebo.ai community version Mozilla Public License Version 2.0 (MPL-2.0) — With Data Protection Clauses
 * If a copy of the LICENCE was not distributed with this file, You can obtain one at
 * https://gebo.ai/gebo-ai-community-version-mozilla-public-license-version-2-0-mpl-2-0-with-data-protection-clauses/
 * and https://mozilla.org/MPL/2.0/.
 * Copyright (c) 2025+ Gebo.ai
 */
/**
 * AI generated comments
 * This file implements a component for administering Sharepoint CMS systems within the Gebo.ai application.
 * It provides a UI for creating, editing, and managing Sharepoint content management system configurations.
 */
import { Injector } from "@angular/core";
import { FormGroup } from "@angular/forms";
import { GSharepointContentManagementSystem, SecretInfo, SecretsControllerService, SharepointSystemsControllerService } from "@Gebo.ai/gebo-ai-rest-api";
import { BaseEntityEditingComponent, GeboFormGroupsService, GeboUIActionRoutingService, GeboUIOutputForwardingService } from "@Gebo.ai/reusable-ui";
import { ConfirmationService } from "primeng/api";
import { Observable } from "rxjs";
import * as i0 from "@angular/core";
/**
 * Component for administering Sharepoint systems in the Gebo.ai application.
 * This component provides a form UI for creating and editing Sharepoint system configurations.
 * It extends BaseEntityEditingComponent with GSharepointContentManagementSystem as the entity type.
 */
export declare class GeboAISharepointAdminComponent extends BaseEntityEditingComponent<GSharepointContentManagementSystem> {
    private confluenceControllerService;
    private secretControllerService;
    /**
     * Entity name used for identification in the base component
     */
    protected entityName: string;
    /**
     * Form group that binds to the UI form fields for the Sharepoint system
     */
    formGroup: FormGroup<any>;
    /**
     * Identity context code for secrets retrieval and creation
     */
    private actualIdentityContext;
    /**
     * Current Sharepoint version selection
     */
    actualSharepointVersion: GSharepointContentManagementSystem.SharepointVersionEnum;
    /**
     * Observable to load available secrets for the Sharepoint system
     */
    identitiesObservable: Observable<SecretInfo[]>;
    /**
     * Available Sharepoint versions for dropdown selection
     */
    sharepointVersions: {
        code: GSharepointContentManagementSystem.SharepointVersionEnum;
        description: string;
    }[];
    /**
     * Action request for creating a new secret
     */
    newSecretAction: import("@Gebo.ai/reusable-ui").GeboUIActionRequest;
    /**
     * Constructor initializes the component and sets up form field behaviors
     * Subscribes to form control changes to enforce specific validation rules and behaviors
     * based on the selected Sharepoint version.
     */
    constructor(injector: Injector, geboFormGroupsService: GeboFormGroupsService, confirmationService: ConfirmationService, confluenceControllerService: SharepointSystemsControllerService, secretControllerService: SecretsControllerService, geboUIActionRoutingService: GeboUIActionRoutingService, outputForwardingService?: GeboUIOutputForwardingService);
    /**
     * Tests the current Sharepoint system configuration.
     * Currently implemented as an empty placeholder method.
     */
    testSystem(): void;
    /**
     * Helper method to dynamically set a form field's validation and enabled state
     * @param field - The name of the form field to modify
     * @param enabled - Whether the field should be enabled and required (true) or disabled (false)
     */
    private requiredAndEnabled;
    /**
     * Fetches a Sharepoint system by its code identifier
     * @param code - The unique code of the Sharepoint system
     * @returns Observable with the found system or null
     */
    findByCode(code: string): Observable<GSharepointContentManagementSystem | null>;
    /**
     * Updates an existing Sharepoint system
     * @param value - The Sharepoint system data to update
     * @returns Observable with the updated system
     */
    save(value: GSharepointContentManagementSystem): Observable<GSharepointContentManagementSystem>;
    /**
     * Creates a new Sharepoint system
     * @param value - The new Sharepoint system data
     * @returns Observable with the created system
     */
    insert(value: GSharepointContentManagementSystem): Observable<GSharepointContentManagementSystem>;
    /**
     * Deletes a Sharepoint system
     * @param value - The Sharepoint system to delete
     * @returns Observable indicating success or failure
     */
    delete(value: GSharepointContentManagementSystem): Observable<boolean>;
    /**
     * Determines if a Sharepoint system can be deleted
     * Currently always returns true as there are no restrictions implemented
     * @param value - The Sharepoint system to check
     * @returns Observable with deletion permission info
     */
    canBeDeleted(value: GSharepointContentManagementSystem): Observable<{
        canBeDeleted: boolean;
        message: string;
    }>;
    static ɵfac: i0.ɵɵFactoryDeclaration<GeboAISharepointAdminComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<GeboAISharepointAdminComponent, "gebo-ai-sharepoint-admin-component", never, {}, {}, never, never, false, never>;
}
//# sourceMappingURL=gebo-ai-sharepoint-system-admin.component.d.ts.map