import { ComputedWorkflowStatus, JobWorkflowStepSummary } from '@Gebo.ai/gebo-ai-rest-api';
export declare function renderData(result: ComputedWorkflowStatus, workflowStepsSummaries: JobWorkflowStepSummary[] | undefined): StatusRendering; /**
 * Type definition for PrimeNG pie chart data structure.
 * Represents a structured format for chart visualization with labels, datasets, and styling options.
 */
export type NGPieChart = {
    labels: string[];
    datasets: {
        label: string;
        data: number[];
        backgroundColor?: string[];
        borderColor?: string[];
        borderWith?: number;
    }[];
    id?: string;
};
export interface StatusRendering extends ComputedWorkflowStatus {
    piechart: NGPieChart;
    documentsChart?: NGPieChart;
    tokensChart?: NGPieChart;
    childs?: StatusRendering[];
    id?: string;
}
//# sourceMappingURL=graphic-rendering.d.ts.map