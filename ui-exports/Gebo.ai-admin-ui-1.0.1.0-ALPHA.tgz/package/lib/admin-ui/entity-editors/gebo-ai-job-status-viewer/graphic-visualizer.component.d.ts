import { OnChanges, OnInit, SimpleChanges } from "@angular/core";
import { NGPieChart, StatusRendering } from "./graphic-rendering";
import { GeboAITranslationService, UIExistingText } from "@Gebo.ai/reusable-ui";
import * as i0 from "@angular/core";
export declare class GeboAIJobGraphicVisualizerComponent implements OnInit, OnChanges {
    private geboTranslationService;
    constructor(geboTranslationService: GeboAITranslationService);
    rendered?: StatusRendering;
    protected viewed?: StatusRendering;
    pieOptions: {
        plugins: {
            legend: {
                labels: {
                    usePointStyle: boolean;
                    color: string;
                };
            };
        };
    };
    basicOptions: {
        plugins: {
            legend: {
                labels: {
                    color: string;
                };
            };
        };
        scales: {
            x: {
                ticks: {
                    color: string;
                };
                grid: {
                    color: string;
                };
            };
            y: {
                beginAtZero: boolean;
                ticks: {
                    color: string;
                };
                grid: {
                    color: string;
                };
            };
        };
    };
    ngOnInit(): void;
    private subscription?;
    private treeTranslate;
    private reapplyTextResources;
    private stripTextResources;
    private addResources;
    applyResources(translations: UIExistingText[] | undefined, chart: NGPieChart): void;
    ngOnChanges(changes: SimpleChanges): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<GeboAIJobGraphicVisualizerComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<GeboAIJobGraphicVisualizerComponent, "gebo-ai-jobsummary-graphic-visualizer", never, { "rendered": { "alias": "rendered"; "required": false; }; }, {}, never, never, false, never>;
}
