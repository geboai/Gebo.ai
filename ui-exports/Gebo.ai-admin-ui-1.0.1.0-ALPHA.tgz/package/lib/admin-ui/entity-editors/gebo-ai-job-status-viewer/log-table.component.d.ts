/**
 * This Source Code is subject to the terms of the
 * Gebo.ai community version Mozilla Public License Version 2.0 (MPL-2.0) — With Data Protection Clauses
 * If a copy of the LICENCE was not distributed with this file, You can obtain one at
 * https://gebo.ai/gebo-ai-community-version-mozilla-public-license-version-2-0-mpl-2-0-with-data-protection-clauses/
 * and https://mozilla.org/MPL/2.0/.
 * Copyright (c) 2025+ Gebo.ai
 */
/**
 * AI generated comments
 *
 * LogTableComponent is responsible for displaying a paginated table of job status items.
 * This component can fetch logs based on either className or jobType parameters, and handles
 * pagination, selection, deletion, and displaying details of log entries.
 */
import { OnChanges, SimpleChanges } from "@angular/core";
import { FormGroup } from "@angular/forms";
import { DataPage, GJobStatusItem, GObjectRefGProjectEndpoint, JobsEntriesForJobType, LogViewControllerService, PageGJobStatusItem } from "@Gebo.ai/gebo-ai-rest-api";
import { GeboUIActionRoutingService } from "@Gebo.ai/reusable-ui";
import { PaginatorState } from "primeng/paginator";
import * as i0 from "@angular/core";
export declare class LogTableComponent implements OnChanges {
    private logViewControllerService;
    private geboUIActionRoutingService;
    /** Class name used to filter log entries */
    className?: string;
    /** Job type enumeration to filter log entries */
    jobType?: JobsEntriesForJobType.JobTypeEnum;
    /** Project endpoint reference to filter log entries */
    endPointReference?: GObjectRefGProjectEndpoint;
    /** Indicates whether data is currently being loaded */
    loading: boolean;
    /** Pagination information */
    page: DataPage;
    /** Raw paginated data returned from the API */
    data?: PageGJobStatusItem;
    /** Processed job status items */
    actualData: GJobStatusItem[];
    /** Form group for the component */
    formGroup: FormGroup;
    /**
     * Initializes the component with required services
     * @param logViewControllerService Service to interact with log-related API endpoints
     * @param geboUIActionRoutingService Service to handle UI action routing
     */
    constructor(logViewControllerService: LogViewControllerService, geboUIActionRoutingService: GeboUIActionRoutingService);
    /**
     * Lifecycle hook that responds to input property changes
     * Loads data when className or jobType changes
     * @param changes Object containing changed properties
     */
    ngOnChanges(changes: SimpleChanges): void;
    /**
     * Handles pagination events and reloads data with new pagination parameters
     * @param value PaginatorState containing page information
     */
    onPageChange(value: PaginatorState): void;
    /**
     * Opens a detailed view of a job status item
     * @param item The job status item to display details for
     */
    showItem(item: GJobStatusItem): void;
    /**
     * Selects all items in the current view
     * Note: Placeholder method - implementation pending
     */
    selectAll(): void;
    /**
     * Deletes all selected job status items
     * Filters items marked as selected and calls the API to delete them
     */
    deleteSelected(): void;
    /**
     * Resets pagination and reloads data
     * Useful for refreshing the table after operations that modify the dataset
     */
    reloadData(): void;
    /**
     * Fetches job status data based on input parameters
     * Uses either endpoint reference or className to retrieve data
     * Updates component state with the fetched data
     */
    private loadData;
    static ɵfac: i0.ɵɵFactoryDeclaration<LogTableComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<LogTableComponent, "gebo-ai-log-table-component", never, { "className": { "alias": "className"; "required": false; }; "jobType": { "alias": "jobType"; "required": false; }; "endPointReference": { "alias": "endPointReference"; "required": false; }; }, {}, never, never, false, never>;
}
//# sourceMappingURL=log-table.component.d.ts.map