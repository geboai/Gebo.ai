/**
 * This Source Code is subject to the terms of the
 * Gebo.ai community version Mozilla Public License Version 2.0 (MPL-2.0) — With Data Protection Clauses
 * If a copy of the LICENCE was not distributed with this file, You can obtain one at
 * https://gebo.ai/gebo-ai-community-version-mozilla-public-license-version-2-0-mpl-2-0-with-data-protection-clauses/
 * and https://mozilla.org/MPL/2.0/.
 * Copyright (c) 2025+ Gebo.ai
 */
/**
 * AI generated comments
 * Module for managing and displaying job status information, including content reading and vectorization tasks.
 * This component provides visualization of job progress, task completion statistics, and log messages.
 */
import { Injector, SimpleChanges } from '@angular/core';
import { FormGroup } from "@angular/forms";
import { CompanySystemsControllerService, DataPage, GJobStatus, JobLauncherControllerService, JobSummary, LogViewControllerService, PageGUserMessage, SystemInfos } from "@Gebo.ai/gebo-ai-rest-api";
import { BaseEntityEditingComponent, GeboFormGroupsService, GeboUIActionRoutingService, GeboUIOutputForwardingService } from "@Gebo.ai/reusable-ui";
import { ConfirmationService, ToastMessageOptions } from 'primeng/api';
import { PaginatorState } from 'primeng/paginator';
import { Observable } from "rxjs";
import { StatusRendering } from './graphic-rendering';
import * as i0 from "@angular/core";
export declare class GeboAIJobStatusViewerComponent extends BaseEntityEditingComponent<GJobStatus> {
    private JobLauncherControllerService;
    private logViewControllerService;
    private companySystemsControllerService;
    /**
     * The name of the entity this component manages
     */
    protected entityName: string;
    /**
     * Title displayed for the job, changes based on job type
     */
    jobTitle: string;
    /**
     * Form group for managing form controls
     */
    formGroup: FormGroup<any>;
    /**
     * Information about the system the job is running on
     */
    systemInfos?: SystemInfos;
    /**
     * Summary information about the current job
     */
    jobSummary?: JobSummary;
    /**
     * Collection of log messages from the job execution
     */
    logMessages: ToastMessageOptions[];
    /**
     * Number of rows to display in the paginated view
     */
    nRows: number;
    /**
     * Current pagination state
     */
    actualPage: DataPage;
    /**
     * Current page of user messages
     */
    actualPageData?: PageGUserMessage;
    rootGraphicData?: StatusRendering;
    /**
     * Component constructor that initializes services and triggers initial data refresh
     */
    constructor(injector: Injector, geboFormGroupsService: GeboFormGroupsService, JobLauncherControllerService: JobLauncherControllerService, confirmService: ConfirmationService, logViewControllerService: LogViewControllerService, geboUIActionRoutingService: GeboUIActionRoutingService, companySystemsControllerService: CompanySystemsControllerService, outputForwardingService?: GeboUIOutputForwardingService);
    /**
     * Lifecycle hook for component initialization
     */
    ngOnInit(): void;
    /**
     * Responds to changes in component inputs.
     * Loads system information when entity changes.
     */
    ngOnChanges(changes: SimpleChanges): void;
    /**
     * Periodically reloads job status data until the job is completed.
     * Fetches job status, messages, and summary information.
     */
    private reloadPeriodically;
    /**
     * Refreshes all chart graphics with the latest job summary data.
     * Creates and updates chart data structures for visualization.
     */
    private refreshGraphics;
    /**
     * Formats timestamp into a readable time string
     * @param timestamp The timestamp to format
     * @returns Formatted time string
     */
    totsString(timestamp: Date | undefined): any;
    /**
     * Handles paginator state changes and reloads data with new pagination parameters
     * @param value The new paginator state
     */
    onPageChange(value: PaginatorState): void;
    /**
     * Processes the loaded job status data and updates the job title based on job type
     * @param actualValue The loaded GJobStatus entity
     */
    protected onLoadedPersistentData(actualValue: GJobStatus): void;
    /**
     * Manually triggers data reload
     */
    reloadData(): void;
    /**
     * Retrieves a job status by its code
     * @param code The job code to lookup
     * @returns Observable containing the job status or null
     */
    findByCode(code: string): Observable<GJobStatus | null>;
    /**
     * Not implemented - saving is not supported for job status
     */
    save(value: GJobStatus): Observable<GJobStatus>;
    /**
     * Not implemented - insertion is not supported for job status
     */
    insert(value: GJobStatus): Observable<GJobStatus>;
    /**
     * Deletes a job status entry by its code
     * @param value The job status to delete
     * @returns Observable indicating success or failure
     */
    delete(value: GJobStatus): Observable<boolean>;
    /**
     * Determines if a job status can be deleted based on whether it's finished
     * @param value The job status to check
     * @returns Observable containing deletion permission and message
     */
    canBeDeleted(value: GJobStatus): Observable<{
        canBeDeleted: boolean;
        message: string;
    }>;
    static ɵfac: i0.ɵɵFactoryDeclaration<GeboAIJobStatusViewerComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<GeboAIJobStatusViewerComponent, "gebo-ai-job-status-viewer-component", never, {}, {}, never, never, false, never>;
}
//# sourceMappingURL=gebo-ai-job-status-viewer.component.d.ts.map