/**
 * This Source Code is subject to the terms of the
 * Gebo.ai community version Mozilla Public License Version 2.0 (MPL-2.0) — With Data Protection Clauses
 * If a copy of the LICENCE was not distributed with this file, You can obtain one at
 * https://gebo.ai/gebo-ai-community-version-mozilla-public-license-version-2-0-mpl-2-0-with-data-protection-clauses/
 * and https://mozilla.org/MPL/2.0/.
 * Copyright (c) 2025+ Gebo.ai
 */
import { EventEmitter, OnChanges, OnInit, SimpleChanges } from "@angular/core";
import { FileSystemSharesSettingControllerService, GFileSystemShareReference, SharedFilesystemUIConfig } from "@Gebo.ai/gebo-ai-rest-api";
import { GeboUIActionRoutingService } from "@Gebo.ai/reusable-ui";
import * as i0 from "@angular/core";
/**
 * AI generated comments
 *
 * Component that manages the display and interaction with shared filesystems.
 * This component allows users to view, open, and create new filesystem shares.
 * It communicates with the backend services to fetch shared filesystem configurations
 * and uses the GeboUIActionRoutingService to handle navigation and actions.
 */
export declare class GeboAISharedFilesystemsComponent implements OnInit, OnChanges {
    private fileSystemSharesSettingControllerService;
    private geboUIRoutinService;
    /** Flag to indicate if data is currently being loaded */
    loading: boolean;
    /** Controls the visibility of the component */
    visible: boolean;
    /** Event emitter that fires when the component is closed */
    closed: EventEmitter<boolean>;
    /** Configuration for the shared filesystem UI */
    sharedFilesystemConfig?: SharedFilesystemUIConfig;
    /** List of available filesystem shares */
    shares: GFileSystemShareReference[];
    /**
     * Initializes the component with necessary services
     * @param fileSystemSharesSettingControllerService Service to interact with filesystem shares API
     * @param geboUIRoutinService Service to handle UI routing actions
     */
    constructor(fileSystemSharesSettingControllerService: FileSystemSharesSettingControllerService, geboUIRoutinService: GeboUIActionRoutingService);
    /**
     * Lifecycle hook that is called after component initialization
     */
    ngOnInit(): void;
    /**
     * Handles the closing of the component and emits an event to the parent
     * @param e Event that triggered the close
     */
    closeMe(e: any): void;
    /**
     * Loads the shared filesystem configuration data from the backend service.
     * Updates the component with the fetched shares and configurations.
     */
    loadData(): void;
    /**
     * Angular lifecycle hook that responds to changes in component inputs.
     * Loads data when the component becomes visible.
     * @param changes Object containing all changed input properties
     */
    ngOnChanges(changes: SimpleChanges): void;
    /**
     * Opens a specific file share for viewing or editing
     * Uses the GeboUIRoutingService to navigate to the appropriate view
     * @param value The file share reference to be opened
     */
    openFileShare(value: GFileSystemShareReference): void;
    /**
     * Creates a new file share
     * Initializes with default MongoDB configuration and routes to the creation view
     */
    newFileShare(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<GeboAISharedFilesystemsComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<GeboAISharedFilesystemsComponent, "gebo-ai-shared-filesystem-component", never, { "visible": { "alias": "visible"; "required": false; }; }, { "closed": "closed"; }, never, never, false, never>;
}
//# sourceMappingURL=gebo-ai-shared-filesystems.component.d.ts.map