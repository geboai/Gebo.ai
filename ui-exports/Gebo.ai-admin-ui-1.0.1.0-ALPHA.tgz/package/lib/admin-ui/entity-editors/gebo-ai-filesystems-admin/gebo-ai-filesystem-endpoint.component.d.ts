/**
 * This Source Code is subject to the terms of the
 * Gebo.ai community version Mozilla Public License Version 2.0 (MPL-2.0) — With Data Protection Clauses
 * If a copy of the LICENCE was not distributed with this file, You can obtain one at
 * https://gebo.ai/gebo-ai-community-version-mozilla-public-license-version-2-0-mpl-2-0-with-data-protection-clauses/
 * and https://mozilla.org/MPL/2.0/.
 * Copyright (c) 2025+ Gebo.ai
 */
import { Injector } from "@angular/core";
import { FormGroup } from "@angular/forms";
import { FileSystemsBrowsingControllerService, FileSystemsControllerService, GFilesystemProjectEndpoint, GProject, JobLauncherControllerService, ProjectsControllerService } from "@Gebo.ai/gebo-ai-rest-api";
import { BaseEntityEditingComponent, browsePathObservableCallback, GeboAIFileType, GeboFormGroupsService, GeboUIActionRoutingService, GeboUIOutputForwardingService, loadRootsObservableCallback, reconstructNavigationObservableCallback } from "@Gebo.ai/reusable-ui";
import { ConfirmationService } from "primeng/api";
import { Observable } from "rxjs";
import * as i0 from "@angular/core";
/**
 * Component for managing filesystem endpoints within Gebo.ai.
 * Handles creation, editing, and management of GFilesystemProjectEndpoint entities.
 * Provides UI functionality for browsing file systems, uploading files, and managing endpoint configuration.
 * Extends BaseEntityEditingComponent to handle common entity editing operations.
 */
export declare class GeboAIFileSystemEndpointComponent extends BaseEntityEditingComponent<GFilesystemProjectEndpoint> {
    private filesystemsControllerService;
    private filesystemsBrowsing;
    private projectsController;
    private JobLauncherControllerService;
    private actionsRouter;
    protected entityName: string;
    handShakeCode?: string;
    /** Controls whether the project can be modified */
    cantModifyProject: boolean;
    /** Observable for retrieving available projects */
    projectsObservable: Observable<GProject[]>;
    /** Form group for managing form controls */
    formGroup: FormGroup<any>;
    /** Tracks the published state of the endpoint */
    published: boolean;
    /** Callback for loading filesystem roots */
    loadRootsObservable: loadRootsObservableCallback;
    /** Callback for browsing filesystem paths */
    browsePathObservable: browsePathObservableCallback;
    /** Callback for reconstructing navigation based on navigation points */
    reconstructNavigationObservableCallback: reconstructNavigationObservableCallback;
    /** List of file types available for selection */
    fileTypesList: GeboAIFileType[];
    /**
     * Constructor for the component, initializes services and parent class.
     * Sets up subscription to published value changes and enables backend processing check.
     */
    constructor(injector: Injector, geboFormGroupsService: GeboFormGroupsService, filesystemsControllerService: FileSystemsControllerService, filesystemsBrowsing: FileSystemsBrowsingControllerService, projectsController: ProjectsControllerService, JobLauncherControllerService: JobLauncherControllerService, actionsRouter: GeboUIActionRoutingService, confirmService: ConfirmationService, outputForwardingService?: GeboUIOutputForwardingService);
    /**
     * Checks if there are any running backend jobs for the entity
     * @param reference The reference object to check for running jobs
     * @returns An Observable<boolean> indicating if there are running jobs
     */
    protected checkBackendProcessing(reference: {
        className?: string;
        code?: string;
    }): Observable<boolean>;
    /**
     * Lifecycle hook for component initialization
     * Calls parent initialization method
     */
    ngOnInit(): void;
    /**
     * Handles actions when new data is created
     * @param actualValue The new filesystem endpoint data
     */
    protected onNewData(actualValue: GFilesystemProjectEndpoint): void;
    /**
     * Handles actions when persistent data is loaded
     * @param actualValue The loaded filesystem endpoint data
     */
    protected onLoadedPersistentData(actualValue: GFilesystemProjectEndpoint): void;
    /**
     * Finds a filesystem endpoint by its code
     * @param code The code to search for
     * @returns An Observable with the found endpoint or null
     */
    findByCode(code: string): Observable<GFilesystemProjectEndpoint | null>;
    /**
     * Saves an existing filesystem endpoint
     * @param value The endpoint to save
     * @returns An Observable with the saved endpoint
     */
    save(value: GFilesystemProjectEndpoint): Observable<GFilesystemProjectEndpoint>;
    /**
     * Inserts a new filesystem endpoint
     * @param value The endpoint to insert
     * @returns An Observable with the inserted endpoint
     */
    insert(value: GFilesystemProjectEndpoint): Observable<GFilesystemProjectEndpoint>;
    /**
     * Deletes a filesystem endpoint
     * @param value The endpoint to delete
     * @returns An Observable indicating success or failure
     */
    delete(value: GFilesystemProjectEndpoint): Observable<boolean>;
    /**
     * Checks if the endpoint can be deleted
     * @param value The endpoint to check
     * @returns An Observable with the result and any message
     */
    canBeDeleted(value: GFilesystemProjectEndpoint): Observable<{
        canBeDeleted: boolean;
        message: string;
    }>;
    /**
     * Performs both save and publish operations
     * Uses the utility function doSaveAndPublishCall
     */
    doSaveAndPublish(): void;
    /**
     * Performs the publish operation for the endpoint
     * Creates a job to process the endpoint and opens the job status view
     */
    doPublish(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<GeboAIFileSystemEndpointComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<GeboAIFileSystemEndpointComponent, "gebo-ai-filesystem-endpoint-component", never, { "cantModifyProject": { "alias": "cantModifyProject"; "required": false; }; }, {}, never, never, false, never>;
}
