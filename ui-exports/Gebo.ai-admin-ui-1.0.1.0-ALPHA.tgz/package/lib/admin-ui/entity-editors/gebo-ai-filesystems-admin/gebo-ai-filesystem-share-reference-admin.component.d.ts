/**
 * This Source Code is subject to the terms of the
 * Gebo.ai community version Mozilla Public License Version 2.0 (MPL-2.0) — With Data Protection Clauses
 * If a copy of the LICENCE was not distributed with this file, You can obtain one at
 * https://gebo.ai/gebo-ai-community-version-mozilla-public-license-version-2-0-mpl-2-0-with-data-protection-clauses/
 * and https://mozilla.org/MPL/2.0/.
 * Copyright (c) 2025+ Gebo.ai
 */
/**
 * AI generated comments
 *
 * This component manages filesystem share references in the Gebo.ai system.
 * It extends BaseEntityEditingComponent to provide CRUD operations for GFileSystemShareReference entities.
 * The component handles validation, filesystem navigation, and communication with backend services.
 */
import { Injector } from "@angular/core";
import { FormGroup } from "@angular/forms";
import { FileSystemSharesSettingControllerService, GFileSystemShareReference } from "@Gebo.ai/gebo-ai-rest-api";
import { BaseEntityEditingComponent, browsePathObservableCallback, GeboFormGroupsService, GeboUIActionRoutingService, GeboUIOutputForwardingService, loadRootsObservableCallback, reconstructNavigationObservableCallback } from "@Gebo.ai/reusable-ui";
import { ConfirmationService } from "primeng/api";
import { Observable } from "rxjs";
import * as i0 from "@angular/core";
/**
 * Component responsible for administering GFileSystemShareReference entities
 * Provides UI for creating, viewing, editing, and deleting filesystem share references
 * Uses Angular Forms for data entry and validation
 */
export declare class GeboAIGFileSystemShareReferenceAdminComponent extends BaseEntityEditingComponent<GFileSystemShareReference> {
    private fileSystemSharesSettingControllerService;
    /**
     * Defines the entity name for this component
     */
    protected entityName: string;
    /**
     * Form group that captures and validates user input for the filesystem share reference
     * Contains fields for code, description, mongoConfigured flag, and the actual reference
     */
    formGroup: FormGroup<any>;
    /**
     * Observable callback to load the root filesystem nodes
     * Used for navigation tree population
     */
    loadRootsObservable: loadRootsObservableCallback;
    /**
     * Observable callback to browse filesystem path
     * Used for navigating through the filesystem hierarchy
     */
    browsePathObservable: browsePathObservableCallback;
    /**
     * Observable callback to reconstruct navigation from points
     * Used for restoring navigation state
     */
    reconstructNavigationObservableCallback: reconstructNavigationObservableCallback;
    /**
     * Component constructor that injects required services
     *
     * @param injector Angular injector for dependency injection
     * @param fileSystemSharesSettingControllerService Service for filesystem share operations
     * @param geboFormGroupsService Service for form group management
     * @param confirmationService Service for user confirmations
     * @param geboUIActionRoutingService Service for UI action routing
     * @param outputForwardingService Optional service for output forwarding
     */
    constructor(injector: Injector, fileSystemSharesSettingControllerService: FileSystemSharesSettingControllerService, geboFormGroupsService: GeboFormGroupsService, confirmationService: ConfirmationService, geboUIActionRoutingService: GeboUIActionRoutingService, outputForwardingService?: GeboUIOutputForwardingService);
    /**
     * Angular lifecycle hook that initializes the component
     * Calls the parent class initialization
     */
    ngOnInit(): void;
    /**
     * Checks if the provided filesystem share reference can be inserted
     * Validates the entity against backend rules
     *
     * @param value The filesystem share reference to validate
     * @returns Observable containing validation result and message
     */
    canBeInserted(value: GFileSystemShareReference): Observable<{
        canBeInserted: boolean;
        message: string;
    }>;
    /**
     * Retrieves a filesystem share reference by its code
     *
     * @param code The unique code of the filesystem share reference
     * @returns Observable with the found entity or null
     */
    findByCode(code: string): Observable<GFileSystemShareReference | null>;
    /**
     * Updates an existing filesystem share reference
     * This method is not implemented and throws an error when called
     *
     * @param value The filesystem share reference to update
     * @throws Error indicating the method is not implemented
     */
    save(value: GFileSystemShareReference): Observable<GFileSystemShareReference>;
    /**
     * Creates a new filesystem share reference
     *
     * @param value The filesystem share reference to create
     * @returns Observable with the created entity
     */
    insert(value: GFileSystemShareReference): Observable<GFileSystemShareReference>;
    /**
     * Deletes a filesystem share reference
     *
     * @param value The filesystem share reference to delete
     * @returns Observable indicating success/failure
     */
    delete(value: GFileSystemShareReference): Observable<boolean>;
    /**
     * Checks if the provided filesystem share reference can be deleted
     * Currently always returns true with no validation
     *
     * @param value The filesystem share reference to check
     * @returns Observable with deletion permission status
     */
    canBeDeleted(value: GFileSystemShareReference): Observable<{
        canBeDeleted: boolean;
        message: string;
    }>;
    static ɵfac: i0.ɵɵFactoryDeclaration<GeboAIGFileSystemShareReferenceAdminComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<GeboAIGFileSystemShareReferenceAdminComponent, "gebo-ai-filesystem-share-reference-admin-component", never, {}, {}, never, never, false, never>;
}
