import { Injector } from "@angular/core";
import { FormGroup } from "@angular/forms";
import { ChatModelsControllerService, CompanySystemsControllerService, GKnowledgeBase, GObjectRef, GObjectRefGBaseModelConfig, GProject, GraphRagConfigurationControllerService, GraphRagExtractionConfig, KnowledgeBaseControllerService, ProjectsControllerService } from "@Gebo.ai/gebo-ai-rest-api";
import { BaseEntityEditingComponent, GeboFormGroupsService, GeboUIActionRoutingService, GeboUIOutputForwardingService } from "@Gebo.ai/reusable-ui";
import { ConfirmationService } from "primeng/api";
import { Observable } from "rxjs";
import * as i0 from "@angular/core";
export declare class GeboAIGraphRagExtractionConfigComponent extends BaseEntityEditingComponent<GraphRagExtractionConfig> {
    private geboChatModels;
    private graphRagExtractionConfigService;
    private knowledgeBaseService;
    private projectsService;
    private systemsService;
    protected entityName: string;
    formGroup: FormGroup<any>;
    protected systemConfiguration?: GraphRagExtractionConfig;
    /** Available chat models to choose from */
    protected chatModelsData?: GObjectRefGBaseModelConfig[];
    protected knowledgeBase?: GKnowledgeBase;
    protected project?: GProject;
    protected dataSource?: GObjectRef;
    protected defaultConfiguration: boolean;
    protected graphRagAllSources: boolean;
    protected processEveryDocument: boolean | undefined;
    /** The default chat model configuration */
    protected defaultChatModel?: {
        code?: string;
        description?: string;
    };
    protected configurationLabel?: string;
    protected extractionFormats: {
        code: GraphRagExtractionConfig.ExtractionFormatEnum;
        description: string;
    }[];
    constructor(injector: Injector, geboFormGroupsService: GeboFormGroupsService, confirmationService: ConfirmationService, geboUIActionRoutingService: GeboUIActionRoutingService, outputForwardingService: GeboUIOutputForwardingService, geboChatModels: ChatModelsControllerService, graphRagExtractionConfigService: GraphRagConfigurationControllerService, knowledgeBaseService: KnowledgeBaseControllerService, projectsService: ProjectsControllerService, systemsService: CompanySystemsControllerService);
    ngOnInit(): void;
    private loadLookups;
    protected onLoadedPersistentData(actualValue: GraphRagExtractionConfig): void;
    protected onNewData(actualValue: GraphRagExtractionConfig): void;
    findByCode(code: string): Observable<GraphRagExtractionConfig | null>;
    save(value: GraphRagExtractionConfig): Observable<GraphRagExtractionConfig>;
    insert(value: GraphRagExtractionConfig): Observable<GraphRagExtractionConfig>;
    delete(value: GraphRagExtractionConfig): Observable<boolean>;
    canBeDeleted(value: GraphRagExtractionConfig): Observable<{
        canBeDeleted: boolean;
        message: string;
    }>;
    static ɵfac: i0.ɵɵFactoryDeclaration<GeboAIGraphRagExtractionConfigComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<GeboAIGraphRagExtractionConfigComponent, "gebo-ai-graph-rag-extraction-config-component", never, {}, {}, never, never, false, never>;
}
