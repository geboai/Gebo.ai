/**
 * This Source Code is subject to the terms of the
 * Gebo.ai community version Mozilla Public License Version 2.0 (MPL-2.0) — With Data Protection Clauses
 * If a copy of the LICENCE was not distributed with this file, You can obtain one at
 * https://gebo.ai/gebo-ai-community-version-mozilla-public-license-version-2-0-mpl-2-0-with-data-protection-clauses/
 * and https://mozilla.org/MPL/2.0/.
 * Copyright (c) 2025+ Gebo.ai
 */
/**
 * AI generated comments
 * This component handles the Google Workspace access integration for Gebo.ai.
 * It manages the authentication flow between the user's Google Workspace account
 * and the Gebo.ai application, handling both initial authentication and cases
 * where credentials already exist.
 */
import { EventEmitter, OnChanges, OnInit, SimpleChanges } from "@angular/core";
import { FormGroup } from "@angular/forms";
import { ActivatedRoute, Router } from "@angular/router";
import { GoogleWorkspaceAccessHandshakeControllerService, StartGooglWorkspaceAccessRespose, UserControllerService } from "@Gebo.ai/gebo-ai-rest-api";
import { ToastMessageOptions } from "primeng/api";
import * as i0 from "@angular/core";
export declare class GeboAIGoogleWorkspaceAccessComponent implements OnInit, OnChanges {
    private googleWorkspaceAccessHandshakeService;
    private usersControllo;
    private router;
    private activatedRoute;
    /**
     * Form group to manage user input for the Google Workspace access
     */
    formGroup: FormGroup;
    /**
     * Flag to indicate whether a loading process is active
     */
    loading: boolean;
    /**
     * Stores the response data from the Google Workspace access handshake
     */
    handshakeData?: StartGooglWorkspaceAccessRespose;
    /**
     * Flag to indicate whether the access authorization process has started
     */
    accessStarted: boolean;
    /**
     * URL to navigate to on successful handshake
     */
    uiSuccessForward: string;
    /**
     * URL to navigate to on handshake failure
     */
    uiErrorForward: string;
    /**
     * Event emitter triggered when user already has an existing Google account connected
     */
    alreadyExistingAccount: EventEmitter<true>;
    /**
     * Collection of user-facing messages to display
     */
    userMessages: ToastMessageOptions[];
    /**
     * Constructor initializes the component with necessary services
     * @param googleWorkspaceAccessHandshakeService Service to handle Google Workspace access
     * @param usersControllo Service to get user information
     * @param router Angular router service for navigation
     * @param activatedRoute Current activated route
     */
    constructor(googleWorkspaceAccessHandshakeService: GoogleWorkspaceAccessHandshakeControllerService, usersControllo: UserControllerService, router: Router, activatedRoute: ActivatedRoute);
    /**
     * Lifecycle hook that initializes the component.
     * Gets the current user and sets up initial form data and messages.
     */
    ngOnInit(): void;
    /**
     * Lifecycle hook that responds to changes in component inputs
     * @param changes SimpleChanges object containing changed properties
     */
    ngOnChanges(changes: SimpleChanges): void;
    /**
     * Initiates the Google Workspace access handshake process.
     * Handles both new integrations and cases where credentials already exist.
     * If successful, either emits an event for existing accounts or redirects
     * the user to the Google authorization page.
     */
    doTryAccess(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<GeboAIGoogleWorkspaceAccessComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<GeboAIGoogleWorkspaceAccessComponent, "gebo-ai-google-workspace-access-component", never, { "uiSuccessForward": { "alias": "uiSuccessForward"; "required": false; }; "uiErrorForward": { "alias": "uiErrorForward"; "required": false; }; }, { "alreadyExistingAccount": "alreadyExistingAccount"; }, never, never, false, never>;
}
