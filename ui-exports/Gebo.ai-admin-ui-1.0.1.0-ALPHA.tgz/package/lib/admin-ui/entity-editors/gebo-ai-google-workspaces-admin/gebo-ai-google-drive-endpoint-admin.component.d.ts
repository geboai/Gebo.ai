/**
 * This Source Code is subject to the terms of the
 * Gebo.ai community version Mozilla Public License Version 2.0 (MPL-2.0) — With Data Protection Clauses
 * If a copy of the LICENCE was not distributed with this file, You can obtain one at
 * https://gebo.ai/gebo-ai-community-version-mozilla-public-license-version-2-0-mpl-2-0-with-data-protection-clauses/
 * and https://mozilla.org/MPL/2.0/.
 * Copyright (c) 2025+ Gebo.ai
 */
/**
 * AI generated comments
 *
 * This component manages Google Drive project endpoints in the Gebo.ai system.
 * It handles creating, editing, and deleting Google Drive endpoints that connect
 * projects with Google Drive systems. The component provides functionality for
 * browsing Google Drive contents, managing synchronization settings, and handling
 * authentication with Google Workspace.
 */
import { Injector } from "@angular/core";
import { FormGroup } from "@angular/forms";
import { GGoogleDriveProjectEndpoint, GGoogleDriveSystem, GoogleDriveBrowsingControllerService, GoogleDriveSystemsControllerService, GProject, JobLauncherControllerService, ProjectsControllerService } from "@Gebo.ai/gebo-ai-rest-api";
import { BaseEntityEditingComponent, browsePathObservableCallback, GeboAIFileType, GeboFormGroupsService, GeboUIActionRequest, GeboUIActionRoutingService, GeboUIOutputForwardingService, loadRootsObservableCallback } from "@Gebo.ai/reusable-ui";
import { ConfirmationService } from "primeng/api";
import { Observable } from "rxjs";
import * as i0 from "@angular/core";
export declare class GeboAiGoogleDriveProjectEndpointAdminComponent extends BaseEntityEditingComponent<GGoogleDriveProjectEndpoint> {
    private _confirmationService;
    private projectsController;
    private googleDriveBrowsing;
    private googleDriveSystemsControllerService;
    private JobLauncherControllerService;
    private actionsRouter;
    /**
     * Entity name identifier for the Google Drive project endpoint
     */
    protected entityName: string;
    /**
     * Context identifier for Google Workspace authentication
     */
    private actualIdentityContext;
    /**
     * Form group containing all editable fields for the Google Drive project endpoint
     */
    formGroup: FormGroup<any>;
    /**
     * Observable that fetches the list of available projects
     */
    projectsObservable: Observable<GProject[]>;
    /**
     * Array of available Google Drive systems
     */
    drivesObservable: Observable<GGoogleDriveSystem[]>;
    /**
     * UI action request template for creating a new Google Drive system
     */
    newGoogleDriveRequest: GeboUIActionRequest;
    /**
     * Flag indicating if Google Drive systems exist in the environment
     */
    googleDriveSystemsExisting: boolean;
    /**
     * Flag indicating if the endpoint is published
     */
    published: boolean;
    /**
     * Observable callback for loading root directories from Google Drive
     */
    loadRootsObservable: loadRootsObservableCallback;
    /**
     * Observable callback for browsing directories within a Google Drive path
     */
    browsePathObservable: browsePathObservableCallback;
    /**
     * URL to forward to on successful operations
     */
    uiSuccessForward: string;
    /**
     * URL to forward to on failed operations
     */
    uiErrorForward: string;
    /**
     * Tracks the last selected Google Drive system code for change detection
     */
    private lastDriveSystemCode;
    /**
     * List of supported file types for vectorization
     */
    fileTypesList: GeboAIFileType[];
    /**
     * Component constructor that initializes services and sets up subscriptions
     * for reactive form handling and Google Drive browsing functionality.
     */
    constructor(injector: Injector, geboFormGroupsService: GeboFormGroupsService, _confirmationService: ConfirmationService, projectsController: ProjectsControllerService, googleDriveBrowsing: GoogleDriveBrowsingControllerService, googleDriveSystemsControllerService: GoogleDriveSystemsControllerService, JobLauncherControllerService: JobLauncherControllerService, actionsRouter: GeboUIActionRoutingService, outputForwardingService: GeboUIOutputForwardingService);
    /**
     * Retrieves a Google Drive project endpoint by its code
     * @param code The unique identifier code of the endpoint
     * @returns An observable of the found endpoint or null
     */
    findByCode(code: string): Observable<GGoogleDriveProjectEndpoint | null>;
    /**
     * Saves changes to an existing Google Drive project endpoint
     * @param value The endpoint object with updated values
     * @returns An observable of the updated endpoint
     */
    save(value: GGoogleDriveProjectEndpoint): Observable<GGoogleDriveProjectEndpoint>;
    /**
     * Creates a new Google Drive project endpoint
     * @param value The new endpoint object to create
     * @returns An observable of the created endpoint
     */
    insert(value: GGoogleDriveProjectEndpoint): Observable<GGoogleDriveProjectEndpoint>;
    /**
     * Deletes a Google Drive project endpoint
     * @param value The endpoint object to delete
     * @returns An observable indicating success (true) or failure
     */
    delete(value: GGoogleDriveProjectEndpoint): Observable<boolean>;
    /**
     * Checks if an endpoint can be safely deleted
     * @param value The endpoint to check
     * @returns An observable with deletion status and explanation message
     */
    canBeDeleted(value: GGoogleDriveProjectEndpoint): Observable<{
        canBeDeleted: boolean;
        message: string;
    }>;
    /**
     * Initializes the component and loads required data
     */
    ngOnInit(): void;
    /**
     * Publishes the endpoint by creating a background job to process it
     * This triggers synchronization and indexing of Google Drive content
     */
    doPublish(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<GeboAiGoogleDriveProjectEndpointAdminComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<GeboAiGoogleDriveProjectEndpointAdminComponent, "gebo-ai-google-drive-endpoint-admin-component", never, {}, {}, never, never, false, never>;
}
