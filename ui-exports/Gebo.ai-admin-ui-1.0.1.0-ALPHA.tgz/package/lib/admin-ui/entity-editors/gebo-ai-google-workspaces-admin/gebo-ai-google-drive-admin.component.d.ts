/**
 * This Source Code is subject to the terms of the
 * Gebo.ai community version Mozilla Public License Version 2.0 (MPL-2.0) — With Data Protection Clauses
 * If a copy of the LICENCE was not distributed with this file, You can obtain one at
 * https://gebo.ai/gebo-ai-community-version-mozilla-public-license-version-2-0-mpl-2-0-with-data-protection-clauses/
 * and https://mozilla.org/MPL/2.0/.
 * Copyright (c) 2025+ Gebo.ai
 */
/**
 * AI generated comments
 * This component provides an admin interface for managing Google Drive systems in the application.
 * It extends BaseEntityEditingComponent with specific functionality for Google Drive system CRUD operations.
 * The component handles form creation, validation, and integration with the Google Drive API services.
 */
import { Injector } from "@angular/core";
import { FormGroup } from "@angular/forms";
import { GGoogleDriveSystem, GoogleDriveSystemsControllerService, SecretInfo, SecretsControllerService } from "@Gebo.ai/gebo-ai-rest-api";
import { BaseEntityEditingComponent, GeboFormGroupsService, GeboUIActionRequest, GeboUIActionRoutingService, GeboUIOutputForwardingService } from "@Gebo.ai/reusable-ui";
import { ConfirmationService } from "primeng/api";
import { Observable } from "rxjs";
import * as i0 from "@angular/core";
export declare class GeboAiGoogleDriveSystemAdminComponent extends BaseEntityEditingComponent<GGoogleDriveSystem> {
    private googleDriveSystemsControllerService;
    private secretControllerService;
    /**
     * The name of the entity type being managed by this component
     */
    protected entityName: string;
    /**
     * Form group that contains all fields required for Google Drive system configuration
     * Includes system properties like code, description, URI, and credentials
     */
    formGroup: FormGroup<any>;
    /**
     * Identity context used for retrieving secrets related to Google Workspace
     */
    private actualIdentityContext;
    /**
     * Observable that provides a list of secret information available for Google Workspace
     */
    identitiesObservable: Observable<SecretInfo[]>;
    /**
     * Action request for creating a new secret for Google Cloud JSON credentials
     */
    newSecretAction: GeboUIActionRequest;
    /**
     * Constructor initializes the component with required services and sets up form behavior
     * Enforces that contentManagementSystemType is always 'google-drive-handler'
     */
    constructor(injector: Injector, geboFormGroupsService: GeboFormGroupsService, confirmationService: ConfirmationService, googleDriveSystemsControllerService: GoogleDriveSystemsControllerService, secretControllerService: SecretsControllerService, geboUIActionRoutingService: GeboUIActionRoutingService, outputForwardingService?: GeboUIOutputForwardingService);
    /**
     * Retrieves a Google Drive system by its code
     * @param code The unique identifier for the Google Drive system
     * @returns An Observable with the found Google Drive system or null if not found
     */
    findByCode(code: string): Observable<GGoogleDriveSystem | null>;
    /**
     * Updates an existing Google Drive system
     * @param value The Google Drive system with updated values
     * @returns An Observable with the updated Google Drive system
     */
    save(value: GGoogleDriveSystem): Observable<GGoogleDriveSystem>;
    /**
     * Creates a new Google Drive system
     * @param value The Google Drive system to be created
     * @returns An Observable with the newly created Google Drive system
     */
    insert(value: GGoogleDriveSystem): Observable<GGoogleDriveSystem>;
    /**
     * Deletes a Google Drive system
     * @param value The Google Drive system to be deleted
     * @returns An Observable with boolean indicating success or failure
     */
    delete(value: GGoogleDriveSystem): Observable<boolean>;
    /**
     * Determines if a Google Drive system can be safely deleted by checking for dependencies
     * @param value The Google Drive system to check
     * @returns An Observable with an object containing deletion status and a message
     */
    canBeDeleted(value: GGoogleDriveSystem): Observable<{
        canBeDeleted: boolean;
        message: string;
    }>;
    static ɵfac: i0.ɵɵFactoryDeclaration<GeboAiGoogleDriveSystemAdminComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<GeboAiGoogleDriveSystemAdminComponent, "gebo-ai-google-drive-system-admin-component", never, {}, {}, never, never, false, never>;
}
