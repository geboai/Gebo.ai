/**
 * This Source Code is subject to the terms of the
 * Gebo.ai community version Mozilla Public License Version 2.0 (MPL-2.0) — With Data Protection Clauses
 * If a copy of the LICENCE was not distributed with this file, You can obtain one at
 * https://gebo.ai/gebo-ai-community-version-mozilla-public-license-version-2-0-mpl-2-0-with-data-protection-clauses/
 * and https://mozilla.org/MPL/2.0/.
 * Copyright (c) 2025+ Gebo.ai
 */
/**
 * AI generated comments
 * This file defines a component for fast configuration of Google Drive integration.
 * It handles the creation of Google Drive system configurations through a form interface.
 */
import { EventEmitter, OnChanges, OnInit, SimpleChanges } from "@angular/core";
import { FormGroup } from "@angular/forms";
import { GGoogleDriveSystem, GoogleDriveSystemsControllerService } from "@Gebo.ai/gebo-ai-rest-api";
import { ToastMessageOptions } from "primeng/api";
import * as i0 from "@angular/core";
/**
 * Component that provides a form interface for quickly setting up a Google Drive integration.
 * It collects a description and JSON credentials, then sends them to the API to create
 * a new Google Drive system configuration.
 */
export declare class GeboAIGoogleDriveFastComponent implements OnInit, OnChanges {
    private googleDriveController;
    /** Flag to indicate if an API operation is in progress */
    loading: boolean;
    /** Collection of messages to display to the user */
    userMessages: ToastMessageOptions[];
    /** Event emitter that triggers when the user cancels the operation */
    cancelAction: EventEmitter<boolean>;
    /** Event emitter that triggers when a new Google Drive system is successfully created */
    insertedGoogleDriveSystemEvent: EventEmitter<GGoogleDriveSystem>;
    /** Form group containing the description and JSON content fields */
    formGroup: FormGroup;
    /**
     * Constructor that injects the Google Drive systems controller service
     * @param googleDriveController Service for interacting with Google Drive API
     */
    constructor(googleDriveController: GoogleDriveSystemsControllerService);
    /**
     * Lifecycle hook that runs when the component is initialized
     */
    ngOnInit(): void;
    /**
     * Lifecycle hook that runs when component inputs change
     * @param changes Simple changes object containing current and previous values
     */
    ngOnChanges(changes: SimpleChanges): void;
    /**
     * Handles the cancel action by emitting a cancel event
     */
    doCancel(): void;
    /**
     * Handles form submission by preparing and sending the Google Drive system
     * configuration data to the API, then emitting the result if successful
     */
    doInsert(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<GeboAIGoogleDriveFastComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<GeboAIGoogleDriveFastComponent, "gebo-ai-google-drive-fast-component", never, {}, { "cancelAction": "cancelAction"; "insertedGoogleDriveSystemEvent": "insertedGoogleDriveSystemEvent"; }, never, never, false, never>;
}
//# sourceMappingURL=gebo-ai-google-drive-fast.component.d.ts.map