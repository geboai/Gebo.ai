/**
 * This Source Code is subject to the terms of the
 * Gebo.ai community version Mozilla Public License Version 2.0 (MPL-2.0) — With Data Protection Clauses
 * If a copy of the LICENCE was not distributed with this file, You can obtain one at
 * https://gebo.ai/gebo-ai-community-version-mozilla-public-license-version-2-0-mpl-2-0-with-data-protection-clauses/
 * and https://mozilla.org/MPL/2.0/.
 * Copyright (c) 2025+ Gebo.ai
 */
/**
 * Validates if a string represents a valid URL by checking if it can be parsed
 * into a URL object with valid host, protocol, and port properties.
 *
 * @param baseUrl - The URL string to validate
 * @returns true if the URL is valid, false otherwise
 */
export declare function isValidUrl(baseUrl: string): boolean;
//# sourceMappingURL=url-ok.d.ts.map