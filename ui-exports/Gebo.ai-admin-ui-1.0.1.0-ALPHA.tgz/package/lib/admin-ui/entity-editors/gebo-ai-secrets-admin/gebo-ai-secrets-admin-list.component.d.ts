/**
 * This Source Code is subject to the terms of the
 * Gebo.ai community version Mozilla Public License Version 2.0 (MPL-2.0) — With Data Protection Clauses
 * If a copy of the LICENCE was not distributed with this file, You can obtain one at
 * https://gebo.ai/gebo-ai-community-version-mozilla-public-license-version-2-0-mpl-2-0-with-data-protection-clauses/
 * and https://mozilla.org/MPL/2.0/.
 * Copyright (c) 2025+ Gebo.ai
 */
import { EventEmitter, OnChanges, OnInit, SimpleChanges } from "@angular/core";
import { SecretInfo, SecretsControllerService } from "@Gebo.ai/gebo-ai-rest-api";
import { GeboUIActionRoutingService } from "@Gebo.ai/reusable-ui";
import * as i0 from "@angular/core";
/**
 * AI generated comments
 *
 * This component displays and manages a list of secrets for a specified context.
 * It allows creating new secrets and refreshing the list when changes occur.
 * The component interacts with the SecretsControllerService to fetch secrets data
 * and uses GeboUIActionRoutingService to handle user actions.
 */
export declare class GeboAiSecretsAdminListComponent implements OnChanges, OnInit {
    private secretsControllerService;
    private geboUIActionRoutingService;
    /** The context code for which secrets should be loaded */
    contextCode?: string;
    /** Types of secrets that can be created in this component */
    allowedTypes: SecretInfo.SecretTypeEnum[];
    /** Flag indicating whether secrets are currently being loaded */
    loading: boolean;
    /** Collection of secret information objects displayed in the list */
    secretsInfo: SecretInfo[];
    /** Event emitter that notifies parent components when the secrets list changes */
    secretsListChange: EventEmitter<boolean>;
    /**
     * Constructor initializes the required services
     * @param secretsControllerService Service for interacting with secrets API
     * @param geboUIActionRoutingService Service for routing UI actions
     */
    constructor(secretsControllerService: SecretsControllerService, geboUIActionRoutingService: GeboUIActionRoutingService);
    /**
     * Fetches secrets from the API for the current context code
     * Sets loading state during API call and clears the secrets list
     * if no context code is provided
     */
    private loadSecrets;
    /**
     * Lifecycle hook that responds to input property changes
     * Reloads secrets when the context code changes
     */
    ngOnChanges(changes: SimpleChanges): void;
    /**
     * Lifecycle hook for component initialization
     */
    ngOnInit(): void;
    /**
     * Creates a new secret for the current context
     * Triggers a UI action to display the creation form and handles
     * the action performed event to reload the secrets list when complete
     */
    newSecret(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<GeboAiSecretsAdminListComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<GeboAiSecretsAdminListComponent, "gebo-ai-secrets-admin-list-component", never, { "contextCode": { "alias": "contextCode"; "required": false; }; "allowedTypes": { "alias": "allowedTypes"; "required": false; }; }, { "secretsListChange": "secretsListChange"; }, never, never, false, never>;
}
