/**
 * This Source Code is subject to the terms of the
 * Gebo.ai community version Mozilla Public License Version 2.0 (MPL-2.0) — With Data Protection Clauses
 * If a copy of the LICENCE was not distributed with this file, You can obtain one at
 * https://gebo.ai/gebo-ai-community-version-mozilla-public-license-version-2-0-mpl-2-0-with-data-protection-clauses/
 * and https://mozilla.org/MPL/2.0/.
 * Copyright (c) 2025+ Gebo.ai
 */
import { Injector, SimpleChanges } from "@angular/core";
import { BaseEntityEditingComponent, GeboFormGroupsService, GeboUIActionRoutingService, GeboUIOutputForwardingService } from "@Gebo.ai/reusable-ui";
import { GeboSshKeySecretContent, GeboTokenContent, SecretInfo, GeboUsernamePasswordContent, SecretsControllerService, GeboCustomSecretContent, GeboOauth2SecretContent, GeboGoogleOauth2SecretContent, GeboGoogleJsonSecretContent } from "@Gebo.ai/gebo-ai-rest-api";
import { FormGroup } from "@angular/forms";
import { Observable } from "rxjs";
import { ConfirmationService } from "primeng/api";
import * as i0 from "@angular/core";
/**
 * AI generated comments
 * This file defines components for managing secrets in the Gebo.ai application. It provides functionality
 * for creating different types of secrets like SSH keys, tokens, username/password combinations, and OAuth2 credentials.
 */
/**
 * Interface representing a wrapper for different types of secrets.
 * It provides a unified structure for handling various secret types with different content formats.
 */
export interface SecretWrapper {
    code?: string;
    contextCode?: string;
    description?: string;
    secretType: SecretInfo.SecretTypeEnum;
    sshContent?: GeboSshKeySecretContent;
    tokenContent?: GeboTokenContent;
    usernamePasswordContent?: GeboUsernamePasswordContent;
    customContent?: GeboCustomSecretContent;
    oauth2StandardContent?: GeboOauth2SecretContent;
    googleOauth2Content?: GeboGoogleOauth2SecretContent;
    googleJsonContent?: GeboGoogleJsonSecretContent;
}
/**
 * Component for editing secret configurations in the admin interface.
 * Extends BaseEntityEditingComponent to provide standard CRUD functionality for SecretWrapper objects.
 * Handles different secret types and their specific form requirements dynamically.
 */
export declare class GeboAiSecretsAdminEditComponent extends BaseEntityEditingComponent<SecretWrapper> {
    private secretControllerService;
    private geboFsService;
    /** Identifies the entity type being managed by this component */
    protected entityName: string;
    /** Configures which secret types are allowed to be created/edited in this instance */
    allowedTypes: SecretInfo.SecretTypeEnum[];
    oauth2ChoosableScopes: {
        code: string;
        description: string;
    }[];
    oauth2MandatoryScopes: {
        code: string;
        description: string;
    }[];
    oauth2ForcedProviderName?: string;
    hideProviderChoice: boolean;
    /** All possible secret types with their display descriptions */
    private typesOptions;
    /** Filtered secret types that can be selected by the user */
    choosableTypes: {
        code?: SecretInfo.SecretTypeEnum;
        description?: string;
    }[];
    /** Currently selected secret type */
    actualSecretType?: SecretInfo.SecretTypeEnum;
    /** Main form group containing all form controls for different secret types */
    formGroup: FormGroup<any>;
    /**
     * Constructor initializes the component and sets up form validation based on secret type.
     * Subscribes to secretType value changes to dynamically update form validation requirements.
     */
    constructor(injector: Injector, secretControllerService: SecretsControllerService, confirmService: ConfirmationService, geboFsService: GeboFormGroupsService, geboUIActionRoutingService: GeboUIActionRoutingService, outputForwardingService?: GeboUIOutputForwardingService);
    /**
     * Helper method to enable/disable and set validation requirements for form groups based on selected secret type.
     * When required is true, the form is enabled and all fields are required.
     * When required is false, the form is disabled and validators are cleared.
     *
     * @param formName The name of the form group to update
     * @param required Whether this form group's fields should be required
     */
    private switchRequired;
    protected getFormGroupChild(name: string): FormGroup;
    /**
     * Handles input property changes, specifically to update the available secret types
     * based on the allowedTypes input property.
     */
    ngOnChanges(changes: SimpleChanges): void;
    /**
     * Loads a secret by its code. Not implemented in this component.
     */
    findByCode(code: string): Observable<SecretWrapper | null>;
    /**
     * Updates an existing secret. Not implemented in this component.
     */
    save(value: SecretWrapper): Observable<SecretWrapper>;
    /**
     * Creates a new secret based on the provided SecretWrapper.
     * Dispatches to different API methods based on the secret type.
     *
     * @param value The secret configuration to save
     * @returns An Observable with the created SecretWrapper including server-generated fields
     */
    insert(value: SecretWrapper): Observable<SecretWrapper>;
    /**
     * Deletes an existing secret. Not implemented in this component.
     */
    delete(value: SecretWrapper): Observable<boolean>;
    /**
     * Checks if a secret can be deleted. Not implemented in this component.
     */
    canBeDeleted(value: SecretWrapper): Observable<{
        canBeDeleted: boolean;
        message: string;
    }>;
    static ɵfac: i0.ɵɵFactoryDeclaration<GeboAiSecretsAdminEditComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<GeboAiSecretsAdminEditComponent, "gebo-ai-secrets-admin-edit-component", never, { "allowedTypes": { "alias": "allowedTypes"; "required": false; }; "oauth2ChoosableScopes": { "alias": "oauth2ChoosableScopes"; "required": false; }; "oauth2MandatoryScopes": { "alias": "oauth2MandatoryScopes"; "required": false; }; "oauth2ForcedProviderName": { "alias": "oauth2ForcedProviderName"; "required": false; }; "hideProviderChoice": { "alias": "hideProviderChoice"; "required": false; }; }, {}, never, never, false, never>;
}
