/**
 * This Source Code is subject to the terms of the
 * Gebo.ai community version Mozilla Public License Version 2.0 (MPL-2.0) — With Data Protection Clauses
 * If a copy of the LICENCE was not distributed with this file, You can obtain one at
 * https://gebo.ai/gebo-ai-community-version-mozilla-public-license-version-2-0-mpl-2-0-with-data-protection-clauses/
 * and https://mozilla.org/MPL/2.0/.
 * Copyright (c) 2025+ Gebo.ai
 */
/**
 * AI generated comments
 * This file provides a component for managing Gebo AI chat profiles in the admin interface.
 * It includes functionality for creating, editing, and deleting chat profile configurations,
 * with support for configuring chat and embedding models, knowledge bases, and other settings.
 */
import { Injector } from "@angular/core";
import { FormGroup } from "@angular/forms";
import { ChatModelsControllerService, EmbeddingModelsControllersService, GChatProfileConfiguration, GeboAdminChatProfilesConfigurationControllerService, GKnowledgeBase, KnowledgeBaseControllerService, PromptTemplatesControllerService } from "@Gebo.ai/gebo-ai-rest-api";
import { BaseEntityEditingComponent, GeboFormGroupsService, GeboUIActionRoutingService, GeboUIOutputForwardingService } from "@Gebo.ai/reusable-ui";
import { ConfirmationService } from "primeng/api";
import { Observable } from "rxjs";
import * as i0 from "@angular/core";
/**
 * Interface that extends GChatProfileConfiguration with additional properties
 * to handle UI-specific model selection options for chat and embedding models
 */
interface ExtendedGChatProfileConfiguration extends GChatProfileConfiguration {
    useDefaultChatModel: string;
    useDefaultEmbeddingModel: string;
}
/**
 * Component for administering Gebo AI chat profiles
 * Provides a UI for creating, editing, and managing chat profiles with various
 * configuration options including models, knowledge bases, and access controls
 */
export declare class GeboAIChatProfileAdminComponent extends BaseEntityEditingComponent<ExtendedGChatProfileConfiguration> {
    private geboChatProfileAdminService;
    private geboChatModels;
    private embeddingModels;
    private knowledgeBaseController;
    private promptTemplatesControllerService;
    /** The entity name used for internal identification */
    protected entityName: string;
    /** Form group containing all editable fields for the chat profile */
    formGroup: FormGroup<any>;
    /** Available chat models to choose from */
    chatModelsData: {
        code?: string;
        description?: string;
        className?: string;
    }[];
    /** The default chat model configuration */
    defaultChatModel: any;
    /** Available embedding models to choose from */
    embeddingModelsData: {
        code?: string;
        description?: string;
        className?: string;
    }[];
    /** The default embedding model configuration */
    defaultEmbeddingModel: any;
    /** All available knowledge bases */
    allKnowledgeBaseData: GKnowledgeBase[];
    /** Flag indicating if custom chat model selection is enabled */
    isChooseChatModel: boolean;
    /** Flag indicating if custom embedding model selection is enabled */
    isChooseEmbeddingModel: boolean;
    /**
     * Constructor initializing the component and setting up form control behaviors
     */
    constructor(injector: Injector, geboFormGroupsService: GeboFormGroupsService, geboChatProfileAdminService: GeboAdminChatProfilesConfigurationControllerService, geboChatModels: ChatModelsControllerService, embeddingModels: EmbeddingModelsControllersService, knowledgeBaseController: KnowledgeBaseControllerService, promptTemplatesControllerService: PromptTemplatesControllerService, confirmService: ConfirmationService, geboUIActionRoutingService: GeboUIActionRoutingService, outputForwardingService?: GeboUIOutputForwardingService);
    /**
     * Sets a control value if it differs from the current value
     *
     * @param ctrlName Name of the form control
     * @param value New value to set
     */
    private setIfDifferent;
    /**
     * Adds or removes the required validator for a form control
     *
     * @param ctrlName Name of the form control
     * @param required Whether the control should be required
     */
    private setControlRequired;
    /**
     * Enables or disables a form control and sets its required status accordingly
     *
     * @param ctrlName Name of the form control
     * @param enabled Whether the control should be enabled
     */
    private setControlEnabledAndRequired;
    /**
     * Handles new data when a chat profile is loaded
     * Converts backend data to frontend format and loads default prompt if needed
     *
     * @param actualValue The chat profile configuration data
     */
    protected onNewData(actualValue: ExtendedGChatProfileConfiguration): void;
    /**
     * Initializes the component and loads related data from the backend
     * Retrieves available chat models, embedding models, and knowledge bases
     */
    ngOnInit(): void;
    /**
     * Finds a chat profile by its code
     *
     * @param code The unique code identifying the chat profile
     * @returns Observable of the found chat profile or null
     */
    findByCode(code: string): Observable<ExtendedGChatProfileConfiguration | null>;
    /**
     * Saves changes to an existing chat profile
     *
     * @param value The updated chat profile configuration
     * @returns Observable of the saved chat profile
     */
    save(value: ExtendedGChatProfileConfiguration): Observable<ExtendedGChatProfileConfiguration>;
    /**
     * Creates a new chat profile
     *
     * @param value The new chat profile configuration
     * @returns Observable of the created chat profile
     */
    insert(value: ExtendedGChatProfileConfiguration): Observable<ExtendedGChatProfileConfiguration>;
    /**
     * Deletes a chat profile
     *
     * @param value The chat profile to delete
     * @returns Observable indicating deletion success
     */
    delete(value: GChatProfileConfiguration): Observable<boolean>;
    /**
     * Checks if a chat profile can be deleted
     * Currently always returns true
     *
     * @param value The chat profile to check
     * @returns Observable with deletion status and message
     */
    canBeDeleted(value: GChatProfileConfiguration): Observable<{
        canBeDeleted: boolean;
        message: string;
    }>;
    static ɵfac: i0.ɵɵFactoryDeclaration<GeboAIChatProfileAdminComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<GeboAIChatProfileAdminComponent, "gebo-ai-chat-profile-admin-component", never, {}, {}, never, never, false, never>;
}
export {};
//# sourceMappingURL=gebo-ai-chat-profile-admin.component.d.ts.map