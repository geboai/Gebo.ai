/**
 * This Source Code is subject to the terms of the
 * Gebo.ai community version Mozilla Public License Version 2.0 (MPL-2.0) — With Data Protection Clauses
 * If a copy of the LICENCE was not distributed with this file, You can obtain one at
 * https://gebo.ai/gebo-ai-community-version-mozilla-public-license-version-2-0-mpl-2-0-with-data-protection-clauses/
 * and https://mozilla.org/MPL/2.0/.
 * Copyright (c) 2025+ Gebo.ai
 */
/**
 * AI generated comments
 *
 * This file contains a component responsible for managing uploads endpoints in a Gebo.ai application.
 * It extends BaseEntityEditingComponent to handle CRUD operations for GUploadsProjectEndpoint entities
 * and provides functionality for file uploads, project selection, and publishing.
 */
import { Injector } from "@angular/core";
import { FormGroup } from "@angular/forms";
import { FileUploadControllerService, GUploadsProjectEndpoint, GProject, JobLauncherControllerService, ProjectsControllerService, FileUploadsControllerService } from "@Gebo.ai/gebo-ai-rest-api";
import { BaseEntityEditingComponent, GeboAIFileType, GeboAIRootNotificationService, GeboFormGroupsService, GeboUIActionRoutingService, GeboUIOutputForwardingService } from "@Gebo.ai/reusable-ui";
import { ConfirmationService } from "primeng/api";
import { FileBeforeUploadEvent, FileProgressEvent, UploadEvent } from "primeng/fileupload";
import { Observable } from "rxjs";
import * as i0 from "@angular/core";
/**
 * Component for managing uploads endpoints in Gebo.ai
 *
 * This component provides a user interface for creating, reading, updating, and deleting
 * uploads endpoints. It handles file uploads, project selection, and endpoint configuration.
 * It also manages the publishing process to make the endpoint available for use.
 */
export declare class GeboAIUploadsEndpointComponent extends BaseEntityEditingComponent<GUploadsProjectEndpoint> {
    private uploadsControllerService;
    private projectsController;
    private JobLauncherControllerService;
    private actionsRouter;
    private messageService;
    private uploadControllerService;
    /** Name of the entity type being managed */
    protected entityName: string;
    /** Authentication token for upload operations */
    handShakeCode?: string;
    /** Base URL for API endpoints */
    baseUrl: string;
    /** Flag controlling whether project can be modified */
    cantModifyProject: boolean;
    /** Observable of available projects to select from */
    projectsObservable: Observable<GProject[]>;
    /** Form group containing all form controls for the entity */
    formGroup: FormGroup<any>;
    /** Flag indicating if the endpoint is published */
    published: boolean;
    /** List of allowed file extensions for upload */
    filesExtensionsList: String[];
    /** Flat string representation of allowed file extensions */
    filesExtensionsFlatList: string;
    /** List of allowed file types for upload */
    fileTypesList: GeboAIFileType[];
    /**
     * Constructor initializes services and sets up subscriptions
     *
     * @param injector Angular injector for dependency injection
     * @param geboFormGroupsService Service for managing form groups
     * @param uploadsControllerService Service for managing file uploads
     * @param projectsController Service for accessing projects
     * @param JobLauncherControllerService Service for launching background jobs
     * @param actionsRouter Service for routing UI actions
     * @param messageService Service for displaying messages to the user
     * @param uploadControllerService Service for file upload operations
     * @param confirmService Service for confirmation dialogs
     * @param path Base API path
     * @param outputForwardingService Service for forwarding outputs
     */
    constructor(injector: Injector, geboFormGroupsService: GeboFormGroupsService, uploadsControllerService: FileUploadsControllerService, projectsController: ProjectsControllerService, JobLauncherControllerService: JobLauncherControllerService, actionsRouter: GeboUIActionRoutingService, messageService: GeboAIRootNotificationService, uploadControllerService: FileUploadControllerService, confirmService: ConfirmationService, path: string, outputForwardingService?: GeboUIOutputForwardingService);
    /**
     * Checks if backend processing is running for the given reference
     *
     * @param reference Object reference to check for running jobs
     * @returns Observable that emits true if processing is running, false otherwise
     */
    protected checkBackendProcessing(reference: {
        className?: string;
        code?: string;
    }): Observable<boolean>;
    /**
     * Initializes the component, loading necessary data from backend services
     */
    ngOnInit(): void;
    /**
     * Handles operations when new data is created
     *
     * @param actualValue The newly created entity
     */
    protected onNewData(actualValue: GUploadsProjectEndpoint): void;
    /**
     * Handles operations when persistent data is loaded
     *
     * @param actualValue The loaded entity
     */
    protected onLoadedPersistentData(actualValue: GUploadsProjectEndpoint): void;
    /**
     * Finds an uploads endpoint by its code
     *
     * @param code The code to search for
     * @returns Observable that emits the found entity or null
     */
    findByCode(code: string): Observable<GUploadsProjectEndpoint | null>;
    /**
     * Saves an existing uploads endpoint
     *
     * @param value The entity to save
     * @returns Observable that emits the saved entity
     */
    save(value: GUploadsProjectEndpoint): Observable<GUploadsProjectEndpoint>;
    /**
     * Inserts a new uploads endpoint
     *
     * @param value The entity to insert
     * @returns Observable that emits the inserted entity
     */
    insert(value: GUploadsProjectEndpoint): Observable<GUploadsProjectEndpoint>;
    /**
     * Deletes an uploads endpoint
     *
     * @param value The entity to delete
     * @returns Observable that emits true if deletion was successful
     */
    delete(value: GUploadsProjectEndpoint): Observable<boolean>;
    /**
     * Checks if an entity can be deleted
     *
     * @param value The entity to check
     * @returns Observable that emits an object indicating if deletion is allowed and any message
     */
    canBeDeleted(value: GUploadsProjectEndpoint): Observable<{
        canBeDeleted: boolean;
        message: string;
    }>;
    /**
     * Handles successful file upload events
     *
     * @param event The upload event
     */
    onBasicUploadAuto(event: UploadEvent): void;
    /**
     * Handles events that occur before a file upload starts
     *
     * @param event The before upload event
     */
    onBeforeUpload(event: FileBeforeUploadEvent): void;
    /**
     * Handles file upload progress events
     *
     * @param event The progress event
     */
    onProgress(event: FileProgressEvent): void;
    /**
     * Saves the entity and publishes it in one operation
     */
    doSaveAndPublish(): void;
    /**
     * Publishes the uploads endpoint by creating a backend job
     */
    doPublish(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<GeboAIUploadsEndpointComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<GeboAIUploadsEndpointComponent, "gebo-ai-uploads-endpoint-component", never, { "cantModifyProject": { "alias": "cantModifyProject"; "required": false; }; }, {}, never, never, false, never>;
}
