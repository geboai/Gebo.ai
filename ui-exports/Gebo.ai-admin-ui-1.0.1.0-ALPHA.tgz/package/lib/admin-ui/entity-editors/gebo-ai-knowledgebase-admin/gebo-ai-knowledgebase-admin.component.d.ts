/**
 * This Source Code is subject to the terms of the
 * Gebo.ai community version Mozilla Public License Version 2.0 (MPL-2.0) — With Data Protection Clauses
 * If a copy of the LICENCE was not distributed with this file, You can obtain one at
 * https://gebo.ai/gebo-ai-community-version-mozilla-public-license-version-2-0-mpl-2-0-with-data-protection-clauses/
 * and https://mozilla.org/MPL/2.0/.
 * Copyright (c) 2025+ Gebo.ai
 */
/**
 * AI generated comments
 * This file implements a Knowledge Base administration component that extends BaseEntityEditingComponent
 * from the Gebo.ai reusable UI library. The component allows users to manage knowledge bases
 * with functionalities like creating, updating, deleting, and linking to projects.
 */
import { Injector, SimpleChanges } from "@angular/core";
import { FormGroup } from "@angular/forms";
import { ContentsResetControllerService, EmbeddingModelsControllersService, GKnowledgeBase, GObjectRef, GProject, KnowledgeBaseControllerService } from "@Gebo.ai/gebo-ai-rest-api";
import { BaseEntityEditingComponentAutoDeleteCheck, EnrichedChild, GeboAIPluggableKnowledgeAdminBaseTreeSearchService, GeboFormGroupsService, GeboUIActionRoutingService, GeboUIOutputForwardingService } from "@Gebo.ai/reusable-ui";
import { ConfirmationService } from "primeng/api";
import { Observable } from "rxjs";
import * as i0 from "@angular/core";
/**
 * Component for administering knowledge bases in the Gebo.ai system.
 * Provides a UI for creating, viewing, editing, and deleting knowledge bases,
 * as well as managing associated projects and embedding models.
 */
export declare class GeboAiKnowledgeBaseAdminComponent extends BaseEntityEditingComponentAutoDeleteCheck<GKnowledgeBase> {
    private treeSearchService;
    private knowledgeBaseControllerService;
    private embeddingConfigurationsControllerService;
    private geboFGService;
    private contentsResetService;
    private confirmService;
    private actionServices;
    private outForwardingService?;
    /**
     * Name of the entity type being managed by this component
     */
    protected entityName: string;
    /**
     * Form group containing all editable fields of the knowledge base
     */
    formGroup: FormGroup;
    /**
     * List of child projects under this knowledge base
     */
    rootChildProjects: EnrichedChild[];
    /**
     * Available embedding models that can be associated with this knowledge base
     */
    modelsChoicesSource: {
        description?: string;
        code?: string;
        className?: string;
    }[];
    /**
     * All knowledge bases in the system (excluding the current one)
     */
    allKnowledgeBaseData: GKnowledgeBase[];
    graphRagContext?: {
        knowledgeBaseCode?: string;
        projectCode?: string;
        reference?: GObjectRef;
    };
    /**
     * Initializes the component with required services and dependencies
     */
    constructor(injector: Injector, treeSearchService: GeboAIPluggableKnowledgeAdminBaseTreeSearchService, knowledgeBaseControllerService: KnowledgeBaseControllerService, embeddingConfigurationsControllerService: EmbeddingModelsControllersService, geboFGService: GeboFormGroupsService, contentsResetService: ContentsResetControllerService, confirmService: ConfirmationService, actionServices: GeboUIActionRoutingService, outForwardingService?: GeboUIOutputForwardingService | undefined);
    /**
     * Returns a comma-separated string of all referenced knowledge base descriptions
     */
    get kbDescriptions(): string;
    protected onLoadedPersistentData(actualValue: GKnowledgeBase): void;
    /**
     * Initializes the component by loading embedding models and knowledge bases
     */
    ngOnInit(): void;
    /**
     * Responds to changes in the component's inputs, loading projects when the entity changes
     */
    ngOnChanges(changes: SimpleChanges): void;
    /**
     * Loads all projects associated with the current knowledge base
     */
    loadProjects(): void;
    /**
     * Creates a new project under the current knowledge base
     */
    newProject(): void;
    /**
     * Opens an existing project for editing
     * @param data The project to open
     */
    openProject(data: GProject): void;
    /**
     * Fetches a knowledge base by its code
     * @param code The unique code of the knowledge base
     * @returns Observable containing the found knowledge base or null
     */
    findByCode(code: string): Observable<GKnowledgeBase | null>;
    /**
     * Saves changes to an existing knowledge base
     * @param value The knowledge base with updated values
     * @returns Observable containing the updated knowledge base
     */
    save(value: GKnowledgeBase): Observable<GKnowledgeBase>;
    /**
     * Creates a new knowledge base
     * @param value The knowledge base data to insert
     * @returns Observable containing the newly created knowledge base
     */
    insert(value: GKnowledgeBase): Observable<GKnowledgeBase>;
    /**
     * Deletes a knowledge base
     * @param value The knowledge base to delete
     * @returns Observable indicating success (true) or failure
     */
    delete(value: GKnowledgeBase): Observable<boolean>;
    /**
     * Triggers reindexing of the knowledge base contents after confirmation
     */
    doReindex(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<GeboAiKnowledgeBaseAdminComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<GeboAiKnowledgeBaseAdminComponent, "gebo-ai-knowledgebase-admin-component", never, {}, {}, never, never, false, never>;
}
