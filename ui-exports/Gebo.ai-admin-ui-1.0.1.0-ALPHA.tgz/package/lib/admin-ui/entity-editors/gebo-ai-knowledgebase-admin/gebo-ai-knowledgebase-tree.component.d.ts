/**
 * This Source Code is subject to the terms of the
 * Gebo.ai community version Mozilla Public License Version 2.0 (MPL-2.0) — With Data Protection Clauses
 * If a copy of the LICENCE was not distributed with this file, You can obtain one at
 * https://gebo.ai/gebo-ai-community-version-mozilla-public-license-version-2-0-mpl-2-0-with-data-protection-clauses/
 * and https://mozilla.org/MPL/2.0/.
 * Copyright (c) 2025+ Gebo.ai
 */
import { OnChanges, OnInit, SimpleChanges } from "@angular/core";
import { IngestionFileTypesLibraryControllerService } from "@Gebo.ai/gebo-ai-rest-api";
import { EnrichedChild, GeboAIPluggableKnowledgeAdminBaseTreeSearchService, GeboUIActionRoutingService } from "@Gebo.ai/reusable-ui";
import { TreeNode } from "primeng/api";
import { TreeNodeExpandEvent, TreeNodeSelectEvent } from "primeng/tree";
import * as i0 from "@angular/core";
/**
 * AI generated comments
 *
 * This component displays a hierarchical tree view of knowledge bases, projects, and files.
 * It provides functionality to navigate through the tree structure, expand nodes to view children,
 * and perform actions on tree nodes such as editing and creating new elements.
 * The tree supports various node types including knowledge bases, projects, project endpoints,
 * virtual folders, and files.
 */
export declare class GeboAiKnowledgeBaseTreeComponent implements OnInit, OnChanges {
    private actionServices;
    private childsSearchService;
    private ingestionFileTypesLibraryService;
    /** Root nodes of the tree */
    roots: TreeNode[];
    /** Currently selected nodes in the tree */
    selectedNodes: TreeNode[];
    /** Cache of available ingestion handlers */
    private handlersLibrary;
    /** Cache of supported file types for ingestion */
    private fileTypesLibrary;
    /** Input data representing the initial tree structure */
    data: EnrichedChild[];
    /** Flag indicating whether the component is currently loading data */
    loading: boolean;
    /**
     * Constructor initializes required services
     * @param actionServices Service for routing UI actions
     * @param childsSearchService Service for loading child nodes in the tree
     * @param ingestionFileTypesLibraryService Service for fetching ingestion file type information
     */
    constructor(actionServices: GeboUIActionRoutingService, childsSearchService: GeboAIPluggableKnowledgeAdminBaseTreeSearchService, ingestionFileTypesLibraryService: IngestionFileTypesLibraryControllerService);
    /**
     * Initializes the component by loading ingestion file types and handlers
     * from the server when the component is created
     */
    ngOnInit(): void;
    /**
     * Responds to changes in input properties, specifically rebuilding
     * the tree roots when the data input changes
     * @param changes The changes that have occurred
     */
    ngOnChanges(changes: SimpleChanges): void;
    /**
     * Handles updates to a node's data by triggering node expansion
     * @param node The tree node that has been updated
     */
    onDataUpdate(node: TreeNode): void;
    /**
     * Handles node expansion events by loading the appropriate child nodes based on node type
     * @param event The expansion event containing the node to expand
     */
    nodeExpand(event: TreeNodeExpandEvent): void;
    /**
     * Handles node collapse events
     * @param node The collapsed node
     */
    nodeCollapse(node: any): void;
    /**
     * Opens the knowledge base editor for the selected node
     * @param node The knowledge base node to edit
     */
    openEditKnowledgeBase(node: TreeNode): void;
    /**
     * Creates a new root project for the selected knowledge base node
     * @param node The knowledge base node to create a project under
     */
    createRootProject(node: TreeNode): void;
    /**
     * Opens the project editor for the selected node
     * @param node The project node to edit
     */
    openEditProject(node: TreeNode): void;
    /** Flag indicating whether content viewing is open */
    openContentViewing: boolean;
    /** Code of the content being viewed */
    openContentViewingCode: string;
    /**
     * Opens the appropriate editor or viewer for a generic node
     * @param node The node to open
     */
    openGenericalNode(node: TreeNode): void;
    /**
     * Handles node selection events
     * @param event The node selection event
     */
    nodeSelect(event: TreeNodeSelectEvent): void;
    /**
     * Handles node unselection events
     * @param node The unselected node
     */
    nodeUnselect(node: any): void;
    /**
     * Reloads all knowledge base nodes from the server and updates the tree
     * while preserving expanded states where possible
     */
    private reloadKnowledgebaseNodes;
    /**
     * Reloads the children of a knowledge base node from the server
     * @param parent The knowledge base parent node whose children should be reloaded
     */
    private reloadKnowledgeBaseChilds;
    /**
     * Reloads the children of a project node from the server
     * @param parent The project parent node whose children should be reloaded
     */
    private reloadProjectChilds;
    static ɵfac: i0.ɵɵFactoryDeclaration<GeboAiKnowledgeBaseTreeComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<GeboAiKnowledgeBaseTreeComponent, "gebo-ai-knowledgebase-tree-component", never, { "data": { "alias": "data"; "required": false; }; }, {}, never, never, false, never>;
}
