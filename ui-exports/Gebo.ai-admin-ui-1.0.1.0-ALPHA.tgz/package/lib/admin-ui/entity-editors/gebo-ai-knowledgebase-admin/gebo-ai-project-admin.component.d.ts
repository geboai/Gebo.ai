/**
 * This Source Code is subject to the terms of the
 * Gebo.ai community version Mozilla Public License Version 2.0 (MPL-2.0) — With Data Protection Clauses
 * If a copy of the LICENCE was not distributed with this file, You can obtain one at
 * https://gebo.ai/gebo-ai-community-version-mozilla-public-license-version-2-0-mpl-2-0-with-data-protection-clauses/
 * and https://mozilla.org/MPL/2.0/.
 * Copyright (c) 2025+ Gebo.ai
 */
/**
 * AI generated comments
 *
 * This file defines the GeboAiProjectAdminComponent, which provides an interface for managing
 * project entities within the Gebo.ai system. It extends BaseEntityEditingComponent
 * to provide CRUD (Create, Read, Update, Delete) operations for GProject entities.
 * The component allows users to create, edit, delete, and manage projects, including
 * their relationships with knowledge bases and parent projects.
 */
import { Injector } from "@angular/core";
import { FormGroup } from "@angular/forms";
import { ContentsResetControllerService, GKnowledgeBase, GProject, KnowledgeBaseControllerService, ProjectsControllerService, GObjectRef } from "@Gebo.ai/gebo-ai-rest-api";
import { BaseEntityEditingComponentAutoDeleteCheck, EnrichedChild, GeboAIPluggableKnowledgeAdminBaseTreeSearchService, GeboFormGroupsService, GeboUIActionRoutingService, GeboUIOutputForwardingService } from "@Gebo.ai/reusable-ui";
import { ConfirmationService } from "primeng/api";
import { Observable } from "rxjs";
import * as i0 from "@angular/core";
/**
 * Component for administering Gebo AI projects
 * This component provides a UI for creating, editing, and managing projects within the system.
 * It handles project properties like code, description, parent-child relationships, and access controls.
 * The component also supports project-related operations like content reindexing.
 */
export declare class GeboAiProjectAdminComponent extends BaseEntityEditingComponentAutoDeleteCheck<GProject> {
    private knowledgeBaseControllerService;
    private treeService;
    private projectsControllerService;
    private geboFGService;
    private contentsResetService;
    private confirmService;
    private outForwardingService?;
    /**
     * The entity name for this component
     */
    protected entityName: string;
    /**
     * Form group defining the structure and controls for the project edit form
     * Contains fields for all editable properties of a project
     */
    formGroup: FormGroup<any>;
    /**
     * Flag indicating whether knowledge base editing is enabled
     */
    editKnowledgebase: boolean;
    /**
     * Observable containing all knowledge bases available for selection
     */
    knowledgeBases: Observable<GKnowledgeBase[]>;
    /**
     * The parent project of the current project, if any
     */
    parentProject?: GProject;
    /**
     * Array of child entities related to this project
     */
    treeChilds: EnrichedChild[];
    graphRagContext?: {
        knowledgeBaseCode?: string;
        projectCode?: string;
        reference?: GObjectRef;
    };
    /**
     * Constructor initializing the component with required services
     * Sets up subscriptions to form value changes to update related data
     *
     * @param injector Angular dependency injector
     * @param knowledgeBaseControllerService Service for knowledge base operations
     * @param treeService Service for handling project hierarchies
     * @param projectsControllerService Service for project CRUD operations
     * @param geboFGService Service for form group management
     * @param contentsResetService Service for resetting/reindexing content
     * @param confirmService Service for displaying confirmation dialogs
     * @param geboUIActionRoutingService Service for routing UI actions
     * @param outForwardingService Optional service for output forwarding
     */
    constructor(injector: Injector, knowledgeBaseControllerService: KnowledgeBaseControllerService, treeService: GeboAIPluggableKnowledgeAdminBaseTreeSearchService, projectsControllerService: ProjectsControllerService, geboFGService: GeboFormGroupsService, contentsResetService: ContentsResetControllerService, confirmService: ConfirmationService, geboUIActionRoutingService: GeboUIActionRoutingService, outForwardingService?: GeboUIOutputForwardingService | undefined);
    /**
     * Lifecycle hook called when persistent data is loaded
     * Loads child entities related to the current project
     *
     * @param actualValue The loaded project data
     */
    protected onLoadedPersistentData(actualValue: GProject): void;
    /**
     * Retrieves a project by its code
     *
     * @param code The unique code of the project to find
     * @returns An Observable containing either the found project or null
     */
    findByCode(code: string): Observable<GProject | null>;
    /**
     * Saves changes to an existing project
     *
     * @param value The project data to save
     * @returns An Observable containing the updated project
     */
    save(value: GProject): Observable<GProject>;
    /**
     * Deletes a project
     *
     * @param value The project to delete
     * @returns An Observable indicating success or failure
     */
    delete(value: GProject): Observable<boolean>;
    /**
     * Creates a new project
     *
     * @param value The project data to insert
     * @returns An Observable containing the newly created project
     */
    insert(value: GProject): Observable<GProject>;
    /**
     * Triggers a reindexing of all contents associated with the current project
     * Displays a confirmation dialog before proceeding
     */
    doReindex(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<GeboAiProjectAdminComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<GeboAiProjectAdminComponent, "gebo-ai-project-admin-component", never, { "editKnowledgebase": { "alias": "editKnowledgebase"; "required": false; }; }, {}, never, never, false, never>;
}
//# sourceMappingURL=gebo-ai-project-admin.component.d.ts.map