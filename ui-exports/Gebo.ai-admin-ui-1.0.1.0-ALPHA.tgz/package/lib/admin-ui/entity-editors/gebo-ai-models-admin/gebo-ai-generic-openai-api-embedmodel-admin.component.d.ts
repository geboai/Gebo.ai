/**
 * This Source Code is subject to the terms of the
 * Gebo.ai community version Mozilla Public License Version 2.0 (MPL-2.0) — With Data Protection Clauses
 * If a copy of the LICENCE was not distributed with this file, You can obtain one at
 * https://gebo.ai/gebo-ai-community-version-mozilla-public-license-version-2-0-mpl-2-0-with-data-protection-clauses/
 * and https://mozilla.org/MPL/2.0/.
 * Copyright (c) 2025+ Gebo.ai
 */
/**
 * AI generated comments
 * This module provides a component for administering Generic OpenAI API embedding models.
 * It includes functionality for creating, editing, and managing embedding model configurations
 * with support for different model types, API secrets, and base URLs.
 */
import { Injector } from "@angular/core";
import { FormGroup } from "@angular/forms";
import { GBaseChatModelChoice, GenericOpenAIAPIEmbeddingModelConfig, GenericOpenAiapiEmbeddingModelsConfigurationControllerService, GenericOpenAIEmbeddingModelTypeConfig, SecretInfo, SecretsControllerService } from "@Gebo.ai/gebo-ai-rest-api";
import { BaseEntityEditingComponentAutoDeleteCheck, GeboFormGroupsService, GeboUIActionRoutingService, GeboUIOutputForwardingService } from "@Gebo.ai/reusable-ui";
import { ConfirmationService } from "primeng/api";
import { Observable } from "rxjs";
import * as i0 from "@angular/core";
/**
 * Component for managing OpenAI API embedding model configurations.
 * This component extends BaseEntityEditingComponent and provides an interface
 * for managing GenericOpenAIAPIEmbeddingModelConfig entities, including:
 * - Creating new embedding model configurations
 * - Editing existing configurations
 * - Selecting model types and specific models
 * - Configuring API secrets and base URLs
 * - Validating configuration settings
 */
export declare class GeboAIGenericOpenAIAPIEmbedModelAdminComponent extends BaseEntityEditingComponentAutoDeleteCheck<GenericOpenAIAPIEmbeddingModelConfig> {
    private openaiEmbedModelConfigService;
    private secretControllerService;
    /**
     * The name of the entity being managed by this component
     */
    protected entityName: string;
    /**
     * The allowed types of secrets that can be used with this model
     */
    allowedTypes: SecretInfo.SecretTypeEnum[];
    /**
     * Form group containing all editable fields for the embedding model configuration
     */
    formGroup: FormGroup<any>;
    /**
     * Stores the previous form values to detect changes
     */
    private oldValue;
    /**
     * Available model choices for the selected configuration
     */
    modelChoicesData: GBaseChatModelChoice[];
    /**
     * List of available model types
     */
    modelTypes?: GenericOpenAIEmbeddingModelTypeConfig[];
    /**
     * Currently selected model type
     */
    modelType?: GenericOpenAIEmbeddingModelTypeConfig;
    /**
     * Observable that provides available secrets for authentication
     */
    identitiesObservable: Observable<SecretInfo[]>;
    /**
     * Action configuration for creating a new secret
     */
    newSecretAction: import("@Gebo.ai/reusable-ui").GeboUIActionRequest;
    /**
     * Constructor initializes the component and sets up form value change handlers
     * to react to configuration changes like updating the baseUrl or apiSecretCode.
     *
     * @param injector Angular injector for dependency injection
     * @param geboFormGroupsService Service for form group management
     * @param openaiEmbedModelConfigService Service for OpenAI embedding model configuration
     * @param confirmService Service for confirmation dialogs
     * @param secretControllerService Service for managing secrets
     * @param geboUIActionRoutingService Service for UI action routing
     * @param outputForwardingService Optional service for output forwarding
     */
    constructor(injector: Injector, geboFormGroupsService: GeboFormGroupsService, openaiEmbedModelConfigService: GenericOpenAiapiEmbeddingModelsConfigurationControllerService, confirmService: ConfirmationService, secretControllerService: SecretsControllerService, geboUIActionRoutingService: GeboUIActionRoutingService, outputForwardingService?: GeboUIOutputForwardingService);
    /**
     * Refreshes the provider model data based on the selected model type.
     * Updates the identities observable and new secret action with appropriate provider ID.
     * Sets the baseUrl if not already specified.
     *
     * @param actualValue The current embedding model configuration
     */
    private refreshProviderModel;
    /**
     * Initializes the component and loads model types from the backend
     */
    ngOnInit(): void;
    /**
     * Loads secrets information for the current configuration
     * This method appears to be a placeholder for future implementation
     *
     * @param actualValue The current embedding model configuration
     */
    private loadSecretsInfos;
    /**
     * Loads available models based on the provided base URL and API secret code
     *
     * @param newValue Object containing baseUrl and apiSecretCode
     */
    private loadModels;
    /**
     * Handles setup when loading persistent data from the backend
     *
     * @param actualValue The loaded embedding model configuration
     */
    protected onLoadedPersistentData(actualValue: GenericOpenAIAPIEmbeddingModelConfig): void;
    /**
     * Handles setup when creating new data
     *
     * @param actualValue The new embedding model configuration
     */
    protected onNewData(actualValue: GenericOpenAIAPIEmbeddingModelConfig): void;
    /**
     * Finds a configuration by its code
     *
     * @param code The code to search for
     * @returns Observable with the found configuration or null
     */
    findByCode(code: string): Observable<GenericOpenAIAPIEmbeddingModelConfig | null>;
    /**
     * Saves an existing configuration
     *
     * @param value The configuration to save
     * @returns Observable with the saved configuration
     */
    save(value: GenericOpenAIAPIEmbeddingModelConfig): Observable<GenericOpenAIAPIEmbeddingModelConfig>;
    /**
     * Inserts a new configuration
     *
     * @param value The configuration to insert
     * @returns Observable with the inserted configuration
     */
    insert(value: GenericOpenAIAPIEmbeddingModelConfig): Observable<GenericOpenAIAPIEmbeddingModelConfig>;
    /**
     * Deletes a configuration
     *
     * @param value The configuration to delete
     * @returns Observable with the delete operation result
     */
    delete(value: GenericOpenAIAPIEmbeddingModelConfig): Observable<boolean>;
    static ɵfac: i0.ɵɵFactoryDeclaration<GeboAIGenericOpenAIAPIEmbedModelAdminComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<GeboAIGenericOpenAIAPIEmbedModelAdminComponent, "gebo-ai-generic-open-ai-api-embed-model-admin-component", never, {}, {}, never, never, false, never>;
}
