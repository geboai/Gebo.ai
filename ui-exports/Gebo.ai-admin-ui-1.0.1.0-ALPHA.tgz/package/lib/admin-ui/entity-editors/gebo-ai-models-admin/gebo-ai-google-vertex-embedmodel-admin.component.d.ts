/**
 * This Source Code is subject to the terms of the
 * Gebo.ai community version Mozilla Public License Version 2.0 (MPL-2.0) — With Data Protection Clauses
 * If a copy of the LICENCE was not distributed with this file, You can obtain one at
 * https://gebo.ai/gebo-ai-community-version-mozilla-public-license-version-2-0-mpl-2-0-with-data-protection-clauses/
 * and https://mozilla.org/MPL/2.0/.
 * Copyright (c) 2025+ Gebo.ai
 */
/**
 * AI generated comments
 * This file defines a component for managing Google Vertex AI embedding model configurations.
 * It extends BaseEntityEditingComponent to provide editing functionality for
 * Google Vertex embedding model configurations, including CRUD operations,
 * model selection, and secret management integration.
 */
import { Injector } from "@angular/core";
import { FormGroup } from "@angular/forms";
import { GBaseChatModelChoice, GGoogleVertexEmbeddingModelConfig, GoogleVertexEmbeddingModelsConfigurationControllerService, SecretInfo, SecretsControllerService } from "@Gebo.ai/gebo-ai-rest-api";
import { BaseEntityEditingComponentAutoDeleteCheck, GeboFormGroupsService, GeboUIActionRoutingService, GeboUIOutputForwardingService } from "@Gebo.ai/reusable-ui";
import { ConfirmationService } from "primeng/api";
import { Observable } from "rxjs";
import * as i0 from "@angular/core";
/**
 * Component responsible for administering Google Vertex AI embedding models.
 * Provides a user interface for creating, updating, and managing Google Vertex
 * embedding model configurations. Handles communication with backend services
 * for CRUD operations and fetching available models.
 */
export declare class GeboAIGoogleVertexEmbedModelAdminComponent extends BaseEntityEditingComponentAutoDeleteCheck<GGoogleVertexEmbeddingModelConfig> {
    private openaiEmbedModelConfigService;
    private secretControllerService;
    /**
     * Entity name used for component identification and logging
     */
    protected entityName: string;
    /**
     * Array of allowed secret types for this component, currently only TOKEN type is supported
     */
    allowedTypes: SecretInfo.SecretTypeEnum[];
    /**
     * Form group containing form controls for the embedding model configuration
     */
    formGroup: FormGroup<any>;
    /**
     * Stores previous form values to detect changes
     */
    private oldValue;
    /**
     * Available model choices retrieved from the API
     */
    modelChoicesData: GBaseChatModelChoice[];
    /**
     * Observable that fetches Google Vertex secrets from the backend
     */
    identitiesObservable: Observable<SecretInfo[]>;
    /**
     * Action configuration for creating new secrets for Google Vertex
     */
    newSecretAction: import("@Gebo.ai/reusable-ui").GeboUIActionRequest;
    /**
     * Component constructor that initializes services and sets up form value change subscription
     * to update models when relevant fields change
     */
    constructor(injector: Injector, geboFormGroupsService: GeboFormGroupsService, openaiEmbedModelConfigService: GoogleVertexEmbeddingModelsConfigurationControllerService, secretControllerService: SecretsControllerService, confirmService: ConfirmationService, geboUIActionRoutingService: GeboUIActionRoutingService, outputForwardingService?: GeboUIOutputForwardingService);
    /**
     * Loads available embedding models from Google Vertex AI API
     * based on the provided base URL and API secret code
     * @param newValue Object containing baseUrl and apiSecretCode
     */
    private loadModels;
    /**
     * Handles initialization after loading existing data
     * Sets the model type code and loads available models
     * @param actualValue The loaded entity data
     */
    protected onLoadedPersistentData(actualValue: GGoogleVertexEmbeddingModelConfig): void;
    /**
     * Handles initialization for new entity creation
     * Sets default model type code
     * @param actualValue The new entity template data
     */
    protected onNewData(actualValue: GGoogleVertexEmbeddingModelConfig): void;
    /**
     * Fetches a Google Vertex embedding model configuration by its code
     * @param code The unique code identifier of the configuration
     * @returns Observable with the found configuration or null
     */
    findByCode(code: string): Observable<GGoogleVertexEmbeddingModelConfig | null>;
    /**
     * Saves changes to an existing Google Vertex embedding model configuration
     * @param value The updated configuration data
     * @returns Observable with the saved configuration
     */
    save(value: GGoogleVertexEmbeddingModelConfig): Observable<GGoogleVertexEmbeddingModelConfig>;
    /**
     * Creates a new Google Vertex embedding model configuration
     * @param value The new configuration data
     * @returns Observable with the created configuration
     */
    insert(value: GGoogleVertexEmbeddingModelConfig): Observable<GGoogleVertexEmbeddingModelConfig>;
    /**
     * Deletes a Google Vertex embedding model configuration
     * @param value The configuration to delete
     * @returns Observable indicating success or failure
     */
    delete(value: GGoogleVertexEmbeddingModelConfig): Observable<boolean>;
    static ɵfac: i0.ɵɵFactoryDeclaration<GeboAIGoogleVertexEmbedModelAdminComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<GeboAIGoogleVertexEmbedModelAdminComponent, "gebo-ai-google-vertex-embed-model-admin-component", never, {}, {}, never, never, false, never>;
}
