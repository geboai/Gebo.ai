/**
 * This Source Code is subject to the terms of the
 * Gebo.ai community version Mozilla Public License Version 2.0 (MPL-2.0) — With Data Protection Clauses
 * If a copy of the LICENCE was not distributed with this file, You can obtain one at
 * https://gebo.ai/gebo-ai-community-version-mozilla-public-license-version-2-0-mpl-2-0-with-data-protection-clauses/
 * and https://mozilla.org/MPL/2.0/.
 * Copyright (c) 2025+ Gebo.ai
 */
/**
 * AI generated comments
 * This file defines the MistralAI Embedding Model administration component in the Gebo.ai application.
 * It provides UI and logic for managing MistralAI embedding model configurations including
 * creating, updating, deleting and retrieving model configurations.
 */
import { Injector } from "@angular/core";
import { FormGroup } from "@angular/forms";
import { GBaseChatModelChoice, GMistralEmbeddingModelConfig, MistralAiEmbeddingModelsConfigurationControllerService, SecretInfo, SecretsControllerService } from "@Gebo.ai/gebo-ai-rest-api";
import { BaseEntityEditingComponentAutoDeleteCheck, GeboFormGroupsService, GeboUIActionRoutingService, GeboUIOutputForwardingService } from "@Gebo.ai/reusable-ui";
import { ConfirmationService } from "primeng/api";
import { Observable } from "rxjs";
import * as i0 from "@angular/core";
/**
 * Component responsible for administering MistralAI embedding models.
 * Extends BaseEntityEditingComponent to manage CRUD operations for GMistralEmbeddingModelConfig entities.
 * Provides UI for configuring MistralAI embedding models, managing API secrets, and selecting models.
 */
export declare class GeboAIMistralAIEmbedModelAdminComponent extends BaseEntityEditingComponentAutoDeleteCheck<GMistralEmbeddingModelConfig> {
    private MIstralEmbedModelConfigService;
    private secretControllerService;
    /**
     * The name of the entity being managed by this component
     */
    protected entityName: string;
    /**
     * Types of secrets that are allowed for MistralAI embedding models
     */
    allowedTypes: SecretInfo.SecretTypeEnum[];
    /**
     * Form group for managing the MistralAI embedding model configuration
     */
    formGroup: FormGroup<any>;
    /**
     * Tracks the old form values to detect changes
     */
    private oldValue;
    /**
     * Available model choices for MistralAI embedding models
     */
    modelChoicesData: GBaseChatModelChoice[];
    /**
     * Observable for retrieving secrets related to MistralAI
     */
    identitiesObservable: Observable<SecretInfo[]>;
    /**
     * Action request for creating a new secret for MistralAI
     */
    newSecretAction: import("@Gebo.ai/reusable-ui").GeboUIActionRequest;
    /**
     * Constructor initializes the component with required services and sets up form change subscriptions
     * to reload models when relevant form fields change
     */
    constructor(injector: Injector, geboFormGroupsService: GeboFormGroupsService, MIstralEmbedModelConfigService: MistralAiEmbeddingModelsConfigurationControllerService, secretControllerService: SecretsControllerService, confirmService: ConfirmationService, geboUIActionRoutingService: GeboUIActionRoutingService, outputForwardingService?: GeboUIOutputForwardingService);
    /**
     * Loads available MistralAI embedding models based on the provided baseUrl and apiSecretCode
     * Updates the modelChoicesData with the retrieved models
     */
    private loadModels;
    /**
     * Handles initialization after persistent data is loaded
     * Sets the model type code and loads models based on the configuration
     */
    protected onLoadedPersistentData(actualValue: GMistralEmbeddingModelConfig): void;
    /**
     * Handles initialization for new data
     * Sets the default model type code for new configurations
     */
    protected onNewData(actualValue: GMistralEmbeddingModelConfig): void;
    /**
     * Retrieves a specific MistralAI embedding model configuration by its code
     */
    findByCode(code: string): Observable<GMistralEmbeddingModelConfig | null>;
    /**
     * Saves changes to an existing MistralAI embedding model configuration
     */
    save(value: GMistralEmbeddingModelConfig): Observable<GMistralEmbeddingModelConfig>;
    /**
     * Creates a new MistralAI embedding model configuration
     */
    insert(value: GMistralEmbeddingModelConfig): Observable<GMistralEmbeddingModelConfig>;
    /**
     * Deletes a MistralAI embedding model configuration
     */
    delete(value: GMistralEmbeddingModelConfig): Observable<boolean>;
    static ɵfac: i0.ɵɵFactoryDeclaration<GeboAIMistralAIEmbedModelAdminComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<GeboAIMistralAIEmbedModelAdminComponent, "gebo-ai-mistral-ai-embed-model-admin-component", never, {}, {}, never, never, false, never>;
}
//# sourceMappingURL=gebo-ai-mistralai-embedmodel-admin.component.d.ts.map