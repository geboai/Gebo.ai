import { Injector, OnInit } from "@angular/core";
import { FormGroup } from "@angular/forms";
import { GenericOpenAIAPIRankerModelChoice, GenericOpenAIAPIRankerModelConfig, GenericOpenAiRankerModelsConfigurationControllerService, GenericOpenAIRankerModelTypeConfig, SecretInfo, SecretsControllerService } from "@Gebo.ai/gebo-ai-rest-api";
import { BaseEntityEditingComponent, GeboFormGroupsService, GeboUIActionRequest, GeboUIActionRoutingService, GeboUIOutputForwardingService } from "@Gebo.ai/reusable-ui";
import { ConfirmationService } from "primeng/api";
import { Observable } from "rxjs";
import * as i0 from "@angular/core";
export declare class GeboAIGenericOpenaAIAPiRankerAdminComponent extends BaseEntityEditingComponent<GenericOpenAIAPIRankerModelConfig> implements OnInit {
    private genericOpenAIAPIRankerService;
    private secretControllerService;
    protected entityName: string;
    formGroup: FormGroup<any>;
    /**
         * Tracks previous form values for comparison to detect changes
         */
    private oldValue;
    /**
     * Stores available model choices for the selected API configuration
     */
    modelChoicesData: GenericOpenAIAPIRankerModelChoice[];
    /**
     * Observable for retrieving available identity/secret information
     */
    identitiesObservable?: Observable<SecretInfo[]>;
    /**
     * Action request for creating a new secret
     */
    newSecretAction?: GeboUIActionRequest;
    /**
     * Available model types for OpenAI API configurations
     */
    modelTypes?: GenericOpenAIRankerModelTypeConfig[];
    /**
     * Currently selected model type
     */
    modelType?: GenericOpenAIRankerModelTypeConfig;
    constructor(injector: Injector, geboFormGroupsService: GeboFormGroupsService, confirmationService: ConfirmationService, geboUIActionRoutingService: GeboUIActionRoutingService, outputForwardingService: GeboUIOutputForwardingService, genericOpenAIAPIRankerService: GenericOpenAiRankerModelsConfigurationControllerService, secretControllerService: SecretsControllerService);
    ngOnInit(): void;
    /**
         * Updates model provider information based on the selected model type
         * Sets up identities observable and configures baseUrl if necessary
         * @param actualValue The current model configuration
         */
    private refreshProviderModel;
    /**
     * Loads available models from the OpenAI API using the provided configuration
     * @param newValue Object containing baseUrl and apiSecretCode used to authenticate with the API
     */
    private loadModels;
    /**
     * Called when persistent data is loaded, refreshes provider model and loads available models
     * @param actualValue The loaded model configuration
     */
    protected onLoadedPersistentData(actualValue: GenericOpenAIAPIRankerModelConfig): void;
    /**
     * Called when creating a new entity, initializes provider model data
     * @param actualValue The new model configuration
     */
    protected onNewData(actualValue: GenericOpenAIAPIRankerModelConfig): void;
    findByCode(code: string): Observable<GenericOpenAIAPIRankerModelConfig | null>;
    save(value: GenericOpenAIAPIRankerModelConfig): Observable<GenericOpenAIAPIRankerModelConfig>;
    insert(value: GenericOpenAIAPIRankerModelConfig): Observable<GenericOpenAIAPIRankerModelConfig>;
    delete(value: GenericOpenAIAPIRankerModelConfig): Observable<boolean>;
    canBeDeleted(value: GenericOpenAIAPIRankerModelConfig): Observable<{
        canBeDeleted: boolean;
        message: string;
    }>;
    static ɵfac: i0.ɵɵFactoryDeclaration<GeboAIGenericOpenaAIAPiRankerAdminComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<GeboAIGenericOpenaAIAPiRankerAdminComponent, "gebo-ai-generic-openai-api-ranker-component", never, {}, {}, never, never, false, never>;
}
//# sourceMappingURL=gebo-ai-generic-openai-api-ranker-admin.component.d.ts.map