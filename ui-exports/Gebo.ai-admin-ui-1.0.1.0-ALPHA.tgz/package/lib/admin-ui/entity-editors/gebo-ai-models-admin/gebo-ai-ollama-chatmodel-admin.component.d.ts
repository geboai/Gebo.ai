/**
 * This Source Code is subject to the terms of the
 * Gebo.ai community version Mozilla Public License Version 2.0 (MPL-2.0) — With Data Protection Clauses
 * If a copy of the LICENCE was not distributed with this file, You can obtain one at
 * https://gebo.ai/gebo-ai-community-version-mozilla-public-license-version-2-0-mpl-2-0-with-data-protection-clauses/
 * and https://mozilla.org/MPL/2.0/.
 * Copyright (c) 2025+ Gebo.ai
 */
/**
 * AI generated comments
 *
 * This file contains the GeboAIOllamaChatModelAdminComponent which is responsible for
 * managing Ollama Chat Model configurations within the Gebo.ai platform. It provides functionality
 * for creating, editing, updating, and deleting Ollama chat model configurations, as well as loading
 * available models from an Ollama server.
 */
import { Injector } from "@angular/core";
import { FormGroup } from "@angular/forms";
import { GBaseChatModelChoice, GOllamaChatModelConfig, OllamaChatModelsConfigurationControllerService, SecretInfo, SecretsControllerService } from "@Gebo.ai/gebo-ai-rest-api";
import { BaseEntityEditingComponentAutoDeleteCheck, GeboFormGroupsService, GeboUIActionRoutingService, GeboUIOutputForwardingService } from "@Gebo.ai/reusable-ui";
import { ConfirmationService } from "primeng/api";
import { Observable } from "rxjs";
import * as i0 from "@angular/core";
/**
 * Component for administering Ollama Chat Model configurations.
 * This component extends BaseEntityEditingComponent and provides
 * a UI for creating, editing, and managing Ollama chat model configurations.
 * It handles form management, model loading, and CRUD operations for
 * Ollama chat model configurations.
 */
export declare class GeboAIOllamaChatModelAdminComponent extends BaseEntityEditingComponentAutoDeleteCheck<GOllamaChatModelConfig> {
    private chatModelConfigService;
    private secretControllerService;
    /**
     * The name of the entity being managed by this component
     */
    protected entityName: string;
    /**
     * The types of secrets allowed for Ollama model configuration
     */
    allowedTypes: SecretInfo.SecretTypeEnum[];
    /**
     * Form group containing controls for all editable properties of an Ollama chat model configuration
     */
    formGroup: FormGroup<any>;
    /**
     * Stores the previous form values to detect changes
     */
    private oldValue;
    /**
     * List of available chat models retrieved from the Ollama server
     */
    modelChoicesData: GBaseChatModelChoice[];
    /**
     * Observable for available secrets in the Ollama context
     */
    identitiesObservable: Observable<SecretInfo[]>;
    /**
     * Action configuration for creating a new secret
     */
    newSecretAction: import("@Gebo.ai/reusable-ui").GeboUIActionRequest;
    /**
     * Constructor initializes the component and sets up form value change detection
     * to dynamically load models when the baseUrl or apiSecretCode changes.
     */
    constructor(injector: Injector, geboFormGroupsService: GeboFormGroupsService, chatModelConfigService: OllamaChatModelsConfigurationControllerService, secretControllerService: SecretsControllerService, confirmService: ConfirmationService, geboUIActionRoutingService: GeboUIActionRoutingService, outputForwardingService?: GeboUIOutputForwardingService);
    /**
     * Loads the available models from the Ollama server based on the provided baseUrl and apiSecretCode
     * @param newValue Object containing baseUrl and apiSecretCode to connect to the Ollama server
     */
    private loadModels;
    /**
     * Handles initialization when loading existing entity data
     * Sets the modelTypeCode and loads available models from the Ollama server
     * @param actualValue The loaded configuration entity
     */
    protected onLoadedPersistentData(actualValue: GOllamaChatModelConfig): void;
    /**
     * Handles initialization for new entity creation
     * Sets the default modelTypeCode for new Ollama chat models
     * @param actualValue The new configuration entity
     */
    protected onNewData(actualValue: GOllamaChatModelConfig): void;
    /**
     * Retrieves an Ollama chat model configuration by its code
     * @param code The unique identifier for the configuration
     * @returns Observable containing the found configuration or null
     */
    findByCode(code: string): Observable<GOllamaChatModelConfig | null>;
    /**
     * Saves changes to an existing Ollama chat model configuration
     * @param value The configuration to update
     * @returns Observable with the updated configuration
     */
    save(value: GOllamaChatModelConfig): Observable<GOllamaChatModelConfig>;
    /**
     * Creates a new Ollama chat model configuration
     * @param value The new configuration to insert
     * @returns Observable with the created configuration
     */
    insert(value: GOllamaChatModelConfig): Observable<GOllamaChatModelConfig>;
    /**
     * Deletes an Ollama chat model configuration
     * @param value The configuration to delete
     * @returns Observable indicating success or failure
     */
    delete(value: GOllamaChatModelConfig): Observable<boolean>;
    static ɵfac: i0.ɵɵFactoryDeclaration<GeboAIOllamaChatModelAdminComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<GeboAIOllamaChatModelAdminComponent, "gebo-ai-ollama-ai-chat-model-admin-component", never, {}, {}, never, never, false, never>;
}
