/**
 * This Source Code is subject to the terms of the
 * Gebo.ai community version Mozilla Public License Version 2.0 (MPL-2.0) — With Data Protection Clauses
 * If a copy of the LICENCE was not distributed with this file, You can obtain one at
 * https://gebo.ai/gebo-ai-community-version-mozilla-public-license-version-2-0-mpl-2-0-with-data-protection-clauses/
 * and https://mozilla.org/MPL/2.0/.
 * Copyright (c) 2025+ Gebo.ai
 */
/**
 * AI generated comments
 *
 * This file defines the GeboAIAnthropicChatModelAdminComponent which manages the configuration
 * for Anthropic chat models within the Gebo.ai application. The component allows users to create,
 * edit, and delete Anthropic chat model configurations, including setting model parameters,
 * access controls, and API connections.
 */
import { Injector } from "@angular/core";
import { FormGroup } from "@angular/forms";
import { FunctionsLookupControllerService, GBaseChatModelChoice, GLookupEntry, GAnthropicChatModelConfig, SecretInfo, SecretsControllerService, AnthropicChatModelsConfigurationControllerService } from "@Gebo.ai/gebo-ai-rest-api";
import { BaseEntityEditingComponentAutoDeleteCheck, GeboFormGroupsService, GeboUIActionRoutingService, GeboUIOutputForwardingService } from "@Gebo.ai/reusable-ui";
import { ConfirmationService } from "primeng/api";
import { Observable } from "rxjs";
import * as i0 from "@angular/core";
/**
 * Component responsible for managing Anthropic chat model configurations.
 * Extends BaseEntityEditingComponent to provide CRUD functionality for GAnthropicChatModelConfig entities.
 * This component displays a form for editing model settings like temperature, top-p, context length,
 * and manages API connections through secret keys.
 */
export declare class GeboAIAnthropicChatModelAdminComponent extends BaseEntityEditingComponentAutoDeleteCheck<GAnthropicChatModelConfig> {
    private anthropicChatModelConfigService;
    private functionsLookupControllerService;
    private secretControllerService;
    /**
     * Entity name used for form identification and processing
     */
    protected entityName: string;
    /**
     * Allowed types of secrets that can be used with Anthropic models
     */
    allowedTypes: SecretInfo.SecretTypeEnum[];
    /**
     * Form group containing all the configurable fields for an Anthropic chat model
     */
    formGroup: FormGroup<any>;
    /**
     * Maintains the previous value of the form to detect changes
     */
    private oldValue;
    /**
     * List of available Anthropic models to choose from
     */
    modelChoicesData: GBaseChatModelChoice[];
    /**
     * Observable that provides the list of available secrets for Anthropic context
     */
    identitiesObservable: Observable<SecretInfo[]>;
    /**
     * Action request for creating a new secret
     */
    newSecretAction: import("@Gebo.ai/reusable-ui").GeboUIActionRequest;
    /**
     * List of available functions that can be enabled for the model
     */
    functionsList: GLookupEntry[];
    /**
     * Constructor that initializes the component and sets up form change listeners
     */
    constructor(injector: Injector, geboFormGroupsService: GeboFormGroupsService, anthropicChatModelConfigService: AnthropicChatModelsConfigurationControllerService, functionsLookupControllerService: FunctionsLookupControllerService, secretControllerService: SecretsControllerService, confirmService: ConfirmationService, geboUIActionRoutingService: GeboUIActionRoutingService, outputForwardingService?: GeboUIOutputForwardingService);
    /**
     * Initializes the component and loads the list of available functions
     */
    ngOnInit(): void;
    /**
     * Loads the available models from Anthropic based on the provided configuration
     * This is called when the API secret or baseUrl changes
     */
    private loadModels;
    /**
     * Handler called when persistent data is loaded, sets the model type
     * and loads available models from Anthropic
     */
    protected onLoadedPersistentData(actualValue: GAnthropicChatModelConfig): void;
    /**
     * Handler called when creating a new entity, sets default model type
     */
    protected onNewData(actualValue: GAnthropicChatModelConfig): void;
    /**
     * Retrieves an Anthropic chat model configuration by its code
     */
    findByCode(code: string): Observable<GAnthropicChatModelConfig | null>;
    /**
     * Saves an existing Anthropic chat model configuration
     */
    save(value: GAnthropicChatModelConfig): Observable<GAnthropicChatModelConfig>;
    /**
     * Inserts a new Anthropic chat model configuration
     */
    insert(value: GAnthropicChatModelConfig): Observable<GAnthropicChatModelConfig>;
    /**
     * Deletes an Anthropic chat model configuration
     */
    delete(value: GAnthropicChatModelConfig): Observable<boolean>;
    static ɵfac: i0.ɵɵFactoryDeclaration<GeboAIAnthropicChatModelAdminComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<GeboAIAnthropicChatModelAdminComponent, "gebo-ai-anthropic-chat-model-admin-component", never, {}, {}, never, never, false, never>;
}
