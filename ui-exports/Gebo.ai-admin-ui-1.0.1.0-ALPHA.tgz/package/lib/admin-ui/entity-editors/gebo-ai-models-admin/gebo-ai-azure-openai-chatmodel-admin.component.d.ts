/**
 * This Source Code is subject to the terms of the
 * Gebo.ai community version Mozilla Public License Version 2.0 (MPL-2.0) — With Data Protection Clauses
 * If a copy of the LICENCE was not distributed with this file, You can obtain one at
 * https://gebo.ai/gebo-ai-community-version-mozilla-public-license-version-2-0-mpl-2-0-with-data-protection-clauses/
 * and https://mozilla.org/MPL/2.0/.
 * Copyright (c) 2025+ Gebo.ai
 */
import { Injector } from "@angular/core";
import { FormGroup } from "@angular/forms";
import { AzureOpenAiChatModelsConfigurationControllerService, FunctionsLookupControllerService, GAzureOpenAIChatModelConfig, GBaseChatModelChoice, GLookupEntry, SecretInfo, SecretsControllerService } from "@Gebo.ai/gebo-ai-rest-api";
import { BaseEntityEditingComponentAutoDeleteCheck, GeboFormGroupsService, GeboUIActionRoutingService, GeboUIOutputForwardingService } from "@Gebo.ai/reusable-ui";
import { ConfirmationService } from "primeng/api";
import { Observable } from "rxjs";
import * as i0 from "@angular/core";
/**
 * Component for managing OpenAI chat model configurations.
 * Provides UI for creating, updating, and deleting OpenAI chat model configurations.
 * Extends BaseEntityEditingComponent to use common entity editing functionality.
 */
export declare class GeboAIAzureOpenAIChatModelAdminComponent extends BaseEntityEditingComponentAutoDeleteCheck<GAzureOpenAIChatModelConfig> {
    private openaiChatModelConfigService;
    private functionsLookupControllerService;
    private secretControllerService;
    /**
     * Name of the entity type being managed by this component
     */
    protected entityName: string;
    /**
     * The allowed secret types for OpenAI API credentials
     */
    allowedTypes: SecretInfo.SecretTypeEnum[];
    /**
     * Form group to manage the OpenAI chat model configuration fields
     */
    formGroup: FormGroup<any>;
    /**
     * Stores previous form values to detect changes
     */
    private oldValue;
    /**
     * Available OpenAI model choices for selection
     */
    modelChoicesData: GBaseChatModelChoice[];
    /**
     * Observable for retrieving OpenAI secrets
     */
    identitiesObservable: Observable<SecretInfo[]>;
    /**
     * Action for creating a new OpenAI secret
     */
    newSecretAction: import("@Gebo.ai/reusable-ui").GeboUIActionRequest;
    /**
     * List of available functions for the chat model
     */
    functionsList: GLookupEntry[];
    /**
     * Constructor initializes the component with necessary services and sets up form change handling
     */
    constructor(injector: Injector, geboFormGroupsService: GeboFormGroupsService, openaiChatModelConfigService: AzureOpenAiChatModelsConfigurationControllerService, functionsLookupControllerService: FunctionsLookupControllerService, secretControllerService: SecretsControllerService, confirmService: ConfirmationService, geboUIActionRoutingService: GeboUIActionRoutingService, outputForwardingService?: GeboUIOutputForwardingService);
    /**
     * Initializes the component and loads available functions
     */
    ngOnInit(): void;
    /**
     * Loads available OpenAI models based on provided configuration
     * @param newValue Object containing baseUrl and/or apiSecretCode
     */
    private loadModels;
    /**
     * Handles when persistent data is loaded into the component
     * @param actualValue The loaded OpenAI chat model configuration
     */
    protected onLoadedPersistentData(actualValue: GAzureOpenAIChatModelConfig): void;
    /**
     * Handles initialization for new data
     * @param actualValue Default values for new OpenAI chat model configuration
     */
    protected onNewData(actualValue: GAzureOpenAIChatModelConfig): void;
    /**
     * Finds an OpenAI chat model configuration by code
     * @param code The code to search for
     * @returns Observable with the matching configuration or null
     */
    findByCode(code: string): Observable<GAzureOpenAIChatModelConfig | null>;
    /**
     * Saves an existing OpenAI chat model configuration
     * @param value The configuration to save
     * @returns Observable with the updated configuration
     */
    save(value: GAzureOpenAIChatModelConfig): Observable<GAzureOpenAIChatModelConfig>;
    /**
     * Inserts a new OpenAI chat model configuration
     * @param value The new configuration to insert
     * @returns Observable with the inserted configuration
     */
    insert(value: GAzureOpenAIChatModelConfig): Observable<GAzureOpenAIChatModelConfig>;
    /**
     * Deletes an OpenAI chat model configuration
     * @param value The configuration to delete
     * @returns Observable with the deletion result
     */
    delete(value: GAzureOpenAIChatModelConfig): Observable<boolean>;
    static ɵfac: i0.ɵɵFactoryDeclaration<GeboAIAzureOpenAIChatModelAdminComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<GeboAIAzureOpenAIChatModelAdminComponent, "gebo-ai-azure-open-ai-chat-model-admin-component", never, {}, {}, never, never, false, never>;
}
//# sourceMappingURL=gebo-ai-azure-openai-chatmodel-admin.component.d.ts.map