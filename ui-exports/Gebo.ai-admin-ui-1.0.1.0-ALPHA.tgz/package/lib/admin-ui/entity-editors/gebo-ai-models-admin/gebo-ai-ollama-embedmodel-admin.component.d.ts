/**
 * This Source Code is subject to the terms of the
 * Gebo.ai community version Mozilla Public License Version 2.0 (MPL-2.0) — With Data Protection Clauses
 * If a copy of the LICENCE was not distributed with this file, You can obtain one at
 * https://gebo.ai/gebo-ai-community-version-mozilla-public-license-version-2-0-mpl-2-0-with-data-protection-clauses/
 * and https://mozilla.org/MPL/2.0/.
 * Copyright (c) 2025+ Gebo.ai
 */
/**
 * AI generated comments
 *
 * This file contains a component for managing Ollama embedding models in the Gebo.ai application.
 * It extends BaseEntityEditingComponent to provide CRUD operations for Ollama embedding model configurations.
 */
import { Injector } from "@angular/core";
import { FormGroup } from "@angular/forms";
import { EmbeddingModelsControllersService, GBaseChatModelChoice, GOllamaEmbeddingModelConfig, OllamaEmbeddingModelsConfigurationControllerService, SecretInfo, SecretsControllerService } from "@Gebo.ai/gebo-ai-rest-api";
import { BaseEntityEditingComponentAutoDeleteCheck, GeboFormGroupsService, GeboUIActionRoutingService, GeboUIOutputForwardingService } from "@Gebo.ai/reusable-ui";
import { ConfirmationService } from "primeng/api";
import { Observable } from "rxjs";
import * as i0 from "@angular/core";
/**
 * Component responsible for administrating Ollama embedding models.
 * It provides a UI to create, read, update and delete embedding model configurations
 * that connect to Ollama's API.
 */
export declare class GeboAIOllamaEmbedModelAdminComponent extends BaseEntityEditingComponentAutoDeleteCheck<GOllamaEmbeddingModelConfig> {
    private embedModelConfigService;
    private embeddingModelsControllerService;
    private secretControllerService;
    /**
     * The entity name for this component, used for tracking and reference
     */
    protected entityName: string;
    /**
     * Defines the allowed secret types that can be used with Ollama embedding models
     */
    allowedTypes: SecretInfo.SecretTypeEnum[];
    /**
     * Form group containing form controls for all editable properties of the embedding model
     */
    formGroup: FormGroup<any>;
    /**
     * Stores the previous form values to detect changes
     */
    private oldValue;
    /**
     * Available model choices fetched from Ollama
     */
    modelChoicesData: GBaseChatModelChoice[];
    /**
     * Observable containing available secrets for Ollama context
     */
    identitiesObservable: Observable<SecretInfo[]>;
    /**
     * Action configuration for creating a new secret for Ollama
     */
    newSecretAction: import("@Gebo.ai/reusable-ui").GeboUIActionRequest;
    /**
     * Constructor initializes the component and sets up form value change monitoring
     * to automatically load available models when URL or API secret changes
     */
    constructor(injector: Injector, geboFormGroupsService: GeboFormGroupsService, embedModelConfigService: OllamaEmbeddingModelsConfigurationControllerService, embeddingModelsControllerService: EmbeddingModelsControllersService, secretControllerService: SecretsControllerService, confirmService: ConfirmationService, geboUIActionRoutingService: GeboUIActionRoutingService, outputForwardingService?: GeboUIOutputForwardingService);
    /**
     * Loads available embedding models from Ollama based on the provided base URL and API secret
     * Updates the model choices dropdown with the results
     *
     * @param newValue Object containing baseUrl and apiSecretCode to connect to Ollama
     */
    private loadModels;
    /**
     * Callback executed when an existing entity is loaded
     * Sets the modelTypeCode and loads available models
     *
     * @param actualValue The loaded embedding model configuration
     */
    protected onLoadedPersistentData(actualValue: GOllamaEmbeddingModelConfig): void;
    /**
     * Callback executed when initializing a new entity
     * Sets the default modelTypeCode for new configurations
     *
     * @param actualValue The new embedding model configuration
     */
    protected onNewData(actualValue: GOllamaEmbeddingModelConfig): void;
    /**
     * Finds an embedding model configuration by its code
     *
     * @param code The unique code identifier for the model configuration
     * @returns Observable of the found configuration or null if not found
     */
    findByCode(code: string): Observable<GOllamaEmbeddingModelConfig | null>;
    /**
     * Saves changes to an existing embedding model configuration
     *
     * @param value The updated embedding model configuration
     * @returns Observable of the saved configuration
     */
    save(value: GOllamaEmbeddingModelConfig): Observable<GOllamaEmbeddingModelConfig>;
    /**
     * Inserts a new embedding model configuration
     *
     * @param value The new embedding model configuration to insert
     * @returns Observable of the inserted configuration
     */
    insert(value: GOllamaEmbeddingModelConfig): Observable<GOllamaEmbeddingModelConfig>;
    /**
     * Deletes an embedding model configuration
     *
     * @param value The embedding model configuration to delete
     * @returns Observable indicating success or failure
     */
    delete(value: GOllamaEmbeddingModelConfig): Observable<boolean>;
    static ɵfac: i0.ɵɵFactoryDeclaration<GeboAIOllamaEmbedModelAdminComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<GeboAIOllamaEmbedModelAdminComponent, "gebo-ai-ollama-ai-embed-model-admin-component", never, {}, {}, never, never, false, never>;
}
//# sourceMappingURL=gebo-ai-ollama-embedmodel-admin.component.d.ts.map