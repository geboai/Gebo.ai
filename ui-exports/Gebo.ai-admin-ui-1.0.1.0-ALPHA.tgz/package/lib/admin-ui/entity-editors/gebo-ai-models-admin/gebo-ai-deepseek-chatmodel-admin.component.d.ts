/**
 * This Source Code is subject to the terms of the
 * Gebo.ai community version Mozilla Public License Version 2.0 (MPL-2.0) — With Data Protection Clauses
 * If a copy of the LICENCE was not distributed with this file, You can obtain one at
 * https://gebo.ai/gebo-ai-community-version-mozilla-public-license-version-2-0-mpl-2-0-with-data-protection-clauses/
 * and https://mozilla.org/MPL/2.0/.
 * Copyright (c) 2025+ Gebo.ai
 */
/**
 * AI generated comments
 * This file contains the implementation of the Deepseek Chat Model Administration component,
 * which allows users to manage Deepseek chat model configurations in the Gebo.ai platform.
 */
import { Injector } from "@angular/core";
import { FormGroup } from "@angular/forms";
import { FunctionsLookupControllerService, GBaseChatModelChoice, GLookupEntry, SecretInfo, SecretsControllerService, GDeepseekChatModelConfig, DeepseekChatModelsConfigurationControllerService } from "@Gebo.ai/gebo-ai-rest-api";
import { BaseEntityEditingComponentAutoDeleteCheck, GeboFormGroupsService, GeboUIActionRoutingService, GeboUIOutputForwardingService } from "@Gebo.ai/reusable-ui";
import { ConfirmationService } from "primeng/api";
import { Observable } from "rxjs";
import * as i0 from "@angular/core";
/**
 * Component for administering Deepseek chat model configurations.
 * This component extends the BaseEntityEditingComponent and provides functionality
 * for creating, updating, and deleting Deepseek chat model configurations.
 * It includes form controls for various configuration parameters and integrates with
 * related services for managing secrets and functions.
 */
export declare class GeboAIDeepseekChatModelAdminComponent extends BaseEntityEditingComponentAutoDeleteCheck<GDeepseekChatModelConfig> {
    private deepseekChatModelConfigService;
    private functionsLookupControllerService;
    private secretControllerService;
    /**
     * The name of the entity being managed by this component
     */
    protected entityName: string;
    /**
     * Allowed types of secrets for this model (only token-based authentication supported)
     */
    allowedTypes: SecretInfo.SecretTypeEnum[];
    /**
     * Form group containing all configuration fields for the Deepseek chat model
     */
    formGroup: FormGroup<any>;
    /**
     * Tracks the previous form value to detect changes for model loading
     */
    private oldValue;
    /**
     * Available model choices fetched from the Deepseek API
     */
    modelChoicesData: GBaseChatModelChoice[];
    /**
     * Observable for Deepseek-related identity secrets
     */
    identitiesObservable: Observable<SecretInfo[]>;
    /**
     * Action configuration for creating a new secret
     */
    newSecretAction: import("@Gebo.ai/reusable-ui").GeboUIActionRequest;
    /**
     * List of available functions that can be enabled for this model
     */
    functionsList: GLookupEntry[];
    /**
     * Constructor initializes services and sets up form value change monitoring
     * to automatically load models when relevant configuration changes
     */
    constructor(injector: Injector, geboFormGroupsService: GeboFormGroupsService, deepseekChatModelConfigService: DeepseekChatModelsConfigurationControllerService, functionsLookupControllerService: FunctionsLookupControllerService, secretControllerService: SecretsControllerService, confirmService: ConfirmationService, geboUIActionRoutingService: GeboUIActionRoutingService, outputForwardingService?: GeboUIOutputForwardingService);
    /**
     * Initializes the component and loads available functions
     * from the backend service
     */
    ngOnInit(): void;
    /**
     * Loads available Deepseek models based on the provided configuration
     * @param newValue The configuration containing baseUrl and apiSecretCode
     */
    private loadModels;
    /**
     * Handles initialization when loading existing configuration data
     * @param actualValue The loaded configuration data
     */
    protected onLoadedPersistentData(actualValue: GDeepseekChatModelConfig): void;
    /**
     * Handles initialization for new configuration creation
     * @param actualValue The initial configuration data
     */
    protected onNewData(actualValue: GDeepseekChatModelConfig): void;
    /**
     * Finds a Deepseek chat model configuration by its code
     * @param code The unique code of the configuration to find
     * @returns Observable containing the found configuration or null
     */
    findByCode(code: string): Observable<GDeepseekChatModelConfig | null>;
    /**
     * Saves changes to an existing Deepseek chat model configuration
     * @param value The configuration data to save
     * @returns Observable containing the updated configuration
     */
    save(value: GDeepseekChatModelConfig): Observable<GDeepseekChatModelConfig>;
    /**
     * Creates a new Deepseek chat model configuration
     * @param value The configuration data to insert
     * @returns Observable containing the created configuration
     */
    insert(value: GDeepseekChatModelConfig): Observable<GDeepseekChatModelConfig>;
    /**
     * Deletes a Deepseek chat model configuration
     * @param value The configuration to delete
     * @returns Observable indicating whether deletion was successful
     */
    delete(value: GDeepseekChatModelConfig): Observable<boolean>;
    static ɵfac: i0.ɵɵFactoryDeclaration<GeboAIDeepseekChatModelAdminComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<GeboAIDeepseekChatModelAdminComponent, "gebo-ai-deepseek-chat-model-admin-component", never, {}, {}, never, never, false, never>;
}
//# sourceMappingURL=gebo-ai-deepseek-chatmodel-admin.component.d.ts.map