/**
 * This Source Code is subject to the terms of the
 * Gebo.ai community version Mozilla Public License Version 2.0 (MPL-2.0) — With Data Protection Clauses
 * If a copy of the LICENCE was not distributed with this file, You can obtain one at
 * https://gebo.ai/gebo-ai-community-version-mozilla-public-license-version-2-0-mpl-2-0-with-data-protection-clauses/
 * and https://mozilla.org/MPL/2.0/.
 * Copyright (c) 2025+ Gebo.ai
 */
/**
 * AI generated comments
 * This component is responsible for managing OpenAI embedding model configurations.
 * It extends BaseEntityEditingComponent to handle CRUD operations for GOpenAIEmbeddingModelConfig entities.
 * The component provides UI for creating, editing, and deleting OpenAI embedding model configurations,
 * fetching available models from the OpenAI API, and managing API secret connections.
 */
import { Injector } from "@angular/core";
import { FormGroup } from "@angular/forms";
import { GBaseChatModelChoice, GOpenAIEmbeddingModelConfig, OpenAiEmbeddingModelsConfigurationControllerService, SecretInfo, SecretsControllerService } from "@Gebo.ai/gebo-ai-rest-api";
import { BaseEntityEditingComponentAutoDeleteCheck, GeboFormGroupsService, GeboUIActionRoutingService, GeboUIOutputForwardingService } from "@Gebo.ai/reusable-ui";
import { ConfirmationService } from "primeng/api";
import { Observable } from "rxjs";
import * as i0 from "@angular/core";
export declare class GeboAIOpenAIEmbedModelAdminComponent extends BaseEntityEditingComponentAutoDeleteCheck<GOpenAIEmbeddingModelConfig> {
    private openaiEmbedModelConfigService;
    private secretControllerService;
    /**
     * The entity name identifier for the GOpenAIEmbeddingModelConfig
     */
    protected entityName: string;
    /**
     * Types of secrets allowed for this component - limited to TOKEN type
     */
    allowedTypes: SecretInfo.SecretTypeEnum[];
    /**
     * Form group to handle the editable properties of the embedding model config
     */
    formGroup: FormGroup<any>;
    /**
     * Keeps track of the previous form values to detect changes
     */
    private oldValue;
    /**
     * Available model choices data from OpenAI
     */
    modelChoicesData: GBaseChatModelChoice[];
    /**
     * Observable for retrieving OpenAI identity secrets
     */
    identitiesObservable: Observable<SecretInfo[]>;
    /**
     * Action request for creating a new secret
     */
    newSecretAction: import("@Gebo.ai/reusable-ui").GeboUIActionRequest;
    /**
     * Component constructor that initializes the form and sets up value change detection
     * to update models when relevant form fields change
     */
    constructor(injector: Injector, geboFormGroupsService: GeboFormGroupsService, openaiEmbedModelConfigService: OpenAiEmbeddingModelsConfigurationControllerService, secretControllerService: SecretsControllerService, confirmService: ConfirmationService, geboUIActionRoutingService: GeboUIActionRoutingService, outputForwardingService?: GeboUIOutputForwardingService);
    /**
     * Loads available embedding models from OpenAI based on the provided URL and API secret
     * Sets the loading state and updates model choices data once retrieved
     * @param newValue Object containing baseUrl and apiSecretCode
     */
    private loadModels;
    /**
     * Handles initializing the form when editing an existing entity
     * Sets model type code and loads available models
     * @param actualValue The existing model configuration being loaded
     */
    protected onLoadedPersistentData(actualValue: GOpenAIEmbeddingModelConfig): void;
    /**
     * Handles initializing the form when creating a new entity
     * Sets the default model type code
     * @param actualValue The new model configuration being created
     */
    protected onNewData(actualValue: GOpenAIEmbeddingModelConfig): void;
    /**
     * Retrieves an embedding model configuration by its code
     * @param code The unique code of the model configuration to find
     * @returns Observable containing the found configuration or null
     */
    findByCode(code: string): Observable<GOpenAIEmbeddingModelConfig | null>;
    /**
     * Updates an existing embedding model configuration
     * @param value The model configuration to update
     * @returns Observable containing the updated configuration
     */
    save(value: GOpenAIEmbeddingModelConfig): Observable<GOpenAIEmbeddingModelConfig>;
    /**
     * Creates a new embedding model configuration
     * @param value The model configuration to create
     * @returns Observable containing the created configuration
     */
    insert(value: GOpenAIEmbeddingModelConfig): Observable<GOpenAIEmbeddingModelConfig>;
    /**
     * Deletes an embedding model configuration
     * @param value The model configuration to delete
     * @returns Observable indicating whether the delete operation was successful
     */
    delete(value: GOpenAIEmbeddingModelConfig): Observable<boolean>;
    static ɵfac: i0.ɵɵFactoryDeclaration<GeboAIOpenAIEmbedModelAdminComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<GeboAIOpenAIEmbedModelAdminComponent, "gebo-ai-open-ai-embed-model-admin-component", never, {}, {}, never, never, false, never>;
}
