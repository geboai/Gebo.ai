/**
 * This Source Code is subject to the terms of the
 * Gebo.ai community version Mozilla Public License Version 2.0 (MPL-2.0) — With Data Protection Clauses
 * If a copy of the LICENCE was not distributed with this file, You can obtain one at
 * https://gebo.ai/gebo-ai-community-version-mozilla-public-license-version-2-0-mpl-2-0-with-data-protection-clauses/
 * and https://mozilla.org/MPL/2.0/.
 * Copyright (c) 2025+ Gebo.ai
 */
/**
 * AI generated comments
 * This file contains a component for administering Mistral AI chat model configurations in the Gebo.ai application.
 * It handles creation, reading, updating, and deletion of Mistral AI chat model configurations, as well as
 * managing related data like secrets, functions, and model choices.
 */
import { Injector } from "@angular/core";
import { FormGroup } from "@angular/forms";
import { FunctionsLookupControllerService, GBaseChatModelChoice, GLookupEntry, GMistralChatModelConfig, MistralAiChatModelsConfigurationControllerService, SecretInfo, SecretsControllerService } from "@Gebo.ai/gebo-ai-rest-api";
import { BaseEntityEditingComponentAutoDeleteCheck, GeboFormGroupsService, GeboUIActionRoutingService, GeboUIOutputForwardingService } from "@Gebo.ai/reusable-ui";
import { ConfirmationService } from "primeng/api";
import { Observable } from "rxjs";
import * as i0 from "@angular/core";
/**
 * Component responsible for managing Mistral AI chat model configurations.
 * Extends BaseEntityEditingComponent to provide CRUD operations for GMistralChatModelConfig entities.
 * Handles form management, model data fetching, and interactions with related services.
 */
export declare class GeboAIMistralAIChatModelAdminComponent extends BaseEntityEditingComponentAutoDeleteCheck<GMistralChatModelConfig> {
    private openaiChatModelConfigService;
    private functionsLookupControllerService;
    private secretControllerService;
    /** The entity name used for identification and operations */
    protected entityName: string;
    /** List of allowed secret types for this model configuration */
    allowedTypes: SecretInfo.SecretTypeEnum[];
    /** Form group containing controls for all editable fields of the model configuration */
    formGroup: FormGroup<any>;
    /** Keeps track of previous form values to detect changes */
    private oldValue;
    /** List of available model choices from Mistral AI */
    modelChoicesData: GBaseChatModelChoice[];
    /** Observable for getting identities related to Mistral AI context */
    identitiesObservable: Observable<SecretInfo[]>;
    /** Action configuration for creating new Mistral AI secrets */
    newSecretAction: import("@Gebo.ai/reusable-ui").GeboUIActionRequest;
    /** List of available functions for the model */
    functionsList: GLookupEntry[];
    /**
     * Constructor initializes the component and sets up form value change subscription.
     * The subscription refreshes model choices when API secret or base URL changes.
     */
    constructor(injector: Injector, geboFormGroupsService: GeboFormGroupsService, openaiChatModelConfigService: MistralAiChatModelsConfigurationControllerService, functionsLookupControllerService: FunctionsLookupControllerService, secretControllerService: SecretsControllerService, confirmService: ConfirmationService, geboUIActionRoutingService: GeboUIActionRoutingService, outputForwardingService?: GeboUIOutputForwardingService);
    /**
     * Initializes the component and loads available functions from the backend.
     * Extends the parent class initialization.
     */
    ngOnInit(): void;
    /**
     * Loads available Mistral AI models based on the provided configuration.
     * Sets loading state and updates model choices when data is received.
     *
     * @param newValue The configuration containing baseUrl and apiSecretCode
     */
    private loadModels;
    /**
     * Handles setup when loading existing model configuration data.
     * Sets the model type code and loads available models.
     *
     * @param actualValue The loaded model configuration
     */
    protected onLoadedPersistentData(actualValue: GMistralChatModelConfig): void;
    /**
     * Handles setup for new model configuration.
     * Sets the default model type code.
     *
     * @param actualValue The new model configuration
     */
    protected onNewData(actualValue: GMistralChatModelConfig): void;
    /**
     * Retrieves a model configuration by its code.
     *
     * @param code The unique code of the model configuration
     * @returns An Observable with the found configuration or null
     */
    findByCode(code: string): Observable<GMistralChatModelConfig | null>;
    /**
     * Saves (updates) an existing model configuration.
     *
     * @param value The model configuration to save
     * @returns An Observable with the saved configuration
     */
    save(value: GMistralChatModelConfig): Observable<GMistralChatModelConfig>;
    /**
     * Inserts a new model configuration.
     *
     * @param value The model configuration to insert
     * @returns An Observable with the inserted configuration
     */
    insert(value: GMistralChatModelConfig): Observable<GMistralChatModelConfig>;
    /**
     * Deletes a model configuration.
     *
     * @param value The model configuration to delete
     * @returns An Observable indicating success or failure
     */
    delete(value: GMistralChatModelConfig): Observable<boolean>;
    static ɵfac: i0.ɵɵFactoryDeclaration<GeboAIMistralAIChatModelAdminComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<GeboAIMistralAIChatModelAdminComponent, "gebo-ai-mistral-ai-chat-model-admin-component", never, {}, {}, never, never, false, never>;
}
