/**
 * This Source Code is subject to the terms of the
 * Gebo.ai community version Mozilla Public License Version 2.0 (MPL-2.0) — With Data Protection Clauses
 * If a copy of the LICENCE was not distributed with this file, You can obtain one at
 * https://gebo.ai/gebo-ai-community-version-mozilla-public-license-version-2-0-mpl-2-0-with-data-protection-clauses/
 * and https://mozilla.org/MPL/2.0/.
 * Copyright (c) 2025+ Gebo.ai
 */
/**
 * AI generated comments
 * This file implements an Angular component for administering Generic OpenAI API Chat models.
 * It provides functionality to create, update, delete, and manage configuration settings for
 * OpenAI API chat models within the Gebo.ai system.
 */
import { Injector } from "@angular/core";
import { FormGroup } from "@angular/forms";
import { FunctionsLookupControllerService, GBaseChatModelChoice, GenericOpenAIAPIChatModelConfig, GenericOpenAiapiChatModelsConfigurationControllerService, GenericOpenAIChatModelTypeConfig, GLookupEntry, SecretInfo, SecretsControllerService } from "@Gebo.ai/gebo-ai-rest-api";
import { BaseEntityEditingComponentAutoDeleteCheck, GeboFormGroupsService, GeboUIActionRequest, GeboUIActionRoutingService, GeboUIOutputForwardingService } from "@Gebo.ai/reusable-ui";
import { ConfirmationService } from "primeng/api";
import { Observable } from "rxjs";
import * as i0 from "@angular/core";
/**
 * Component for administering Generic OpenAI API Chat model configurations.
 * This component extends BaseEntityEditingComponent and provides a user interface
 * for managing OpenAI API chat model settings including API credentials, model types,
 * context length, temperature, and access permissions.
 */
export declare class GeboAIGenericOpenAIAPIChatModelAdminComponent extends BaseEntityEditingComponentAutoDeleteCheck<GenericOpenAIAPIChatModelConfig> {
    private openaiChatModelConfigService;
    private functionsLookupControllerService;
    private secretControllerService;
    /**
     * Entity name used for identification throughout the component
     */
    protected entityName: string;
    /**
     * Defines the allowed secret types for this component
     */
    allowedTypes: SecretInfo.SecretTypeEnum[];
    /**
     * FormGroup defining all the form controls needed for the OpenAI API model configuration
     */
    formGroup: FormGroup<any>;
    /**
     * Tracks previous form values for comparison to detect changes
     */
    private oldValue;
    /**
     * Stores available model choices for the selected API configuration
     */
    modelChoicesData: GBaseChatModelChoice[];
    /**
     * Observable for retrieving available identity/secret information
     */
    identitiesObservable?: Observable<SecretInfo[]>;
    /**
     * Action request for creating a new secret
     */
    newSecretAction?: GeboUIActionRequest;
    /**
     * List of available functions that can be enabled for the model
     */
    functionsList: GLookupEntry[];
    /**
     * Available model types for OpenAI API configurations
     */
    modelTypes?: GenericOpenAIChatModelTypeConfig[];
    /**
     * Currently selected model type
     */
    modelType?: GenericOpenAIChatModelTypeConfig;
    /**
     * Component constructor that initializes services and sets up form value change subscriptions
     */
    constructor(injector: Injector, geboFormGroupsService: GeboFormGroupsService, openaiChatModelConfigService: GenericOpenAiapiChatModelsConfigurationControllerService, functionsLookupControllerService: FunctionsLookupControllerService, secretControllerService: SecretsControllerService, geboUIActionRoutingService: GeboUIActionRoutingService, confirmService: ConfirmationService, outputForwardingService?: GeboUIOutputForwardingService);
    /**
     * Lifecycle hook that initializes component data including functions list and model types
     */
    ngOnInit(): void;
    /**
     * Updates model provider information based on the selected model type
     * Sets up identities observable and configures baseUrl if necessary
     * @param actualValue The current model configuration
     */
    private refreshProviderModel;
    /**
     * Loads available models from the OpenAI API using the provided configuration
     * @param newValue Object containing baseUrl and apiSecretCode used to authenticate with the API
     */
    private loadModels;
    /**
     * Called when persistent data is loaded, refreshes provider model and loads available models
     * @param actualValue The loaded model configuration
     */
    protected onLoadedPersistentData(actualValue: GenericOpenAIAPIChatModelConfig): void;
    /**
     * Called when creating a new entity, initializes provider model data
     * @param actualValue The new model configuration
     */
    protected onNewData(actualValue: GenericOpenAIAPIChatModelConfig): void;
    /**
     * Retrieves a model configuration by its code
     * @param code The code identifying the model configuration
     * @returns An Observable with the model configuration or null
     */
    findByCode(code: string): Observable<GenericOpenAIAPIChatModelConfig | null>;
    /**
     * Saves updates to an existing model configuration
     * @param value The model configuration to update
     * @returns An Observable with the updated model configuration
     */
    save(value: GenericOpenAIAPIChatModelConfig): Observable<GenericOpenAIAPIChatModelConfig>;
    /**
     * Inserts a new model configuration
     * @param value The model configuration to insert
     * @returns An Observable with the inserted model configuration
     */
    insert(value: GenericOpenAIAPIChatModelConfig): Observable<GenericOpenAIAPIChatModelConfig>;
    /**
     * Deletes a model configuration
     * @param value The model configuration to delete
     * @returns An Observable indicating success or failure
     */
    delete(value: GenericOpenAIAPIChatModelConfig): Observable<boolean>;
    static ɵfac: i0.ɵɵFactoryDeclaration<GeboAIGenericOpenAIAPIChatModelAdminComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<GeboAIGenericOpenAIAPIChatModelAdminComponent, "gebo-ai-generic-open-ai-api-chat-model-admin-component", never, {}, {}, never, never, false, never>;
}
//# sourceMappingURL=gebo-ai-generic-openai-api-chatmodel-admin.component.d.ts.map