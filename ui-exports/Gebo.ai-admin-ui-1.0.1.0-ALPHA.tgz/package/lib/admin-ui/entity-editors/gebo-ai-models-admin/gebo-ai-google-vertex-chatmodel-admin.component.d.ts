/**
 * This Source Code is subject to the terms of the
 * Gebo.ai community version Mozilla Public License Version 2.0 (MPL-2.0) — With Data Protection Clauses
 * If a copy of the LICENCE was not distributed with this file, You can obtain one at
 * https://gebo.ai/gebo-ai-community-version-mozilla-public-license-version-2-0-mpl-2-0-with-data-protection-clauses/
 * and https://mozilla.org/MPL/2.0/.
 * Copyright (c) 2025+ Gebo.ai
 */
/**
 * AI generated comments
 *
 * This file implements a component for managing Google Vertex AI chat model configurations.
 * It extends BaseEntityEditingComponent to provide CRUD operations for GGoogleVertexChatModelConfig entities.
 * The component allows users to configure model settings, select models, manage API secrets, and configure
 * accessibility and function settings.
 */
import { Injector } from "@angular/core";
import { FormGroup } from "@angular/forms";
import { FunctionsLookupControllerService, GBaseChatModelChoice, GGoogleVertexChatModelConfig, GLookupEntry, GoogleVertexChatModelsConfigurationControllerService, SecretInfo, SecretsControllerService } from "@Gebo.ai/gebo-ai-rest-api";
import { BaseEntityEditingComponentAutoDeleteCheck, GeboFormGroupsService, GeboUIActionRoutingService, GeboUIOutputForwardingService } from "@Gebo.ai/reusable-ui";
import { ConfirmationService } from "primeng/api";
import { Observable } from "rxjs";
import * as i0 from "@angular/core";
/**
 * Component responsible for managing Google Vertex AI chat model configurations.
 * Provides UI for creating, editing, and deleting chat model configurations
 * with specific settings for the Google Vertex AI platform.
 */
export declare class GeboAIGoogleVertexChatModelAdminComponent extends BaseEntityEditingComponentAutoDeleteCheck<GGoogleVertexChatModelConfig> {
    private chatModelConfigService;
    private functionsLookupControllerService;
    private secretControllerService;
    protected entityName: string;
    allowedTypes: SecretInfo.SecretTypeEnum[];
    formGroup: FormGroup<any>;
    private oldValue;
    modelChoicesData: GBaseChatModelChoice[];
    identitiesObservable: Observable<SecretInfo[]>;
    newSecretAction: import("@Gebo.ai/reusable-ui").GeboUIActionRequest;
    functionsList: GLookupEntry[];
    /**
     * Constructor initializes the component with required dependencies and sets up form value change subscription
     * to automatically reload models when baseUrl or apiSecretCode change.
     */
    constructor(injector: Injector, geboFormGroupsService: GeboFormGroupsService, chatModelConfigService: GoogleVertexChatModelsConfigurationControllerService, functionsLookupControllerService: FunctionsLookupControllerService, secretControllerService: SecretsControllerService, confirmService: ConfirmationService, geboUIActionRoutingService: GeboUIActionRoutingService, outputForwardingService?: GeboUIOutputForwardingService);
    /**
     * Initializes the component, sets up loading state and fetches the list of available functions
     * that can be enabled for the chat model.
     */
    ngOnInit(): void;
    /**
     * Loads available models from Google Vertex AI based on the provided configuration.
     * Updates the model choices dropdown with the fetched models.
     *
     * @param newValue Object containing baseUrl and apiSecretCode needed to fetch models
     */
    private loadModels;
    /**
     * Called when loading existing configuration data.
     * Sets the model type code and loads available models.
     *
     * @param actualValue The loaded configuration data
     */
    protected onLoadedPersistentData(actualValue: GGoogleVertexChatModelConfig): void;
    /**
     * Called when creating a new configuration.
     * Sets the default model type code for Google Vertex AI.
     *
     * @param actualValue The new configuration data
     */
    protected onNewData(actualValue: GGoogleVertexChatModelConfig): void;
    /**
     * Retrieves a configuration by its code identifier.
     *
     * @param code The unique code of the configuration to find
     * @returns An Observable with the found configuration or null
     */
    findByCode(code: string): Observable<GGoogleVertexChatModelConfig | null>;
    /**
     * Saves changes to an existing configuration.
     * Updates the operation status based on the server response.
     *
     * @param value The configuration to save
     * @returns An Observable with the saved configuration
     */
    save(value: GGoogleVertexChatModelConfig): Observable<GGoogleVertexChatModelConfig>;
    /**
     * Creates a new configuration.
     * Updates the operation status based on the server response.
     *
     * @param value The new configuration to create
     * @returns An Observable with the created configuration
     */
    insert(value: GGoogleVertexChatModelConfig): Observable<GGoogleVertexChatModelConfig>;
    /**
     * Deletes a configuration.
     * Updates the operation status based on the server response.
     *
     * @param value The configuration to delete
     * @returns An Observable indicating success or failure
     */
    delete(value: GGoogleVertexChatModelConfig): Observable<boolean>;
    static ɵfac: i0.ɵɵFactoryDeclaration<GeboAIGoogleVertexChatModelAdminComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<GeboAIGoogleVertexChatModelAdminComponent, "gebo-ai-google-vertex-chat-model-admin-component", never, {}, {}, never, never, false, never>;
}
//# sourceMappingURL=gebo-ai-google-vertex-chatmodel-admin.component.d.ts.map