/**
 * This Source Code is subject to the terms of the
 * Gebo.ai community version Mozilla Public License Version 2.0 (MPL-2.0) — With Data Protection Clauses
 * If a copy of the LICENCE was not distributed with this file, You can obtain one at
 * https://gebo.ai/gebo-ai-community-version-mozilla-public-license-version-2-0-mpl-2-0-with-data-protection-clauses/
 * and https://mozilla.org/MPL/2.0/.
 * Copyright (c) 2025+ Gebo.ai
 */
/**
 * AI generated comments
 * This module defines the GeboAIPromptAdminComponent which is responsible for managing AI prompt configurations.
 * It extends BaseEntityEditingComponent to provide CRUD functionality for GPromptConfig entities.
 * The component handles form creation, validation, and interactions with backend services for prompt administration.
 */
import { Injector } from "@angular/core";
import { FormGroup } from "@angular/forms";
import { ChatModelsControllerService, EmbeddingModelsControllersService, GeboAdminPromptsControllerService, GPromptConfig } from "@Gebo.ai/gebo-ai-rest-api";
import { BaseEntityEditingComponent, GeboFormGroupsService, GeboUIActionRoutingService, GeboUIOutputForwardingService } from "@Gebo.ai/reusable-ui";
import { ConfirmationService } from "primeng/api";
import { Observable } from "rxjs";
import * as i0 from "@angular/core";
/**
 * Component for managing AI prompt configurations in the admin interface.
 * Provides a UI for creating, editing, viewing and deleting prompt configurations.
 * Uses Angular's reactive forms for data management and validation.
 */
export declare class GeboAIPromptAdminComponent extends BaseEntityEditingComponent<GPromptConfig> {
    private geboPromptConfigurationService;
    private geboChatModels;
    private embeddingModels;
    /**
     * Name of the entity being managed by this component
     */
    protected entityName: string;
    /**
     * Form group that contains all the controls for editing a prompt configuration
     * Includes fields for code, description, prompt text, model information, and category
     */
    formGroup: FormGroup<any>;
    /**
     * Array of available prompt categories to be displayed in the category selector
     */
    promptCategories: string[];
    /**
     * Component constructor that injects required services
     * @param injector Angular injector for dependency injection
     * @param geboFormGroupsService Service for managing form groups
     * @param geboPromptConfigurationService Service for CRUD operations on prompt configurations
     * @param geboChatModels Service for accessing available chat models
     * @param embeddingModels Service for accessing available embedding models
     * @param confirmService Service for showing confirmation dialogs
     * @param geboUIActionRoutingService Service for handling UI actions and routing
     * @param outputForwardingService Optional service for forwarding output to other components
     */
    constructor(injector: Injector, geboFormGroupsService: GeboFormGroupsService, geboPromptConfigurationService: GeboAdminPromptsControllerService, geboChatModels: ChatModelsControllerService, embeddingModels: EmbeddingModelsControllersService, confirmService: ConfirmationService, geboUIActionRoutingService: GeboUIActionRoutingService, outputForwardingService?: GeboUIOutputForwardingService);
    /**
     * Lifecycle hook that initializes the component
     * Calls the parent initialization and loads the prompt categories
     */
    ngOnInit(): void;
    /**
     * Finds a prompt configuration by its code
     * @param code The unique code identifier for the prompt configuration
     * @returns An Observable containing the found GPromptConfig or null if not found
     */
    findByCode(code: string): Observable<GPromptConfig | null>;
    /**
     * Saves (updates) an existing prompt configuration
     * @param value The GPromptConfig object to update
     * @returns An Observable containing the updated GPromptConfig
     */
    save(value: GPromptConfig): Observable<GPromptConfig>;
    /**
     * Inserts a new prompt configuration
     * @param value The GPromptConfig object to insert
     * @returns An Observable containing the inserted GPromptConfig
     */
    insert(value: GPromptConfig): Observable<GPromptConfig>;
    /**
     * Deletes a prompt configuration
     * @param value The GPromptConfig object to delete
     * @returns An Observable containing a boolean indicating success
     */
    delete(value: GPromptConfig): Observable<boolean>;
    /**
     * Checks if a prompt configuration can be deleted
     * Currently always returns true as there are no restrictions on deletion
     * @param value The GPromptConfig to check
     * @returns An Observable containing an object with canBeDeleted flag and message
     */
    canBeDeleted(value: GPromptConfig): Observable<{
        canBeDeleted: boolean;
        message: string;
    }>;
    static ɵfac: i0.ɵɵFactoryDeclaration<GeboAIPromptAdminComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<GeboAIPromptAdminComponent, "gebo-ai-prompt-admin-component", never, {}, {}, never, never, false, never>;
}
