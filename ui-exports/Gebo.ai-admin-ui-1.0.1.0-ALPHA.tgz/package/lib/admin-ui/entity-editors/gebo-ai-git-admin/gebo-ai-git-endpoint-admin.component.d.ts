/**
 * This Source Code is subject to the terms of the
 * Gebo.ai community version Mozilla Public License Version 2.0 (MPL-2.0) — With Data Protection Clauses
 * If a copy of the LICENCE was not distributed with this file, You can obtain one at
 * https://gebo.ai/gebo-ai-community-version-mozilla-public-license-version-2-0-mpl-2-0-with-data-protection-clauses/
 * and https://mozilla.org/MPL/2.0/.
 * Copyright (c) 2025+ Gebo.ai
 */
/**
 * AI generated comments
 * This is the Git Endpoint Administration Component which allows users to manage Git project endpoints
 * in the Gebo.ai application. It extends the BaseEntityEditingComponent to provide CRUD operations
 * for Git project endpoints.
 */
import { JobLauncherControllerService } from '@Gebo.ai/gebo-ai-rest-api';
import { Injector } from "@angular/core";
import { FormGroup } from "@angular/forms";
import { GGitContentManagementSystem, GitSystemsControllerService, GProject, GGitProjectEndpoint, ProjectsControllerService, SecretsControllerService, SecretInfo } from "@Gebo.ai/gebo-ai-rest-api";
import { Observable } from "rxjs";
import { BaseEntityEditingComponent, GeboAIFileType, GeboFormGroupsService, GeboUIActionRequest, GeboUIActionRoutingService, GeboUIOutputForwardingService } from "@Gebo.ai/reusable-ui";
import { ConfirmationService } from 'primeng/api';
import * as i0 from "@angular/core";
export declare class GeboAiGitEndpointAdminComponent extends BaseEntityEditingComponent<GGitProjectEndpoint> {
    private gitSystemsController;
    private projectsController;
    private secretControllerService;
    private JobLauncherControllerService;
    private actionsRouter;
    private geboFGService;
    private outForwardingService?;
    /**
     * Defines the entity name for this component as GGitProjectEndpoint
     */
    protected entityName: string;
    /**
     * Input property to control whether the Git system can be modified
     */
    cantModifyGitSystem: boolean;
    /**
     * Input property to control whether the project can be modified
     */
    cantModifyProject: boolean;
    /**
     * Form group to manage all the input fields for the Git endpoint
     */
    formGroup: FormGroup<any>;
    /**
     * Observable to fetch and display available projects
     */
    projectsObservable: Observable<GProject[]>;
    /**
     * Observable to fetch and display available Git systems
     */
    gitSystemsObservable: Observable<GGitContentManagementSystem[]>;
    /**
     * Context identifier for Git identity secrets
     */
    private actualIdentityContext;
    /**
     * Observable to fetch and display available identities for Git authentication
     */
    identitiesObservable: Observable<SecretInfo[]>;
    /**
     * Observable to fetch and display available Git branches
     */
    branchesObservable: Observable<{
        code: string;
        description: string;
    }[]>;
    /**
     * Flag to track whether the repository has public access
     */
    publicAccess: boolean;
    /**
     * Flag to track whether the endpoint is published
     */
    published: boolean;
    /**
     * Action request for creating a new Git secret
     */
    newSecretAction: GeboUIActionRequest;
    /**
     * Stores the last values of the endpoint to detect changes
     */
    private lastValues?;
    /**
     * List of file types supported by the system
     */
    fileTypesList: GeboAIFileType[];
    /**
     * Constructor for the Git Endpoint Admin Component
     * Initializes services and sets up form control behavior
     */
    constructor(injector: Injector, gitSystemsController: GitSystemsControllerService, projectsController: ProjectsControllerService, secretControllerService: SecretsControllerService, JobLauncherControllerService: JobLauncherControllerService, actionsRouter: GeboUIActionRoutingService, confirmService: ConfirmationService, geboFGService: GeboFormGroupsService, outForwardingService?: GeboUIOutputForwardingService | undefined);
    /**
     * Evaluates whether the branches list needs to be reloaded based on changes to repository URI,
     * identity code, or public access flag
     * @param value The current Git project endpoint values
     */
    private evaluateBranchesListReload;
    /**
     * Handles changes to Git connectivity parameters and triggers branch list refresh
     */
    onGitConnectivityChange(): void;
    /**
     * Checks if there are any backend processing jobs running for this entity
     * @param reference The entity reference to check
     * @returns Observable<boolean> indicating if backend jobs are running
     */
    protected checkBackendProcessing(reference: {
        className?: string;
        code?: string;
    }): Observable<boolean>;
    /**
     * Finds a Git endpoint by its code
     * @param code The endpoint code to search for
     * @returns Observable containing the found Git endpoint or null
     */
    findByCode(code: string): Observable<GGitProjectEndpoint | null>;
    /**
     * Saves changes to an existing Git endpoint
     * @param value The Git endpoint to update
     * @returns Observable containing the updated Git endpoint
     */
    save(value: GGitProjectEndpoint): Observable<GGitProjectEndpoint>;
    /**
     * Deletes a Git endpoint
     * @param value The Git endpoint to delete
     * @returns Observable indicating success
     */
    delete(value: GGitProjectEndpoint): Observable<boolean>;
    /**
     * Inserts a new Git endpoint
     * @param value The Git endpoint to insert
     * @returns Observable containing the inserted Git endpoint
     */
    insert(value: GGitProjectEndpoint): Observable<GGitProjectEndpoint>;
    /**
     * Checks if the Git endpoint can be deleted
     * @param value The Git endpoint to check
     * @returns Observable containing the deletion status and message
     */
    canBeDeleted(value: GGitProjectEndpoint): Observable<{
        canBeDeleted: boolean;
        message: string;
    }>;
    /**
     * Handles actions after loading persistent data
     * @param actualValue The loaded Git endpoint data
     */
    protected onLoadedPersistentData(actualValue: GGitProjectEndpoint): void;
    /**
     * Handles actions when new data is created
     * @param actualValue The new Git endpoint data
     */
    protected onNewData(actualValue: GGitProjectEndpoint): void;
    /**
     * Publishes the Git endpoint by creating a job in the backend
     * Saves the data first, then initiates the job and routes to the job status view
     */
    doPublish(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<GeboAiGitEndpointAdminComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<GeboAiGitEndpointAdminComponent, "gebo-ai-git-endpoint-admin-component", never, { "cantModifyGitSystem": { "alias": "cantModifyGitSystem"; "required": false; }; "cantModifyProject": { "alias": "cantModifyProject"; "required": false; }; }, {}, never, never, false, never>;
}
//# sourceMappingURL=gebo-ai-git-endpoint-admin.component.d.ts.map