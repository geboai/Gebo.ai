/**
 * This Source Code is subject to the terms of the
 * Gebo.ai community version Mozilla Public License Version 2.0 (MPL-2.0) — With Data Protection Clauses
 * If a copy of the LICENCE was not distributed with this file, You can obtain one at
 * https://gebo.ai/gebo-ai-community-version-mozilla-public-license-version-2-0-mpl-2-0-with-data-protection-clauses/
 * and https://mozilla.org/MPL/2.0/.
 * Copyright (c) 2025+ Gebo.ai
 */
/**
 * AI generated comments
 * This component manages Git system administration in the Gebo.ai application.
 * It extends the BaseEntityEditingComponent to provide CRUD operations for Git content management systems.
 * The component allows users to create, update, and delete Git system configurations
 * and manages related identity secrets.
 */
import { Injector } from "@angular/core";
import { FormGroup } from "@angular/forms";
import { GGitContentManagementSystem, GContentManagementSystemType, GitSystemsControllerService, SecretsControllerService, SecretInfo } from "@Gebo.ai/gebo-ai-rest-api";
import { Observable } from "rxjs";
import { BaseEntityEditingComponent, GeboFormGroupsService, GeboUIActionRoutingService, GeboUIOutputForwardingService } from "@Gebo.ai/reusable-ui";
import { ConfirmationService } from "primeng/api";
import * as i0 from "@angular/core";
export declare class GeboAiGitSystemAdminComponent extends BaseEntityEditingComponent<GGitContentManagementSystem> {
    private gitControllerService;
    private secretControllerService;
    private geboFGService;
    private outForwardingService?;
    /**
     * The entity name used for identification in the base component
     */
    protected entityName: string;
    /**
     * Input property to control whether the Git system reference can be modified
     * When true, the component will prevent modifications to the Git system reference
     */
    cantModifyGitSystemReference: boolean;
    /**
     * Array to store available Git content management system types
     */
    systemTypes: GContentManagementSystemType[];
    /**
     * Form group to capture and manage Git system configuration data
     * Includes fields for code, description, baseUri, type, access settings, and identity
     */
    formGroup: FormGroup<any>;
    /**
     * Flag indicating whether the Git system has public access
     */
    publicAccess: boolean;
    /**
     * Observable that provides the available Git system types
     */
    contentManagementSystemTypeObservable: Observable<GContentManagementSystemType[]>;
    /**
     * Secret context code used for identity management
     * Follows the format 'git-system:' + codeValue
     */
    secretContextCode: string;
    /**
     * Observable that provides the list of secret identities for the current Git system
     */
    identitiesObservable: Observable<SecretInfo[]>;
    /**
     * Component constructor
     * Sets up subscriptions to form control value changes to update the secret context
     * and public access flag when their corresponding values change
     *
     * @param injector Angular injector for dependency injection
     * @param gitControllerService Service for Git system operations
     * @param secretControllerService Service for secret management operations
     * @param geboFGService Service for form group management
     * @param confirmService Service for user confirmations
     * @param geboUIActionRoutingService Service for UI action routing
     * @param outForwardingService Optional service for output forwarding
     */
    constructor(injector: Injector, gitControllerService: GitSystemsControllerService, secretControllerService: SecretsControllerService, geboFGService: GeboFormGroupsService, confirmService: ConfirmationService, geboUIActionRoutingService: GeboUIActionRoutingService, outForwardingService?: GeboUIOutputForwardingService | undefined);
    /**
     * Refreshes the observable that provides secret identities
     * Uses the current secretContextCode to fetch relevant identities
     */
    refreshIdentitiesObservable(): void;
    /**
     * Overrides the base method to find a Git system by its code
     * @param code The code of the Git system to find
     * @returns An Observable containing the found Git system or null if not found
     */
    findByCode(code: string): Observable<GGitContentManagementSystem | null>;
    /**
     * Overrides the base method to save a Git system
     * @param value The Git system to save
     * @returns An Observable containing the saved Git system
     */
    save(value: GGitContentManagementSystem): Observable<GGitContentManagementSystem>;
    /**
     * Overrides the base method to delete a Git system
     * @param value The Git system to delete
     * @returns An Observable containing true if deletion is successful
     */
    delete(value: GGitContentManagementSystem): Observable<boolean>;
    /**
     * Overrides the base method to insert a new Git system
     * @param value The Git system to insert
     * @returns An Observable containing the inserted Git system
     */
    insert(value: GGitContentManagementSystem): Observable<GGitContentManagementSystem>;
    /**
     * Overrides the base method to check if a Git system can be deleted
     * Currently always returns true with an empty message
     * @param value The Git system to check
     * @returns An Observable containing the deletion status and message
     */
    canBeDeleted(value: GGitContentManagementSystem): Observable<{
        canBeDeleted: boolean;
        message: string;
    }>;
    static ɵfac: i0.ɵɵFactoryDeclaration<GeboAiGitSystemAdminComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<GeboAiGitSystemAdminComponent, "gebo-ai-git-system-admin-component", never, { "cantModifyGitSystemReference": { "alias": "cantModifyGitSystemReference"; "required": false; }; }, {}, never, never, false, never>;
}
//# sourceMappingURL=gebo-ai-git-system-admin.component.d.ts.map