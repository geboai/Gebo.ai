/**
 * This Source Code is subject to the terms of the
 * Gebo.ai community version Mozilla Public License Version 2.0 (MPL-2.0) — With Data Protection Clauses
 * If a copy of the LICENCE was not distributed with this file, You can obtain one at
 * https://gebo.ai/gebo-ai-community-version-mozilla-public-license-version-2-0-mpl-2-0-with-data-protection-clauses/
 * and https://mozilla.org/MPL/2.0/.
 * Copyright (c) 2025+ Gebo.ai
 */
/**
 * AI generated comments
 * Component for managing user data in the Gebo.ai application.
 * Provides functionality for creating, editing, and deleting users with role management.
 * Handles form control for user properties and displays messages for operation outcomes.
 */
import { EventEmitter, OnChanges, OnInit, SimpleChanges } from "@angular/core";
import { FormGroup } from "@angular/forms";
import { AuthProviderDto, AuthProvidersControllerService, EditableUser, UsersAdminControllerService } from "@Gebo.ai/gebo-ai-rest-api";
import { ConfirmationService, ToastMessageOptions } from "primeng/api";
import { Observable } from "rxjs";
import * as i0 from "@angular/core";
export declare class GeboAIUserComponent implements OnInit, OnChanges {
    private usersAdminControllerService;
    private authProvidersControllerService;
    private confirmService;
    /** Indicates if an operation is in progress */
    loading: boolean;
    /** Array to store toast messages displayed to the user */
    userMessages: ToastMessageOptions[];
    /** User data received as input, used for editing existing users */
    user?: EditableUser;
    /** Mode of operation: "NEW" for creating a new user, "EDIT" for updating an existing one */
    mode?: "EDIT" | "NEW";
    /** Event emitter to notify parent components of changes to user data */
    changedData: EventEmitter<EditableUser | undefined>;
    /** Form group for managing user data fields */
    formGroup: FormGroup;
    /** Form group for managing password input */
    pwdFormGroup: FormGroup;
    /** Available roles for user assignment */
    protected rolesList: string[];
    protected actualAuthProvider?: AuthProviderDto.ProviderEnum;
    protected authProviderObservable: Observable<{
        code?: string;
        description?: string;
    }[]>;
    /**
     * Component constructor
     * @param usersAdminControllerService Service for user administration operations
     * @param confirmService Service for displaying confirmation dialogs
     */
    constructor(usersAdminControllerService: UsersAdminControllerService, authProvidersControllerService: AuthProvidersControllerService, confirmService: ConfirmationService);
    /**
     * Lifecycle hook that is called after component initialization
     * Sets up a subscription to role changes to ensure USER role is always present
     * when APPLICATION role is not selected
     */
    ngOnInit(): void;
    /**
     * Lifecycle hook that is called when input properties change
     * Loads user data when in EDIT mode and the user input changes
     * @param changes Object containing changes to input properties
     */
    ngOnChanges(changes: SimpleChanges): void;
    /**
     * Handles the insertion of a new user
     * Checks if username already exists before creating the user
     */
    doInsert(): void;
    /**
     * Handles saving changes to an existing user
     * Updates the user data and notifies parent components
     */
    doSave(): void;
    /**
     * Performs the actual user deletion after confirmation
     * Calls the API to delete the user and notifies parent components
     */
    private doPhisicalDelete;
    /**
     * Initiates the user deletion process with confirmation
     * Displays a confirmation dialog before executing the delete operation
     */
    doDelete(): void;
    protected openChangePasswordWindow: boolean;
    protected doChangePassword(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<GeboAIUserComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<GeboAIUserComponent, "gebo-ai-user-component", never, { "user": { "alias": "user"; "required": false; }; "mode": { "alias": "mode"; "required": false; }; }, { "changedData": "changedData"; }, never, never, false, never>;
}
