/**
 * This Source Code is subject to the terms of the
 * Gebo.ai community version Mozilla Public License Version 2.0 (MPL-2.0) — With Data Protection Clauses
 * If a copy of the LICENCE was not distributed with this file, You can obtain one at
 * https://gebo.ai/gebo-ai-community-version-mozilla-public-license-version-2-0-mpl-2-0-with-data-protection-clauses/
 * and https://mozilla.org/MPL/2.0/.
 * Copyright (c) 2025+ Gebo.ai
 */
import { Injector } from "@angular/core";
import { FormGroup } from "@angular/forms";
import { UserInfos, UsersAdminControllerService, UsersGroup } from "@Gebo.ai/gebo-ai-rest-api";
import { BaseEntityEditingComponent, GeboFormGroupsService, GeboUIActionRoutingService, GeboUIOutputForwardingService } from "@Gebo.ai/reusable-ui";
import { ConfirmationService } from "primeng/api";
import { Observable } from "rxjs";
import * as i0 from "@angular/core";
/**
 * AI generated comments
 *
 * Component responsible for managing user groups in the Gebo.ai application.
 * This component extends BaseEntityEditingComponent to provide CRUD operations
 * for UsersGroup entities. It handles form creation, user loading,
 * and API interactions for group management.
 */
export declare class GeboAIGroupComponent extends BaseEntityEditingComponent<UsersGroup> {
    private userAdminControllerService;
    /**
     * Name of the entity this component manages.
     * Used for logging and error messages.
     */
    protected entityName: string;
    /**
     * Form group for managing UsersGroup data inputs.
     * Contains fields for code, description, and userIds.
     */
    formGroup: FormGroup<any>;
    /**
     * List of all users in the system.
     * Populated on component initialization to allow user selection for the group.
     */
    users?: UserInfos[];
    /**
     * Initializes the component by calling the parent initialization
     * and loading all users from the backend service.
     */
    ngOnInit(): void;
    /**
     * Constructor that injects required services.
     *
     * @param injector Angular injector for dependency resolution
     * @param geboFormGroupsService Service for managing form groups
     * @param confirmService Service for displaying confirmation dialogs
     * @param userAdminControllerService Service for user administration API calls
     * @param geboUIActionRoutingService Service for UI action routing
     * @param outputForwardingService Optional service for output forwarding
     */
    constructor(injector: Injector, geboFormGroupsService: GeboFormGroupsService, confirmService: ConfirmationService, userAdminControllerService: UsersAdminControllerService, geboUIActionRoutingService: GeboUIActionRoutingService, outputForwardingService?: GeboUIOutputForwardingService);
    /**
     * Finds a user group by its code.
     *
     * @param code The unique code of the group to find
     * @returns An Observable containing the found group or null if not found
     */
    findByCode(code: string): Observable<UsersGroup | null>;
    /**
     * Updates an existing user group.
     *
     * @param value The user group with updated values
     * @returns An Observable containing the updated group
     */
    save(value: UsersGroup): Observable<UsersGroup>;
    /**
     * Creates a new user group.
     *
     * @param value The new user group to create
     * @returns An Observable containing the created group
     */
    insert(value: UsersGroup): Observable<UsersGroup>;
    /**
     * Deletes a user group.
     *
     * @param value The user group to delete
     * @returns An Observable containing a boolean indicating success
     */
    delete(value: UsersGroup): Observable<boolean>;
    /**
     * Checks if a user group can be deleted.
     * Currently always returns true with no validation logic.
     *
     * @param value The user group to check
     * @returns An Observable containing the deletion possibility info
     */
    canBeDeleted(value: UsersGroup): Observable<{
        canBeDeleted: boolean;
        message: string;
    }>;
    static ɵfac: i0.ɵɵFactoryDeclaration<GeboAIGroupComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<GeboAIGroupComponent, "gebo-ai-users-group-component", never, {}, {}, never, never, false, never>;
}
