import { EventEmitter, OnChanges, OnInit, SimpleChanges } from "@angular/core";
import { FormGroup } from "@angular/forms";
import { GUserMessage, UsersAdminControllerService } from "@Gebo.ai/gebo-ai-rest-api";
import { GeboAITranslationService } from "@Gebo.ai/reusable-ui";
import { MessageService } from "primeng/api";
import * as i0 from "@angular/core";
export declare class GeboAIChangeUserPasswordComponent implements OnInit, OnChanges {
    private userAdminService;
    private messageService;
    private geboTranslationService;
    openWindow: boolean;
    username?: string;
    openWindowChange: EventEmitter<boolean>;
    protected loading: boolean;
    protected formGroup: FormGroup;
    messages: GUserMessage[];
    constructor(userAdminService: UsersAdminControllerService, messageService: MessageService, geboTranslationService: GeboAITranslationService);
    ngOnChanges(changes: SimpleChanges): void;
    ngOnInit(): void;
    protected doChangePassword(): void;
    protected skipWindow(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<GeboAIChangeUserPasswordComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<GeboAIChangeUserPasswordComponent, "gebo-ai-change-user-password-component", never, { "openWindow": { "alias": "openWindow"; "required": false; }; "username": { "alias": "username"; "required": false; }; }, { "openWindowChange": "openWindowChange"; }, never, never, false, never>;
}
