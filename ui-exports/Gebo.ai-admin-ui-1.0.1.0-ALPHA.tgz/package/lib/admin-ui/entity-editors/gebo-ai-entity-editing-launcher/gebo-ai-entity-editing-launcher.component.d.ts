import { GeboAIChooseDataSourceTypeComponent, GeboUIActionRoutingService } from "@Gebo.ai/reusable-ui";
import { GeboAiKnowledgeBaseAdminComponent } from "../gebo-ai-knowledgebase-admin/gebo-ai-knowledgebase-admin.component";
import { GeboAiProjectAdminComponent } from "../gebo-ai-knowledgebase-admin/gebo-ai-project-admin.component";
import { GeboAiGitSystemAdminComponent } from "../gebo-ai-git-admin/gebo-ai-git-system-admin.component";
import { GeboAiGitEndpointAdminComponent } from "../gebo-ai-git-admin/gebo-ai-git-endpoint-admin.component";
import { GeboAiSecretsAdminEditComponent } from "../gebo-ai-secrets-admin/gebo-ai-secrets-admin-edit.component";
import { GeboAIJobStatusViewerComponent } from "../gebo-ai-job-status-viewer/gebo-ai-job-status-viewer.component";
import { GeboAIFileSystemEndpointComponent } from "../gebo-ai-filesystems-admin/gebo-ai-filesystem-endpoint.component";
import { GeboAIOpenAIChatModelAdminComponent } from "../gebo-ai-models-admin/gebo-ai-openai-chatmodel-admin.component";
import { GeboAIOpenAIEmbedModelAdminComponent } from "../gebo-ai-models-admin/gebo-ai-openai-embedmodel-admin.component";
import { GeboAIOllamaChatModelAdminComponent } from "../gebo-ai-models-admin/gebo-ai-ollama-chatmodel-admin.component";
import { GeboAIOllamaEmbedModelAdminComponent } from "../gebo-ai-models-admin/gebo-ai-ollama-embedmodel-admin.component";
import { GeboAIChatProfileAdminComponent } from "../gebo-ai-chat-profile-admin/gebo-ai-chat-profile-admin.component";
import { GeboAIPromptAdminComponent } from "../gebo-ai-prompt-admin/gebo-ai-prompt-admin.component";
import { GeboAIGroupComponent } from "../gebo-ai-users-admin/gebo-ai-group.component";
import { GeboAIUploadsEndpointComponent } from "../gebo-ai-uploads-admin/gebo-ai-uploads-endpoint.component";
import { GeboAIGFileSystemShareReferenceAdminComponent } from '../gebo-ai-filesystems-admin/gebo-ai-filesystem-share-reference-admin.component';
import { GeboAIGoogleSearchAccountComponent } from "../gebo-ai-google-search-admin/gebo-ai-google-search-account.component";
import { GeboAIAnthropicChatModelAdminComponent } from "../gebo-ai-models-admin/gebo-ai-anthropic-chatmodel-admin.component";
import { GeboAIConfluenceEndpointComponent } from "../gebo-ai-atlassian-admin/gebo-ai-confluence-endpoint.component";
import { GeboAIConfluenceAdminComponent } from "../gebo-ai-atlassian-admin/gebo-ai-confluence-system-admin.component";
import { GeboAiGoogleDriveSystemAdminComponent } from "../gebo-ai-google-workspaces-admin/gebo-ai-google-drive-admin.component";
import { GeboAiGoogleDriveProjectEndpointAdminComponent } from "../gebo-ai-google-workspaces-admin/gebo-ai-google-drive-endpoint-admin.component";
import { GeboAIGenericOpenAIAPIChatModelAdminComponent } from "../gebo-ai-models-admin/gebo-ai-generic-openai-api-chatmodel-admin.component";
import { GeboAIGenericOpenAIAPIEmbedModelAdminComponent } from "../gebo-ai-models-admin/gebo-ai-generic-openai-api-embedmodel-admin.component";
import { GeboAIGoogleVertexChatModelAdminComponent } from "../gebo-ai-models-admin/gebo-ai-google-vertex-chatmodel-admin.component";
import { GeboAIGoogleVertexEmbedModelAdminComponent } from "../gebo-ai-models-admin/gebo-ai-google-vertex-embedmodel-admin.component";
import { GeboAIMistralAIChatModelAdminComponent } from "../gebo-ai-models-admin/gebo-ai-mistralai-chatmodel-admin.component";
import { GeboAIMistralAIEmbedModelAdminComponent } from "../gebo-ai-models-admin/gebo-ai-mistralai-embedmodel-admin.component";
import { GeboAISharepointEndpointComponent } from "../gebo-ai-sharepoint-admin/gebo-ai-sharepoint-endpoint.component";
import { GeboAISharepointAdminComponent } from "../gebo-ai-sharepoint-admin/gebo-ai-sharepoint-system-admin.component";
import { GeboAIJiraAdminComponent } from "../gebo-ai-atlassian-admin/gebo-ai-jira-system-admin.component";
import { GeboAIJiraEndpointComponent } from "../gebo-ai-atlassian-admin/gebo-ai-jira-endpoint.component";
import { GeboAIDeepseekChatModelAdminComponent } from "../gebo-ai-models-admin/gebo-ai-deepseek-chatmodel-admin.component";
import { GeboAIOauth2RegistrationComponent } from "../gebo-ai-oauth2-admin/gebo-ai-oauth2-registration.component";
import { GeboAIAzureOpenAIChatModelAdminComponent } from "../gebo-ai-models-admin/gebo-ai-azure-openai-chatmodel-admin.component";
import { GeboAIAzureOpenAIEmbedModelAdminComponent } from "../gebo-ai-models-admin/gebo-ai-azure-openai-embedmodel-admin.component";
import { GeboAIGraphRagExtractionConfigComponent } from "../gebo-graph-rag-extraction-config-admin/graph-rag-extraction-config.component";
import { GeboAIDeepSearchConfigAdminComponent } from "../gebo-deep-search-admin/gebo-deep-search-admin.component";
import { GeboAIGenericOpenaAIAPiRankerAdminComponent } from "../gebo-ai-models-admin/gebo-ai-generic-openai-api-ranker-admin.component";
import * as i0 from "@angular/core";
/**
 * @Component GeboAiEntityEditingLauncherComponent
 *
 * This component serves as a central hub for launching the appropriate admin interfaces
 * for different entity types in the Gebo.ai system. It maintains references to all the
 * different administrative component types that can be launched depending on the entity
 * being edited. This allows for dynamic loading of the appropriate editing interface
 * based on user selection or system requirements.
 *
 * The component references various admin components including:
 * - Knowledge base and project management
 * - Git system and endpoint management
 * - Secret management
 * - Job status viewing
 * - Various AI model administration (OpenAI, Anthropic, Ollama, etc.)
 * - Integration components for different platforms (Confluence, Google Drive, SharePoint, etc.)
 */
export declare class GeboAiEntityEditingLauncherComponent {
    private actionServices;
    /**
     * Reference to the Knowledge Base admin component type
     */
    knowledgebaseAdminType: typeof GeboAiKnowledgeBaseAdminComponent;
    /**
     * Reference to the Project admin component type
     */
    projectAdminType: typeof GeboAiProjectAdminComponent;
    /**
     * Reference to the Git System admin component type
     */
    gitSystemAdminType: typeof GeboAiGitSystemAdminComponent;
    /**
     * Reference to the Git Endpoint admin component type
     */
    gitEndpointAdminType: typeof GeboAiGitEndpointAdminComponent;
    /**
     * Reference to the Secrets admin component type
     */
    secretAdminType: typeof GeboAiSecretsAdminEditComponent;
    /**
     * Reference to the Job Status Viewer component type
     */
    jobViewerType: typeof GeboAIJobStatusViewerComponent;
    /**
     * Reference to the Uploads Endpoint component type
     */
    uploadsType: typeof GeboAIUploadsEndpointComponent;
    /**
     * Reference to the File Systems Endpoint component type
     */
    fileSystemsType: typeof GeboAIFileSystemEndpointComponent;
    /**
     * Reference to the OpenAI Chat Model admin component type
     */
    openAIChatModelType: typeof GeboAIOpenAIChatModelAdminComponent;
    /**
     * Reference to the Anthropic Chat Model admin component type
     */
    AnthropicChatModelType: typeof GeboAIAnthropicChatModelAdminComponent;
    /**
     * Reference to the Deepseek Chat Model admin component type
     */
    DeepseekChatModelType: typeof GeboAIDeepseekChatModelAdminComponent;
    /**
     * Reference to the OpenAI Embedding Model admin component type
     */
    openAIEmbedModelType: typeof GeboAIOpenAIEmbedModelAdminComponent;
    /**
     * Reference to the Ollama Chat Model admin component type
     */
    ollamaChatModelType: typeof GeboAIOllamaChatModelAdminComponent;
    /**
     * Reference to the Ollama Embedding Model admin component type
     */
    ollamaEmbedModelType: typeof GeboAIOllamaEmbedModelAdminComponent;
    /**
     * Reference to the Chat Profile admin component type
     */
    chatProfileType: typeof GeboAIChatProfileAdminComponent;
    /**
     * Reference to the Prompt admin component type
     */
    promptType: typeof GeboAIPromptAdminComponent;
    /**
     * Reference to the Users Group component type
     */
    usersGroupType: typeof GeboAIGroupComponent;
    /**
     * Reference to the File System Share Reference admin component type
     */
    GFileSystemShareReferenceType: typeof GeboAIGFileSystemShareReferenceAdminComponent;
    /**
     * Reference to the Google Search Configuration component type
     */
    googleSearchConfigType: typeof GeboAIGoogleSearchAccountComponent;
    /**
     * Reference to the Confluence Endpoint component type
     */
    confluenceEndpointType: typeof GeboAIConfluenceEndpointComponent;
    /**
     * Reference to the Confluence System admin component type
     */
    confluenceSystemType: typeof GeboAIConfluenceAdminComponent;
    /**
     * Reference to the Google Drive System admin component type
     */
    googleDriveSystemType: typeof GeboAiGoogleDriveSystemAdminComponent;
    /**
     * Reference to the Google Drive Endpoint admin component type
     */
    googleDriveEndpointType: typeof GeboAiGoogleDriveProjectEndpointAdminComponent;
    /**
     * Reference to the Generic OpenAI API Chat Model admin component type
     */
    genericOpenAIAPIChatModelType: typeof GeboAIGenericOpenAIAPIChatModelAdminComponent;
    /**
     * Reference to the Generic OpenAI API Embedding Model admin component type
     */
    genericOpenAIAPIEmbeddedModelType: typeof GeboAIGenericOpenAIAPIEmbedModelAdminComponent;
    /**
     * Reference to the Google Vertex Chat Model admin component type
     */
    googleVertexChatModelType: typeof GeboAIGoogleVertexChatModelAdminComponent;
    /**
     * Reference to the Google Vertex Embedding Model admin component type
     */
    googleVertexEmbeddingModelType: typeof GeboAIGoogleVertexEmbedModelAdminComponent;
    /**
     * Reference to the MistralAI Chat Model admin component type
     */
    mistralAIChatModelType: typeof GeboAIMistralAIChatModelAdminComponent;
    /**
     * Reference to the MistralAI Embedding Model admin component type
     */
    mistralAIEmbeddingModelType: typeof GeboAIMistralAIEmbedModelAdminComponent;
    /**
     * Reference to the Choose Data Source Type component
     */
    choosedDataSourceType: typeof GeboAIChooseDataSourceTypeComponent;
    /**
     * Reference to the SharePoint Endpoint admin component type
     */
    sharepointEndpointAdminType: typeof GeboAISharepointEndpointComponent;
    /**
     * Reference to the SharePoint System admin component type
     */
    sharepointSystemType: typeof GeboAISharepointAdminComponent;
    /**
     * Reference to the Jira System admin component type
     */
    jiraSystemType: typeof GeboAIJiraAdminComponent;
    /**
     * Reference to the Jira Endpoint System admin component type
     */
    jiraEndpointSystemType: typeof GeboAIJiraEndpointComponent;
    geboAIOauth2RegistrationComponent: typeof GeboAIOauth2RegistrationComponent;
    azureOpenAIChatModelComponent: typeof GeboAIAzureOpenAIChatModelAdminComponent;
    azureOpenAIEmbeddingModelComponent: typeof GeboAIAzureOpenAIEmbedModelAdminComponent;
    geboGraphRagExtractionConfigComponent: typeof GeboAIGraphRagExtractionConfigComponent;
    deepSearchConfigAdminComponent: typeof GeboAIDeepSearchConfigAdminComponent;
    genericOpenAIRankerModelComponent: typeof GeboAIGenericOpenaAIAPiRankerAdminComponent;
    /**
     * Constructor for the GeboAiEntityEditingLauncherComponent
     *
     * @param actionServices Service for routing actions within the UI
     */
    constructor(actionServices: GeboUIActionRoutingService);
    static ɵfac: i0.ɵɵFactoryDeclaration<GeboAiEntityEditingLauncherComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<GeboAiEntityEditingLauncherComponent, "gebo-ai-entity-editing-launcher", never, {}, {}, never, never, false, never>;
}
