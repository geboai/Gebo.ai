/**
 * This Source Code is subject to the terms of the
 * Gebo.ai community version Mozilla Public License Version 2.0 (MPL-2.0) — With Data Protection Clauses
 * If a copy of the LICENCE was not distributed with this file, You can obtain one at
 * https://gebo.ai/gebo-ai-community-version-mozilla-public-license-version-2-0-mpl-2-0-with-data-protection-clauses/
 * and https://mozilla.org/MPL/2.0/.
 * Copyright (c) 2025+ Gebo.ai
 */
/**
 * AI generated comments
 *
 * This component implements a wizard for generating AI-assisted prompt templates.
 * It allows users to select a model and provide a query to generate an appropriate
 * prompt template that can then be applied to a parent form.
 *
 * The component handles loading available chat models, configuring the wizard,
 * and managing the dialog for prompt generation and selection.
 */
import { OnChanges, OnInit, SimpleChanges } from "@angular/core";
import { FormGroup } from "@angular/forms";
import { ChatModelsLookupControllerService, GLookupEntry, OperationStatusPromptTemplateResponse, PromptTemplateWizardControllerService } from "@Gebo.ai/gebo-ai-rest-api";
import { ToastMessageOptions } from "primeng/api";
import * as i0 from "@angular/core";
export declare class GeboAIPromptWizardComponent implements OnInit, OnChanges {
    private promptWizardControllerService;
    private modelsLookupService;
    /**
     * Name of the control in the parent form group where the generated prompt will be delivered
     */
    deliveryPromptControlName?: string;
    /**
     * Parent form group that will receive the generated prompt
     */
    deliveryFormGroup?: FormGroup;
    /**
     * Optional placeholder text for the prompt template input field
     */
    promptTemplatePlaceholderText?: string;
    /**
     * Flag to determine if the wizard operates in RAG (Retrieval Augmented Generation) mode
     */
    ragWizardMode: boolean;
    /**
     * Default placeholder text for prompt template when none is provided
     */
    defaultTemplatePlaceHolderText?: string;
    /**
     * Controls the visibility of the prompt wizard dialog
     */
    dialogVisible: boolean;
    /**
     * Messages to display to the user in the UI
     */
    userMessages: ToastMessageOptions[];
    /**
     * Flag to indicate when async operations are in progress
     */
    loading: boolean;
    /**
     * Form group for collecting user input including model selection and query
     */
    formGroup: FormGroup;
    /**
     * Form group for the generated prompt response
     */
    responseFormGroup: FormGroup;
    /**
     * Stores the most recent response from the prompt generation service
     */
    lastResponse?: OperationStatusPromptTemplateResponse;
    /**
     * Available chat models for prompt generation
     */
    chatModels?: GLookupEntry[];
    /**
     * Initializes the component with required services for prompt generation and model lookup
     *
     * @param promptWizardControllerService Service for generating prompt templates
     * @param modelsLookupService Service for retrieving available chat models
     */
    constructor(promptWizardControllerService: PromptTemplateWizardControllerService, modelsLookupService: ChatModelsLookupControllerService);
    /**
     * Handler for closing the modal dialog
     *
     * @param a Event parameter (unused)
     */
    closeModal(a: any): void;
    /**
     * Initializes the component by loading available chat models and wizard configurations
     * Sets default prompt if available from configuration
     */
    ngOnInit(): void;
    /**
     * Responds to changes in input properties, particularly updating the query field
     * when the promptTemplatePlaceholderText input changes
     *
     * @param changes Simple changes object containing information about changed properties
     */
    ngOnChanges(changes: SimpleChanges): void;
    /**
     * Calls the prompt template generation service with the current form values
     * Updates the response form group with the generated template
     */
    doGeneratePrompt(): void;
    /**
     * Handles cancellation of the prompt generation dialog
     * Closes the dialog without applying the generated prompt
     */
    doCancelAction(): void;
    /**
     * Applies the generated prompt to the parent form and closes the dialog
     * Only functions if all required inputs (deliveryFormGroup, deliveryPromptControlName)
     * are provided and the response form is valid
     */
    doAcceptPrompt(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<GeboAIPromptWizardComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<GeboAIPromptWizardComponent, "gebo-ai-prompt-wizard-component", never, { "deliveryPromptControlName": { "alias": "deliveryPromptControlName"; "required": false; }; "deliveryFormGroup": { "alias": "deliveryFormGroup"; "required": false; }; "promptTemplatePlaceholderText": { "alias": "promptTemplatePlaceholderText"; "required": false; }; "ragWizardMode": { "alias": "ragWizardMode"; "required": false; }; }, {}, never, never, false, never>;
}
