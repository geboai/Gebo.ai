/**
 * This Source Code is subject to the terms of the
 * Gebo.ai community version Mozilla Public License Version 2.0 (MPL-2.0) — With Data Protection Clauses
 * If a copy of the LICENCE was not distributed with this file, You can obtain one at
 * https://gebo.ai/gebo-ai-community-version-mozilla-public-license-version-2-0-mpl-2-0-with-data-protection-clauses/
 * and https://mozilla.org/MPL/2.0/.
 * Copyright (c) 2025+ Gebo.ai
 */
import { OnInit } from "@angular/core";
import { ControlValueAccessor, FormGroup } from "@angular/forms";
import { BuildSystemRef, BuildSystemsControllerService } from "@Gebo.ai/gebo-ai-rest-api";
import { Observable } from "rxjs";
import * as i0 from "@angular/core";
/**
 * AI generated comments
 * Extends the BuildSystemRef interface with additional properties for UI representation
 */
interface ExtendedBuildSystemRef extends BuildSystemRef {
    code?: string;
    description?: string;
}
/**
 * Component that provides a UI for selecting build systems
 * Implements ControlValueAccessor to integrate with Angular Forms
 * Allows users to choose from available build systems and configurations
 */
export declare class BuildSystemsChooserComponent implements OnInit, ControlValueAccessor {
    private buildSystemController;
    /** Form group containing the chooser control */
    formGroup: FormGroup;
    /** Observable that emits the list of available build systems */
    buildSystemsObservable: Observable<ExtendedBuildSystemRef[]>;
    /** Currently selected build system references */
    value: BuildSystemRef[];
    /** Cached data of available build systems */
    buildSystemsData: ExtendedBuildSystemRef[];
    /** Flag to control whether the component is in read-only mode */
    readonly: boolean;
    /**
     * Constructor that injects the build system controller service
     * @param buildSystemController Service to fetch build system data
     */
    constructor(buildSystemController: BuildSystemsControllerService);
    /**
     * Initializes the component, sets up form control subscriptions,
     * and fetches available build systems from the API
     */
    ngOnInit(): void;
    /**
     * ControlValueAccessor implementation: Updates the component value from the form model
     * @param obj Array of BuildSystemRef objects to set as the selected value
     */
    writeValue(obj: any): void;
    /** Function to call when the value changes */
    onChange?: (v: any) => void;
    /**
     * ControlValueAccessor implementation: Registers the onChange callback
     * @param fn Function to call when the value changes
     */
    registerOnChange(fn: any): void;
    /** Function to call when the control is touched */
    onTouch?: (v: any) => void;
    /**
     * ControlValueAccessor implementation: Registers the onTouched callback
     * @param fn Function to call when the control is touched
     */
    registerOnTouched(fn: any): void;
    /**
     * ControlValueAccessor implementation: Sets the disabled state of the control
     * @param isDisabled Whether the control should be disabled
     */
    setDisabledState?(isDisabled: boolean): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<BuildSystemsChooserComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<BuildSystemsChooserComponent, "gebo-ai-build-systems-chooser", never, { "readonly": { "alias": "readonly"; "required": false; }; }, {}, never, never, false, never>;
}
export {};
//# sourceMappingURL=build-systems-chooser.component.d.ts.map