/**
 * This Source Code is subject to the terms of the
 * Gebo.ai community version Mozilla Public License Version 2.0 (MPL-2.0) — With Data Protection Clauses
 * If a copy of the LICENCE was not distributed with this file, You can obtain one at
 * https://gebo.ai/gebo-ai-community-version-mozilla-public-license-version-2-0-mpl-2-0-with-data-protection-clauses/
 * and https://mozilla.org/MPL/2.0/.
 * Copyright (c) 2025+ Gebo.ai
 */
import { OnChanges, OnInit, SimpleChanges } from "@angular/core";
import { FormGroup } from "@angular/forms";
import { GBaseChatModelConfig } from "@Gebo.ai/gebo-ai-rest-api";
import * as i0 from "@angular/core";
/**
 * @Component GeboAIStandardChatModelSettings
 *
 * A component that provides UI controls for configuring standard chat model settings.
 * It handles temperature, top-p, and context length parameters that are common across
 * many language models. The component responds to model changes and updates settings
 * based on the selected model's capabilities and constraints.
 */
export declare class GeboAIStandardChatModelSettings implements OnInit, OnChanges {
    formGroup?: FormGroup;
    minTemperature: number;
    maxTemperature: number;
    maxTemperatureDigits: number;
    minTopP: number;
    maxTopP: number;
    maxTopPDigits: number;
    minContextLength: number;
    maxContextLength: number;
    thinking: boolean;
    maxGeneratedTokens: boolean;
    protected defaultContextLength?: number;
    protected modelHaveNativeContextWindowSettings: boolean;
    protected thinkingOptions: {
        code: GBaseChatModelConfig.ThinkingEnum;
        description: string;
    }[];
    /**
     * Lifecycle hook that is called after data-bound properties are initialized
     */
    ngOnInit(): void;
    /**
     * Updates the component state based on the selected model's capabilities
     * Sets appropriate default context length and determines if the model
     * has native context window settings
     *
     * @param choosed - The selected model object containing context length information
     */
    private notifyChoosedModelChange;
    /**
     * Lifecycle hook that is called when any data-bound property of the directive changes
     * Handles changes to the form group and subscribes to model selection changes
     *
     * @param changes - Object containing all changed properties with current and previous values
     */
    ngOnChanges(changes: SimpleChanges): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<GeboAIStandardChatModelSettings, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<GeboAIStandardChatModelSettings, "gebo-ai-standard-chat-model-settings-component", never, { "formGroup": { "alias": "formGroup"; "required": false; }; "minTemperature": { "alias": "minTemperature"; "required": false; }; "maxTemperature": { "alias": "maxTemperature"; "required": false; }; "maxTemperatureDigits": { "alias": "maxTemperatureDigits"; "required": false; }; "minTopP": { "alias": "minTopP"; "required": false; }; "maxTopP": { "alias": "maxTopP"; "required": false; }; "maxTopPDigits": { "alias": "maxTopPDigits"; "required": false; }; "minContextLength": { "alias": "minContextLength"; "required": false; }; "maxContextLength": { "alias": "maxContextLength"; "required": false; }; "thinking": { "alias": "thinking"; "required": false; }; "maxGeneratedTokens": { "alias": "maxGeneratedTokens"; "required": false; }; }, {}, never, never, false, never>;
}
