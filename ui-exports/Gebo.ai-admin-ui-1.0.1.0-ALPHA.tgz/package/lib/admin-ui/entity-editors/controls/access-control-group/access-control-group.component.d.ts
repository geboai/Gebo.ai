/**
 * This Source Code is subject to the terms of the
 * Gebo.ai community version Mozilla Public License Version 2.0 (MPL-2.0) — With Data Protection Clauses
 * If a copy of the LICENCE was not distributed with this file, You can obtain one at
 * https://gebo.ai/gebo-ai-community-version-mozilla-public-license-version-2-0-mpl-2-0-with-data-protection-clauses/
 * and https://mozilla.org/MPL/2.0/.
 * Copyright (c) 2025+ Gebo.ai
 */
/**
 * AI generated comments
 * This module provides a component for controlling access permissions in the application.
 * It allows setting access controls for users and groups, with options to make resources
 * accessible to all users or specific users/groups.
 */
import { OnChanges, OnInit, SimpleChanges } from "@angular/core";
import { FormGroup } from "@angular/forms";
import { UserInfos, UsersAdminControllerService, UsersGroup } from "@Gebo.ai/gebo-ai-rest-api";
import * as i0 from "@angular/core";
/**
 * Component that provides UI for managing access control settings.
 * It allows selecting users and groups who should have access to a resource,
 * as well as an option to make the resource accessible to all users.
 */
export declare class GeboAIAccessControlComponent implements OnInit, OnChanges {
    private userAdminControllerService;
    /**
     * Form group that contains the access control settings.
     * Expected to contain or receive controls for accessibleGroups, accessibleUsers, and accessibleToAll.
     */
    formGroup?: FormGroup;
    /**
     * Flag indicating whether the component is currently loading data from the backend.
     */
    loadingRelatedBackend: boolean;
    /**
     * Creates an instance of the access control component.
     * @param userAdminControllerService Service for accessing user and group information
     */
    constructor(userAdminControllerService: UsersAdminControllerService);
    /**
     * Flag indicating whether the resource is accessible to all users.
     */
    accessibleToAll: boolean;
    /**
     * List of all users in the system that can be granted access.
     */
    users?: UserInfos[];
    /**
     * List of all user groups in the system that can be granted access.
     */
    groups?: UsersGroup[];
    /**
     * Initializes the component by fetching users and groups from the backend.
     * Uses forkJoin to parallelize the API calls for better performance.
     */
    ngOnInit(): void;
    /**
     * Initializes the form group by ensuring all required controls exist and
     * setting up value change subscriptions to keep the UI state synchronized.
     * If controls don't exist, they are added to the form group.
     */
    private initializeFormGroup;
    /**
     * Responds to input changes, particularly when the formGroup input changes.
     * Ensures the form group is properly initialized with the necessary controls.
     * @param changes The changes that occurred on the component's inputs
     */
    ngOnChanges(changes: SimpleChanges): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<GeboAIAccessControlComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<GeboAIAccessControlComponent, "gebo-ai-access-control", never, { "formGroup": { "alias": "formGroup"; "required": false; }; }, {}, never, never, false, never>;
}
//# sourceMappingURL=access-control-group.component.d.ts.map