/**
 * This Source Code is subject to the terms of the
 * Gebo.ai community version Mozilla Public License Version 2.0 (MPL-2.0) — With Data Protection Clauses
 * If a copy of the LICENCE was not distributed with this file, You can obtain one at
 * https://gebo.ai/gebo-ai-community-version-mozilla-public-license-version-2-0-mpl-2-0-with-data-protection-clauses/
 * and https://mozilla.org/MPL/2.0/.
 * Copyright (c) 2025+ Gebo.ai
 */
/**
 * AI generated comments
 *
 * This component manages advanced settings for chat models in the Gebo.ai application.
 * It provides functionality for displaying and configuring advanced options for chat models,
 * such as functions lookup and default prompt templates.
 */
import { OnChanges, OnInit, SimpleChanges } from "@angular/core";
import { FormGroup } from "@angular/forms";
import { FunctionsLookupControllerService, GLookupEntry, PromptTemplatesControllerService } from "@Gebo.ai/gebo-ai-rest-api";
import * as i0 from "@angular/core";
export declare class GeboAIAdvancedChatModelGroupComponent implements OnInit, OnChanges {
    private functionsLookupControllerService;
    private promptTemplatesControllerService;
    /** Form group for managing the advanced chat model settings */
    formGroup?: FormGroup;
    /**
     * Determines the mode of operation for the component
     * - NEW: Creating a new chat model
     * - EDIT: Editing an existing chat model
     * - EDIT_OR_NEW: Flexible mode supporting both operations
     */
    mode?: "NEW" | "EDIT" | "EDIT_OR_NEW";
    /** Flag indicating whether the entity data has been loaded */
    entityDataLoaded: boolean;
    /** List of available functions that can be used in the chat model */
    functionsList: GLookupEntry[];
    /** Loading state indicator for asynchronous operations */
    loading: boolean;
    /**
     * Constructor initializes the component with required services
     * @param functionsLookupControllerService Service for retrieving available functions
     * @param promptTemplatesControllerService Service for managing prompt templates
     */
    constructor(functionsLookupControllerService: FunctionsLookupControllerService, promptTemplatesControllerService: PromptTemplatesControllerService);
    /**
     * Lifecycle hook that initializes the component
     * Fetches the list of available functions when the component is initialized
     */
    ngOnInit(): void;
    /**
     * Lifecycle hook that responds to changes in component inputs
     * Fetches and sets the default prompt when entity data is loaded and form is available
     * @param changes SimpleChanges object containing current and previous values of inputs
     */
    ngOnChanges(changes: SimpleChanges): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<GeboAIAdvancedChatModelGroupComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<GeboAIAdvancedChatModelGroupComponent, "gebo-advanced-chatmodel-group-component", never, { "formGroup": { "alias": "formGroup"; "required": false; }; "mode": { "alias": "mode"; "required": false; }; "entityDataLoaded": { "alias": "entityDataLoaded"; "required": false; }; }, {}, never, never, false, never>;
}
