import { OnChanges, OnInit, SimpleChanges } from "@angular/core";
import { GeboNeo4jModuleSetupControllerService, GObjectRef, GraphRagConfigurationControllerService, GraphRagExtractionConfig } from "@Gebo.ai/gebo-ai-rest-api";
import { GeboUIActionRoutingService } from "@Gebo.ai/reusable-ui";
import * as i0 from "@angular/core";
export declare class GeboAIGraphragConfigComponent implements OnInit, OnChanges {
    private geboUIRouter;
    private graphRagConfigService;
    private graphRagModuleSetupService;
    context?: {
        knowledgeBaseCode?: string;
        projectCode?: string;
        reference?: GObjectRef;
    };
    protected graphRagConfig?: GraphRagExtractionConfig;
    protected neo4jEnabled: boolean;
    protected loading: boolean;
    protected graphRagIsSetup: boolean;
    constructor(geboUIRouter: GeboUIActionRoutingService, graphRagConfigService: GraphRagConfigurationControllerService, graphRagModuleSetupService: GeboNeo4jModuleSetupControllerService);
    private reload;
    ngOnInit(): void;
    ngOnChanges(changes: SimpleChanges): void;
    newConfiguration(): void;
    editConfiguration(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<GeboAIGraphragConfigComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<GeboAIGraphragConfigComponent, "gebo-ai-graphrag-component", never, { "context": { "alias": "context"; "required": false; }; }, {}, never, never, false, never>;
}
//# sourceMappingURL=graphrag-config.component.d.ts.map