/**
 * This Source Code is subject to the terms of the
 * Gebo.ai community version Mozilla Public License Version 2.0 (MPL-2.0) — With Data Protection Clauses
 * If a copy of the LICENCE was not distributed with this file, You can obtain one at
 * https://gebo.ai/gebo-ai-community-version-mozilla-public-license-version-2-0-mpl-2-0-with-data-protection-clauses/
 * and https://mozilla.org/MPL/2.0/.
 * Copyright (c) 2025+ Gebo.ai
 */
import { Injector } from "@angular/core";
import { FormGroup } from "@angular/forms";
import { GGoogleSearchApiCredentials, GoogleSearchConfigurationControllerService, SecretsControllerService } from "@Gebo.ai/gebo-ai-rest-api";
import { BaseEntityEditingComponent, GeboFormGroupsService, GeboUIActionRoutingService, GeboUIOutputForwardingService } from "@Gebo.ai/reusable-ui";
import { ConfirmationService } from "primeng/api";
import { Observable } from "rxjs";
import * as i0 from "@angular/core";
/**
 * Component responsible for managing Google Search API credentials.
 * This component extends BaseEntityEditingComponent to provide CRUD operations
 * for Google Search API credentials. It includes a form for editing credential
 * properties like code, description, secret code, and custom search engine ID.
 */
export declare class GeboAIGoogleSearchAccountComponent extends BaseEntityEditingComponent<GGoogleSearchApiCredentials> {
    private googleSearchConfigService;
    private secretsControllerService;
    /**
     * The entity name used for identification in the system
     */
    protected entityName: string;
    /**
     * Form group that contains the form controls for the Google Search API credentials
     * Includes fields for code, description, secretCode, and customSearchEngineId
     */
    formGroup: FormGroup<any>;
    /**
     * Observable that provides a list of available secret identities from the Google Search context
     */
    identitiesObservable: Observable<any[]>;
    /**
     * Action configuration for creating a new secret, specifying the Google Search context,
     * entity name, entity object, and the TOKEN type
     */
    newSecretAction: import("@Gebo.ai/reusable-ui").GeboUIActionRequest;
    /**
     * Constructor that initializes the component with necessary dependencies
     *
     * @param injector Angular injector for dependency injection
     * @param googleSearchConfigService Service to interact with Google Search configuration API
     * @param secretsControllerService Service to manage secrets
     * @param geboFormGroupsService Service to handle form groups
     * @param confirmationService Service to handle confirmation dialogs
     * @param geboUIActionRoutingService Service to handle UI action routing
     * @param outputForwardingService Optional service for output forwarding
     */
    constructor(injector: Injector, googleSearchConfigService: GoogleSearchConfigurationControllerService, secretsControllerService: SecretsControllerService, geboFormGroupsService: GeboFormGroupsService, confirmationService: ConfirmationService, geboUIActionRoutingService: GeboUIActionRoutingService, outputForwardingService?: GeboUIOutputForwardingService);
    /**
     * Retrieves a Google Search API credential by its code
     *
     * @param code The unique code of the credential to find
     * @returns An Observable containing the found credential or null if not found
     */
    findByCode(code: string): Observable<GGoogleSearchApiCredentials | null>;
    /**
     * Updates an existing Google Search API credential
     *
     * @param value The credential with updated values
     * @returns An Observable containing the updated credential
     */
    save(value: GGoogleSearchApiCredentials): Observable<GGoogleSearchApiCredentials>;
    /**
     * Creates a new Google Search API credential
     *
     * @param value The new credential to insert
     * @returns An Observable containing the newly created credential
     */
    insert(value: GGoogleSearchApiCredentials): Observable<GGoogleSearchApiCredentials>;
    /**
     * Deletes a Google Search API credential
     *
     * @param value The credential to delete
     * @returns An Observable containing a boolean indicating success
     */
    delete(value: GGoogleSearchApiCredentials): Observable<boolean>;
    /**
     * Checks if a Google Search API credential can be deleted
     * Currently always returns true with an empty message
     *
     * @param value The credential to check
     * @returns An Observable containing an object with canBeDeleted flag and a message
     */
    canBeDeleted(value: GGoogleSearchApiCredentials): Observable<{
        canBeDeleted: boolean;
        message: string;
    }>;
    static ɵfac: i0.ɵɵFactoryDeclaration<GeboAIGoogleSearchAccountComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<GeboAIGoogleSearchAccountComponent, "gebo-ai-google-search-account-component", never, {}, {}, never, never, false, never>;
}
