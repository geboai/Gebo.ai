import { Injector } from "@angular/core";
import { FormGroup } from "@angular/forms";
import { DeepSearchConfig, DeepSearchDataSourceAccess, GBaseObject, GeboDeepSearchAdminControllerService, UserInfos, UsersAdminControllerService, UsersGroup } from "@Gebo.ai/gebo-ai-rest-api";
import { BaseEntityEditingComponent, GeboFormGroupsService, GeboUIActionRoutingService, GeboUIOutputForwardingService } from "@Gebo.ai/reusable-ui";
import { ConfirmationService } from "primeng/api";
import { Observable } from "rxjs";
import * as i0 from "@angular/core";
export interface DataSourceAccessRow {
    dataSource: GBaseObject;
    formGroup: FormGroup;
    availableUsers: UserInfos[];
}
export declare class GeboAIDeepSearchConfigAdminComponent extends BaseEntityEditingComponent<DeepSearchConfig> {
    private deepSearchConfigService;
    private usersService;
    protected entityName: string;
    protected minThreashold: number;
    protected maxThreashold: number;
    formGroup: FormGroup<any>;
    protected defaultConfiguration?: DeepSearchConfig;
    protected searchType?: DeepSearchConfig.SearchTypeEnum;
    protected searchTypeOptions: {
        code: DeepSearchConfig.SearchTypeEnum;
        description: string;
    }[];
    protected users: UserInfos[];
    protected groups: UsersGroup[];
    protected dataSources: GBaseObject[];
    protected dsAccessRows: DataSourceAccessRow[];
    constructor(injector: Injector, geboFormGroupsService: GeboFormGroupsService, confirmationService: ConfirmationService, geboUIActionRoutingService: GeboUIActionRoutingService, outputForwardingService: GeboUIOutputForwardingService, deepSearchConfigService: GeboDeepSearchAdminControllerService, usersService: UsersAdminControllerService);
    ngOnInit(): void;
    protected getform(frm: string): FormGroup;
    protected onLoadedPersistentData(actualValue: DeepSearchConfig): void;
    protected onNewData(actualValue: DeepSearchConfig): void;
    findByCode(code: string): Observable<DeepSearchConfig | null>;
    private toggleAccessModes;
    protected buildDsAccessRows(incomingAccesses?: DeepSearchDataSourceAccess[]): void;
    private updateAvailableUsers;
    private prepareForSave;
    save(value: DeepSearchConfig): Observable<DeepSearchConfig>;
    insert(value: DeepSearchConfig): Observable<DeepSearchConfig>;
    delete(value: DeepSearchConfig): Observable<boolean>;
    canBeDeleted(value: DeepSearchConfig): Observable<{
        canBeDeleted: boolean;
        message: string;
    }>;
    static ɵfac: i0.ɵɵFactoryDeclaration<GeboAIDeepSearchConfigAdminComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<GeboAIDeepSearchConfigAdminComponent, "gebo-ai-deep-search-admin-component", never, {}, {}, never, never, false, never>;
}
//# sourceMappingURL=gebo-deep-search-admin.component.d.ts.map