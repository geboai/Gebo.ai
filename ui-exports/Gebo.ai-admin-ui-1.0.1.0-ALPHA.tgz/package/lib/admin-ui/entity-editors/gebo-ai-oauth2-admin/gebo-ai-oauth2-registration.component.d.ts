import { Injector } from "@angular/core";
import { AbstractControl, FormGroup } from "@angular/forms";
import { AuthProviderDto, OAuth2AdminControllerService, Oauth2ProviderModifiableData } from "@Gebo.ai/gebo-ai-rest-api";
import { BaseEntityEditingComponent, GeboFormGroupsService, GeboUIActionRoutingService, GeboUIOutputForwardingService } from "@Gebo.ai/reusable-ui";
import { ConfirmationService } from "primeng/api";
import { Observable } from "rxjs";
import * as i0 from "@angular/core";
export declare class GeboAIOauth2RegistrationComponent extends BaseEntityEditingComponent<Oauth2ProviderModifiableData> {
    private basePath;
    private oauth2ControllerService;
    protected entityName: string;
    formGroup: FormGroup<any>;
    protected redirectUrls: string[];
    protected refererUrls: string[];
    protected currentProvider?: AuthProviderDto.ProviderEnum;
    oauth2ChoosableScopes: {
        code: string;
        description: string;
    }[];
    oauth2MandatoryScopes: {
        code: string;
        description: string;
    }[];
    protected providers: {
        code?: AuthProviderDto.ProviderEnum;
        description?: string;
    }[];
    protected authClientMethodData: {
        code: Oauth2ProviderModifiableData.AuthClientMethodEnum;
        description: string;
    }[];
    protected authGrantTypeData: {
        code: Oauth2ProviderModifiableData.AuthGrantTypeEnum;
        description: string;
    }[];
    protected configurationTypesData: {
        code: Oauth2ProviderModifiableData.ConfigurationTypeEnum;
        description: string;
    }[];
    protected readonly: boolean;
    constructor(basePath: string, injector: Injector, geboFormGroupsService: GeboFormGroupsService, confirmationService: ConfirmationService, geboUIActionRoutingService: GeboUIActionRoutingService, outputForwardingService: GeboUIOutputForwardingService, oauth2ControllerService: OAuth2AdminControllerService);
    protected onNewData(actualValue: Oauth2ProviderModifiableData): void;
    protected cat(base: string, relative: string, id?: string): string;
    protected onLoadedPersistentData(actualValue: Oauth2ProviderModifiableData): void;
    private modifyValidation;
    switchMandatory(ctrl: AbstractControl<any, any>, required: boolean): void;
    ngOnInit(): void;
    findByCode(code: string): Observable<Oauth2ProviderModifiableData | null>;
    save(value: Oauth2ProviderModifiableData): Observable<Oauth2ProviderModifiableData>;
    insert(value: Oauth2ProviderModifiableData): Observable<Oauth2ProviderModifiableData>;
    delete(value: Oauth2ProviderModifiableData): Observable<boolean>;
    canBeDeleted(value: Oauth2ProviderModifiableData): Observable<{
        canBeDeleted: boolean;
        message: string;
    }>;
    static ɵfac: i0.ɵɵFactoryDeclaration<GeboAIOauth2RegistrationComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<GeboAIOauth2RegistrationComponent, "gebo-ai-oauth2-registration-component", never, { "oauth2ChoosableScopes": { "alias": "oauth2ChoosableScopes"; "required": false; }; "oauth2MandatoryScopes": { "alias": "oauth2MandatoryScopes"; "required": false; }; }, {}, never, never, false, never>;
}
