/**
 * This Source Code is subject to the terms of the
 * Gebo.ai community version Mozilla Public License Version 2.0 (MPL-2.0) — With Data Protection Clauses
 * If a copy of the LICENCE was not distributed with this file, You can obtain one at
 * https://gebo.ai/gebo-ai-community-version-mozilla-public-license-version-2-0-mpl-2-0-with-data-protection-clauses/
 * and https://mozilla.org/MPL/2.0/.
 * Copyright (c) 2025+ Gebo.ai
 */
/**
 * AI generated comments
 *
 * This component handles the fast configuration of a Jira system in Gebo.ai.
 * It provides a form interface for users to input Jira system details and quickly
 * set up a new Jira integration. The component manages form state, loading indicators,
 * and communication with backend services.
 */
import { EventEmitter, OnInit } from "@angular/core";
import { FormGroup } from "@angular/forms";
import { GJiraSystem, JiraSystemsControllerService, UserControllerService } from "@Gebo.ai/gebo-ai-rest-api";
import { ToastMessageOptions } from "primeng/api";
import * as i0 from "@angular/core";
export declare class GeboAIJiraSystemFastComponent implements OnInit {
    private confluenceService;
    private userControllerService;
    /** Indicates whether the component is currently loading data */
    loading: boolean;
    /** Form group that manages the Jira system configuration fields */
    formGroup: FormGroup;
    /** Collection of messages to display to the user after operations */
    userMessages: ToastMessageOptions[];
    /** Event emitter that broadcasts a newly created Jira system */
    newJiraSystemEvent: EventEmitter<GJiraSystem>;
    /** Event emitter that broadcasts when the creation process is cancelled */
    cancelAction: EventEmitter<boolean>;
    /**
     * Component constructor that initializes services and default form values
     * @param confluenceService Service for Jira system operations
     * @param userControllerService Service for user-related operations
     */
    constructor(confluenceService: JiraSystemsControllerService, userControllerService: UserControllerService);
    /**
     * Enables or disables a specific form control
     * @param ctrlName The name of the control to enable/disable
     * @param enabled Boolean indicating whether to enable (true) or disable (false) the control
     */
    setEnabled(ctrlName: string, enabled: boolean): void;
    /**
     * Lifecycle hook that initializes the component
     * Fetches current user data and populates the username field
     */
    ngOnInit(): void;
    /**
     * Submits the form data to create a new Jira system
     * Emits an event with the new system on successful creation
     */
    doInsert(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<GeboAIJiraSystemFastComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<GeboAIJiraSystemFastComponent, "gebo-ai-jira-system-fast-component", never, {}, { "newJiraSystemEvent": "newJiraSystemEvent"; "cancelAction": "cancelAction"; }, never, never, false, never>;
}
//# sourceMappingURL=gebo-ai-jira-system-fast.component.d.ts.map