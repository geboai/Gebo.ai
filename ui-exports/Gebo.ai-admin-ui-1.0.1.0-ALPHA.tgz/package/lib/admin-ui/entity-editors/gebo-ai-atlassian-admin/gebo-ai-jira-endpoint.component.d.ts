/**
 * This Source Code is subject to the terms of the
 * Gebo.ai community version Mozilla Public License Version 2.0 (MPL-2.0) — With Data Protection Clauses
 * If a copy of the LICENCE was not distributed with this file, You can obtain one at
 * https://gebo.ai/gebo-ai-community-version-mozilla-public-license-version-2-0-mpl-2-0-with-data-protection-clauses/
 * and https://mozilla.org/MPL/2.0/.
 * Copyright (c) 2025+ Gebo.ai
 */
/**
 * AI generated comments
 * This module contains a component for managing JIRA project endpoints in Gebo.ai.
 * It allows users to create, edit, and delete JIRA project endpoints, as well as
 * interact with JIRA systems and browse JIRA content.
 */
import { Injector } from "@angular/core";
import { FormGroup } from "@angular/forms";
import { GConfluenceProjectEndpoint, GProject, JobLauncherControllerService, ProjectsControllerService, SecretInfo, GJiraProjectEndpoint, JiraSystemsControllerService, JiraBrowsingControllerService } from "@Gebo.ai/gebo-ai-rest-api";
import { BaseEntityEditingComponent, GeboAIFileType, GeboFormGroupsService, GeboUIActionRequest, GeboUIActionRoutingService, GeboUIOutputForwardingService } from "@Gebo.ai/reusable-ui";
import { ConfirmationService } from "primeng/api";
import { Observable } from "rxjs";
import { loadRootsObservableCallback, browsePathObservableCallback } from "@Gebo.ai/reusable-ui";
import * as i0 from "@angular/core";
/**
 * Component for managing Jira project endpoints within the Gebo.ai application.
 * This component extends BaseEntityEditingComponent to provide editing capabilities
 * for GJiraProjectEndpoint entities, including creating, updating, and deleting
 * Jira project endpoints. It also provides functionality for browsing Jira content,
 * connecting to Jira systems, and publishing endpoints.
 */
export declare class GeboAIJiraEndpointComponent extends BaseEntityEditingComponent<GJiraProjectEndpoint> {
    private jiraControllerService;
    private jiraBrowsing;
    private projectsController;
    private JobLauncherControllerService;
    private actionsRouter;
    /**
     * The name of the entity type this component manages
     */
    protected entityName: string;
    /**
     * Flag that determines if the project field can be modified
     * When true, the project field is read-only
     */
    cantModifyProject: boolean;
    /**
     * Observable for loading available projects from the backend
     */
    projectsObservable: Observable<GProject[]>;
    /**
     * Form group for managing the entity's editable fields
     */
    formGroup: FormGroup<any>;
    /**
     * Flag indicating if the endpoint is published
     */
    published: boolean;
    /**
     * Array of available Jira systems
     */
    jiraServersObservable: Observable<import("@Gebo.ai/gebo-ai-rest-api").GJiraSystem[]>;
    /**
     * Request object for creating a new Jira server
     */
    newjiraServerRequest: GeboUIActionRequest;
    /**
     * Identity context identifier for Jira systems
     */
    private actualIdentityContext;
    /**
     * Flag indicating if there are no accounts or systems configured
     */
    noAccountsAndSystems: boolean;
    /**
     * Stores the last selected Confluence system code to avoid redundant operations
     */
    private lastConfluenceSystemCode;
    /**
     * Available identity/secret information for authentication
     */
    identities: SecretInfo[];
    /**
     * Callback function for loading root elements from Jira
     */
    loadRootsObservable: loadRootsObservableCallback;
    /**
     * Callback function for browsing Jira content by path
     */
    browsePathObservable: browsePathObservableCallback;
    /**
     * List of supported file types
     */
    fileTypesList: GeboAIFileType[];
    /**
     * Constructor that initializes the component and sets up subscriptions
     * to form control changes and other initialization tasks.
     */
    constructor(injector: Injector, geboFormGroupsService: GeboFormGroupsService, jiraControllerService: JiraSystemsControllerService, jiraBrowsing: JiraBrowsingControllerService, projectsController: ProjectsControllerService, JobLauncherControllerService: JobLauncherControllerService, actionsRouter: GeboUIActionRoutingService, confirmService: ConfirmationService, outputForwardingService: GeboUIOutputForwardingService);
    /**
     * Checks if there are any running backend processes for this entity
     * @param reference The entity reference to check
     * @returns An Observable that resolves to true if there are running jobs, false otherwise
     */
    protected checkBackendProcessing(reference: {
        className?: string;
        code?: string;
    }): Observable<boolean>;
    /**
     * Lifecycle hook that initializes the component after Angular initializes
     * the data-bound properties
     */
    ngOnInit(): void;
    /**
     * Handles initialization when creating a new entity
     * @param actualValue The new entity instance
     */
    protected onNewData(actualValue: GConfluenceProjectEndpoint): void;
    /**
     * Handles initialization when loading an existing entity
     * @param actualValue The loaded entity instance
     */
    protected onLoadedPersistentData(actualValue: GConfluenceProjectEndpoint): void;
    /**
     * Finds a Jira project endpoint by its code
     * @param code The code of the endpoint to find
     * @returns An Observable that resolves to the found entity or null
     */
    findByCode(code: string): Observable<GConfluenceProjectEndpoint | null>;
    /**
     * Saves changes to an existing Jira project endpoint
     * @param value The endpoint to update
     * @returns An Observable that resolves to the updated entity
     */
    save(value: GConfluenceProjectEndpoint): Observable<GConfluenceProjectEndpoint>;
    /**
     * Creates a new Jira project endpoint
     * @param value The endpoint to create
     * @returns An Observable that resolves to the created entity
     */
    insert(value: GConfluenceProjectEndpoint): Observable<GConfluenceProjectEndpoint>;
    /**
     * Deletes a Jira project endpoint
     * @param value The endpoint to delete
     * @returns An Observable that resolves to true if deletion was successful
     */
    delete(value: GConfluenceProjectEndpoint): Observable<boolean>;
    /**
     * Checks if an endpoint can be deleted
     * @param value The endpoint to check
     * @returns An Observable that resolves to an object indicating if deletion is possible
     */
    canBeDeleted(value: GConfluenceProjectEndpoint): Observable<{
        canBeDeleted: boolean;
        message: string;
    }>;
    /**
     * Combined save and publish operation
     * Uses the utility function to perform both operations in sequence
     */
    doSaveAndPublish(): void;
    /**
     * Publishes the endpoint by creating a backend job
     * This triggers the synchronization process with Jira
     */
    doPublish(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<GeboAIJiraEndpointComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<GeboAIJiraEndpointComponent, "gebo-ai-jira-endpoint-component", never, { "cantModifyProject": { "alias": "cantModifyProject"; "required": false; }; }, {}, never, never, false, never>;
}
//# sourceMappingURL=gebo-ai-jira-endpoint.component.d.ts.map