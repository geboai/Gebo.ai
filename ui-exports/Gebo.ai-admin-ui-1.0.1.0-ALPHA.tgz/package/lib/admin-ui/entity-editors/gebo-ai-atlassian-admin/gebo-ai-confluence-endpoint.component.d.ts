/**
 * This Source Code is subject to the terms of the
 * Gebo.ai community version Mozilla Public License Version 2.0 (MPL-2.0) — With Data Protection Clauses
 * If a copy of the LICENCE was not distributed with this file, You can obtain one at
 * https://gebo.ai/gebo-ai-community-version-mozilla-public-license-version-2-0-mpl-2-0-with-data-protection-clauses/
 * and https://mozilla.org/MPL/2.0/.
 * Copyright (c) 2025+ Gebo.ai
 */
/**
 * AI generated comments
 * This module contains a component for managing Confluence endpoints in the Gebo.ai system.
 * It allows users to create, edit, delete, and publish Confluence endpoints that connect
 * projects to Confluence systems.
 */
import { Injector } from "@angular/core";
import { FormGroup } from "@angular/forms";
import { GConfluenceProjectEndpoint, GProject, JobLauncherControllerService, ProjectsControllerService, ConfluenceSystemsControllerService, ConfluenceBrowsingControllerService, GConfluenceSystem } from "@Gebo.ai/gebo-ai-rest-api";
import { BaseEntityEditingComponent, GeboAIFileType, GeboAIRootNotificationService, GeboFormGroupsService, GeboUIActionRequest, GeboUIActionRoutingService, GeboUIOutputForwardingService } from "@Gebo.ai/reusable-ui";
import { ConfirmationService } from "primeng/api";
import { Observable } from "rxjs";
import { loadRootsObservableCallback, browsePathObservableCallback } from "@Gebo.ai/reusable-ui";
import * as i0 from "@angular/core";
/**
 * Component responsible for managing Confluence endpoints.
 * This component allows users to create, edit, and manage Confluence endpoints that connect
 * Gebo.ai projects to Confluence systems. It supports configuration of connection parameters,
 * synchronization settings, and publishing operations.
 */
export declare class GeboAIConfluenceEndpointComponent extends BaseEntityEditingComponent<GConfluenceProjectEndpoint> {
    private confluenceControllerService;
    private confluenceBrowsing;
    private projectsController;
    private JobLauncherControllerService;
    private actionsRouter;
    private messageService;
    /** The entity type name used for identification */
    protected entityName: string;
    /** The handshake code used for authentication */
    handShakeCode?: string;
    /** Flag indicating whether the project can be modified */
    cantModifyProject: boolean;
    /** Observable for retrieving available projects */
    projectsObservable: Observable<GProject[]>;
    /** Form group containing all editable fields for the Confluence endpoint */
    formGroup: FormGroup<any>;
    /** Flag indicating whether the endpoint is published */
    published: boolean;
    /** List of available Confluence server systems */
    confluenceServersObservable: Observable<GConfluenceSystem[]>;
    /** Action request for creating a new Confluence server */
    newConfluenceServerRequest: GeboUIActionRequest;
    /** Tracks the last selected Confluence system code */
    private lastConfluenceSystemCode;
    /** Observable callback for loading Confluence roots */
    loadRootsObservable: loadRootsObservableCallback;
    /** Observable callback for browsing Confluence paths */
    browsePathObservable: browsePathObservableCallback;
    /** List of supported file types */
    fileTypesList: GeboAIFileType[];
    /**
     * Creates an instance of GeboAIConfluenceEndpointComponent.
     * Initializes the component and sets up subscriptions for form control changes.
     */
    constructor(injector: Injector, geboFormGroupsService: GeboFormGroupsService, confluenceControllerService: ConfluenceSystemsControllerService, confluenceBrowsing: ConfluenceBrowsingControllerService, projectsController: ProjectsControllerService, JobLauncherControllerService: JobLauncherControllerService, actionsRouter: GeboUIActionRoutingService, messageService: GeboAIRootNotificationService, confirmService: ConfirmationService, outputForwardingService: GeboUIOutputForwardingService);
    /**
     * Checks if a backend process is running for the specified reference
     * @param reference The object reference to check for running jobs
     * @returns An Observable with boolean indicating if a process is running
     */
    protected checkBackendProcessing(reference: {
        className?: string;
        code?: string;
    }): Observable<boolean>;
    /**
     * Initializes the component and checks for existing accounts and systems
     */
    ngOnInit(): void;
    /**
     * Handles initialization of a new entity
     * @param actualValue The new entity value
     */
    protected onNewData(actualValue: GConfluenceProjectEndpoint): void;
    /**
     * Handles the loaded persistent data
     * @param actualValue The loaded entity value
     */
    protected onLoadedPersistentData(actualValue: GConfluenceProjectEndpoint): void;
    /**
     * Finds a Confluence endpoint by its code
     * @param code The endpoint code to search for
     * @returns An Observable of the found endpoint or null
     */
    findByCode(code: string): Observable<GConfluenceProjectEndpoint | null>;
    /**
     * Saves changes to an existing Confluence endpoint
     * @param value The endpoint to update
     * @returns An Observable of the updated endpoint
     */
    save(value: GConfluenceProjectEndpoint): Observable<GConfluenceProjectEndpoint>;
    /**
     * Inserts a new Confluence endpoint
     * @param value The new endpoint to insert
     * @returns An Observable of the created endpoint
     */
    insert(value: GConfluenceProjectEndpoint): Observable<GConfluenceProjectEndpoint>;
    /**
     * Deletes a Confluence endpoint
     * @param value The endpoint to delete
     * @returns An Observable indicating success
     */
    delete(value: GConfluenceProjectEndpoint): Observable<boolean>;
    /**
     * Checks if the endpoint can be deleted
     * @param value The endpoint to check
     * @returns An Observable with deletion status and message
     */
    canBeDeleted(value: GConfluenceProjectEndpoint): Observable<{
        canBeDeleted: boolean;
        message: string;
    }>;
    /**
     * Performs both save and publish operations
     */
    doSaveAndPublish(): void;
    /**
     * Publishes the Confluence endpoint by creating a job
     * Saves the entity first, then launches a job to process the endpoint
     */
    doPublish(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<GeboAIConfluenceEndpointComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<GeboAIConfluenceEndpointComponent, "gebo-ai-confluence-endpoint-component", never, { "cantModifyProject": { "alias": "cantModifyProject"; "required": false; }; }, {}, never, never, false, never>;
}
