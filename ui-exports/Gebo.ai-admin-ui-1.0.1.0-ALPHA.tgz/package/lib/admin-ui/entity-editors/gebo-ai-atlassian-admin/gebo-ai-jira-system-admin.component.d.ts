/**
 * This Source Code is subject to the terms of the
 * Gebo.ai community version Mozilla Public License Version 2.0 (MPL-2.0) — With Data Protection Clauses
 * If a copy of the LICENCE was not distributed with this file, You can obtain one at
 * https://gebo.ai/gebo-ai-community-version-mozilla-public-license-version-2-0-mpl-2-0-with-data-protection-clauses/
 * and https://mozilla.org/MPL/2.0/.
 * Copyright (c) 2025+ Gebo.ai
 */
import { Injector } from "@angular/core";
import { FormGroup } from "@angular/forms";
import { GConfluenceSystem, GJiraSystem, JiraSystemsControllerService, SecretInfo, SecretsControllerService } from "@Gebo.ai/gebo-ai-rest-api";
import { BaseEntityEditingComponent, GeboFormGroupsService, GeboUIActionRoutingService, GeboUIOutputForwardingService } from "@Gebo.ai/reusable-ui";
import { ConfirmationService } from "primeng/api";
import { Observable } from "rxjs";
import * as i0 from "@angular/core";
export declare class GeboAIJiraAdminComponent extends BaseEntityEditingComponent<GJiraSystem> {
    private jiraControllerService;
    private secretControllerService;
    /**
     * Name of the entity being managed by this component
     */
    protected entityName: string;
    /**
     * Form group containing all the form controls for the Jira system configuration
     * Includes fields for system identification, connection details, and associated secret
     */
    formGroup: FormGroup<any>;
    /**
     * Identity context used for secret management with Jira
     * This identifies the type of secrets that are compatible with this system
     */
    private actualIdentityContext;
    /**
     * Observable that provides the list of available secrets for Jira authentication
     */
    identitiesObservable: Observable<SecretInfo[]>;
    /**
     * Action definition for creating a new secret for Jira integration
     * Uses USERNAME_PASSWORD authentication type
     */
    newSecretAction: import("@Gebo.ai/reusable-ui").GeboUIActionRequest;
    /**
     * Constructor initializes services and sets up form control behaviors
     * Enforces that the contentManagementSystemType is always 'ATLASSIAN-JIRA'
     */
    constructor(injector: Injector, geboFormGroupsService: GeboFormGroupsService, confirmationService: ConfirmationService, jiraControllerService: JiraSystemsControllerService, secretControllerService: SecretsControllerService, geboUIActionRoutingService: GeboUIActionRoutingService, outputForwardingService?: GeboUIOutputForwardingService);
    /**
     * Tests the connection to the configured Jira system
     * Currently implemented as an empty method - likely to be enhanced with actual testing logic
     */
    testSystem(): void;
    /**
     * Retrieves a Jira system by its code identifier
     * @param code The unique code of the Jira system to find
     * @returns An Observable containing the found system or null if not found
     */
    findByCode(code: string): Observable<GConfluenceSystem | null>;
    /**
     * Updates an existing Jira system configuration
     * @param value The updated Jira system object
     * @returns An Observable with the updated Jira system
     */
    save(value: GConfluenceSystem): Observable<GConfluenceSystem>;
    /**
     * Creates a new Jira system configuration
     * @param value The new Jira system object to create
     * @returns An Observable with the created Jira system
     */
    insert(value: GConfluenceSystem): Observable<GConfluenceSystem>;
    /**
     * Deletes a Jira system configuration
     * @param value The Jira system object to delete
     * @returns An Observable indicating whether the deletion was successful
     */
    delete(value: GConfluenceSystem): Observable<boolean>;
    /**
     * Checks if a Jira system can be safely deleted
     * Currently always returns true without performing any checks
     * @param value The Jira system to check
     * @returns An Observable with deletion permission info
     */
    canBeDeleted(value: GConfluenceSystem): Observable<{
        canBeDeleted: boolean;
        message: string;
    }>;
    static ɵfac: i0.ɵɵFactoryDeclaration<GeboAIJiraAdminComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<GeboAIJiraAdminComponent, "gebo-ai-jira-admin-component", never, {}, {}, never, never, false, never>;
}
//# sourceMappingURL=gebo-ai-jira-system-admin.component.d.ts.map