/**
 * This Source Code is subject to the terms of the
 * Gebo.ai community version Mozilla Public License Version 2.0 (MPL-2.0) — With Data Protection Clauses
 * If a copy of the LICENCE was not distributed with this file, You can obtain one at
 * https://gebo.ai/gebo-ai-community-version-mozilla-public-license-version-2-0-mpl-2-0-with-data-protection-clauses/
 * and https://mozilla.org/MPL/2.0/.
 * Copyright (c) 2025+ Gebo.ai
 */
/**
 * AI generated comments
 *
 * Component for quickly creating a new Confluence system integration.
 * This component provides a form for entering Confluence system configuration details
 * like base URI, credentials, and version type. It supports both cloud and on-premise
 * Confluence instances with appropriate validation for each type.
 */
import { EventEmitter, OnInit } from "@angular/core";
import { FormGroup } from "@angular/forms";
import { ConfluenceSystemsControllerService, GConfluenceSystem, UserControllerService } from "@Gebo.ai/gebo-ai-rest-api";
import { ToastMessageOptions } from "primeng/api";
import * as i0 from "@angular/core";
export declare class GeboAIConfluenceSystemFastComponent implements OnInit {
    private confluenceService;
    private userControllerService;
    /** Flag to indicate if the component is currently loading data */
    loading: boolean;
    /** Form group containing all inputs for Confluence system configuration */
    formGroup: FormGroup;
    /** Array to store messages that will be displayed to the user */
    userMessages: ToastMessageOptions[];
    /** Available Confluence versions that can be selected */
    confluenceVersions: {
        code: GConfluenceSystem.ConfluenceVersionEnum;
        description: string;
    }[];
    /** Currently selected Confluence version */
    currentConfluenceVersion?: GConfluenceSystem.ConfluenceVersionEnum;
    /** Event emitted when a new Confluence system is successfully created */
    newConfluenceSystemEvent: EventEmitter<GConfluenceSystem>;
    /** Event emitted when the user cancels the form */
    cancelAction: EventEmitter<boolean>;
    /**
     * Constructor initializes the component with necessary services and sets default form values
     * @param confluenceService Service for Confluence system operations
     * @param userControllerService Service for user operations
     */
    constructor(confluenceService: ConfluenceSystemsControllerService, userControllerService: UserControllerService);
    /**
     * Enables or disables a form control by name
     * @param ctrlName The name of the control to enable/disable
     * @param enabled Boolean indicating whether to enable (true) or disable (false) the control
     */
    setEnabled(ctrlName: string, enabled: boolean): void;
    /**
     * Custom validator function that validates the form based on the selected Confluence version
     * For cloud version, token is required; for on-premise, password is required
     * @param ctrl The AbstractControl to validate
     * @returns ValidationErrors or null if validation passes
     */
    private validate;
    /**
     * Initializes the component by setting up form validation and loading current user data
     */
    ngOnInit(): void;
    /**
     * Submits the form data to create a new Confluence system configuration
     * On success, emits the created system via newConfluenceSystemEvent
     */
    doInsert(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<GeboAIConfluenceSystemFastComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<GeboAIConfluenceSystemFastComponent, "gebo-ai-confluence-system-fast-component", never, {}, { "newConfluenceSystemEvent": "newConfluenceSystemEvent"; "cancelAction": "cancelAction"; }, never, never, false, never>;
}
