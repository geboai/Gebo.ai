/**
 * This Source Code is subject to the terms of the
 * Gebo.ai community version Mozilla Public License Version 2.0 (MPL-2.0) — With Data Protection Clauses
 * If a copy of the LICENCE was not distributed with this file, You can obtain one at
 * https://gebo.ai/gebo-ai-community-version-mozilla-public-license-version-2-0-mpl-2-0-with-data-protection-clauses/
 * and https://mozilla.org/MPL/2.0/.
 * Copyright (c) 2025+ Gebo.ai
 */
import { Injector } from "@angular/core";
import { FormGroup } from "@angular/forms";
import { ConfluenceSystemsControllerService, GConfluenceSystem, SecretInfo, SecretsControllerService } from "@Gebo.ai/gebo-ai-rest-api";
import { BaseEntityEditingComponent, GeboFormGroupsService, GeboUIActionRoutingService, GeboUIOutputForwardingService } from "@Gebo.ai/reusable-ui";
import { ConfirmationService } from "primeng/api";
import { Observable } from "rxjs";
import * as i0 from "@angular/core";
/**
 * AI generated comments
 * This component manages Confluence systems in Gebo.ai platform.
 * It provides UI for creating, updating, and deleting Confluence system configurations.
 * The component extends BaseEntityEditingComponent to handle basic CRUD operations
 * and implements form controls for all Confluence system properties.
 */
export declare class GeboAIConfluenceAdminComponent extends BaseEntityEditingComponent<GConfluenceSystem> {
    private confluenceControllerService;
    private secretControllerService;
    /**
     * Entity name used for identification in various operations
     */
    protected entityName: string;
    /**
     * Form group containing all editable fields for a Confluence system
     */
    formGroup: FormGroup<any>;
    /**
     * Identity context used for secret management
     */
    private actualIdentityContext;
    /**
     * Observable that returns available secrets for the Confluence context
     */
    identitiesObservable: Observable<SecretInfo[]>;
    /**
     * Available Confluence versions for selection in the UI
     */
    confluenceVersions: {
        code: GConfluenceSystem.ConfluenceVersionEnum;
        description: string;
    }[];
    /**
     * Action request for creating a new secret, defaulting to USERNAME_PASSWORD authentication
     */
    newSecretAction: import("@Gebo.ai/reusable-ui").GeboUIActionRequest;
    /**
     * Constructor initializes the component with necessary services for CRUD operations
     * and sets up value change subscriptions to handle form control interactions
     */
    constructor(injector: Injector, geboFormGroupsService: GeboFormGroupsService, confirmationService: ConfirmationService, confluenceControllerService: ConfluenceSystemsControllerService, secretControllerService: SecretsControllerService, geboUIActionRoutingService: GeboUIActionRoutingService, outputForwardingService?: GeboUIOutputForwardingService);
    /**
     * Tests the configured Confluence system connection
     */
    testSystem(): void;
    /**
     * Finds a Confluence system by its code
     * @param code The unique identifier for the Confluence system
     * @returns An Observable containing the found Confluence system or null
     */
    findByCode(code: string): Observable<GConfluenceSystem | null>;
    /**
     * Saves changes to an existing Confluence system
     * @param value The Confluence system with updated values
     * @returns An Observable containing the updated Confluence system
     */
    save(value: GConfluenceSystem): Observable<GConfluenceSystem>;
    /**
     * Creates a new Confluence system
     * @param value The new Confluence system to insert
     * @returns An Observable containing the created Confluence system
     */
    insert(value: GConfluenceSystem): Observable<GConfluenceSystem>;
    /**
     * Deletes a Confluence system
     * @param value The Confluence system to delete
     * @returns An Observable indicating whether the deletion was successful
     */
    delete(value: GConfluenceSystem): Observable<boolean>;
    /**
     * Checks if a Confluence system can be deleted
     * Currently always returns true with no validation
     * @param value The Confluence system to check
     * @returns An Observable containing the deletion status and any related message
     */
    canBeDeleted(value: GConfluenceSystem): Observable<{
        canBeDeleted: boolean;
        message: string;
    }>;
    static ɵfac: i0.ɵɵFactoryDeclaration<GeboAIConfluenceAdminComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<GeboAIConfluenceAdminComponent, "gebo-ai-confluence-admin-component", never, {}, {}, never, never, false, never>;
}
//# sourceMappingURL=gebo-ai-confluence-system-admin.component.d.ts.map