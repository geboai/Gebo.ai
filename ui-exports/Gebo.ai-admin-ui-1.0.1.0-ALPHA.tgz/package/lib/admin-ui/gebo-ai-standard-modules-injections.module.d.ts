/**
 * This Source Code is subject to the terms of the
 * Gebo.ai community version Mozilla Public License Version 2.0 (MPL-2.0) — With Data Protection Clauses
 * If a copy of the LICENCE was not distributed with this file, You can obtain one at
 * https://gebo.ai/gebo-ai-community-version-mozilla-public-license-version-2-0-mpl-2-0-with-data-protection-clauses/
 * and https://mozilla.org/MPL/2.0/.
 * Copyright (c) 2025+ Gebo.ai
 */
/**
 * AI generated comments
 * Exports constants representing different module identifiers used throughout the application.
 * These constants are used to identify various modules that can be plugged into the system.
 */
import { ConfluenceSystemsControllerService, FileSystemsControllerService, FileUploadsControllerService, GitSystemsControllerService, GoogleDriveSystemsControllerService, GProject, JiraSystemsControllerService, SharepointSystemsControllerService } from "@Gebo.ai/gebo-ai-rest-api";
import { GeboAIEntitiesSettingWizardConfiguration, GeboAIPluggableProjectEndpointModuleService, GeboUIActionRequest } from "@Gebo.ai/reusable-ui";
import { Observable } from "rxjs";
import { ModuleWithProviders } from "@angular/core";
import * as i0 from "@angular/core";
import * as i1 from "@angular/common";
export declare const SHARED_FILESYSTEM_MODULE = "shared-filesystem-module";
export declare const UPLOADS_MODULE = "uploads-module";
export declare const GIT_MODULE = "git-module";
export declare const GOOGLEDRIVE_MODULE = "google-drive-module";
export declare const CONFLUENCE_MODULE = "confluence-module";
export declare const JIRA_MODULE = "jira-module";
export declare const SHAREPOINT_MODULE = "sharepoint-module";
/**
 * Injectable service responsible for managing shared filesystem project endpoints.
 * Implements GeboAIPluggableProjectEndpointModuleService interface to enable pluggable
 * module functionality for shared filesystem data sources.
 * This service provides methods to find existing endpoints for a project and create new endpoints.
 */
export declare class GeboAISharedFilesystemModuleProjectEndpointService implements GeboAIPluggableProjectEndpointModuleService {
    private sharedFilesystemService;
    constructor(sharedFilesystemService: FileSystemsControllerService);
    /**
     * Fetches all filesystem endpoints for a given project by its code.
     * @param code - The project code to search endpoints for
     * @returns Observable containing array of endpoints with code, description and parent project code
     */
    findByProjectEndpoints(code: string): Observable<{
        code?: string;
        description?: string;
        parentProjectCode?: string;
    }[]>;
    /**
     * Creates a UI action request for creating a new filesystem endpoint for a project.
     * This method supports wizard-style creation flows by handling step configurations.
     * @param project - The project to create the endpoint for
     * @param wizardStepsConfigurations - Optional configuration for multi-step wizards
     * @param actualWizardStepConfigrationId - Optional ID of the current wizard step
     * @returns GeboUIActionRequest configured for creating a new filesystem endpoint
     */
    byProjectCreateAction(project: GProject, wizardStepsConfigurations?: GeboAIEntitiesSettingWizardConfiguration[], actualWizardStepConfigrationId?: string): GeboUIActionRequest;
    static ɵfac: i0.ɵɵFactoryDeclaration<GeboAISharedFilesystemModuleProjectEndpointService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<GeboAISharedFilesystemModuleProjectEndpointService>;
}
/**
 * Injectable service responsible for managing Git repository project endpoints.
 * Implements the GeboAIPluggableProjectEndpointModuleService interface to provide
 * specific functionality for Git repository data sources within projects.
 */
export declare class GeboAIGitModuleProjectEndpointService implements GeboAIPluggableProjectEndpointModuleService {
    private sharedFilesystemService;
    constructor(sharedFilesystemService: GitSystemsControllerService);
    /**
     * Retrieves all Git endpoints associated with a specific project.
     * @param code - The project code to search endpoints for
     * @returns Observable containing array of Git endpoints with their details
     */
    findByProjectEndpoints(code: string): Observable<{
        code?: string;
        description?: string;
        parentProjectCode?: string;
    }[]>;
    /**
     * Creates a UI action request for creating a new Git repository endpoint.
     * Supports wizard-based configuration flow if wizard parameters are provided.
     * @param project - The project to create the Git endpoint for
     * @param wizardStepsConfigurations - Optional wizard steps configuration
     * @param actualWizardStepConfigrationId - Optional current step ID in the wizard
     * @returns GeboUIActionRequest configured for creating a new Git endpoint
     */
    byProjectCreateAction(project: GProject, wizardStepsConfigurations?: GeboAIEntitiesSettingWizardConfiguration[], actualWizardStepConfigrationId?: string): GeboUIActionRequest;
    static ɵfac: i0.ɵɵFactoryDeclaration<GeboAIGitModuleProjectEndpointService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<GeboAIGitModuleProjectEndpointService>;
}
/**
 * Injectable service managing file upload project endpoints.
 * Implements GeboAIPluggableProjectEndpointModuleService to provide functionality
 * for handling file uploads as data sources within projects.
 */
export declare class GeboAIUpladsModuleProjectEndpointService implements GeboAIPluggableProjectEndpointModuleService {
    private uploadsService;
    constructor(uploadsService: FileUploadsControllerService);
    /**
     * Retrieves all upload endpoints associated with a specific project.
     * @param code - The project code to search for endpoints
     * @returns Observable containing array of upload endpoints
     */
    findByProjectEndpoints(code: string): Observable<{
        code?: string;
        description?: string;
        parentProjectCode?: string;
    }[]>;
    /**
     * Creates an action request for adding a new file upload endpoint to a project.
     * @param project - The project to create the upload endpoint for
     * @param wizardStepsConfigurations - Optional wizard configuration steps
     * @param actualWizardStepConfigrationId - Optional current wizard step ID
     * @returns GeboUIActionRequest configured for creating a new uploads endpoint
     */
    byProjectCreateAction(project: GProject, wizardStepsConfigurations?: GeboAIEntitiesSettingWizardConfiguration[], actualWizardStepConfigrationId?: string): GeboUIActionRequest;
    static ɵfac: i0.ɵɵFactoryDeclaration<GeboAIUpladsModuleProjectEndpointService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<GeboAIUpladsModuleProjectEndpointService>;
}
/**
 * Injectable service responsible for managing SharePoint project endpoints.
 * Implements GeboAIPluggableProjectEndpointModuleService to provide functionality
 * for connecting to Microsoft SharePoint/OneDrive data sources.
 */
export declare class GeboAISharepointModuleProjectEndpointService implements GeboAIPluggableProjectEndpointModuleService {
    private sharepointService;
    constructor(sharepointService: SharepointSystemsControllerService);
    /**
     * Retrieves all SharePoint endpoints associated with a specific project.
     * @param code - The project code to search for endpoints
     * @returns Observable containing array of SharePoint endpoints
     */
    findByProjectEndpoints(code: string): Observable<{
        code?: string;
        description?: string;
        parentProjectCode?: string;
    }[]>;
    /**
     * Creates an action request for adding a new SharePoint endpoint to a project.
     * @param project - The project to create the SharePoint endpoint for
     * @param wizardStepsConfigurations - Optional wizard configuration steps
     * @param actualWizardStepConfigrationId - Optional current wizard step ID
     * @returns GeboUIActionRequest configured for creating a new SharePoint endpoint
     */
    byProjectCreateAction(project: GProject, wizardStepsConfigurations?: GeboAIEntitiesSettingWizardConfiguration[], actualWizardStepConfigrationId?: string): GeboUIActionRequest;
    static ɵfac: i0.ɵɵFactoryDeclaration<GeboAISharepointModuleProjectEndpointService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<GeboAISharepointModuleProjectEndpointService>;
}
/**
 * Injectable service responsible for managing Atlassian Confluence project endpoints.
 * Implements GeboAIPluggableProjectEndpointModuleService to provide functionality
 * for connecting to Confluence data sources.
 */
export declare class GeboAIConfluenceModuleProjectEndpointService implements GeboAIPluggableProjectEndpointModuleService {
    private sharedFilesystemService;
    constructor(sharedFilesystemService: ConfluenceSystemsControllerService);
    /**
     * Retrieves all Confluence endpoints associated with a specific project.
     * @param code - The project code to search for endpoints
     * @returns Observable containing array of Confluence endpoints
     */
    findByProjectEndpoints(code: string): Observable<{
        code?: string;
        description?: string;
        parentProjectCode?: string;
    }[]>;
    /**
     * Creates an action request for adding a new Confluence endpoint to a project.
     * @param project - The project to create the Confluence endpoint for
     * @param wizardStepsConfigurations - Optional wizard configuration steps
     * @param actualWizardStepConfigrationId - Optional current wizard step ID
     * @returns GeboUIActionRequest configured for creating a new Confluence endpoint
     */
    byProjectCreateAction(project: GProject, wizardStepsConfigurations?: GeboAIEntitiesSettingWizardConfiguration[], actualWizardStepConfigrationId?: string): GeboUIActionRequest;
    static ɵfac: i0.ɵɵFactoryDeclaration<GeboAIConfluenceModuleProjectEndpointService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<GeboAIConfluenceModuleProjectEndpointService>;
}
/**
 * Injectable service responsible for managing Atlassian Jira project endpoints.
 * Implements GeboAIPluggableProjectEndpointModuleService to provide functionality
 * for connecting to Jira data sources.
 */
export declare class GeboAIJiraModuleProjectEndpointService implements GeboAIPluggableProjectEndpointModuleService {
    private jiraService;
    constructor(jiraService: JiraSystemsControllerService);
    /**
     * Retrieves all Jira endpoints associated with a specific project.
     * @param code - The project code to search for endpoints
     * @returns Observable containing array of Jira endpoints
     */
    findByProjectEndpoints(code: string): Observable<{
        code?: string;
        description?: string;
        parentProjectCode?: string;
    }[]>;
    /**
     * Creates an action request for adding a new Jira endpoint to a project.
     * @param project - The project to create the Jira endpoint for
     * @param wizardStepsConfigurations - Optional wizard configuration steps
     * @param actualWizardStepConfigrationId - Optional current wizard step ID
     * @returns GeboUIActionRequest configured for creating a new Jira endpoint
     */
    byProjectCreateAction(project: GProject, wizardStepsConfigurations?: GeboAIEntitiesSettingWizardConfiguration[], actualWizardStepConfigrationId?: string): GeboUIActionRequest;
    static ɵfac: i0.ɵɵFactoryDeclaration<GeboAIJiraModuleProjectEndpointService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<GeboAIJiraModuleProjectEndpointService>;
}
/**
 * Injectable service responsible for managing Google Drive project endpoints.
 * Implements GeboAIPluggableProjectEndpointModuleService to provide functionality
 * for connecting to Google Drive data sources.
 */
export declare class GeboAIGoogleDriveModuleProjectEndpointService implements GeboAIPluggableProjectEndpointModuleService {
    private jiraService;
    constructor(jiraService: GoogleDriveSystemsControllerService);
    /**
     * Retrieves all Google Drive endpoints associated with a specific project.
     * @param code - The project code to search for endpoints
     * @returns Observable containing array of Google Drive endpoints
     */
    findByProjectEndpoints(code: string): Observable<{
        code?: string;
        description?: string;
        parentProjectCode?: string;
    }[]>;
    /**
     * Creates an action request for adding a new Google Drive endpoint to a project.
     * @param project - The project to create the Google Drive endpoint for
     * @param wizardStepsConfigurations - Optional wizard configuration steps
     * @param actualWizardStepConfigrationId - Optional current wizard step ID
     * @returns GeboUIActionRequest configured for creating a new Google Drive endpoint
     */
    byProjectCreateAction(project: GProject, wizardStepsConfigurations?: GeboAIEntitiesSettingWizardConfiguration[], actualWizardStepConfigrationId?: string): GeboUIActionRequest;
    static ɵfac: i0.ɵɵFactoryDeclaration<GeboAIGoogleDriveModuleProjectEndpointService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<GeboAIGoogleDriveModuleProjectEndpointService>;
}
/**
 * NgModule that handles the registration of all module services and configurations.
 * This module is responsible for injecting all the pluggable modules into the application
 * by providing their services and configuration blocks to the dependency injection system.
 */
export declare class GeboAICommonModulesInjectionsModule {
    static forRoot(): ModuleWithProviders<GeboAICommonModulesInjectionsModule>;
    static ɵfac: i0.ɵɵFactoryDeclaration<GeboAICommonModulesInjectionsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<GeboAICommonModulesInjectionsModule, never, [typeof i1.CommonModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<GeboAICommonModulesInjectionsModule>;
}
//# sourceMappingURL=gebo-ai-standard-modules-injections.module.d.ts.map