import { HttpClient, HttpHeaders, HttpResponse, HttpEvent } from '@angular/common/http';
import { Observable } from 'rxjs';
import { ResetContentRequest } from '../model/resetContentRequest';
import { ResetContentResponse } from '../model/resetContentResponse';
import { Configuration } from '../configuration';
import * as i0 from "@angular/core";
export declare class ContentsResetControllerService {
    protected httpClient: HttpClient;
    protected basePath: string;
    defaultHeaders: HttpHeaders;
    configuration: Configuration;
    constructor(httpClient: HttpClient, basePath: string, configuration: Configuration);
    /**
     * @param consumes string[] mime-types
     * @return true: consumes contains 'multipart/form-data', false: otherwise
     */
    private canConsumeForm;
    /**
     *
     *
     * @param body
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    resetContentsIngestion(body: ResetContentRequest, observe?: 'body', reportProgress?: boolean): Observable<ResetContentResponse>;
    resetContentsIngestion(body: ResetContentRequest, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<ResetContentResponse>>;
    resetContentsIngestion(body: ResetContentRequest, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<ResetContentResponse>>;
    static ɵfac: i0.ɵɵFactoryDeclaration<ContentsResetControllerService, [null, { optional: true; }, { optional: true; }]>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ContentsResetControllerService>;
}
//# sourceMappingURL=contentsResetController.service.d.ts.map