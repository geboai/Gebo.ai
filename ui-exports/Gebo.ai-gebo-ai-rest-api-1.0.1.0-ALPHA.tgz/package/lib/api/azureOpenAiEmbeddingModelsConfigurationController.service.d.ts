import { HttpClient, HttpHeaders, HttpResponse, HttpEvent } from '@angular/common/http';
import { Observable } from 'rxjs';
import { GAzureOpenAIEmbeddingModelConfig } from '../model/gAzureOpenAIEmbeddingModelConfig';
import { OperationStatusBoolean } from '../model/operationStatusBoolean';
import { OperationStatusGAzureOpenAIEmbeddingModelConfig } from '../model/operationStatusGAzureOpenAIEmbeddingModelConfig';
import { OperationStatusListGAzureOpenAIEmbeddingModelChoice } from '../model/operationStatusListGAzureOpenAIEmbeddingModelChoice';
import { Configuration } from '../configuration';
import * as i0 from "@angular/core";
export declare class AzureOpenAiEmbeddingModelsConfigurationControllerService {
    protected httpClient: HttpClient;
    protected basePath: string;
    defaultHeaders: HttpHeaders;
    configuration: Configuration;
    constructor(httpClient: HttpClient, basePath: string, configuration: Configuration);
    /**
     * @param consumes string[] mime-types
     * @return true: consumes contains 'multipart/form-data', false: otherwise
     */
    private canConsumeForm;
    /**
     *
     *
     * @param body
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    deleteAzureOpenAIEmbeddingModelConfig(body: GAzureOpenAIEmbeddingModelConfig, observe?: 'body', reportProgress?: boolean): Observable<OperationStatusBoolean>;
    deleteAzureOpenAIEmbeddingModelConfig(body: GAzureOpenAIEmbeddingModelConfig, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<OperationStatusBoolean>>;
    deleteAzureOpenAIEmbeddingModelConfig(body: GAzureOpenAIEmbeddingModelConfig, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<OperationStatusBoolean>>;
    /**
     *
     *
     * @param code
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    findAzureOpenAIEmbeddingModelConfigByCode(code: string, observe?: 'body', reportProgress?: boolean): Observable<GAzureOpenAIEmbeddingModelConfig>;
    findAzureOpenAIEmbeddingModelConfigByCode(code: string, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<GAzureOpenAIEmbeddingModelConfig>>;
    findAzureOpenAIEmbeddingModelConfigByCode(code: string, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<GAzureOpenAIEmbeddingModelConfig>>;
    /**
     *
     *
     * @param body
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    getAzureOpenAIEmbeddingModels(body: GAzureOpenAIEmbeddingModelConfig, observe?: 'body', reportProgress?: boolean): Observable<OperationStatusListGAzureOpenAIEmbeddingModelChoice>;
    getAzureOpenAIEmbeddingModels(body: GAzureOpenAIEmbeddingModelConfig, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<OperationStatusListGAzureOpenAIEmbeddingModelChoice>>;
    getAzureOpenAIEmbeddingModels(body: GAzureOpenAIEmbeddingModelConfig, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<OperationStatusListGAzureOpenAIEmbeddingModelChoice>>;
    /**
     *
     *
     * @param body
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    insertAzureOpenAIEmbeddingModelConfig(body: GAzureOpenAIEmbeddingModelConfig, observe?: 'body', reportProgress?: boolean): Observable<OperationStatusGAzureOpenAIEmbeddingModelConfig>;
    insertAzureOpenAIEmbeddingModelConfig(body: GAzureOpenAIEmbeddingModelConfig, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<OperationStatusGAzureOpenAIEmbeddingModelConfig>>;
    insertAzureOpenAIEmbeddingModelConfig(body: GAzureOpenAIEmbeddingModelConfig, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<OperationStatusGAzureOpenAIEmbeddingModelConfig>>;
    /**
     *
     *
     * @param body
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    updateAzureOpenAIEmbeddingModelConfig(body: GAzureOpenAIEmbeddingModelConfig, observe?: 'body', reportProgress?: boolean): Observable<OperationStatusGAzureOpenAIEmbeddingModelConfig>;
    updateAzureOpenAIEmbeddingModelConfig(body: GAzureOpenAIEmbeddingModelConfig, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<OperationStatusGAzureOpenAIEmbeddingModelConfig>>;
    updateAzureOpenAIEmbeddingModelConfig(body: GAzureOpenAIEmbeddingModelConfig, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<OperationStatusGAzureOpenAIEmbeddingModelConfig>>;
    static ɵfac: i0.ɵɵFactoryDeclaration<AzureOpenAiEmbeddingModelsConfigurationControllerService, [null, { optional: true; }, { optional: true; }]>;
    static ɵprov: i0.ɵɵInjectableDeclaration<AzureOpenAiEmbeddingModelsConfigurationControllerService>;
}
