import { HttpClient, HttpHeaders, HttpResponse, HttpEvent } from '@angular/common/http';
import { Observable } from 'rxjs';
import { GoogleSearchRequest } from '../model/googleSearchRequest';
import { GoogleSearchResults } from '../model/googleSearchResults';
import { Configuration } from '../configuration';
import * as i0 from "@angular/core";
export declare class GoogleSearchControllerService {
    protected httpClient: HttpClient;
    protected basePath: string;
    defaultHeaders: HttpHeaders;
    configuration: Configuration;
    constructor(httpClient: HttpClient, basePath: string, configuration: Configuration);
    /**
     * @param consumes string[] mime-types
     * @return true: consumes contains 'multipart/form-data', false: otherwise
     */
    private canConsumeForm;
    /**
     *
     *
     * @param body
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    googleSearch(body: GoogleSearchRequest, observe?: 'body', reportProgress?: boolean): Observable<GoogleSearchResults>;
    googleSearch(body: GoogleSearchRequest, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<GoogleSearchResults>>;
    googleSearch(body: GoogleSearchRequest, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<GoogleSearchResults>>;
    static ɵfac: i0.ɵɵFactoryDeclaration<GoogleSearchControllerService, [null, { optional: true; }, { optional: true; }]>;
    static ɵprov: i0.ɵɵInjectableDeclaration<GoogleSearchControllerService>;
}
//# sourceMappingURL=googleSearchController.service.d.ts.map