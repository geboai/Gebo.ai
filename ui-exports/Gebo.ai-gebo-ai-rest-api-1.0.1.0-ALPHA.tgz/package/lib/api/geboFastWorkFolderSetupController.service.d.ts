import { HttpClient, HttpHeaders, HttpResponse, HttpEvent } from '@angular/common/http';
import { Observable } from 'rxjs';
import { ComponentEnabledStatus } from '../model/componentEnabledStatus';
import { FastWorkDirectorySetupData } from '../model/fastWorkDirectorySetupData';
import { OperationStatusWorkFolderSetupStatus } from '../model/operationStatusWorkFolderSetupStatus';
import { WorkFolderSetupStatus } from '../model/workFolderSetupStatus';
import { Configuration } from '../configuration';
import * as i0 from "@angular/core";
export declare class GeboFastWorkFolderSetupControllerService {
    protected httpClient: HttpClient;
    protected basePath: string;
    defaultHeaders: HttpHeaders;
    configuration: Configuration;
    constructor(httpClient: HttpClient, basePath: string, configuration: Configuration);
    /**
     * @param consumes string[] mime-types
     * @return true: consumes contains 'multipart/form-data', false: otherwise
     */
    private canConsumeForm;
    /**
     *
     *
     * @param body
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    configureWorkDirectory(body: FastWorkDirectorySetupData, observe?: 'body', reportProgress?: boolean): Observable<OperationStatusWorkFolderSetupStatus>;
    configureWorkDirectory(body: FastWorkDirectorySetupData, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<OperationStatusWorkFolderSetupStatus>>;
    configureWorkDirectory(body: FastWorkDirectorySetupData, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<OperationStatusWorkFolderSetupStatus>>;
    /**
     *
     *
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    getWorkDirectorySetupEnabled(observe?: 'body', reportProgress?: boolean): Observable<ComponentEnabledStatus>;
    getWorkDirectorySetupEnabled(observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<ComponentEnabledStatus>>;
    getWorkDirectorySetupEnabled(observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<ComponentEnabledStatus>>;
    /**
     *
     *
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    getWorkDirectorySetupStatus(observe?: 'body', reportProgress?: boolean): Observable<WorkFolderSetupStatus>;
    getWorkDirectorySetupStatus(observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<WorkFolderSetupStatus>>;
    getWorkDirectorySetupStatus(observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<WorkFolderSetupStatus>>;
    static ɵfac: i0.ɵɵFactoryDeclaration<GeboFastWorkFolderSetupControllerService, [null, { optional: true; }, { optional: true; }]>;
    static ɵprov: i0.ɵɵInjectableDeclaration<GeboFastWorkFolderSetupControllerService>;
}
//# sourceMappingURL=geboFastWorkFolderSetupController.service.d.ts.map