import { HttpClient, HttpHeaders, HttpResponse, HttpEvent } from '@angular/common/http';
import { Observable } from 'rxjs';
import { DeepSearchDataSourceDocumentResult } from '../model/deepSearchDataSourceDocumentResult';
import { DeepSearchDataSourceResponse } from '../model/deepSearchDataSourceResponse';
import { DeepSearchDocumentAnalisysResultStep } from '../model/deepSearchDocumentAnalisysResultStep';
import { DeepSearchRequest } from '../model/deepSearchRequest';
import { DeepSearchResponse } from '../model/deepSearchResponse';
import { GBaseObject } from '../model/gBaseObject';
import { GeboChatRequest } from '../model/geboChatRequest';
import { PageDeepSearchDocumentAnalisysResultStep } from '../model/pageDeepSearchDocumentAnalisysResultStep';
import { PageDeepSearchRequest } from '../model/pageDeepSearchRequest';
import { ServerSentEventString } from '../model/serverSentEventString';
import { Configuration } from '../configuration';
import * as i0 from "@angular/core";
export declare class GeboDeepSearchControllerService {
    protected httpClient: HttpClient;
    protected basePath: string;
    defaultHeaders: HttpHeaders;
    configuration: Configuration;
    constructor(httpClient: HttpClient, basePath: string, configuration: Configuration);
    /**
     * @param consumes string[] mime-types
     * @return true: consumes contains 'multipart/form-data', false: otherwise
     */
    private canConsumeForm;
    /**
     *
     *
     * @param body
     * @param dataSourceCode
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    dataSourceDeepSearch(body: GeboChatRequest, dataSourceCode: string, observe?: 'body', reportProgress?: boolean): Observable<Array<ServerSentEventString>>;
    dataSourceDeepSearch(body: GeboChatRequest, dataSourceCode: string, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<Array<ServerSentEventString>>>;
    dataSourceDeepSearch(body: GeboChatRequest, dataSourceCode: string, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<Array<ServerSentEventString>>>;
    /**
     *
     *
     * @param body
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    deleteDeepSearch(body: DeepSearchRequest, observe?: 'body', reportProgress?: boolean): Observable<any>;
    deleteDeepSearch(body: DeepSearchRequest, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<any>>;
    deleteDeepSearch(body: DeepSearchRequest, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<any>>;
    /**
     *
     *
     * @param body
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    doDeepSearch(body: DeepSearchRequest, observe?: 'body', reportProgress?: boolean): Observable<DeepSearchResponse>;
    doDeepSearch(body: DeepSearchRequest, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<DeepSearchResponse>>;
    doDeepSearch(body: DeepSearchRequest, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<DeepSearchResponse>>;
    /**
     *
     *
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    getDeepSearchDataSources(observe?: 'body', reportProgress?: boolean): Observable<Array<GBaseObject>>;
    getDeepSearchDataSources(observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<Array<GBaseObject>>>;
    getDeepSearchDataSources(observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<Array<GBaseObject>>>;
    /**
     *
     *
     * @param deepSearchCode
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    getDeepSearchDocumentsCount(deepSearchCode: string, observe?: 'body', reportProgress?: boolean): Observable<number>;
    getDeepSearchDocumentsCount(deepSearchCode: string, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<number>>;
    getDeepSearchDocumentsCount(deepSearchCode: string, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<number>>;
    /**
     *
     *
     * @param deepSearchCode
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    getMyDeepSearchById(deepSearchCode: string, observe?: 'body', reportProgress?: boolean): Observable<DeepSearchRequest>;
    getMyDeepSearchById(deepSearchCode: string, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<DeepSearchRequest>>;
    getMyDeepSearchById(deepSearchCode: string, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<DeepSearchRequest>>;
    /**
     *
     *
     * @param deepSearchCode
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    getMyDeepSearchDataSourceDocumentResultsByRequestCode(deepSearchCode: string, observe?: 'body', reportProgress?: boolean): Observable<Array<DeepSearchDataSourceDocumentResult>>;
    getMyDeepSearchDataSourceDocumentResultsByRequestCode(deepSearchCode: string, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<Array<DeepSearchDataSourceDocumentResult>>>;
    getMyDeepSearchDataSourceDocumentResultsByRequestCode(deepSearchCode: string, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<Array<DeepSearchDataSourceDocumentResult>>>;
    /**
     *
     *
     * @param deepSearchCode
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    getMyDeepSearchDeepSearchDataSourceResponsesByRequestCode(deepSearchCode: string, observe?: 'body', reportProgress?: boolean): Observable<Array<DeepSearchDataSourceResponse>>;
    getMyDeepSearchDeepSearchDataSourceResponsesByRequestCode(deepSearchCode: string, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<Array<DeepSearchDataSourceResponse>>>;
    getMyDeepSearchDeepSearchDataSourceResponsesByRequestCode(deepSearchCode: string, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<Array<DeepSearchDataSourceResponse>>>;
    /**
     *
     *
     * @param deepSearchCode
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    getMyDeepSearchResponseByRequestCode(deepSearchCode: string, observe?: 'body', reportProgress?: boolean): Observable<DeepSearchResponse>;
    getMyDeepSearchResponseByRequestCode(deepSearchCode: string, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<DeepSearchResponse>>;
    getMyDeepSearchResponseByRequestCode(deepSearchCode: string, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<DeepSearchResponse>>;
    /**
     *
     *
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    getMyDeepSearches(observe?: 'body', reportProgress?: boolean): Observable<Array<DeepSearchRequest>>;
    getMyDeepSearches(observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<Array<DeepSearchRequest>>>;
    getMyDeepSearches(observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<Array<DeepSearchRequest>>>;
    /**
     *
     *
     * @param page
     * @param pageSize
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    getMyDeepSearchesPaged(page: number, pageSize: number, observe?: 'body', reportProgress?: boolean): Observable<PageDeepSearchRequest>;
    getMyDeepSearchesPaged(page: number, pageSize: number, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<PageDeepSearchRequest>>;
    getMyDeepSearchesPaged(page: number, pageSize: number, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<PageDeepSearchRequest>>;
    /**
     *
     *
     * @param deepSearchCode
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    getMyDeepSearchesSteps(deepSearchCode: string, observe?: 'body', reportProgress?: boolean): Observable<Array<DeepSearchDocumentAnalisysResultStep>>;
    getMyDeepSearchesSteps(deepSearchCode: string, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<Array<DeepSearchDocumentAnalisysResultStep>>>;
    getMyDeepSearchesSteps(deepSearchCode: string, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<Array<DeepSearchDocumentAnalisysResultStep>>>;
    /**
     *
     *
     * @param deepSearchCode
     * @param page
     * @param pageSize
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    getMyDeepSearchesStepsPaged(deepSearchCode: string, page: number, pageSize: number, observe?: 'body', reportProgress?: boolean): Observable<PageDeepSearchDocumentAnalisysResultStep>;
    getMyDeepSearchesStepsPaged(deepSearchCode: string, page: number, pageSize: number, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<PageDeepSearchDocumentAnalisysResultStep>>;
    getMyDeepSearchesStepsPaged(deepSearchCode: string, page: number, pageSize: number, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<PageDeepSearchDocumentAnalisysResultStep>>;
    /**
     *
     *
     * @param body
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    internalKnowledgeBaseDeepSearch(body: GeboChatRequest, observe?: 'body', reportProgress?: boolean): Observable<Array<ServerSentEventString>>;
    internalKnowledgeBaseDeepSearch(body: GeboChatRequest, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<Array<ServerSentEventString>>>;
    internalKnowledgeBaseDeepSearch(body: GeboChatRequest, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<Array<ServerSentEventString>>>;
    /**
     *
     *
     * @param deepSearchCode
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    stopDeepSearch(deepSearchCode: string, observe?: 'body', reportProgress?: boolean): Observable<any>;
    stopDeepSearch(deepSearchCode: string, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<any>>;
    stopDeepSearch(deepSearchCode: string, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<any>>;
    /**
     *
     *
     * @param body
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    streamDeepSearch(body: DeepSearchRequest, observe?: 'body', reportProgress?: boolean): Observable<Array<ServerSentEventString>>;
    streamDeepSearch(body: DeepSearchRequest, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<Array<ServerSentEventString>>>;
    streamDeepSearch(body: DeepSearchRequest, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<Array<ServerSentEventString>>>;
    /**
     *
     *
     * @param body
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    streamDeepSearchWithChatContext(body: GeboChatRequest, observe?: 'body', reportProgress?: boolean): Observable<Array<ServerSentEventString>>;
    streamDeepSearchWithChatContext(body: GeboChatRequest, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<Array<ServerSentEventString>>>;
    streamDeepSearchWithChatContext(body: GeboChatRequest, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<Array<ServerSentEventString>>>;
    static ɵfac: i0.ɵɵFactoryDeclaration<GeboDeepSearchControllerService, [null, { optional: true; }, { optional: true; }]>;
    static ɵprov: i0.ɵɵInjectableDeclaration<GeboDeepSearchControllerService>;
}
