import { HttpClient, HttpHeaders, HttpResponse, HttpEvent } from '@angular/common/http';
import { Observable } from 'rxjs';
import { DeletableStatus } from '../model/deletableStatus';
import { FormGroupMetaInfo } from '../model/formGroupMetaInfo';
import { GObjectRef } from '../model/gObjectRef';
import { SimpleGObjectRef } from '../model/simpleGObjectRef';
import { Configuration } from '../configuration';
import * as i0 from "@angular/core";
export declare class GeboAngularFormGroupMetaInfoControllerService {
    protected httpClient: HttpClient;
    protected basePath: string;
    defaultHeaders: HttpHeaders;
    configuration: Configuration;
    constructor(httpClient: HttpClient, basePath: string, configuration: Configuration);
    /**
     * @param consumes string[] mime-types
     * @return true: consumes contains 'multipart/form-data', false: otherwise
     */
    private canConsumeForm;
    /**
     *
     *
     * @param body
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    checkDeletableByGObjectRef(body: GObjectRef, observe?: 'body', reportProgress?: boolean): Observable<DeletableStatus>;
    checkDeletableByGObjectRef(body: GObjectRef, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<DeletableStatus>>;
    checkDeletableByGObjectRef(body: GObjectRef, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<DeletableStatus>>;
    /**
     *
     *
     * @param body
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    checkDeletableBySimpleObjectRef(body: SimpleGObjectRef, observe?: 'body', reportProgress?: boolean): Observable<DeletableStatus>;
    checkDeletableBySimpleObjectRef(body: SimpleGObjectRef, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<DeletableStatus>>;
    checkDeletableBySimpleObjectRef(body: SimpleGObjectRef, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<DeletableStatus>>;
    /**
     *
     *
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    getFormGroupsMetaInfos(observe?: 'body', reportProgress?: boolean): Observable<Array<FormGroupMetaInfo>>;
    getFormGroupsMetaInfos(observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<Array<FormGroupMetaInfo>>>;
    getFormGroupsMetaInfos(observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<Array<FormGroupMetaInfo>>>;
    static ɵfac: i0.ɵɵFactoryDeclaration<GeboAngularFormGroupMetaInfoControllerService, [null, { optional: true; }, { optional: true; }]>;
    static ɵprov: i0.ɵɵInjectableDeclaration<GeboAngularFormGroupMetaInfoControllerService>;
}
