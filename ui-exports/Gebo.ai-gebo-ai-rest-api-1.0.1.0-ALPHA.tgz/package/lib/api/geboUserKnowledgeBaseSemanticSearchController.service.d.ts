import { HttpClient, HttpHeaders, HttpResponse, HttpEvent } from '@angular/common/http';
import { Observable } from 'rxjs';
import { SemanticQueryParam } from '../model/semanticQueryParam';
import { Configuration } from '../configuration';
import * as i0 from "@angular/core";
export declare class GeboUserKnowledgeBaseSemanticSearchControllerService {
    protected httpClient: HttpClient;
    protected basePath: string;
    defaultHeaders: HttpHeaders;
    configuration: Configuration;
    constructor(httpClient: HttpClient, basePath: string, configuration: Configuration);
    /**
     * @param consumes string[] mime-types
     * @return true: consumes contains 'multipart/form-data', false: otherwise
     */
    private canConsumeForm;
    /**
     *
     *
     * @param body
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    semanticSearch(body: SemanticQueryParam, observe?: 'body', reportProgress?: boolean): Observable<Array<string>>;
    semanticSearch(body: SemanticQueryParam, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<Array<string>>>;
    semanticSearch(body: SemanticQueryParam, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<Array<string>>>;
    static ɵfac: i0.ɵɵFactoryDeclaration<GeboUserKnowledgeBaseSemanticSearchControllerService, [null, { optional: true; }, { optional: true; }]>;
    static ɵprov: i0.ɵɵInjectableDeclaration<GeboUserKnowledgeBaseSemanticSearchControllerService>;
}
