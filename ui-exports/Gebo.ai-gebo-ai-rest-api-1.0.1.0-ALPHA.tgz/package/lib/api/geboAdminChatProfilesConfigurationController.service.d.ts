import { HttpClient, HttpHeaders, HttpResponse, HttpEvent } from '@angular/common/http';
import { Observable } from 'rxjs';
import { ChatProfileConfigurationByQbeParam } from '../model/chatProfileConfigurationByQbeParam';
import { DataPage } from '../model/dataPage';
import { GChatProfileConfiguration } from '../model/gChatProfileConfiguration';
import { PageGChatProfileConfiguration } from '../model/pageGChatProfileConfiguration';
import { Configuration } from '../configuration';
import * as i0 from "@angular/core";
export declare class GeboAdminChatProfilesConfigurationControllerService {
    protected httpClient: HttpClient;
    protected basePath: string;
    defaultHeaders: HttpHeaders;
    configuration: Configuration;
    constructor(httpClient: HttpClient, basePath: string, configuration: Configuration);
    /**
     * @param consumes string[] mime-types
     * @return true: consumes contains 'multipart/form-data', false: otherwise
     */
    private canConsumeForm;
    /**
     *
     *
     * @param body
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    deleteChatProfile(body: GChatProfileConfiguration, observe?: 'body', reportProgress?: boolean): Observable<any>;
    deleteChatProfile(body: GChatProfileConfiguration, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<any>>;
    deleteChatProfile(body: GChatProfileConfiguration, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<any>>;
    /**
     *
     *
     * @param code
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    findChatProfileConfigurationByCode(code: string, observe?: 'body', reportProgress?: boolean): Observable<GChatProfileConfiguration>;
    findChatProfileConfigurationByCode(code: string, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<GChatProfileConfiguration>>;
    findChatProfileConfigurationByCode(code: string, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<GChatProfileConfiguration>>;
    /**
     *
     *
     * @param body
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    getAllChatProfileConfiguration(body: DataPage, observe?: 'body', reportProgress?: boolean): Observable<PageGChatProfileConfiguration>;
    getAllChatProfileConfiguration(body: DataPage, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<PageGChatProfileConfiguration>>;
    getAllChatProfileConfiguration(body: DataPage, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<PageGChatProfileConfiguration>>;
    /**
     *
     *
     * @param body
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    getChatProfileConfigurationByQbe(body: ChatProfileConfigurationByQbeParam, observe?: 'body', reportProgress?: boolean): Observable<PageGChatProfileConfiguration>;
    getChatProfileConfigurationByQbe(body: ChatProfileConfigurationByQbeParam, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<PageGChatProfileConfiguration>>;
    getChatProfileConfigurationByQbe(body: ChatProfileConfigurationByQbeParam, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<PageGChatProfileConfiguration>>;
    /**
     *
     *
     * @param body
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    insertChatProfile(body: GChatProfileConfiguration, observe?: 'body', reportProgress?: boolean): Observable<GChatProfileConfiguration>;
    insertChatProfile(body: GChatProfileConfiguration, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<GChatProfileConfiguration>>;
    insertChatProfile(body: GChatProfileConfiguration, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<GChatProfileConfiguration>>;
    /**
     *
     *
     * @param body
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    updateChatProfile(body: GChatProfileConfiguration, observe?: 'body', reportProgress?: boolean): Observable<GChatProfileConfiguration>;
    updateChatProfile(body: GChatProfileConfiguration, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<GChatProfileConfiguration>>;
    updateChatProfile(body: GChatProfileConfiguration, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<GChatProfileConfiguration>>;
    static ɵfac: i0.ɵɵFactoryDeclaration<GeboAdminChatProfilesConfigurationControllerService, [null, { optional: true; }, { optional: true; }]>;
    static ɵprov: i0.ɵɵInjectableDeclaration<GeboAdminChatProfilesConfigurationControllerService>;
}
