import { HttpClient, HttpHeaders, HttpResponse, HttpEvent } from '@angular/common/http';
import { Observable } from 'rxjs';
import { ComponentSetupStatus } from '../model/componentSetupStatus';
import { Configuration } from '../configuration';
import * as i0 from "@angular/core";
export declare class GeboAdvancedSetupStatusControllerService {
    protected httpClient: HttpClient;
    protected basePath: string;
    defaultHeaders: HttpHeaders;
    configuration: Configuration;
    constructor(httpClient: HttpClient, basePath: string, configuration: Configuration);
    /**
     * @param consumes string[] mime-types
     * @return true: consumes contains 'multipart/form-data', false: otherwise
     */
    private canConsumeForm;
    /**
     *
     *
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    getFirstKnowledgeBaseSetupStatus(observe?: 'body', reportProgress?: boolean): Observable<ComponentSetupStatus>;
    getFirstKnowledgeBaseSetupStatus(observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<ComponentSetupStatus>>;
    getFirstKnowledgeBaseSetupStatus(observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<ComponentSetupStatus>>;
    /**
     *
     *
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    getMinimalContentsSetupStatus(observe?: 'body', reportProgress?: boolean): Observable<ComponentSetupStatus>;
    getMinimalContentsSetupStatus(observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<ComponentSetupStatus>>;
    getMinimalContentsSetupStatus(observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<ComponentSetupStatus>>;
    static ɵfac: i0.ɵɵFactoryDeclaration<GeboAdvancedSetupStatusControllerService, [null, { optional: true; }, { optional: true; }]>;
    static ɵprov: i0.ɵɵInjectableDeclaration<GeboAdvancedSetupStatusControllerService>;
}
