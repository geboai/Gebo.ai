import { HttpClient, HttpHeaders, HttpResponse, HttpEvent } from '@angular/common/http';
import { Observable } from 'rxjs';
import { GeboContentProcessRow } from '../model/geboContentProcessRow';
import { GeboKnowledgeBaseSetupStatus } from '../model/geboKnowledgeBaseSetupStatus';
import { Configuration } from '../configuration';
import * as i0 from "@angular/core";
export declare class GeboFastKnowledgeBaseSetupControllerService {
    protected httpClient: HttpClient;
    protected basePath: string;
    defaultHeaders: HttpHeaders;
    configuration: Configuration;
    constructor(httpClient: HttpClient, basePath: string, configuration: Configuration);
    /**
     * @param consumes string[] mime-types
     * @return true: consumes contains 'multipart/form-data', false: otherwise
     */
    private canConsumeForm;
    /**
     *
     *
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    getCompleteKnowledgeBaseSetupStatus(observe?: 'body', reportProgress?: boolean): Observable<GeboKnowledgeBaseSetupStatus>;
    getCompleteKnowledgeBaseSetupStatus(observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<GeboKnowledgeBaseSetupStatus>>;
    getCompleteKnowledgeBaseSetupStatus(observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<GeboKnowledgeBaseSetupStatus>>;
    /**
     *
     *
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    getContentProcessRows(observe?: 'body', reportProgress?: boolean): Observable<Array<GeboContentProcessRow>>;
    getContentProcessRows(observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<Array<GeboContentProcessRow>>>;
    getContentProcessRows(observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<Array<GeboContentProcessRow>>>;
    static ɵfac: i0.ɵɵFactoryDeclaration<GeboFastKnowledgeBaseSetupControllerService, [null, { optional: true; }, { optional: true; }]>;
    static ɵprov: i0.ɵɵInjectableDeclaration<GeboFastKnowledgeBaseSetupControllerService>;
}
//# sourceMappingURL=geboFastKnowledgeBaseSetupController.service.d.ts.map