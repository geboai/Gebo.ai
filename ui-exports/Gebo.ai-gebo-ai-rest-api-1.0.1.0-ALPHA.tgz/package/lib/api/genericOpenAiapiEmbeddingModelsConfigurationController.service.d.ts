import { HttpClient, HttpHeaders, HttpResponse, HttpEvent } from '@angular/common/http';
import { Observable } from 'rxjs';
import { GenericOpenAIAPIEmbeddingModelConfig } from '../model/genericOpenAIAPIEmbeddingModelConfig';
import { GenericOpenAIEmbeddingModelTypeConfig } from '../model/genericOpenAIEmbeddingModelTypeConfig';
import { OperationStatusBoolean } from '../model/operationStatusBoolean';
import { OperationStatusGenericOpenAIAPIEmbeddingModelConfig } from '../model/operationStatusGenericOpenAIAPIEmbeddingModelConfig';
import { OperationStatusListGenericOpenAIAPIEmbeddingModelChoice } from '../model/operationStatusListGenericOpenAIAPIEmbeddingModelChoice';
import { Configuration } from '../configuration';
import * as i0 from "@angular/core";
export declare class GenericOpenAiapiEmbeddingModelsConfigurationControllerService {
    protected httpClient: HttpClient;
    protected basePath: string;
    defaultHeaders: HttpHeaders;
    configuration: Configuration;
    constructor(httpClient: HttpClient, basePath: string, configuration: Configuration);
    /**
     * @param consumes string[] mime-types
     * @return true: consumes contains 'multipart/form-data', false: otherwise
     */
    private canConsumeForm;
    /**
     *
     *
     * @param body
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    deleteGenericOpenAIAPIEmbeddingModelConfig(body: GenericOpenAIAPIEmbeddingModelConfig, observe?: 'body', reportProgress?: boolean): Observable<OperationStatusBoolean>;
    deleteGenericOpenAIAPIEmbeddingModelConfig(body: GenericOpenAIAPIEmbeddingModelConfig, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<OperationStatusBoolean>>;
    deleteGenericOpenAIAPIEmbeddingModelConfig(body: GenericOpenAIAPIEmbeddingModelConfig, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<OperationStatusBoolean>>;
    /**
     *
     *
     * @param code
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    findGenericOpenAIAPIEmbeddingModelConfigByCode(code: string, observe?: 'body', reportProgress?: boolean): Observable<GenericOpenAIAPIEmbeddingModelConfig>;
    findGenericOpenAIAPIEmbeddingModelConfigByCode(code: string, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<GenericOpenAIAPIEmbeddingModelConfig>>;
    findGenericOpenAIAPIEmbeddingModelConfigByCode(code: string, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<GenericOpenAIAPIEmbeddingModelConfig>>;
    /**
     *
     *
     * @param body
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    getGenericOpenAIAPIEmbeddingModels(body: GenericOpenAIAPIEmbeddingModelConfig, observe?: 'body', reportProgress?: boolean): Observable<OperationStatusListGenericOpenAIAPIEmbeddingModelChoice>;
    getGenericOpenAIAPIEmbeddingModels(body: GenericOpenAIAPIEmbeddingModelConfig, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<OperationStatusListGenericOpenAIAPIEmbeddingModelChoice>>;
    getGenericOpenAIAPIEmbeddingModels(body: GenericOpenAIAPIEmbeddingModelConfig, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<OperationStatusListGenericOpenAIAPIEmbeddingModelChoice>>;
    /**
     *
     *
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    getGenericOpenAIEmbeddingModelTypes(observe?: 'body', reportProgress?: boolean): Observable<Array<GenericOpenAIEmbeddingModelTypeConfig>>;
    getGenericOpenAIEmbeddingModelTypes(observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<Array<GenericOpenAIEmbeddingModelTypeConfig>>>;
    getGenericOpenAIEmbeddingModelTypes(observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<Array<GenericOpenAIEmbeddingModelTypeConfig>>>;
    /**
     *
     *
     * @param body
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    insertGenericOpenAIAPIEmbeddingModelConfig(body: GenericOpenAIAPIEmbeddingModelConfig, observe?: 'body', reportProgress?: boolean): Observable<OperationStatusGenericOpenAIAPIEmbeddingModelConfig>;
    insertGenericOpenAIAPIEmbeddingModelConfig(body: GenericOpenAIAPIEmbeddingModelConfig, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<OperationStatusGenericOpenAIAPIEmbeddingModelConfig>>;
    insertGenericOpenAIAPIEmbeddingModelConfig(body: GenericOpenAIAPIEmbeddingModelConfig, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<OperationStatusGenericOpenAIAPIEmbeddingModelConfig>>;
    /**
     *
     *
     * @param body
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    updateGenericOpenAIAPIEmbeddingModelConfig(body: GenericOpenAIAPIEmbeddingModelConfig, observe?: 'body', reportProgress?: boolean): Observable<OperationStatusGenericOpenAIAPIEmbeddingModelConfig>;
    updateGenericOpenAIAPIEmbeddingModelConfig(body: GenericOpenAIAPIEmbeddingModelConfig, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<OperationStatusGenericOpenAIAPIEmbeddingModelConfig>>;
    updateGenericOpenAIAPIEmbeddingModelConfig(body: GenericOpenAIAPIEmbeddingModelConfig, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<OperationStatusGenericOpenAIAPIEmbeddingModelConfig>>;
    static ɵfac: i0.ɵɵFactoryDeclaration<GenericOpenAiapiEmbeddingModelsConfigurationControllerService, [null, { optional: true; }, { optional: true; }]>;
    static ɵprov: i0.ɵɵInjectableDeclaration<GenericOpenAiapiEmbeddingModelsConfigurationControllerService>;
}
//# sourceMappingURL=genericOpenAiapiEmbeddingModelsConfigurationController.service.d.ts.map