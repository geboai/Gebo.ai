import { HttpClient, HttpHeaders, HttpResponse, HttpEvent } from '@angular/common/http';
import { Observable } from 'rxjs';
import { GHuggingfaceChatModelConfig } from '../model/gHuggingfaceChatModelConfig';
import { OperationStatusBoolean } from '../model/operationStatusBoolean';
import { OperationStatusGHuggingfaceChatModelConfig } from '../model/operationStatusGHuggingfaceChatModelConfig';
import { OperationStatusListGHuggingfaceChatModelChoice } from '../model/operationStatusListGHuggingfaceChatModelChoice';
import { Configuration } from '../configuration';
import * as i0 from "@angular/core";
export declare class HuggingfaceChatModelsConfigurationControllerService {
    protected httpClient: HttpClient;
    protected basePath: string;
    defaultHeaders: HttpHeaders;
    configuration: Configuration;
    constructor(httpClient: HttpClient, basePath: string, configuration: Configuration);
    /**
     * @param consumes string[] mime-types
     * @return true: consumes contains 'multipart/form-data', false: otherwise
     */
    private canConsumeForm;
    /**
     *
     *
     * @param body
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    deleteHuggingfaceChatModelConfig(body: GHuggingfaceChatModelConfig, observe?: 'body', reportProgress?: boolean): Observable<OperationStatusBoolean>;
    deleteHuggingfaceChatModelConfig(body: GHuggingfaceChatModelConfig, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<OperationStatusBoolean>>;
    deleteHuggingfaceChatModelConfig(body: GHuggingfaceChatModelConfig, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<OperationStatusBoolean>>;
    /**
     *
     *
     * @param code
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    findHuggingfaceChatModelConfigByCode(code: string, observe?: 'body', reportProgress?: boolean): Observable<GHuggingfaceChatModelConfig>;
    findHuggingfaceChatModelConfigByCode(code: string, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<GHuggingfaceChatModelConfig>>;
    findHuggingfaceChatModelConfigByCode(code: string, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<GHuggingfaceChatModelConfig>>;
    /**
     *
     *
     * @param body
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    getHuggingfaceChatModels(body: GHuggingfaceChatModelConfig, observe?: 'body', reportProgress?: boolean): Observable<OperationStatusListGHuggingfaceChatModelChoice>;
    getHuggingfaceChatModels(body: GHuggingfaceChatModelConfig, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<OperationStatusListGHuggingfaceChatModelChoice>>;
    getHuggingfaceChatModels(body: GHuggingfaceChatModelConfig, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<OperationStatusListGHuggingfaceChatModelChoice>>;
    /**
     *
     *
     * @param body
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    insertHuggingfaceChatModelConfig(body: GHuggingfaceChatModelConfig, observe?: 'body', reportProgress?: boolean): Observable<OperationStatusGHuggingfaceChatModelConfig>;
    insertHuggingfaceChatModelConfig(body: GHuggingfaceChatModelConfig, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<OperationStatusGHuggingfaceChatModelConfig>>;
    insertHuggingfaceChatModelConfig(body: GHuggingfaceChatModelConfig, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<OperationStatusGHuggingfaceChatModelConfig>>;
    /**
     *
     *
     * @param body
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    updateHuggingfaceChatModelConfig(body: GHuggingfaceChatModelConfig, observe?: 'body', reportProgress?: boolean): Observable<OperationStatusGHuggingfaceChatModelConfig>;
    updateHuggingfaceChatModelConfig(body: GHuggingfaceChatModelConfig, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<OperationStatusGHuggingfaceChatModelConfig>>;
    updateHuggingfaceChatModelConfig(body: GHuggingfaceChatModelConfig, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<OperationStatusGHuggingfaceChatModelConfig>>;
    static ɵfac: i0.ɵɵFactoryDeclaration<HuggingfaceChatModelsConfigurationControllerService, [null, { optional: true; }, { optional: true; }]>;
    static ɵprov: i0.ɵɵInjectableDeclaration<HuggingfaceChatModelsConfigurationControllerService>;
}
//# sourceMappingURL=huggingfaceChatModelsConfigurationController.service.d.ts.map