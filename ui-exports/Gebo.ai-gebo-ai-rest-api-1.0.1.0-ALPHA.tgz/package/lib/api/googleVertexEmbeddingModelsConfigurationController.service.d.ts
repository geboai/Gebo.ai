import { HttpClient, HttpHeaders, HttpResponse, HttpEvent } from '@angular/common/http';
import { Observable } from 'rxjs';
import { GGoogleVertexEmbeddingModelConfig } from '../model/gGoogleVertexEmbeddingModelConfig';
import { OperationStatusBoolean } from '../model/operationStatusBoolean';
import { OperationStatusGGoogleVertexEmbeddingModelConfig } from '../model/operationStatusGGoogleVertexEmbeddingModelConfig';
import { OperationStatusListGGoogleVertexEmbeddingModelChoice } from '../model/operationStatusListGGoogleVertexEmbeddingModelChoice';
import { Configuration } from '../configuration';
import * as i0 from "@angular/core";
export declare class GoogleVertexEmbeddingModelsConfigurationControllerService {
    protected httpClient: HttpClient;
    protected basePath: string;
    defaultHeaders: HttpHeaders;
    configuration: Configuration;
    constructor(httpClient: HttpClient, basePath: string, configuration: Configuration);
    /**
     * @param consumes string[] mime-types
     * @return true: consumes contains 'multipart/form-data', false: otherwise
     */
    private canConsumeForm;
    /**
     *
     *
     * @param body
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    deleteGoogleVertexEmbeddingModelConfig(body: GGoogleVertexEmbeddingModelConfig, observe?: 'body', reportProgress?: boolean): Observable<OperationStatusBoolean>;
    deleteGoogleVertexEmbeddingModelConfig(body: GGoogleVertexEmbeddingModelConfig, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<OperationStatusBoolean>>;
    deleteGoogleVertexEmbeddingModelConfig(body: GGoogleVertexEmbeddingModelConfig, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<OperationStatusBoolean>>;
    /**
     *
     *
     * @param code
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    findGoogleVertexEmbeddingModelConfigByCode(code: string, observe?: 'body', reportProgress?: boolean): Observable<GGoogleVertexEmbeddingModelConfig>;
    findGoogleVertexEmbeddingModelConfigByCode(code: string, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<GGoogleVertexEmbeddingModelConfig>>;
    findGoogleVertexEmbeddingModelConfigByCode(code: string, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<GGoogleVertexEmbeddingModelConfig>>;
    /**
     *
     *
     * @param body
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    getGoogleVertexEmbeddingModels(body: GGoogleVertexEmbeddingModelConfig, observe?: 'body', reportProgress?: boolean): Observable<OperationStatusListGGoogleVertexEmbeddingModelChoice>;
    getGoogleVertexEmbeddingModels(body: GGoogleVertexEmbeddingModelConfig, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<OperationStatusListGGoogleVertexEmbeddingModelChoice>>;
    getGoogleVertexEmbeddingModels(body: GGoogleVertexEmbeddingModelConfig, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<OperationStatusListGGoogleVertexEmbeddingModelChoice>>;
    /**
     *
     *
     * @param body
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    insertGoogleVertexEmbeddingModelConfig(body: GGoogleVertexEmbeddingModelConfig, observe?: 'body', reportProgress?: boolean): Observable<OperationStatusGGoogleVertexEmbeddingModelConfig>;
    insertGoogleVertexEmbeddingModelConfig(body: GGoogleVertexEmbeddingModelConfig, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<OperationStatusGGoogleVertexEmbeddingModelConfig>>;
    insertGoogleVertexEmbeddingModelConfig(body: GGoogleVertexEmbeddingModelConfig, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<OperationStatusGGoogleVertexEmbeddingModelConfig>>;
    /**
     *
     *
     * @param body
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    updateGoogleVertexEmbeddingModelConfig(body: GGoogleVertexEmbeddingModelConfig, observe?: 'body', reportProgress?: boolean): Observable<OperationStatusGGoogleVertexEmbeddingModelConfig>;
    updateGoogleVertexEmbeddingModelConfig(body: GGoogleVertexEmbeddingModelConfig, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<OperationStatusGGoogleVertexEmbeddingModelConfig>>;
    updateGoogleVertexEmbeddingModelConfig(body: GGoogleVertexEmbeddingModelConfig, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<OperationStatusGGoogleVertexEmbeddingModelConfig>>;
    static ɵfac: i0.ɵɵFactoryDeclaration<GoogleVertexEmbeddingModelsConfigurationControllerService, [null, { optional: true; }, { optional: true; }]>;
    static ɵprov: i0.ɵɵInjectableDeclaration<GoogleVertexEmbeddingModelsConfigurationControllerService>;
}
//# sourceMappingURL=googleVertexEmbeddingModelsConfigurationController.service.d.ts.map