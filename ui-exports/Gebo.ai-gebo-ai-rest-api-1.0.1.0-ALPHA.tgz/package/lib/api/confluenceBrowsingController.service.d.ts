import { HttpClient, HttpHeaders, HttpResponse, HttpEvent } from '@angular/common/http';
import { Observable } from 'rxjs';
import { BrowseParam } from '../model/browseParam';
import { OperationStatusListGVirtualFilesystemRoot } from '../model/operationStatusListGVirtualFilesystemRoot';
import { OperationStatusListPathInfo } from '../model/operationStatusListPathInfo';
import { OperationStatusListVirtualFilesystemNavigationTreeStatus } from '../model/operationStatusListVirtualFilesystemNavigationTreeStatus';
import { VFilesystemReference } from '../model/vFilesystemReference';
import { Configuration } from '../configuration';
import * as i0 from "@angular/core";
export declare class ConfluenceBrowsingControllerService {
    protected httpClient: HttpClient;
    protected basePath: string;
    defaultHeaders: HttpHeaders;
    configuration: Configuration;
    constructor(httpClient: HttpClient, basePath: string, configuration: Configuration);
    /**
     * @param consumes string[] mime-types
     * @return true: consumes contains 'multipart/form-data', false: otherwise
     */
    private canConsumeForm;
    /**
     *
     *
     * @param body
     * @param systemCode
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    browseConfluencePath(body: BrowseParam, systemCode: string, observe?: 'body', reportProgress?: boolean): Observable<OperationStatusListPathInfo>;
    browseConfluencePath(body: BrowseParam, systemCode: string, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<OperationStatusListPathInfo>>;
    browseConfluencePath(body: BrowseParam, systemCode: string, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<OperationStatusListPathInfo>>;
    /**
     *
     *
     * @param body
     * @param systemCode
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    getConfluenceNavigationStatus(body: Array<VFilesystemReference>, systemCode: string, observe?: 'body', reportProgress?: boolean): Observable<OperationStatusListVirtualFilesystemNavigationTreeStatus>;
    getConfluenceNavigationStatus(body: Array<VFilesystemReference>, systemCode: string, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<OperationStatusListVirtualFilesystemNavigationTreeStatus>>;
    getConfluenceNavigationStatus(body: Array<VFilesystemReference>, systemCode: string, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<OperationStatusListVirtualFilesystemNavigationTreeStatus>>;
    /**
     *
     *
     * @param systemCode
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    getConfluenceRoots(systemCode: string, observe?: 'body', reportProgress?: boolean): Observable<OperationStatusListGVirtualFilesystemRoot>;
    getConfluenceRoots(systemCode: string, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<OperationStatusListGVirtualFilesystemRoot>>;
    getConfluenceRoots(systemCode: string, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<OperationStatusListGVirtualFilesystemRoot>>;
    static ɵfac: i0.ɵɵFactoryDeclaration<ConfluenceBrowsingControllerService, [null, { optional: true; }, { optional: true; }]>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ConfluenceBrowsingControllerService>;
}
//# sourceMappingURL=confluenceBrowsingController.service.d.ts.map