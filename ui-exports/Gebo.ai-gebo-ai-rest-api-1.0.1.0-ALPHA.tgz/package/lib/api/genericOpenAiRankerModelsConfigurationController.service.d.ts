import { HttpClient, HttpHeaders, HttpResponse, HttpEvent } from '@angular/common/http';
import { Observable } from 'rxjs';
import { GenericOpenAIAPIRankerModelConfig } from '../model/genericOpenAIAPIRankerModelConfig';
import { GenericOpenAIRankerModelTypeConfig } from '../model/genericOpenAIRankerModelTypeConfig';
import { OperationStatusBoolean } from '../model/operationStatusBoolean';
import { OperationStatusGenericOpenAIAPIRankerModelConfig } from '../model/operationStatusGenericOpenAIAPIRankerModelConfig';
import { OperationStatusListGenericOpenAIAPIRankerModelChoice } from '../model/operationStatusListGenericOpenAIAPIRankerModelChoice';
import { Configuration } from '../configuration';
import * as i0 from "@angular/core";
export declare class GenericOpenAiRankerModelsConfigurationControllerService {
    protected httpClient: HttpClient;
    protected basePath: string;
    defaultHeaders: HttpHeaders;
    configuration: Configuration;
    constructor(httpClient: HttpClient, basePath: string, configuration: Configuration);
    /**
     * @param consumes string[] mime-types
     * @return true: consumes contains 'multipart/form-data', false: otherwise
     */
    private canConsumeForm;
    /**
     *
     *
     * @param body
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    deleteGenericOpenAIAPIRankerModelConfig(body: GenericOpenAIAPIRankerModelConfig, observe?: 'body', reportProgress?: boolean): Observable<OperationStatusBoolean>;
    deleteGenericOpenAIAPIRankerModelConfig(body: GenericOpenAIAPIRankerModelConfig, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<OperationStatusBoolean>>;
    deleteGenericOpenAIAPIRankerModelConfig(body: GenericOpenAIAPIRankerModelConfig, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<OperationStatusBoolean>>;
    /**
     *
     *
     * @param code
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    findGenericOpenAIAPIRankerModelConfigByCode(code: string, observe?: 'body', reportProgress?: boolean): Observable<GenericOpenAIAPIRankerModelConfig>;
    findGenericOpenAIAPIRankerModelConfigByCode(code: string, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<GenericOpenAIAPIRankerModelConfig>>;
    findGenericOpenAIAPIRankerModelConfigByCode(code: string, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<GenericOpenAIAPIRankerModelConfig>>;
    /**
     *
     *
     * @param body
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    getGenericOpenAIAPIRankerModels(body: GenericOpenAIAPIRankerModelConfig, observe?: 'body', reportProgress?: boolean): Observable<OperationStatusListGenericOpenAIAPIRankerModelChoice>;
    getGenericOpenAIAPIRankerModels(body: GenericOpenAIAPIRankerModelConfig, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<OperationStatusListGenericOpenAIAPIRankerModelChoice>>;
    getGenericOpenAIAPIRankerModels(body: GenericOpenAIAPIRankerModelConfig, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<OperationStatusListGenericOpenAIAPIRankerModelChoice>>;
    /**
     *
     *
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    getGenericOpenAIRankerModelConfigs(observe?: 'body', reportProgress?: boolean): Observable<Array<GenericOpenAIAPIRankerModelConfig>>;
    getGenericOpenAIRankerModelConfigs(observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<Array<GenericOpenAIAPIRankerModelConfig>>>;
    getGenericOpenAIRankerModelConfigs(observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<Array<GenericOpenAIAPIRankerModelConfig>>>;
    /**
     *
     *
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    getGenericOpenAIRankerModelTypes(observe?: 'body', reportProgress?: boolean): Observable<Array<GenericOpenAIRankerModelTypeConfig>>;
    getGenericOpenAIRankerModelTypes(observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<Array<GenericOpenAIRankerModelTypeConfig>>>;
    getGenericOpenAIRankerModelTypes(observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<Array<GenericOpenAIRankerModelTypeConfig>>>;
    /**
     *
     *
     * @param body
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    insertGenericOpenAIAPIRankerModelConfig(body: GenericOpenAIAPIRankerModelConfig, observe?: 'body', reportProgress?: boolean): Observable<OperationStatusGenericOpenAIAPIRankerModelConfig>;
    insertGenericOpenAIAPIRankerModelConfig(body: GenericOpenAIAPIRankerModelConfig, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<OperationStatusGenericOpenAIAPIRankerModelConfig>>;
    insertGenericOpenAIAPIRankerModelConfig(body: GenericOpenAIAPIRankerModelConfig, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<OperationStatusGenericOpenAIAPIRankerModelConfig>>;
    /**
     *
     *
     * @param body
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    updateGenericOpenAIAPIRankerModelConfig(body: GenericOpenAIAPIRankerModelConfig, observe?: 'body', reportProgress?: boolean): Observable<OperationStatusGenericOpenAIAPIRankerModelConfig>;
    updateGenericOpenAIAPIRankerModelConfig(body: GenericOpenAIAPIRankerModelConfig, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<OperationStatusGenericOpenAIAPIRankerModelConfig>>;
    updateGenericOpenAIAPIRankerModelConfig(body: GenericOpenAIAPIRankerModelConfig, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<OperationStatusGenericOpenAIAPIRankerModelConfig>>;
    static ɵfac: i0.ɵɵFactoryDeclaration<GenericOpenAiRankerModelsConfigurationControllerService, [null, { optional: true; }, { optional: true; }]>;
    static ɵprov: i0.ɵɵInjectableDeclaration<GenericOpenAiRankerModelsConfigurationControllerService>;
}
//# sourceMappingURL=genericOpenAiRankerModelsConfigurationController.service.d.ts.map