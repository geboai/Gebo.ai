import { HttpClient, HttpHeaders, HttpResponse, HttpEvent } from '@angular/common/http';
import { Observable } from 'rxjs';
import { GContentManagementSystemType } from '../model/gContentManagementSystemType';
import { GFilesystemContentManagementSystem } from '../model/gFilesystemContentManagementSystem';
import { GFilesystemProjectEndpoint } from '../model/gFilesystemProjectEndpoint';
import { Configuration } from '../configuration';
import * as i0 from "@angular/core";
export declare class FileSystemsControllerService {
    protected httpClient: HttpClient;
    protected basePath: string;
    defaultHeaders: HttpHeaders;
    configuration: Configuration;
    constructor(httpClient: HttpClient, basePath: string, configuration: Configuration);
    /**
     * @param consumes string[] mime-types
     * @return true: consumes contains 'multipart/form-data', false: otherwise
     */
    private canConsumeForm;
    /**
     *
     *
     * @param body
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    deleteFilesystemEndpoint(body: GFilesystemProjectEndpoint, observe?: 'body', reportProgress?: boolean): Observable<any>;
    deleteFilesystemEndpoint(body: GFilesystemProjectEndpoint, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<any>>;
    deleteFilesystemEndpoint(body: GFilesystemProjectEndpoint, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<any>>;
    /**
     *
     *
     * @param parentProjectCode
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    findFileSystemEndpointsByProject(parentProjectCode: string, observe?: 'body', reportProgress?: boolean): Observable<Array<GFilesystemProjectEndpoint>>;
    findFileSystemEndpointsByProject(parentProjectCode: string, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<Array<GFilesystemProjectEndpoint>>>;
    findFileSystemEndpointsByProject(parentProjectCode: string, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<Array<GFilesystemProjectEndpoint>>>;
    /**
     *
     *
     * @param body
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    findFileSystemEndpointsByQbe(body: GFilesystemProjectEndpoint, observe?: 'body', reportProgress?: boolean): Observable<Array<GFilesystemProjectEndpoint>>;
    findFileSystemEndpointsByQbe(body: GFilesystemProjectEndpoint, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<Array<GFilesystemProjectEndpoint>>>;
    findFileSystemEndpointsByQbe(body: GFilesystemProjectEndpoint, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<Array<GFilesystemProjectEndpoint>>>;
    /**
     *
     *
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    getFileSystemSystemTypes1(observe?: 'body', reportProgress?: boolean): Observable<Array<GContentManagementSystemType>>;
    getFileSystemSystemTypes1(observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<Array<GContentManagementSystemType>>>;
    getFileSystemSystemTypes1(observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<Array<GContentManagementSystemType>>>;
    /**
     *
     *
     * @param handlerCode
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    getFileSystemSystems(handlerCode?: string, observe?: 'body', reportProgress?: boolean): Observable<Array<GFilesystemContentManagementSystem>>;
    getFileSystemSystems(handlerCode?: string, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<Array<GFilesystemContentManagementSystem>>>;
    getFileSystemSystems(handlerCode?: string, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<Array<GFilesystemContentManagementSystem>>>;
    /**
     *
     *
     * @param body
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    insertFilesystemEndpoint(body: GFilesystemProjectEndpoint, observe?: 'body', reportProgress?: boolean): Observable<GFilesystemProjectEndpoint>;
    insertFilesystemEndpoint(body: GFilesystemProjectEndpoint, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<GFilesystemProjectEndpoint>>;
    insertFilesystemEndpoint(body: GFilesystemProjectEndpoint, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<GFilesystemProjectEndpoint>>;
    /**
     *
     *
     * @param body
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    updateFilesystemEndpoint(body: GFilesystemProjectEndpoint, observe?: 'body', reportProgress?: boolean): Observable<GFilesystemProjectEndpoint>;
    updateFilesystemEndpoint(body: GFilesystemProjectEndpoint, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<GFilesystemProjectEndpoint>>;
    updateFilesystemEndpoint(body: GFilesystemProjectEndpoint, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<GFilesystemProjectEndpoint>>;
    static ɵfac: i0.ɵɵFactoryDeclaration<FileSystemsControllerService, [null, { optional: true; }, { optional: true; }]>;
    static ɵprov: i0.ɵɵInjectableDeclaration<FileSystemsControllerService>;
}
//# sourceMappingURL=fileSystemsController.service.d.ts.map