import { HttpClient, HttpHeaders, HttpResponse, HttpEvent } from '@angular/common/http';
import { Observable } from 'rxjs';
import { GStatsHolder } from '../model/gStatsHolder';
import { Configuration } from '../configuration';
import * as i0 from "@angular/core";
export declare class GeboCoreAnalisysControllerService {
    protected httpClient: HttpClient;
    protected basePath: string;
    defaultHeaders: HttpHeaders;
    configuration: Configuration;
    constructor(httpClient: HttpClient, basePath: string, configuration: Configuration);
    /**
     * @param consumes string[] mime-types
     * @return true: consumes contains 'multipart/form-data', false: otherwise
     */
    private canConsumeForm;
    /**
     *
     *
     * @param body
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    drillDown(body: GStatsHolder, observe?: 'body', reportProgress?: boolean): Observable<Array<GStatsHolder>>;
    drillDown(body: GStatsHolder, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<Array<GStatsHolder>>>;
    drillDown(body: GStatsHolder, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<Array<GStatsHolder>>>;
    /**
     *
     *
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    getTopLevelKnowledgeBaseCategory(observe?: 'body', reportProgress?: boolean): Observable<GStatsHolder>;
    getTopLevelKnowledgeBaseCategory(observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<GStatsHolder>>;
    getTopLevelKnowledgeBaseCategory(observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<GStatsHolder>>;
    static ɵfac: i0.ɵɵFactoryDeclaration<GeboCoreAnalisysControllerService, [null, { optional: true; }, { optional: true; }]>;
    static ɵprov: i0.ɵɵInjectableDeclaration<GeboCoreAnalisysControllerService>;
}
