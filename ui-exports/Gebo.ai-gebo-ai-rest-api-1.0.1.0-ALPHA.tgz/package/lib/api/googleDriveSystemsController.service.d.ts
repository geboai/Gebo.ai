import { HttpClient, HttpHeaders, HttpResponse, HttpEvent } from '@angular/common/http';
import { Observable } from 'rxjs';
import { FastGoogleDriveSystemInsert } from '../model/fastGoogleDriveSystemInsert';
import { GContentManagementSystemType } from '../model/gContentManagementSystemType';
import { GGoogleDriveProjectEndpoint } from '../model/gGoogleDriveProjectEndpoint';
import { GGoogleDriveSystem } from '../model/gGoogleDriveSystem';
import { OperationStatusGGoogleDriveSystem } from '../model/operationStatusGGoogleDriveSystem';
import { Configuration } from '../configuration';
import * as i0 from "@angular/core";
export declare class GoogleDriveSystemsControllerService {
    protected httpClient: HttpClient;
    protected basePath: string;
    defaultHeaders: HttpHeaders;
    configuration: Configuration;
    constructor(httpClient: HttpClient, basePath: string, configuration: Configuration);
    /**
     * @param consumes string[] mime-types
     * @return true: consumes contains 'multipart/form-data', false: otherwise
     */
    private canConsumeForm;
    /**
     *
     *
     * @param body
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    deleteGoogleDriveProjectEndpoint(body: GGoogleDriveProjectEndpoint, observe?: 'body', reportProgress?: boolean): Observable<any>;
    deleteGoogleDriveProjectEndpoint(body: GGoogleDriveProjectEndpoint, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<any>>;
    deleteGoogleDriveProjectEndpoint(body: GGoogleDriveProjectEndpoint, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<any>>;
    /**
     *
     *
     * @param body
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    deleteGoogleDriveSystem(body: GGoogleDriveSystem, observe?: 'body', reportProgress?: boolean): Observable<any>;
    deleteGoogleDriveSystem(body: GGoogleDriveSystem, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<any>>;
    deleteGoogleDriveSystem(body: GGoogleDriveSystem, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<any>>;
    /**
     *
     *
     * @param body
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    fastGoogleDriveConfig(body: FastGoogleDriveSystemInsert, observe?: 'body', reportProgress?: boolean): Observable<OperationStatusGGoogleDriveSystem>;
    fastGoogleDriveConfig(body: FastGoogleDriveSystemInsert, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<OperationStatusGGoogleDriveSystem>>;
    fastGoogleDriveConfig(body: FastGoogleDriveSystemInsert, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<OperationStatusGGoogleDriveSystem>>;
    /**
     *
     *
     * @param parentProjectCode
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    findGoogleDriveEndpointsByProject(parentProjectCode: string, observe?: 'body', reportProgress?: boolean): Observable<Array<GGoogleDriveProjectEndpoint>>;
    findGoogleDriveEndpointsByProject(parentProjectCode: string, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<Array<GGoogleDriveProjectEndpoint>>>;
    findGoogleDriveEndpointsByProject(parentProjectCode: string, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<Array<GGoogleDriveProjectEndpoint>>>;
    /**
     *
     *
     * @param body
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    findGoogleDriveEndpointsByQbe(body: GGoogleDriveProjectEndpoint, observe?: 'body', reportProgress?: boolean): Observable<Array<GGoogleDriveProjectEndpoint>>;
    findGoogleDriveEndpointsByQbe(body: GGoogleDriveProjectEndpoint, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<Array<GGoogleDriveProjectEndpoint>>>;
    findGoogleDriveEndpointsByQbe(body: GGoogleDriveProjectEndpoint, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<Array<GGoogleDriveProjectEndpoint>>>;
    /**
     *
     *
     * @param code
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    findGoogleDriveProjectEndpointByCode(code: string, observe?: 'body', reportProgress?: boolean): Observable<GGoogleDriveProjectEndpoint>;
    findGoogleDriveProjectEndpointByCode(code: string, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<GGoogleDriveProjectEndpoint>>;
    findGoogleDriveProjectEndpointByCode(code: string, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<GGoogleDriveProjectEndpoint>>;
    /**
     *
     *
     * @param code
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    findGoogleDriveSystemByCode(code: string, observe?: 'body', reportProgress?: boolean): Observable<GGoogleDriveSystem>;
    findGoogleDriveSystemByCode(code: string, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<GGoogleDriveSystem>>;
    findGoogleDriveSystemByCode(code: string, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<GGoogleDriveSystem>>;
    /**
     *
     *
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    getGoogleDriveSystemType(observe?: 'body', reportProgress?: boolean): Observable<GContentManagementSystemType>;
    getGoogleDriveSystemType(observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<GContentManagementSystemType>>;
    getGoogleDriveSystemType(observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<GContentManagementSystemType>>;
    /**
     *
     *
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    getGoogleDriveSystems(observe?: 'body', reportProgress?: boolean): Observable<Array<GGoogleDriveSystem>>;
    getGoogleDriveSystems(observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<Array<GGoogleDriveSystem>>>;
    getGoogleDriveSystems(observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<Array<GGoogleDriveSystem>>>;
    /**
     *
     *
     * @param body
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    insertGoogleDriveProjectEndpoint(body: GGoogleDriveProjectEndpoint, observe?: 'body', reportProgress?: boolean): Observable<GGoogleDriveProjectEndpoint>;
    insertGoogleDriveProjectEndpoint(body: GGoogleDriveProjectEndpoint, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<GGoogleDriveProjectEndpoint>>;
    insertGoogleDriveProjectEndpoint(body: GGoogleDriveProjectEndpoint, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<GGoogleDriveProjectEndpoint>>;
    /**
     *
     *
     * @param body
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    insertGoogleDriveSystem(body: GGoogleDriveSystem, observe?: 'body', reportProgress?: boolean): Observable<OperationStatusGGoogleDriveSystem>;
    insertGoogleDriveSystem(body: GGoogleDriveSystem, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<OperationStatusGGoogleDriveSystem>>;
    insertGoogleDriveSystem(body: GGoogleDriveSystem, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<OperationStatusGGoogleDriveSystem>>;
    /**
     *
     *
     * @param body
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    updateGoogleDriveProjectEndpoint(body: GGoogleDriveProjectEndpoint, observe?: 'body', reportProgress?: boolean): Observable<GGoogleDriveProjectEndpoint>;
    updateGoogleDriveProjectEndpoint(body: GGoogleDriveProjectEndpoint, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<GGoogleDriveProjectEndpoint>>;
    updateGoogleDriveProjectEndpoint(body: GGoogleDriveProjectEndpoint, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<GGoogleDriveProjectEndpoint>>;
    /**
     *
     *
     * @param body
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    updateGoogleDriveSystem(body: GGoogleDriveSystem, observe?: 'body', reportProgress?: boolean): Observable<OperationStatusGGoogleDriveSystem>;
    updateGoogleDriveSystem(body: GGoogleDriveSystem, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<OperationStatusGGoogleDriveSystem>>;
    updateGoogleDriveSystem(body: GGoogleDriveSystem, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<OperationStatusGGoogleDriveSystem>>;
    static ɵfac: i0.ɵɵFactoryDeclaration<GoogleDriveSystemsControllerService, [null, { optional: true; }, { optional: true; }]>;
    static ɵprov: i0.ɵɵInjectableDeclaration<GoogleDriveSystemsControllerService>;
}
//# sourceMappingURL=googleDriveSystemsController.service.d.ts.map