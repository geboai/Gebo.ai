import { HttpClient, HttpHeaders, HttpResponse, HttpEvent } from '@angular/common/http';
import { Observable } from 'rxjs';
import { GLookupEntry } from '../model/gLookupEntry';
import { ToolCategoriesTree } from '../model/toolCategoriesTree';
import { Configuration } from '../configuration';
import * as i0 from "@angular/core";
export declare class FunctionsLookupControllerService {
    protected httpClient: HttpClient;
    protected basePath: string;
    defaultHeaders: HttpHeaders;
    configuration: Configuration;
    constructor(httpClient: HttpClient, basePath: string, configuration: Configuration);
    /**
     * @param consumes string[] mime-types
     * @return true: consumes contains 'multipart/form-data', false: otherwise
     */
    private canConsumeForm;
    /**
     *
     *
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    getAllFunctions(observe?: 'body', reportProgress?: boolean): Observable<Array<GLookupEntry>>;
    getAllFunctions(observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<Array<GLookupEntry>>>;
    getAllFunctions(observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<Array<GLookupEntry>>>;
    /**
     *
     *
     * @param ragContextFunctions
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    getAllFunctionsTree(ragContextFunctions?: boolean, observe?: 'body', reportProgress?: boolean): Observable<Array<ToolCategoriesTree>>;
    getAllFunctionsTree(ragContextFunctions?: boolean, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<Array<ToolCategoriesTree>>>;
    getAllFunctionsTree(ragContextFunctions?: boolean, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<Array<ToolCategoriesTree>>>;
    static ɵfac: i0.ɵɵFactoryDeclaration<FunctionsLookupControllerService, [null, { optional: true; }, { optional: true; }]>;
    static ɵprov: i0.ɵɵInjectableDeclaration<FunctionsLookupControllerService>;
}
//# sourceMappingURL=functionsLookupController.service.d.ts.map