import { HttpClient, HttpHeaders, HttpResponse, HttpEvent } from '@angular/common/http';
import { Observable } from 'rxjs';
import { BrowseParam } from '../model/browseParam';
import { OperationStatusListGVirtualFilesystemRoot } from '../model/operationStatusListGVirtualFilesystemRoot';
import { OperationStatusListPathInfo } from '../model/operationStatusListPathInfo';
import { Configuration } from '../configuration';
import * as i0 from "@angular/core";
export declare class GoogleDriveBrowsingControllerService {
    protected httpClient: HttpClient;
    protected basePath: string;
    defaultHeaders: HttpHeaders;
    configuration: Configuration;
    constructor(httpClient: HttpClient, basePath: string, configuration: Configuration);
    /**
     * @param consumes string[] mime-types
     * @return true: consumes contains 'multipart/form-data', false: otherwise
     */
    private canConsumeForm;
    /**
     *
     *
     * @param body
     * @param driveSystemCode
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    browseGoogleDrivePath(body: BrowseParam, driveSystemCode: string, observe?: 'body', reportProgress?: boolean): Observable<OperationStatusListPathInfo>;
    browseGoogleDrivePath(body: BrowseParam, driveSystemCode: string, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<OperationStatusListPathInfo>>;
    browseGoogleDrivePath(body: BrowseParam, driveSystemCode: string, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<OperationStatusListPathInfo>>;
    /**
     *
     *
     * @param driveSystemCode
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    getGoogleDriveRoots(driveSystemCode: string, observe?: 'body', reportProgress?: boolean): Observable<OperationStatusListGVirtualFilesystemRoot>;
    getGoogleDriveRoots(driveSystemCode: string, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<OperationStatusListGVirtualFilesystemRoot>>;
    getGoogleDriveRoots(driveSystemCode: string, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<OperationStatusListGVirtualFilesystemRoot>>;
    static ɵfac: i0.ɵɵFactoryDeclaration<GoogleDriveBrowsingControllerService, [null, { optional: true; }, { optional: true; }]>;
    static ɵprov: i0.ɵɵInjectableDeclaration<GoogleDriveBrowsingControllerService>;
}
