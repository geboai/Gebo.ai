import { HttpClient, HttpHeaders, HttpResponse, HttpEvent } from '@angular/common/http';
import { Observable } from 'rxjs';
import { StartGooglWorkspaceAccessRequest } from '../model/startGooglWorkspaceAccessRequest';
import { StartGooglWorkspaceAccessRespose } from '../model/startGooglWorkspaceAccessRespose';
import { Configuration } from '../configuration';
import * as i0 from "@angular/core";
export declare class GoogleWorkspaceAccessHandshakeControllerService {
    protected httpClient: HttpClient;
    protected basePath: string;
    defaultHeaders: HttpHeaders;
    configuration: Configuration;
    constructor(httpClient: HttpClient, basePath: string, configuration: Configuration);
    /**
     * @param consumes string[] mime-types
     * @return true: consumes contains 'multipart/form-data', false: otherwise
     */
    private canConsumeForm;
    /**
     *
     *
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    googleWorkspaceRedirect(observe?: 'body', reportProgress?: boolean): Observable<any>;
    googleWorkspaceRedirect(observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<any>>;
    googleWorkspaceRedirect(observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<any>>;
    /**
     *
     *
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    startWorkspaceAccess(observe?: 'body', reportProgress?: boolean): Observable<any>;
    startWorkspaceAccess(observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<any>>;
    startWorkspaceAccess(observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<any>>;
    /**
     *
     *
     * @param body
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    tryGoogleWorkspaceAccess(body: StartGooglWorkspaceAccessRequest, observe?: 'body', reportProgress?: boolean): Observable<StartGooglWorkspaceAccessRespose>;
    tryGoogleWorkspaceAccess(body: StartGooglWorkspaceAccessRequest, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<StartGooglWorkspaceAccessRespose>>;
    tryGoogleWorkspaceAccess(body: StartGooglWorkspaceAccessRequest, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<StartGooglWorkspaceAccessRespose>>;
    static ɵfac: i0.ɵɵFactoryDeclaration<GoogleWorkspaceAccessHandshakeControllerService, [null, { optional: true; }, { optional: true; }]>;
    static ɵprov: i0.ɵɵInjectableDeclaration<GoogleWorkspaceAccessHandshakeControllerService>;
}
