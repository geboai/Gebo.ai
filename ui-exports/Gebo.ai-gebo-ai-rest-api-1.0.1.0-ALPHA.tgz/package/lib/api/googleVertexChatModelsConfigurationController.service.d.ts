import { HttpClient, HttpHeaders, HttpResponse, HttpEvent } from '@angular/common/http';
import { Observable } from 'rxjs';
import { GGoogleVertexChatModelConfig } from '../model/gGoogleVertexChatModelConfig';
import { OperationStatusBoolean } from '../model/operationStatusBoolean';
import { OperationStatusGGoogleVertexChatModelConfig } from '../model/operationStatusGGoogleVertexChatModelConfig';
import { OperationStatusListGGoogleVertexChatModelChoice } from '../model/operationStatusListGGoogleVertexChatModelChoice';
import { Configuration } from '../configuration';
import * as i0 from "@angular/core";
export declare class GoogleVertexChatModelsConfigurationControllerService {
    protected httpClient: HttpClient;
    protected basePath: string;
    defaultHeaders: HttpHeaders;
    configuration: Configuration;
    constructor(httpClient: HttpClient, basePath: string, configuration: Configuration);
    /**
     * @param consumes string[] mime-types
     * @return true: consumes contains 'multipart/form-data', false: otherwise
     */
    private canConsumeForm;
    /**
     *
     *
     * @param body
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    deleteGoogleVertexChatModelConfig(body: GGoogleVertexChatModelConfig, observe?: 'body', reportProgress?: boolean): Observable<OperationStatusBoolean>;
    deleteGoogleVertexChatModelConfig(body: GGoogleVertexChatModelConfig, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<OperationStatusBoolean>>;
    deleteGoogleVertexChatModelConfig(body: GGoogleVertexChatModelConfig, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<OperationStatusBoolean>>;
    /**
     *
     *
     * @param code
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    findGoogleVertexChatModelConfigByCode(code: string, observe?: 'body', reportProgress?: boolean): Observable<GGoogleVertexChatModelConfig>;
    findGoogleVertexChatModelConfigByCode(code: string, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<GGoogleVertexChatModelConfig>>;
    findGoogleVertexChatModelConfigByCode(code: string, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<GGoogleVertexChatModelConfig>>;
    /**
     *
     *
     * @param body
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    getGoogleVertexChatModels(body: GGoogleVertexChatModelConfig, observe?: 'body', reportProgress?: boolean): Observable<OperationStatusListGGoogleVertexChatModelChoice>;
    getGoogleVertexChatModels(body: GGoogleVertexChatModelConfig, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<OperationStatusListGGoogleVertexChatModelChoice>>;
    getGoogleVertexChatModels(body: GGoogleVertexChatModelConfig, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<OperationStatusListGGoogleVertexChatModelChoice>>;
    /**
     *
     *
     * @param body
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    insertGoogleVertexChatModelConfig(body: GGoogleVertexChatModelConfig, observe?: 'body', reportProgress?: boolean): Observable<OperationStatusGGoogleVertexChatModelConfig>;
    insertGoogleVertexChatModelConfig(body: GGoogleVertexChatModelConfig, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<OperationStatusGGoogleVertexChatModelConfig>>;
    insertGoogleVertexChatModelConfig(body: GGoogleVertexChatModelConfig, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<OperationStatusGGoogleVertexChatModelConfig>>;
    /**
     *
     *
     * @param body
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    updateGoogleVertexChatModelConfig(body: GGoogleVertexChatModelConfig, observe?: 'body', reportProgress?: boolean): Observable<OperationStatusGGoogleVertexChatModelConfig>;
    updateGoogleVertexChatModelConfig(body: GGoogleVertexChatModelConfig, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<OperationStatusGGoogleVertexChatModelConfig>>;
    updateGoogleVertexChatModelConfig(body: GGoogleVertexChatModelConfig, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<OperationStatusGGoogleVertexChatModelConfig>>;
    static ɵfac: i0.ɵɵFactoryDeclaration<GoogleVertexChatModelsConfigurationControllerService, [null, { optional: true; }, { optional: true; }]>;
    static ɵprov: i0.ɵɵInjectableDeclaration<GoogleVertexChatModelsConfigurationControllerService>;
}
//# sourceMappingURL=googleVertexChatModelsConfigurationController.service.d.ts.map