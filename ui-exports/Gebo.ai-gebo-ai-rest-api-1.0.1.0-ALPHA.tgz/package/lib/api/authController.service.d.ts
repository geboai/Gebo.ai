import { HttpClient, HttpHeaders, HttpResponse, HttpEvent } from '@angular/common/http';
import { Observable } from 'rxjs';
import { LoginRequest } from '../model/loginRequest';
import { OperationStatusAuthResponse } from '../model/operationStatusAuthResponse';
import { Configuration } from '../configuration';
import * as i0 from "@angular/core";
export declare class AuthControllerService {
    protected httpClient: HttpClient;
    protected basePath: string;
    defaultHeaders: HttpHeaders;
    configuration: Configuration;
    constructor(httpClient: HttpClient, basePath: string, configuration: Configuration);
    /**
     * @param consumes string[] mime-types
     * @return true: consumes contains 'multipart/form-data', false: otherwise
     */
    private canConsumeForm;
    /**
     *
     *
     * @param body
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    authenticateUser(body: LoginRequest, observe?: 'body', reportProgress?: boolean): Observable<OperationStatusAuthResponse>;
    authenticateUser(body: LoginRequest, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<OperationStatusAuthResponse>>;
    authenticateUser(body: LoginRequest, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<OperationStatusAuthResponse>>;
    static ɵfac: i0.ɵɵFactoryDeclaration<AuthControllerService, [null, { optional: true; }, { optional: true; }]>;
    static ɵprov: i0.ɵɵInjectableDeclaration<AuthControllerService>;
}
