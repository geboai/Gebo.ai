import { HttpClient, HttpHeaders, HttpResponse, HttpEvent } from '@angular/common/http';
import { Observable } from 'rxjs';
import { GLookupEntry } from '../model/gLookupEntry';
import { GLookupEntryRef } from '../model/gLookupEntryRef';
import { GLookupEntryRefGBaseChatModelConfig } from '../model/gLookupEntryRefGBaseChatModelConfig';
import { Configuration } from '../configuration';
import * as i0 from "@angular/core";
export declare class ChatModelsLookupControllerService {
    protected httpClient: HttpClient;
    protected basePath: string;
    defaultHeaders: HttpHeaders;
    configuration: Configuration;
    constructor(httpClient: HttpClient, basePath: string, configuration: Configuration);
    /**
     * @param consumes string[] mime-types
     * @return true: consumes contains 'multipart/form-data', false: otherwise
     */
    private canConsumeForm;
    /**
     *
     *
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    getChatModelTypesLookup(observe?: 'body', reportProgress?: boolean): Observable<Array<GLookupEntry>>;
    getChatModelTypesLookup(observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<Array<GLookupEntry>>>;
    getChatModelTypesLookup(observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<Array<GLookupEntry>>>;
    /**
     *
     *
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    getDefaultChatModel(observe?: 'body', reportProgress?: boolean): Observable<GLookupEntryRefGBaseChatModelConfig>;
    getDefaultChatModel(observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<GLookupEntryRefGBaseChatModelConfig>>;
    getDefaultChatModel(observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<GLookupEntryRefGBaseChatModelConfig>>;
    /**
     *
     *
     * @param modelTypeCode
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    getRuntimeConfiguredChatModelsLookup(modelTypeCode?: string, observe?: 'body', reportProgress?: boolean): Observable<Array<GLookupEntryRef>>;
    getRuntimeConfiguredChatModelsLookup(modelTypeCode?: string, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<Array<GLookupEntryRef>>>;
    getRuntimeConfiguredChatModelsLookup(modelTypeCode?: string, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<Array<GLookupEntryRef>>>;
    static ɵfac: i0.ɵɵFactoryDeclaration<ChatModelsLookupControllerService, [null, { optional: true; }, { optional: true; }]>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ChatModelsLookupControllerService>;
}
