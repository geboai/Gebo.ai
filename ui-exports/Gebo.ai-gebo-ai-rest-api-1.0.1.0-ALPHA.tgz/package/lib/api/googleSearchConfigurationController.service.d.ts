import { HttpClient, HttpHeaders, HttpResponse, HttpEvent } from '@angular/common/http';
import { Observable } from 'rxjs';
import { ComponentSetupStatus } from '../model/componentSetupStatus';
import { GGoogleSearchApiCredentials } from '../model/gGoogleSearchApiCredentials';
import { GoogleSearchConfig } from '../model/googleSearchConfig';
import { Configuration } from '../configuration';
import * as i0 from "@angular/core";
export declare class GoogleSearchConfigurationControllerService {
    protected httpClient: HttpClient;
    protected basePath: string;
    defaultHeaders: HttpHeaders;
    configuration: Configuration;
    constructor(httpClient: HttpClient, basePath: string, configuration: Configuration);
    /**
     * @param consumes string[] mime-types
     * @return true: consumes contains 'multipart/form-data', false: otherwise
     */
    private canConsumeForm;
    /**
     *
     *
     * @param body
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    deleteGGoogleSearchApiCredentials(body: GGoogleSearchApiCredentials, observe?: 'body', reportProgress?: boolean): Observable<any>;
    deleteGGoogleSearchApiCredentials(body: GGoogleSearchApiCredentials, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<any>>;
    deleteGGoogleSearchApiCredentials(body: GGoogleSearchApiCredentials, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<any>>;
    /**
     *
     *
     * @param body
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    fastInsertGoogleSearchApiCredentials(body: GoogleSearchConfig, observe?: 'body', reportProgress?: boolean): Observable<GGoogleSearchApiCredentials>;
    fastInsertGoogleSearchApiCredentials(body: GoogleSearchConfig, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<GGoogleSearchApiCredentials>>;
    fastInsertGoogleSearchApiCredentials(body: GoogleSearchConfig, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<GGoogleSearchApiCredentials>>;
    /**
     *
     *
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    getGoogleSearchApiCredentials(observe?: 'body', reportProgress?: boolean): Observable<Array<GGoogleSearchApiCredentials>>;
    getGoogleSearchApiCredentials(observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<Array<GGoogleSearchApiCredentials>>>;
    getGoogleSearchApiCredentials(observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<Array<GGoogleSearchApiCredentials>>>;
    /**
     *
     *
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    getGoogleSearchStatus(observe?: 'body', reportProgress?: boolean): Observable<ComponentSetupStatus>;
    getGoogleSearchStatus(observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<ComponentSetupStatus>>;
    getGoogleSearchStatus(observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<ComponentSetupStatus>>;
    /**
     *
     *
     * @param body
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    insertGGoogleSearchApiCredentials(body: GGoogleSearchApiCredentials, observe?: 'body', reportProgress?: boolean): Observable<GGoogleSearchApiCredentials>;
    insertGGoogleSearchApiCredentials(body: GGoogleSearchApiCredentials, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<GGoogleSearchApiCredentials>>;
    insertGGoogleSearchApiCredentials(body: GGoogleSearchApiCredentials, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<GGoogleSearchApiCredentials>>;
    /**
     *
     *
     * @param code
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    searchGGoogleSearchApiCredentialsByCode(code: string, observe?: 'body', reportProgress?: boolean): Observable<GGoogleSearchApiCredentials>;
    searchGGoogleSearchApiCredentialsByCode(code: string, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<GGoogleSearchApiCredentials>>;
    searchGGoogleSearchApiCredentialsByCode(code: string, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<GGoogleSearchApiCredentials>>;
    /**
     *
     *
     * @param body
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    updateGGoogleSearchApiCredentials(body: GGoogleSearchApiCredentials, observe?: 'body', reportProgress?: boolean): Observable<GGoogleSearchApiCredentials>;
    updateGGoogleSearchApiCredentials(body: GGoogleSearchApiCredentials, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<GGoogleSearchApiCredentials>>;
    updateGGoogleSearchApiCredentials(body: GGoogleSearchApiCredentials, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<GGoogleSearchApiCredentials>>;
    static ɵfac: i0.ɵɵFactoryDeclaration<GoogleSearchConfigurationControllerService, [null, { optional: true; }, { optional: true; }]>;
    static ɵprov: i0.ɵɵInjectableDeclaration<GoogleSearchConfigurationControllerService>;
}
//# sourceMappingURL=googleSearchConfigurationController.service.d.ts.map