import { HttpClient, HttpHeaders, HttpResponse, HttpEvent } from '@angular/common/http';
import { Observable } from 'rxjs';
import { OperationStatusListUserUploadedContent } from '../model/operationStatusListUserUploadedContent';
import { Configuration } from '../configuration';
import * as i0 from "@angular/core";
export declare class GeboUserChatUploadsControllerService {
    protected httpClient: HttpClient;
    protected basePath: string;
    defaultHeaders: HttpHeaders;
    configuration: Configuration;
    constructor(httpClient: HttpClient, basePath: string, configuration: Configuration);
    /**
     * @param consumes string[] mime-types
     * @return true: consumes contains 'multipart/form-data', false: otherwise
     */
    private canConsumeForm;
    /**
     *
     *
     * @param userSessionCode
     * @param files
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    chatSessionUploadForm(userSessionCode: string, files?: Array<Blob>, observe?: 'body', reportProgress?: boolean): Observable<OperationStatusListUserUploadedContent>;
    chatSessionUploadForm(userSessionCode: string, files?: Array<Blob>, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<OperationStatusListUserUploadedContent>>;
    chatSessionUploadForm(userSessionCode: string, files?: Array<Blob>, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<OperationStatusListUserUploadedContent>>;
    /**
     *
     *
     * @param userSessionCode
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    deleteSessionUploads(userSessionCode: string, observe?: 'body', reportProgress?: boolean): Observable<OperationStatusListUserUploadedContent>;
    deleteSessionUploads(userSessionCode: string, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<OperationStatusListUserUploadedContent>>;
    deleteSessionUploads(userSessionCode: string, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<OperationStatusListUserUploadedContent>>;
    /**
     *
     *
     * @param userSessionCode
     * @param uploadedContentId
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    serveContent(userSessionCode: string, uploadedContentId: string, observe?: 'body', reportProgress?: boolean): Observable<any>;
    serveContent(userSessionCode: string, uploadedContentId: string, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<any>>;
    serveContent(userSessionCode: string, uploadedContentId: string, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<any>>;
    static ɵfac: i0.ɵɵFactoryDeclaration<GeboUserChatUploadsControllerService, [null, { optional: true; }, { optional: true; }]>;
    static ɵprov: i0.ɵɵInjectableDeclaration<GeboUserChatUploadsControllerService>;
}
//# sourceMappingURL=geboUserChatUploadsController.service.d.ts.map