import { HttpClient, HttpHeaders, HttpResponse, HttpEvent } from '@angular/common/http';
import { Observable } from 'rxjs';
import { GeboMongoVectorStoreConfig } from '../model/geboMongoVectorStoreConfig';
import { OperationStatusGeboMongoVectorStoreConfig } from '../model/operationStatusGeboMongoVectorStoreConfig';
import { Configuration } from '../configuration';
import * as i0 from "@angular/core";
export declare class GeboVectorStoreConfigurationControllerService {
    protected httpClient: HttpClient;
    protected basePath: string;
    defaultHeaders: HttpHeaders;
    configuration: Configuration;
    constructor(httpClient: HttpClient, basePath: string, configuration: Configuration);
    /**
     * @param consumes string[] mime-types
     * @return true: consumes contains 'multipart/form-data', false: otherwise
     */
    private canConsumeForm;
    /**
     *
     *
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    getActualVectorStoreConfiguration(observe?: 'body', reportProgress?: boolean): Observable<GeboMongoVectorStoreConfig>;
    getActualVectorStoreConfiguration(observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<GeboMongoVectorStoreConfig>>;
    getActualVectorStoreConfiguration(observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<GeboMongoVectorStoreConfig>>;
    /**
     *
     *
     * @param body
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    vectorStoreConfigurationApplyAndSave(body: GeboMongoVectorStoreConfig, observe?: 'body', reportProgress?: boolean): Observable<OperationStatusGeboMongoVectorStoreConfig>;
    vectorStoreConfigurationApplyAndSave(body: GeboMongoVectorStoreConfig, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<OperationStatusGeboMongoVectorStoreConfig>>;
    vectorStoreConfigurationApplyAndSave(body: GeboMongoVectorStoreConfig, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<OperationStatusGeboMongoVectorStoreConfig>>;
    static ɵfac: i0.ɵɵFactoryDeclaration<GeboVectorStoreConfigurationControllerService, [null, { optional: true; }, { optional: true; }]>;
    static ɵprov: i0.ɵɵInjectableDeclaration<GeboVectorStoreConfigurationControllerService>;
}
//# sourceMappingURL=geboVectorStoreConfigurationController.service.d.ts.map