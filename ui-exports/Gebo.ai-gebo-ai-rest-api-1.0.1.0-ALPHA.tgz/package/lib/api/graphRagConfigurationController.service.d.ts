import { HttpClient, HttpHeaders, HttpResponse, HttpEvent } from '@angular/common/http';
import { Observable } from 'rxjs';
import { GObjectRefGProjectEndpoint } from '../model/gObjectRefGProjectEndpoint';
import { GraphRagExtractionConfig } from '../model/graphRagExtractionConfig';
import { Configuration } from '../configuration';
import * as i0 from "@angular/core";
export declare class GraphRagConfigurationControllerService {
    protected httpClient: HttpClient;
    protected basePath: string;
    defaultHeaders: HttpHeaders;
    configuration: Configuration;
    constructor(httpClient: HttpClient, basePath: string, configuration: Configuration);
    /**
     * @param consumes string[] mime-types
     * @return true: consumes contains 'multipart/form-data', false: otherwise
     */
    private canConsumeForm;
    /**
     *
     *
     * @param body
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    deleteGraphRagExtractionConfig(body: GraphRagExtractionConfig, observe?: 'body', reportProgress?: boolean): Observable<any>;
    deleteGraphRagExtractionConfig(body: GraphRagExtractionConfig, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<any>>;
    deleteGraphRagExtractionConfig(body: GraphRagExtractionConfig, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<any>>;
    /**
     *
     *
     * @param code
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    findGraphRagExtractionConfigByCode(code: string, observe?: 'body', reportProgress?: boolean): Observable<GraphRagExtractionConfig>;
    findGraphRagExtractionConfigByCode(code: string, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<GraphRagExtractionConfig>>;
    findGraphRagExtractionConfigByCode(code: string, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<GraphRagExtractionConfig>>;
    /**
     *
     *
     * @param knowledgeBaseCode
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    findGraphRagExtractionConfigByKnowledgeBase(knowledgeBaseCode: string, observe?: 'body', reportProgress?: boolean): Observable<Array<GraphRagExtractionConfig>>;
    findGraphRagExtractionConfigByKnowledgeBase(knowledgeBaseCode: string, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<Array<GraphRagExtractionConfig>>>;
    findGraphRagExtractionConfigByKnowledgeBase(knowledgeBaseCode: string, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<Array<GraphRagExtractionConfig>>>;
    /**
     *
     *
     * @param knowledgeBaseCode
     * @param projectCode
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    findGraphRagExtractionConfigByKnowledgeBaseAndProjectCode(knowledgeBaseCode: string, projectCode: string, observe?: 'body', reportProgress?: boolean): Observable<Array<GraphRagExtractionConfig>>;
    findGraphRagExtractionConfigByKnowledgeBaseAndProjectCode(knowledgeBaseCode: string, projectCode: string, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<Array<GraphRagExtractionConfig>>>;
    findGraphRagExtractionConfigByKnowledgeBaseAndProjectCode(knowledgeBaseCode: string, projectCode: string, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<Array<GraphRagExtractionConfig>>>;
    /**
     *
     *
     * @param body
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    findGraphRagExtractionConfigByProjectEndpointGObjectRef(body: GObjectRefGProjectEndpoint, observe?: 'body', reportProgress?: boolean): Observable<Array<GraphRagExtractionConfig>>;
    findGraphRagExtractionConfigByProjectEndpointGObjectRef(body: GObjectRefGProjectEndpoint, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<Array<GraphRagExtractionConfig>>>;
    findGraphRagExtractionConfigByProjectEndpointGObjectRef(body: GObjectRefGProjectEndpoint, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<Array<GraphRagExtractionConfig>>>;
    /**
     *
     *
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    getDefaultGraphRagExtractionConfig(observe?: 'body', reportProgress?: boolean): Observable<Array<GraphRagExtractionConfig>>;
    getDefaultGraphRagExtractionConfig(observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<Array<GraphRagExtractionConfig>>>;
    getDefaultGraphRagExtractionConfig(observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<Array<GraphRagExtractionConfig>>>;
    /**
     *
     *
     * @param format
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    getSystemGraphRagExtractionConfig(format: string, observe?: 'body', reportProgress?: boolean): Observable<GraphRagExtractionConfig>;
    getSystemGraphRagExtractionConfig(format: string, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<GraphRagExtractionConfig>>;
    getSystemGraphRagExtractionConfig(format: string, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<GraphRagExtractionConfig>>;
    /**
     *
     *
     * @param body
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    instertGraphRagExtractionConfig(body: GraphRagExtractionConfig, observe?: 'body', reportProgress?: boolean): Observable<GraphRagExtractionConfig>;
    instertGraphRagExtractionConfig(body: GraphRagExtractionConfig, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<GraphRagExtractionConfig>>;
    instertGraphRagExtractionConfig(body: GraphRagExtractionConfig, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<GraphRagExtractionConfig>>;
    /**
     *
     *
     * @param body
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    saveGraphRagExtractionConfig(body: GraphRagExtractionConfig, observe?: 'body', reportProgress?: boolean): Observable<GraphRagExtractionConfig>;
    saveGraphRagExtractionConfig(body: GraphRagExtractionConfig, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<GraphRagExtractionConfig>>;
    saveGraphRagExtractionConfig(body: GraphRagExtractionConfig, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<GraphRagExtractionConfig>>;
    static ɵfac: i0.ɵɵFactoryDeclaration<GraphRagConfigurationControllerService, [null, { optional: true; }, { optional: true; }]>;
    static ɵprov: i0.ɵɵInjectableDeclaration<GraphRagConfigurationControllerService>;
}
//# sourceMappingURL=graphRagConfigurationController.service.d.ts.map