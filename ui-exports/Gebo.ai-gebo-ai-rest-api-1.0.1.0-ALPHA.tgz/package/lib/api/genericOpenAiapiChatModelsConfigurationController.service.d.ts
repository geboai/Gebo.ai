import { HttpClient, HttpHeaders, HttpResponse, HttpEvent } from '@angular/common/http';
import { Observable } from 'rxjs';
import { GenericOpenAIAPIChatModelConfig } from '../model/genericOpenAIAPIChatModelConfig';
import { GenericOpenAIChatModelTypeConfig } from '../model/genericOpenAIChatModelTypeConfig';
import { OperationStatusBoolean } from '../model/operationStatusBoolean';
import { OperationStatusGenericOpenAIAPIChatModelConfig } from '../model/operationStatusGenericOpenAIAPIChatModelConfig';
import { OperationStatusListGenericOpenAIAPIChatModelChoice } from '../model/operationStatusListGenericOpenAIAPIChatModelChoice';
import { Configuration } from '../configuration';
import * as i0 from "@angular/core";
export declare class GenericOpenAiapiChatModelsConfigurationControllerService {
    protected httpClient: HttpClient;
    protected basePath: string;
    defaultHeaders: HttpHeaders;
    configuration: Configuration;
    constructor(httpClient: HttpClient, basePath: string, configuration: Configuration);
    /**
     * @param consumes string[] mime-types
     * @return true: consumes contains 'multipart/form-data', false: otherwise
     */
    private canConsumeForm;
    /**
     *
     *
     * @param body
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    deleteGenericOpenAIAPIChatModelConfig(body: GenericOpenAIAPIChatModelConfig, observe?: 'body', reportProgress?: boolean): Observable<OperationStatusBoolean>;
    deleteGenericOpenAIAPIChatModelConfig(body: GenericOpenAIAPIChatModelConfig, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<OperationStatusBoolean>>;
    deleteGenericOpenAIAPIChatModelConfig(body: GenericOpenAIAPIChatModelConfig, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<OperationStatusBoolean>>;
    /**
     *
     *
     * @param code
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    findGenericOpenAIAPIChatModelConfigByCode(code: string, observe?: 'body', reportProgress?: boolean): Observable<GenericOpenAIAPIChatModelConfig>;
    findGenericOpenAIAPIChatModelConfigByCode(code: string, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<GenericOpenAIAPIChatModelConfig>>;
    findGenericOpenAIAPIChatModelConfigByCode(code: string, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<GenericOpenAIAPIChatModelConfig>>;
    /**
     *
     *
     * @param body
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    getGenericOpenAIAPIChatModels(body: GenericOpenAIAPIChatModelConfig, observe?: 'body', reportProgress?: boolean): Observable<OperationStatusListGenericOpenAIAPIChatModelChoice>;
    getGenericOpenAIAPIChatModels(body: GenericOpenAIAPIChatModelConfig, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<OperationStatusListGenericOpenAIAPIChatModelChoice>>;
    getGenericOpenAIAPIChatModels(body: GenericOpenAIAPIChatModelConfig, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<OperationStatusListGenericOpenAIAPIChatModelChoice>>;
    /**
     *
     *
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    getGenericOpenAIChatModelTypes(observe?: 'body', reportProgress?: boolean): Observable<Array<GenericOpenAIChatModelTypeConfig>>;
    getGenericOpenAIChatModelTypes(observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<Array<GenericOpenAIChatModelTypeConfig>>>;
    getGenericOpenAIChatModelTypes(observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<Array<GenericOpenAIChatModelTypeConfig>>>;
    /**
     *
     *
     * @param body
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    insertGenericOpenAIAPIChatModelConfig(body: GenericOpenAIAPIChatModelConfig, observe?: 'body', reportProgress?: boolean): Observable<OperationStatusGenericOpenAIAPIChatModelConfig>;
    insertGenericOpenAIAPIChatModelConfig(body: GenericOpenAIAPIChatModelConfig, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<OperationStatusGenericOpenAIAPIChatModelConfig>>;
    insertGenericOpenAIAPIChatModelConfig(body: GenericOpenAIAPIChatModelConfig, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<OperationStatusGenericOpenAIAPIChatModelConfig>>;
    /**
     *
     *
     * @param body
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    updateGenericOpenAIAPIChatModelConfig(body: GenericOpenAIAPIChatModelConfig, observe?: 'body', reportProgress?: boolean): Observable<OperationStatusGenericOpenAIAPIChatModelConfig>;
    updateGenericOpenAIAPIChatModelConfig(body: GenericOpenAIAPIChatModelConfig, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<OperationStatusGenericOpenAIAPIChatModelConfig>>;
    updateGenericOpenAIAPIChatModelConfig(body: GenericOpenAIAPIChatModelConfig, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<OperationStatusGenericOpenAIAPIChatModelConfig>>;
    static ɵfac: i0.ɵɵFactoryDeclaration<GenericOpenAiapiChatModelsConfigurationControllerService, [null, { optional: true; }, { optional: true; }]>;
    static ɵprov: i0.ɵɵInjectableDeclaration<GenericOpenAiapiChatModelsConfigurationControllerService>;
}
//# sourceMappingURL=genericOpenAiapiChatModelsConfigurationController.service.d.ts.map