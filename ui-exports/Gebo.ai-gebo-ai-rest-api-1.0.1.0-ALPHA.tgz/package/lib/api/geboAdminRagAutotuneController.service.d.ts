import { HttpClient, HttpHeaders, HttpResponse, HttpEvent } from '@angular/common/http';
import { Observable } from 'rxjs';
import { AutotuneVectorStoreInfo } from '../model/autotuneVectorStoreInfo';
import { Configuration } from '../configuration';
import * as i0 from "@angular/core";
export declare class GeboAdminRagAutotuneControllerService {
    protected httpClient: HttpClient;
    protected basePath: string;
    defaultHeaders: HttpHeaders;
    configuration: Configuration;
    constructor(httpClient: HttpClient, basePath: string, configuration: Configuration);
    /**
     * @param consumes string[] mime-types
     * @return true: consumes contains 'multipart/form-data', false: otherwise
     */
    private canConsumeForm;
    /**
     *
     *
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    getLatestComputedVectorStores(observe?: 'body', reportProgress?: boolean): Observable<Array<AutotuneVectorStoreInfo>>;
    getLatestComputedVectorStores(observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<Array<AutotuneVectorStoreInfo>>>;
    getLatestComputedVectorStores(observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<Array<AutotuneVectorStoreInfo>>>;
    static ɵfac: i0.ɵɵFactoryDeclaration<GeboAdminRagAutotuneControllerService, [null, { optional: true; }, { optional: true; }]>;
    static ɵprov: i0.ɵɵInjectableDeclaration<GeboAdminRagAutotuneControllerService>;
}
