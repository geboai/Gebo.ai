import { HttpClient, HttpHeaders, HttpResponse, HttpEvent } from '@angular/common/http';
import { Observable } from 'rxjs';
import { ChatProfileConfigurationLookupByQbeParam } from '../model/chatProfileConfigurationLookupByQbeParam';
import { DataPage } from '../model/dataPage';
import { GChatProfileConfiguration } from '../model/gChatProfileConfiguration';
import { PageGLookupEntry } from '../model/pageGLookupEntry';
import { Configuration } from '../configuration';
import * as i0 from "@angular/core";
export declare class GeboChatProfileLookupControllerService {
    protected httpClient: HttpClient;
    protected basePath: string;
    defaultHeaders: HttpHeaders;
    configuration: Configuration;
    constructor(httpClient: HttpClient, basePath: string, configuration: Configuration);
    /**
     * @param consumes string[] mime-types
     * @return true: consumes contains 'multipart/form-data', false: otherwise
     */
    private canConsumeForm;
    /**
     *
     *
     * @param code
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    findChatProfileConfigurationLookupByCode(code: string, observe?: 'body', reportProgress?: boolean): Observable<GChatProfileConfiguration>;
    findChatProfileConfigurationLookupByCode(code: string, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<GChatProfileConfiguration>>;
    findChatProfileConfigurationLookupByCode(code: string, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<GChatProfileConfiguration>>;
    /**
     *
     *
     * @param body
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    getAllChatProfileConfigurationLoookup(body: DataPage, observe?: 'body', reportProgress?: boolean): Observable<PageGLookupEntry>;
    getAllChatProfileConfigurationLoookup(body: DataPage, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<PageGLookupEntry>>;
    getAllChatProfileConfigurationLoookup(body: DataPage, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<PageGLookupEntry>>;
    /**
     *
     *
     * @param body
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    getChatProfileConfigurationLookupByQbe(body: ChatProfileConfigurationLookupByQbeParam, observe?: 'body', reportProgress?: boolean): Observable<PageGLookupEntry>;
    getChatProfileConfigurationLookupByQbe(body: ChatProfileConfigurationLookupByQbeParam, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<PageGLookupEntry>>;
    getChatProfileConfigurationLookupByQbe(body: ChatProfileConfigurationLookupByQbeParam, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<PageGLookupEntry>>;
    static ɵfac: i0.ɵɵFactoryDeclaration<GeboChatProfileLookupControllerService, [null, { optional: true; }, { optional: true; }]>;
    static ɵprov: i0.ɵɵInjectableDeclaration<GeboChatProfileLookupControllerService>;
}
//# sourceMappingURL=geboChatProfileLookupController.service.d.ts.map