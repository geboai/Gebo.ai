import { HttpClient, HttpHeaders, HttpResponse, HttpEvent } from '@angular/common/http';
import { Observable } from 'rxjs';
import { GContentManagementSystemType } from '../model/gContentManagementSystemType';
import { GGitContentManagementSystem } from '../model/gGitContentManagementSystem';
import { GGitProjectEndpoint } from '../model/gGitProjectEndpoint';
import { OperationStatusGGitProjectEndpoint } from '../model/operationStatusGGitProjectEndpoint';
import { OperationStatusListString } from '../model/operationStatusListString';
import { Configuration } from '../configuration';
import * as i0 from "@angular/core";
export declare class GitSystemsControllerService {
    protected httpClient: HttpClient;
    protected basePath: string;
    defaultHeaders: HttpHeaders;
    configuration: Configuration;
    constructor(httpClient: HttpClient, basePath: string, configuration: Configuration);
    /**
     * @param consumes string[] mime-types
     * @return true: consumes contains 'multipart/form-data', false: otherwise
     */
    private canConsumeForm;
    /**
     *
     *
     * @param body
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    deleteGitEndpoint(body: GGitProjectEndpoint, observe?: 'body', reportProgress?: boolean): Observable<any>;
    deleteGitEndpoint(body: GGitProjectEndpoint, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<any>>;
    deleteGitEndpoint(body: GGitProjectEndpoint, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<any>>;
    /**
     *
     *
     * @param body
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    deleteGitSystem(body: GGitContentManagementSystem, observe?: 'body', reportProgress?: boolean): Observable<any>;
    deleteGitSystem(body: GGitContentManagementSystem, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<any>>;
    deleteGitSystem(body: GGitContentManagementSystem, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<any>>;
    /**
     *
     *
     * @param parentProjectCode
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    findGitEndpointsByProject(parentProjectCode: string, observe?: 'body', reportProgress?: boolean): Observable<Array<GGitProjectEndpoint>>;
    findGitEndpointsByProject(parentProjectCode: string, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<Array<GGitProjectEndpoint>>>;
    findGitEndpointsByProject(parentProjectCode: string, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<Array<GGitProjectEndpoint>>>;
    /**
     *
     *
     * @param body
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    findGitEndpointsByQbe(body: GGitProjectEndpoint, observe?: 'body', reportProgress?: boolean): Observable<Array<GGitProjectEndpoint>>;
    findGitEndpointsByQbe(body: GGitProjectEndpoint, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<Array<GGitProjectEndpoint>>>;
    findGitEndpointsByQbe(body: GGitProjectEndpoint, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<Array<GGitProjectEndpoint>>>;
    /**
     *
     *
     * @param body
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    getBranchesList(body: GGitProjectEndpoint, observe?: 'body', reportProgress?: boolean): Observable<OperationStatusListString>;
    getBranchesList(body: GGitProjectEndpoint, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<OperationStatusListString>>;
    getBranchesList(body: GGitProjectEndpoint, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<OperationStatusListString>>;
    /**
     *
     *
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    getGitSystemTypes(observe?: 'body', reportProgress?: boolean): Observable<Array<GContentManagementSystemType>>;
    getGitSystemTypes(observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<Array<GContentManagementSystemType>>>;
    getGitSystemTypes(observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<Array<GContentManagementSystemType>>>;
    /**
     *
     *
     * @param handlerCode
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    getGitSystems(handlerCode?: string, observe?: 'body', reportProgress?: boolean): Observable<Array<GGitContentManagementSystem>>;
    getGitSystems(handlerCode?: string, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<Array<GGitContentManagementSystem>>>;
    getGitSystems(handlerCode?: string, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<Array<GGitContentManagementSystem>>>;
    /**
     *
     *
     * @param body
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    insertGitEndpoint(body: GGitProjectEndpoint, observe?: 'body', reportProgress?: boolean): Observable<OperationStatusGGitProjectEndpoint>;
    insertGitEndpoint(body: GGitProjectEndpoint, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<OperationStatusGGitProjectEndpoint>>;
    insertGitEndpoint(body: GGitProjectEndpoint, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<OperationStatusGGitProjectEndpoint>>;
    /**
     *
     *
     * @param body
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    insertGitSystem(body: GGitContentManagementSystem, observe?: 'body', reportProgress?: boolean): Observable<GGitContentManagementSystem>;
    insertGitSystem(body: GGitContentManagementSystem, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<GGitContentManagementSystem>>;
    insertGitSystem(body: GGitContentManagementSystem, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<GGitContentManagementSystem>>;
    /**
     *
     *
     * @param body
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    updateGitEndpoint(body: GGitProjectEndpoint, observe?: 'body', reportProgress?: boolean): Observable<OperationStatusGGitProjectEndpoint>;
    updateGitEndpoint(body: GGitProjectEndpoint, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<OperationStatusGGitProjectEndpoint>>;
    updateGitEndpoint(body: GGitProjectEndpoint, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<OperationStatusGGitProjectEndpoint>>;
    /**
     *
     *
     * @param body
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    updateGitSystem(body: GGitContentManagementSystem, observe?: 'body', reportProgress?: boolean): Observable<GGitContentManagementSystem>;
    updateGitSystem(body: GGitContentManagementSystem, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<GGitContentManagementSystem>>;
    updateGitSystem(body: GGitContentManagementSystem, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<GGitContentManagementSystem>>;
    static ɵfac: i0.ɵɵFactoryDeclaration<GitSystemsControllerService, [null, { optional: true; }, { optional: true; }]>;
    static ɵprov: i0.ɵɵInjectableDeclaration<GitSystemsControllerService>;
}
//# sourceMappingURL=gitSystemsController.service.d.ts.map