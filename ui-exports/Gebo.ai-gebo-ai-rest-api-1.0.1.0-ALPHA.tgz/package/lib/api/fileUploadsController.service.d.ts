import { HttpClient, HttpHeaders, HttpResponse, HttpEvent } from '@angular/common/http';
import { Observable } from 'rxjs';
import { GContentManagementSystemType } from '../model/gContentManagementSystemType';
import { GUploadsContentManagementSystem } from '../model/gUploadsContentManagementSystem';
import { GUploadsProjectEndpoint } from '../model/gUploadsProjectEndpoint';
import { Configuration } from '../configuration';
import * as i0 from "@angular/core";
export declare class FileUploadsControllerService {
    protected httpClient: HttpClient;
    protected basePath: string;
    defaultHeaders: HttpHeaders;
    configuration: Configuration;
    constructor(httpClient: HttpClient, basePath: string, configuration: Configuration);
    /**
     * @param consumes string[] mime-types
     * @return true: consumes contains 'multipart/form-data', false: otherwise
     */
    private canConsumeForm;
    /**
     *
     *
     * @param body
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    deleteUploadsEndpoint(body: GUploadsProjectEndpoint, observe?: 'body', reportProgress?: boolean): Observable<any>;
    deleteUploadsEndpoint(body: GUploadsProjectEndpoint, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<any>>;
    deleteUploadsEndpoint(body: GUploadsProjectEndpoint, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<any>>;
    /**
     *
     *
     * @param parentProjectCode
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    findUploadsEndpointsByProject(parentProjectCode: string, observe?: 'body', reportProgress?: boolean): Observable<Array<GUploadsProjectEndpoint>>;
    findUploadsEndpointsByProject(parentProjectCode: string, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<Array<GUploadsProjectEndpoint>>>;
    findUploadsEndpointsByProject(parentProjectCode: string, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<Array<GUploadsProjectEndpoint>>>;
    /**
     *
     *
     * @param body
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    findUploadsEndpointsByQbe(body: GUploadsProjectEndpoint, observe?: 'body', reportProgress?: boolean): Observable<Array<GUploadsProjectEndpoint>>;
    findUploadsEndpointsByQbe(body: GUploadsProjectEndpoint, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<Array<GUploadsProjectEndpoint>>>;
    findUploadsEndpointsByQbe(body: GUploadsProjectEndpoint, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<Array<GUploadsProjectEndpoint>>>;
    /**
     *
     *
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    getFileSystemSystemTypes(observe?: 'body', reportProgress?: boolean): Observable<Array<GContentManagementSystemType>>;
    getFileSystemSystemTypes(observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<Array<GContentManagementSystemType>>>;
    getFileSystemSystemTypes(observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<Array<GContentManagementSystemType>>>;
    /**
     *
     *
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    getUploadableFilesExtensions(observe?: 'body', reportProgress?: boolean): Observable<Array<string>>;
    getUploadableFilesExtensions(observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<Array<string>>>;
    getUploadableFilesExtensions(observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<Array<string>>>;
    /**
     *
     *
     * @param handlerCode
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    getUploadsSystems(handlerCode?: string, observe?: 'body', reportProgress?: boolean): Observable<Array<GUploadsContentManagementSystem>>;
    getUploadsSystems(handlerCode?: string, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<Array<GUploadsContentManagementSystem>>>;
    getUploadsSystems(handlerCode?: string, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<Array<GUploadsContentManagementSystem>>>;
    /**
     *
     *
     * @param body
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    insertUploadsEndpoint(body: GUploadsProjectEndpoint, observe?: 'body', reportProgress?: boolean): Observable<GUploadsProjectEndpoint>;
    insertUploadsEndpoint(body: GUploadsProjectEndpoint, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<GUploadsProjectEndpoint>>;
    insertUploadsEndpoint(body: GUploadsProjectEndpoint, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<GUploadsProjectEndpoint>>;
    /**
     *
     *
     * @param body
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    updateUploadsEndpoint(body: GUploadsProjectEndpoint, observe?: 'body', reportProgress?: boolean): Observable<GUploadsProjectEndpoint>;
    updateUploadsEndpoint(body: GUploadsProjectEndpoint, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<GUploadsProjectEndpoint>>;
    updateUploadsEndpoint(body: GUploadsProjectEndpoint, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<GUploadsProjectEndpoint>>;
    static ɵfac: i0.ɵɵFactoryDeclaration<FileUploadsControllerService, [null, { optional: true; }, { optional: true; }]>;
    static ɵprov: i0.ɵɵInjectableDeclaration<FileUploadsControllerService>;
}
