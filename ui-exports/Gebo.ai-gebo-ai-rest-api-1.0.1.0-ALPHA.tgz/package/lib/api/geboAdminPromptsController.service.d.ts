import { HttpClient, HttpHeaders, HttpResponse, HttpEvent } from '@angular/common/http';
import { Observable } from 'rxjs';
import { GPromptConfig } from '../model/gPromptConfig';
import { PromptFilter } from '../model/promptFilter';
import { Configuration } from '../configuration';
import * as i0 from "@angular/core";
export declare class GeboAdminPromptsControllerService {
    protected httpClient: HttpClient;
    protected basePath: string;
    defaultHeaders: HttpHeaders;
    configuration: Configuration;
    constructor(httpClient: HttpClient, basePath: string, configuration: Configuration);
    /**
     * @param consumes string[] mime-types
     * @return true: consumes contains 'multipart/form-data', false: otherwise
     */
    private canConsumeForm;
    /**
     *
     *
     * @param body
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    deletePromptConfig(body: GPromptConfig, observe?: 'body', reportProgress?: boolean): Observable<any>;
    deletePromptConfig(body: GPromptConfig, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<any>>;
    deletePromptConfig(body: GPromptConfig, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<any>>;
    /**
     *
     *
     * @param code
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    findPromptConfigByCode(code: string, observe?: 'body', reportProgress?: boolean): Observable<GPromptConfig>;
    findPromptConfigByCode(code: string, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<GPromptConfig>>;
    findPromptConfigByCode(code: string, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<GPromptConfig>>;
    /**
     *
     *
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    getPromptCategories(observe?: 'body', reportProgress?: boolean): Observable<Array<string>>;
    getPromptCategories(observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<Array<string>>>;
    getPromptCategories(observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<Array<string>>>;
    /**
     *
     *
     * @param body
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    getPromptConfigByFilter(body: PromptFilter, observe?: 'body', reportProgress?: boolean): Observable<GPromptConfig>;
    getPromptConfigByFilter(body: PromptFilter, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<GPromptConfig>>;
    getPromptConfigByFilter(body: PromptFilter, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<GPromptConfig>>;
    /**
     *
     *
     * @param body
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    insertPromptConfig(body: GPromptConfig, observe?: 'body', reportProgress?: boolean): Observable<GPromptConfig>;
    insertPromptConfig(body: GPromptConfig, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<GPromptConfig>>;
    insertPromptConfig(body: GPromptConfig, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<GPromptConfig>>;
    /**
     *
     *
     * @param body
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    updatePromptConfig(body: GPromptConfig, observe?: 'body', reportProgress?: boolean): Observable<GPromptConfig>;
    updatePromptConfig(body: GPromptConfig, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<GPromptConfig>>;
    updatePromptConfig(body: GPromptConfig, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<GPromptConfig>>;
    static ɵfac: i0.ɵɵFactoryDeclaration<GeboAdminPromptsControllerService, [null, { optional: true; }, { optional: true; }]>;
    static ɵprov: i0.ɵɵInjectableDeclaration<GeboAdminPromptsControllerService>;
}
