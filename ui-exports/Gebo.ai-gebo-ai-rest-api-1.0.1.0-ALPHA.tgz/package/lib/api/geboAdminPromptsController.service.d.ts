import { HttpClient, HttpHeaders, HttpResponse, HttpEvent } from '@angular/common/http';
import { Observable } from 'rxjs';
import { GPromptTemplateConfig } from '../model/gPromptTemplateConfig';
import { PromptFilter } from '../model/promptFilter';
import { Configuration } from '../configuration';
import * as i0 from "@angular/core";
export declare class GeboAdminPromptsControllerService {
    protected httpClient: HttpClient;
    protected basePath: string;
    defaultHeaders: HttpHeaders;
    configuration: Configuration;
    constructor(httpClient: HttpClient, basePath: string, configuration: Configuration);
    /**
     * @param consumes string[] mime-types
     * @return true: consumes contains 'multipart/form-data', false: otherwise
     */
    private canConsumeForm;
    /**
     *
     *
     * @param body
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    deletePromptConfig(body: GPromptTemplateConfig, observe?: 'body', reportProgress?: boolean): Observable<any>;
    deletePromptConfig(body: GPromptTemplateConfig, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<any>>;
    deletePromptConfig(body: GPromptTemplateConfig, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<any>>;
    /**
     *
     *
     * @param code
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    findPromptConfigByCode(code: string, observe?: 'body', reportProgress?: boolean): Observable<GPromptTemplateConfig>;
    findPromptConfigByCode(code: string, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<GPromptTemplateConfig>>;
    findPromptConfigByCode(code: string, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<GPromptTemplateConfig>>;
    /**
     *
     *
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    getPromptCategories(observe?: 'body', reportProgress?: boolean): Observable<Array<string>>;
    getPromptCategories(observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<Array<string>>>;
    getPromptCategories(observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<Array<string>>>;
    /**
     *
     *
     * @param body
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    getPromptConfigByFilter(body: PromptFilter, observe?: 'body', reportProgress?: boolean): Observable<GPromptTemplateConfig>;
    getPromptConfigByFilter(body: PromptFilter, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<GPromptTemplateConfig>>;
    getPromptConfigByFilter(body: PromptFilter, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<GPromptTemplateConfig>>;
    /**
     *
     *
     * @param body
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    insertPromptConfig(body: GPromptTemplateConfig, observe?: 'body', reportProgress?: boolean): Observable<GPromptTemplateConfig>;
    insertPromptConfig(body: GPromptTemplateConfig, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<GPromptTemplateConfig>>;
    insertPromptConfig(body: GPromptTemplateConfig, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<GPromptTemplateConfig>>;
    /**
     *
     *
     * @param body
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    updatePromptConfig(body: GPromptTemplateConfig, observe?: 'body', reportProgress?: boolean): Observable<GPromptTemplateConfig>;
    updatePromptConfig(body: GPromptTemplateConfig, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<GPromptTemplateConfig>>;
    updatePromptConfig(body: GPromptTemplateConfig, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<GPromptTemplateConfig>>;
    static ɵfac: i0.ɵɵFactoryDeclaration<GeboAdminPromptsControllerService, [null, { optional: true; }, { optional: true; }]>;
    static ɵprov: i0.ɵɵInjectableDeclaration<GeboAdminPromptsControllerService>;
}
