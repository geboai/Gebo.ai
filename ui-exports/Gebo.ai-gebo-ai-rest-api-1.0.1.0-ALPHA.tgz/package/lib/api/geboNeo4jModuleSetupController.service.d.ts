import { HttpClient, HttpHeaders, HttpResponse, HttpEvent } from '@angular/common/http';
import { Observable } from 'rxjs';
import { GeboNeo4jModuleConfigDto } from '../model/geboNeo4jModuleConfigDto';
import { Configuration } from '../configuration';
import * as i0 from "@angular/core";
export declare class GeboNeo4jModuleSetupControllerService {
    protected httpClient: HttpClient;
    protected basePath: string;
    defaultHeaders: HttpHeaders;
    configuration: Configuration;
    constructor(httpClient: HttpClient, basePath: string, configuration: Configuration);
    /**
     * @param consumes string[] mime-types
     * @return true: consumes contains 'multipart/form-data', false: otherwise
     */
    private canConsumeForm;
    /**
     *
     *
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    getNeo4jModuleSetupConfig(observe?: 'body', reportProgress?: boolean): Observable<GeboNeo4jModuleConfigDto>;
    getNeo4jModuleSetupConfig(observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<GeboNeo4jModuleConfigDto>>;
    getNeo4jModuleSetupConfig(observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<GeboNeo4jModuleConfigDto>>;
    static ɵfac: i0.ɵɵFactoryDeclaration<GeboNeo4jModuleSetupControllerService, [null, { optional: true; }, { optional: true; }]>;
    static ɵprov: i0.ɵɵInjectableDeclaration<GeboNeo4jModuleSetupControllerService>;
}
