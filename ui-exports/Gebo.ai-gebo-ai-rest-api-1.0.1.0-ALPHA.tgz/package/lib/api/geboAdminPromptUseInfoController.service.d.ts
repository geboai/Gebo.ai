import { HttpClient, HttpHeaders, HttpResponse, HttpEvent } from '@angular/common/http';
import { Observable } from 'rxjs';
import { GPromptUseInfo } from '../model/gPromptUseInfo';
import { Configuration } from '../configuration';
import * as i0 from "@angular/core";
export declare class GeboAdminPromptUseInfoControllerService {
    protected httpClient: HttpClient;
    protected basePath: string;
    defaultHeaders: HttpHeaders;
    configuration: Configuration;
    constructor(httpClient: HttpClient, basePath: string, configuration: Configuration);
    /**
     * @param consumes string[] mime-types
     * @return true: consumes contains 'multipart/form-data', false: otherwise
     */
    private canConsumeForm;
    /**
     *
     *
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    findAll(observe?: 'body', reportProgress?: boolean): Observable<Array<GPromptUseInfo>>;
    findAll(observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<Array<GPromptUseInfo>>>;
    findAll(observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<Array<GPromptUseInfo>>>;
    /**
     *
     *
     * @param code
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    findByCode(code: string, observe?: 'body', reportProgress?: boolean): Observable<GPromptUseInfo>;
    findByCode(code: string, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<GPromptUseInfo>>;
    findByCode(code: string, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<GPromptUseInfo>>;
    /**
     *
     *
     * @param module
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    findByModule(module: string, observe?: 'body', reportProgress?: boolean): Observable<Array<GPromptUseInfo>>;
    findByModule(module: string, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<Array<GPromptUseInfo>>>;
    findByModule(module: string, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<Array<GPromptUseInfo>>>;
    static ɵfac: i0.ɵɵFactoryDeclaration<GeboAdminPromptUseInfoControllerService, [null, { optional: true; }, { optional: true; }]>;
    static ɵprov: i0.ɵɵInjectableDeclaration<GeboAdminPromptUseInfoControllerService>;
}
