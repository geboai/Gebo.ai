import { HttpClient, HttpHeaders, HttpResponse, HttpEvent } from '@angular/common/http';
import { Observable } from 'rxjs';
import { IngestionFileType } from '../model/ingestionFileType';
import { IngestionHandlerConfig } from '../model/ingestionHandlerConfig';
import { Configuration } from '../configuration';
import * as i0 from "@angular/core";
export declare class IngestionFileTypesLibraryControllerService {
    protected httpClient: HttpClient;
    protected basePath: string;
    defaultHeaders: HttpHeaders;
    configuration: Configuration;
    constructor(httpClient: HttpClient, basePath: string, configuration: Configuration);
    /**
     * @param consumes string[] mime-types
     * @return true: consumes contains 'multipart/form-data', false: otherwise
     */
    private canConsumeForm;
    /**
     *
     *
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    getAllFileTypes(observe?: 'body', reportProgress?: boolean): Observable<Array<IngestionFileType>>;
    getAllFileTypes(observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<Array<IngestionFileType>>>;
    getAllFileTypes(observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<Array<IngestionFileType>>>;
    /**
     *
     *
     * @param extension
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    getIngestionFileTypeByExtension(extension: string, observe?: 'body', reportProgress?: boolean): Observable<IngestionFileType>;
    getIngestionFileTypeByExtension(extension: string, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<IngestionFileType>>;
    getIngestionFileTypeByExtension(extension: string, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<IngestionFileType>>;
    /**
     *
     *
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    getIngestionReadingModules(observe?: 'body', reportProgress?: boolean): Observable<Array<IngestionHandlerConfig>>;
    getIngestionReadingModules(observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<Array<IngestionHandlerConfig>>>;
    getIngestionReadingModules(observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<Array<IngestionHandlerConfig>>>;
    static ɵfac: i0.ɵɵFactoryDeclaration<IngestionFileTypesLibraryControllerService, [null, { optional: true; }, { optional: true; }]>;
    static ɵprov: i0.ɵɵInjectableDeclaration<IngestionFileTypesLibraryControllerService>;
}
