import { HttpClient, HttpHeaders, HttpResponse, HttpEvent } from '@angular/common/http';
import { Observable } from 'rxjs';
import { GBaseChatModelChoice } from '../model/gBaseChatModelChoice';
import { GBaseObject } from '../model/gBaseObject';
import { GChatProfileConfiguration } from '../model/gChatProfileConfiguration';
import { GeboChatRequest } from '../model/geboChatRequest';
import { GeboChatResponse } from '../model/geboChatResponse';
import { GeboChatUserInfo } from '../model/geboChatUserInfo';
import { ModelProviderCapabilities } from '../model/modelProviderCapabilities';
import { ServerSentEventString } from '../model/serverSentEventString';
import { Configuration } from '../configuration';
import * as i0 from "@angular/core";
export declare class GeboRagChatControllerService {
    protected httpClient: HttpClient;
    protected basePath: string;
    defaultHeaders: HttpHeaders;
    configuration: Configuration;
    constructor(httpClient: HttpClient, basePath: string, configuration: Configuration);
    /**
     * @param consumes string[] mime-types
     * @return true: consumes contains 'multipart/form-data', false: otherwise
     */
    private canConsumeForm;
    /**
     *
     *
     * @param chatProfileCode
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    getChatModelUserInfoByChatProfileCode(chatProfileCode: string, observe?: 'body', reportProgress?: boolean): Observable<GeboChatUserInfo>;
    getChatModelUserInfoByChatProfileCode(chatProfileCode: string, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<GeboChatUserInfo>>;
    getChatModelUserInfoByChatProfileCode(chatProfileCode: string, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<GeboChatUserInfo>>;
    /**
     *
     *
     * @param chatProfileCode
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    getChatProfileModelMetaInfos(chatProfileCode: string, observe?: 'body', reportProgress?: boolean): Observable<GBaseChatModelChoice>;
    getChatProfileModelMetaInfos(chatProfileCode: string, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<GBaseChatModelChoice>>;
    getChatProfileModelMetaInfos(chatProfileCode: string, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<GBaseChatModelChoice>>;
    /**
     *
     *
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    getChatProfiles(observe?: 'body', reportProgress?: boolean): Observable<Array<GChatProfileConfiguration>>;
    getChatProfiles(observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<Array<GChatProfileConfiguration>>>;
    getChatProfiles(observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<Array<GChatProfileConfiguration>>>;
    /**
     *
     *
     * @param chatProfileCode
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    getProfileProviderModelCapabilities(chatProfileCode: string, observe?: 'body', reportProgress?: boolean): Observable<ModelProviderCapabilities>;
    getProfileProviderModelCapabilities(chatProfileCode: string, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<ModelProviderCapabilities>>;
    getProfileProviderModelCapabilities(chatProfileCode: string, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<ModelProviderCapabilities>>;
    /**
     *
     *
     * @param profileCode
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    getVisibleKnowledgeBasesByProfileCode(profileCode: string, observe?: 'body', reportProgress?: boolean): Observable<Array<GBaseObject>>;
    getVisibleKnowledgeBasesByProfileCode(profileCode: string, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<Array<GBaseObject>>>;
    getVisibleKnowledgeBasesByProfileCode(profileCode: string, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<Array<GBaseObject>>>;
    /**
     *
     *
     * @param body
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    ragChat(body: GeboChatRequest, observe?: 'body', reportProgress?: boolean): Observable<GeboChatResponse>;
    ragChat(body: GeboChatRequest, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<GeboChatResponse>>;
    ragChat(body: GeboChatRequest, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<GeboChatResponse>>;
    /**
     *
     *
     * @param body
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    streamRagResponse(body: GeboChatRequest, observe?: 'body', reportProgress?: boolean): Observable<Array<ServerSentEventString>>;
    streamRagResponse(body: GeboChatRequest, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<Array<ServerSentEventString>>>;
    streamRagResponse(body: GeboChatRequest, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<Array<ServerSentEventString>>>;
    static ɵfac: i0.ɵɵFactoryDeclaration<GeboRagChatControllerService, [null, { optional: true; }, { optional: true; }]>;
    static ɵprov: i0.ɵɵInjectableDeclaration<GeboRagChatControllerService>;
}
//# sourceMappingURL=geboRagChatController.service.d.ts.map