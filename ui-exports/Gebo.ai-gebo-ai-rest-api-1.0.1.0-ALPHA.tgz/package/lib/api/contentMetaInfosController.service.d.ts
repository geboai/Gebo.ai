import { HttpClient, HttpHeaders, HttpResponse, HttpEvent } from '@angular/common/http';
import { Observable } from 'rxjs';
import { ContentMetaInfo } from '../model/contentMetaInfo';
import { ContentObject } from '../model/contentObject';
import { DocumentReferenceView } from '../model/documentReferenceView';
import { PageDocumentReferenceView } from '../model/pageDocumentReferenceView';
import { SearchDocumentByNamePagedParam } from '../model/searchDocumentByNamePagedParam';
import { SearchDocumentByNameParam } from '../model/searchDocumentByNameParam';
import { Configuration } from '../configuration';
import * as i0 from "@angular/core";
export declare class ContentMetaInfosControllerService {
    protected httpClient: HttpClient;
    protected basePath: string;
    defaultHeaders: HttpHeaders;
    configuration: Configuration;
    constructor(httpClient: HttpClient, basePath: string, configuration: Configuration);
    /**
     * @param consumes string[] mime-types
     * @return true: consumes contains 'multipart/form-data', false: otherwise
     */
    private canConsumeForm;
    /**
     *
     *
     * @param body
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    findDocumentReferenceViewByCode(body: Array<string>, observe?: 'body', reportProgress?: boolean): Observable<Array<DocumentReferenceView>>;
    findDocumentReferenceViewByCode(body: Array<string>, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<Array<DocumentReferenceView>>>;
    findDocumentReferenceViewByCode(body: Array<string>, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<Array<DocumentReferenceView>>>;
    /**
     *
     *
     * @param code
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    getContentMetaInfos(code: string, observe?: 'body', reportProgress?: boolean): Observable<ContentMetaInfo>;
    getContentMetaInfos(code: string, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<ContentMetaInfo>>;
    getContentMetaInfos(code: string, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<ContentMetaInfo>>;
    /**
     *
     *
     * @param code
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    getContentObject(code: string, observe?: 'body', reportProgress?: boolean): Observable<ContentObject>;
    getContentObject(code: string, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<ContentObject>>;
    getContentObject(code: string, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<ContentObject>>;
    /**
     *
     *
     * @param body
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    searchByDocumentName(body: SearchDocumentByNameParam, observe?: 'body', reportProgress?: boolean): Observable<Array<DocumentReferenceView>>;
    searchByDocumentName(body: SearchDocumentByNameParam, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<Array<DocumentReferenceView>>>;
    searchByDocumentName(body: SearchDocumentByNameParam, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<Array<DocumentReferenceView>>>;
    /**
     *
     *
     * @param body
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    searchByDocumentNamePaged(body: SearchDocumentByNamePagedParam, observe?: 'body', reportProgress?: boolean): Observable<PageDocumentReferenceView>;
    searchByDocumentNamePaged(body: SearchDocumentByNamePagedParam, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<PageDocumentReferenceView>>;
    searchByDocumentNamePaged(body: SearchDocumentByNamePagedParam, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<PageDocumentReferenceView>>;
    static ɵfac: i0.ɵɵFactoryDeclaration<ContentMetaInfosControllerService, [null, { optional: true; }, { optional: true; }]>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ContentMetaInfosControllerService>;
}
