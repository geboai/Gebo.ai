import { HttpClient, HttpHeaders, HttpResponse, HttpEvent } from '@angular/common/http';
import { Observable } from 'rxjs';
import { GContentManagementSystem } from '../model/gContentManagementSystem';
import { GContentManagementSystemType } from '../model/gContentManagementSystemType';
import { GObjectRefGProjectEndpoint } from '../model/gObjectRefGProjectEndpoint';
import { GProjectEndpoint } from '../model/gProjectEndpoint';
import { SystemInfos } from '../model/systemInfos';
import { Configuration } from '../configuration';
import * as i0 from "@angular/core";
export declare class CompanySystemsControllerService {
    protected httpClient: HttpClient;
    protected basePath: string;
    defaultHeaders: HttpHeaders;
    configuration: Configuration;
    constructor(httpClient: HttpClient, basePath: string, configuration: Configuration);
    /**
     * @param consumes string[] mime-types
     * @return true: consumes contains 'multipart/form-data', false: otherwise
     */
    private canConsumeForm;
    /**
     *
     *
     * @param systemTypeCode
     * @param systemCode
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    getContentSystem(systemTypeCode: string, systemCode: string, observe?: 'body', reportProgress?: boolean): Observable<GContentManagementSystem>;
    getContentSystem(systemTypeCode: string, systemCode: string, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<GContentManagementSystem>>;
    getContentSystem(systemTypeCode: string, systemCode: string, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<GContentManagementSystem>>;
    /**
     *
     *
     * @param systemTypeCode
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    getContentSystemType(systemTypeCode: string, observe?: 'body', reportProgress?: boolean): Observable<GContentManagementSystemType>;
    getContentSystemType(systemTypeCode: string, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<GContentManagementSystemType>>;
    getContentSystemType(systemTypeCode: string, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<GContentManagementSystemType>>;
    /**
     *
     *
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    getContentSystemTypes(observe?: 'body', reportProgress?: boolean): Observable<Array<GContentManagementSystemType>>;
    getContentSystemTypes(observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<Array<GContentManagementSystemType>>>;
    getContentSystemTypes(observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<Array<GContentManagementSystemType>>>;
    /**
     *
     *
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    getContentSystems(observe?: 'body', reportProgress?: boolean): Observable<Array<GContentManagementSystem>>;
    getContentSystems(observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<Array<GContentManagementSystem>>>;
    getContentSystems(observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<Array<GContentManagementSystem>>>;
    /**
     *
     *
     * @param systemTypeCode
     * @param systemCode
     * @param projectEndpointCode
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    getProjectEndpoint(systemTypeCode: string, systemCode: string, projectEndpointCode: string, observe?: 'body', reportProgress?: boolean): Observable<GProjectEndpoint>;
    getProjectEndpoint(systemTypeCode: string, systemCode: string, projectEndpointCode: string, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<GProjectEndpoint>>;
    getProjectEndpoint(systemTypeCode: string, systemCode: string, projectEndpointCode: string, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<GProjectEndpoint>>;
    /**
     *
     *
     * @param body
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    getProjectEndpointByObjectRef(body: GObjectRefGProjectEndpoint, observe?: 'body', reportProgress?: boolean): Observable<GProjectEndpoint>;
    getProjectEndpointByObjectRef(body: GObjectRefGProjectEndpoint, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<GProjectEndpoint>>;
    getProjectEndpointByObjectRef(body: GObjectRefGProjectEndpoint, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<GProjectEndpoint>>;
    /**
     *
     *
     * @param body
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    getProjectEndpointSystemInfos(body: GObjectRefGProjectEndpoint, observe?: 'body', reportProgress?: boolean): Observable<SystemInfos>;
    getProjectEndpointSystemInfos(body: GObjectRefGProjectEndpoint, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<SystemInfos>>;
    getProjectEndpointSystemInfos(body: GObjectRefGProjectEndpoint, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<SystemInfos>>;
    static ɵfac: i0.ɵɵFactoryDeclaration<CompanySystemsControllerService, [null, { optional: true; }, { optional: true; }]>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CompanySystemsControllerService>;
}
//# sourceMappingURL=companySystemsController.service.d.ts.map