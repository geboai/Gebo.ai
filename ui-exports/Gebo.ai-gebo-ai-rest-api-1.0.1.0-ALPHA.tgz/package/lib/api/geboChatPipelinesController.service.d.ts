import { HttpClient, HttpHeaders, HttpResponse, HttpEvent } from '@angular/common/http';
import { Observable } from 'rxjs';
import { GeboChatMessageEnvelope } from '../model/geboChatMessageEnvelope';
import { GeboChatResponse } from '../model/geboChatResponse';
import { PipelineChatMenu } from '../model/pipelineChatMenu';
import { PipelineRequestBody } from '../model/pipelineRequestBody';
import { Configuration } from '../configuration';
import * as i0 from "@angular/core";
export declare class GeboChatPipelinesControllerService {
    protected httpClient: HttpClient;
    protected basePath: string;
    defaultHeaders: HttpHeaders;
    configuration: Configuration;
    constructor(httpClient: HttpClient, basePath: string, configuration: Configuration);
    /**
     * @param consumes string[] mime-types
     * @return true: consumes contains 'multipart/form-data', false: otherwise
     */
    private canConsumeForm;
    /**
     *
     *
     * @param body
     * @param pipelineCode
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    executeChatPipeline(body: PipelineRequestBody, pipelineCode?: string, observe?: 'body', reportProgress?: boolean): Observable<GeboChatResponse>;
    executeChatPipeline(body: PipelineRequestBody, pipelineCode?: string, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<GeboChatResponse>>;
    executeChatPipeline(body: PipelineRequestBody, pipelineCode?: string, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<GeboChatResponse>>;
    /**
     *
     *
     * @param body
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    executeDefaultChatPipeline(body: PipelineRequestBody, observe?: 'body', reportProgress?: boolean): Observable<GeboChatResponse>;
    executeDefaultChatPipeline(body: PipelineRequestBody, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<GeboChatResponse>>;
    executeDefaultChatPipeline(body: PipelineRequestBody, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<GeboChatResponse>>;
    /**
     *
     *
     * @param chatProfileCode
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    getDefaultPersonalPipelinesChatMenu(chatProfileCode: string, observe?: 'body', reportProgress?: boolean): Observable<Array<PipelineChatMenu>>;
    getDefaultPersonalPipelinesChatMenu(chatProfileCode: string, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<Array<PipelineChatMenu>>>;
    getDefaultPersonalPipelinesChatMenu(chatProfileCode: string, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<Array<PipelineChatMenu>>>;
    /**
     *
     *
     * @param chatProfileCode
     * @param pipelineCode
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    getPersonalPipelinesChatMenu(chatProfileCode: string, pipelineCode?: string, observe?: 'body', reportProgress?: boolean): Observable<Array<PipelineChatMenu>>;
    getPersonalPipelinesChatMenu(chatProfileCode: string, pipelineCode?: string, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<Array<PipelineChatMenu>>>;
    getPersonalPipelinesChatMenu(chatProfileCode: string, pipelineCode?: string, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<Array<PipelineChatMenu>>>;
    /**
     *
     *
     * @param userChatContextCode
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    stopChatPipeline(userChatContextCode: string, observe?: 'body', reportProgress?: boolean): Observable<any>;
    stopChatPipeline(userChatContextCode: string, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<any>>;
    stopChatPipeline(userChatContextCode: string, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<any>>;
    /**
     *
     *
     * @param body
     * @param pipelineCode
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    streamChatPipeline(body: PipelineRequestBody, pipelineCode?: string, observe?: 'body', reportProgress?: boolean): Observable<Array<GeboChatMessageEnvelope>>;
    streamChatPipeline(body: PipelineRequestBody, pipelineCode?: string, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<Array<GeboChatMessageEnvelope>>>;
    streamChatPipeline(body: PipelineRequestBody, pipelineCode?: string, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<Array<GeboChatMessageEnvelope>>>;
    /**
     *
     *
     * @param body
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    streamDefaultChatPipeline(body: PipelineRequestBody, observe?: 'body', reportProgress?: boolean): Observable<Array<GeboChatMessageEnvelope>>;
    streamDefaultChatPipeline(body: PipelineRequestBody, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<Array<GeboChatMessageEnvelope>>>;
    streamDefaultChatPipeline(body: PipelineRequestBody, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<Array<GeboChatMessageEnvelope>>>;
    static ɵfac: i0.ɵɵFactoryDeclaration<GeboChatPipelinesControllerService, [null, { optional: true; }, { optional: true; }]>;
    static ɵprov: i0.ɵɵInjectableDeclaration<GeboChatPipelinesControllerService>;
}
