import { HttpClient, HttpHeaders, HttpResponse, HttpEvent } from '@angular/common/http';
import { Observable } from 'rxjs';
import { HandShakeToken } from '../model/handShakeToken';
import { Configuration } from '../configuration';
import * as i0 from "@angular/core";
export declare class FileUploadControllerService {
    protected httpClient: HttpClient;
    protected basePath: string;
    defaultHeaders: HttpHeaders;
    configuration: Configuration;
    constructor(httpClient: HttpClient, basePath: string, configuration: Configuration);
    /**
     * @param consumes string[] mime-types
     * @return true: consumes contains 'multipart/form-data', false: otherwise
     */
    private canConsumeForm;
    /**
     *
     *
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    getHandShakeCode(observe?: 'body', reportProgress?: boolean): Observable<HandShakeToken>;
    getHandShakeCode(observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<HandShakeToken>>;
    getHandShakeCode(observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<HandShakeToken>>;
    /**
     *
     *
     * @param handShakeCode
     * @param files
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    upload1Form(handShakeCode: string, files?: Array<Blob>, observe?: 'body', reportProgress?: boolean): Observable<any>;
    upload1Form(handShakeCode: string, files?: Array<Blob>, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<any>>;
    upload1Form(handShakeCode: string, files?: Array<Blob>, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<any>>;
    static ɵfac: i0.ɵɵFactoryDeclaration<FileUploadControllerService, [null, { optional: true; }, { optional: true; }]>;
    static ɵprov: i0.ɵɵInjectableDeclaration<FileUploadControllerService>;
}
