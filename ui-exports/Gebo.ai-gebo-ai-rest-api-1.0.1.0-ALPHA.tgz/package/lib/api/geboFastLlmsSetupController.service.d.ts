import { HttpClient, HttpHeaders, HttpResponse, HttpEvent } from '@angular/common/http';
import { Observable } from 'rxjs';
import { ComponentLLMSStatus } from '../model/componentLLMSStatus';
import { LLMAutoconfigureCreationData } from '../model/lLMAutoconfigureCreationData';
import { LLMCreateModelData } from '../model/lLMCreateModelData';
import { LLMCredentialsCreationData } from '../model/lLMCredentialsCreationData';
import { LLMCredentialsVerificationData } from '../model/lLMCredentialsVerificationData';
import { LLMModelsLookupParameter } from '../model/lLMModelsLookupParameter';
import { LLMSSetupConfigurationData } from '../model/lLMSSetupConfigurationData';
import { OperationStatusList } from '../model/operationStatusList';
import { OperationStatusListGBaseModelChoice } from '../model/operationStatusListGBaseModelChoice';
import { OperationStatusSecretInfo } from '../model/operationStatusSecretInfo';
import { Configuration } from '../configuration';
import * as i0 from "@angular/core";
export declare class GeboFastLlmsSetupControllerService {
    protected httpClient: HttpClient;
    protected basePath: string;
    defaultHeaders: HttpHeaders;
    configuration: Configuration;
    constructor(httpClient: HttpClient, basePath: string, configuration: Configuration);
    /**
     * @param consumes string[] mime-types
     * @return true: consumes contains 'multipart/form-data', false: otherwise
     */
    private canConsumeForm;
    /**
     *
     *
     * @param body
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    createLLMByAutoconfigure(body: LLMAutoconfigureCreationData, observe?: 'body', reportProgress?: boolean): Observable<OperationStatusList>;
    createLLMByAutoconfigure(body: LLMAutoconfigureCreationData, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<OperationStatusList>>;
    createLLMByAutoconfigure(body: LLMAutoconfigureCreationData, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<OperationStatusList>>;
    /**
     *
     *
     * @param body
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    createLLMCredentials(body: LLMCredentialsCreationData, observe?: 'body', reportProgress?: boolean): Observable<OperationStatusSecretInfo>;
    createLLMCredentials(body: LLMCredentialsCreationData, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<OperationStatusSecretInfo>>;
    createLLMCredentials(body: LLMCredentialsCreationData, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<OperationStatusSecretInfo>>;
    /**
     *
     *
     * @param body
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    createLLMS(body: Array<LLMCreateModelData>, observe?: 'body', reportProgress?: boolean): Observable<OperationStatusList>;
    createLLMS(body: Array<LLMCreateModelData>, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<OperationStatusList>>;
    createLLMS(body: Array<LLMCreateModelData>, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<OperationStatusList>>;
    /**
     *
     *
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    getActualLLMSConfiguration(observe?: 'body', reportProgress?: boolean): Observable<LLMSSetupConfigurationData>;
    getActualLLMSConfiguration(observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<LLMSSetupConfigurationData>>;
    getActualLLMSConfiguration(observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<LLMSSetupConfigurationData>>;
    /**
     *
     *
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    getLLMSSetupStatus(observe?: 'body', reportProgress?: boolean): Observable<ComponentLLMSStatus>;
    getLLMSSetupStatus(observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<ComponentLLMSStatus>>;
    getLLMSSetupStatus(observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<ComponentLLMSStatus>>;
    /**
     *
     *
     * @param body
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    verifyCredentialsAndDownloadModels(body: LLMModelsLookupParameter, observe?: 'body', reportProgress?: boolean): Observable<OperationStatusListGBaseModelChoice>;
    verifyCredentialsAndDownloadModels(body: LLMModelsLookupParameter, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<OperationStatusListGBaseModelChoice>>;
    verifyCredentialsAndDownloadModels(body: LLMModelsLookupParameter, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<OperationStatusListGBaseModelChoice>>;
    /**
     *
     *
     * @param body
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    verifyVendorCredentialsAndDownloadModels(body: LLMCredentialsVerificationData, observe?: 'body', reportProgress?: boolean): Observable<OperationStatusListGBaseModelChoice>;
    verifyVendorCredentialsAndDownloadModels(body: LLMCredentialsVerificationData, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<OperationStatusListGBaseModelChoice>>;
    verifyVendorCredentialsAndDownloadModels(body: LLMCredentialsVerificationData, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<OperationStatusListGBaseModelChoice>>;
    static ɵfac: i0.ɵɵFactoryDeclaration<GeboFastLlmsSetupControllerService, [null, { optional: true; }, { optional: true; }]>;
    static ɵprov: i0.ɵɵInjectableDeclaration<GeboFastLlmsSetupControllerService>;
}
