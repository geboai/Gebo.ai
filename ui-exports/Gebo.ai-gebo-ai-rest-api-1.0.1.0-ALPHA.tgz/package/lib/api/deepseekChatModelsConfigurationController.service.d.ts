import { HttpClient, HttpHeaders, HttpResponse, HttpEvent } from '@angular/common/http';
import { Observable } from 'rxjs';
import { GDeepseekChatModelConfig } from '../model/gDeepseekChatModelConfig';
import { OperationStatusBoolean } from '../model/operationStatusBoolean';
import { OperationStatusGDeepseekChatModelConfig } from '../model/operationStatusGDeepseekChatModelConfig';
import { OperationStatusListGDeepseekChatModelChoice } from '../model/operationStatusListGDeepseekChatModelChoice';
import { Configuration } from '../configuration';
import * as i0 from "@angular/core";
export declare class DeepseekChatModelsConfigurationControllerService {
    protected httpClient: HttpClient;
    protected basePath: string;
    defaultHeaders: HttpHeaders;
    configuration: Configuration;
    constructor(httpClient: HttpClient, basePath: string, configuration: Configuration);
    /**
     * @param consumes string[] mime-types
     * @return true: consumes contains 'multipart/form-data', false: otherwise
     */
    private canConsumeForm;
    /**
     *
     *
     * @param body
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    deleteDeepseekChatModelConfig(body: GDeepseekChatModelConfig, observe?: 'body', reportProgress?: boolean): Observable<OperationStatusBoolean>;
    deleteDeepseekChatModelConfig(body: GDeepseekChatModelConfig, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<OperationStatusBoolean>>;
    deleteDeepseekChatModelConfig(body: GDeepseekChatModelConfig, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<OperationStatusBoolean>>;
    /**
     *
     *
     * @param code
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    findDeepseekChatModelConfigByCode(code: string, observe?: 'body', reportProgress?: boolean): Observable<GDeepseekChatModelConfig>;
    findDeepseekChatModelConfigByCode(code: string, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<GDeepseekChatModelConfig>>;
    findDeepseekChatModelConfigByCode(code: string, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<GDeepseekChatModelConfig>>;
    /**
     *
     *
     * @param body
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    getDeepseekChatModels(body: GDeepseekChatModelConfig, observe?: 'body', reportProgress?: boolean): Observable<OperationStatusListGDeepseekChatModelChoice>;
    getDeepseekChatModels(body: GDeepseekChatModelConfig, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<OperationStatusListGDeepseekChatModelChoice>>;
    getDeepseekChatModels(body: GDeepseekChatModelConfig, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<OperationStatusListGDeepseekChatModelChoice>>;
    /**
     *
     *
     * @param body
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    insertDeepseekChatModelConfig(body: GDeepseekChatModelConfig, observe?: 'body', reportProgress?: boolean): Observable<OperationStatusGDeepseekChatModelConfig>;
    insertDeepseekChatModelConfig(body: GDeepseekChatModelConfig, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<OperationStatusGDeepseekChatModelConfig>>;
    insertDeepseekChatModelConfig(body: GDeepseekChatModelConfig, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<OperationStatusGDeepseekChatModelConfig>>;
    /**
     *
     *
     * @param body
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    updateDeepseekChatModelConfig(body: GDeepseekChatModelConfig, observe?: 'body', reportProgress?: boolean): Observable<OperationStatusGDeepseekChatModelConfig>;
    updateDeepseekChatModelConfig(body: GDeepseekChatModelConfig, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<OperationStatusGDeepseekChatModelConfig>>;
    updateDeepseekChatModelConfig(body: GDeepseekChatModelConfig, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<OperationStatusGDeepseekChatModelConfig>>;
    static ɵfac: i0.ɵɵFactoryDeclaration<DeepseekChatModelsConfigurationControllerService, [null, { optional: true; }, { optional: true; }]>;
    static ɵprov: i0.ɵɵInjectableDeclaration<DeepseekChatModelsConfigurationControllerService>;
}
//# sourceMappingURL=deepseekChatModelsConfigurationController.service.d.ts.map