import { HttpClient, HttpHeaders, HttpResponse, HttpEvent } from '@angular/common/http';
import { Observable } from 'rxjs';
import { ChatInfosByQbeParam } from '../model/chatInfosByQbeParam';
import { ChatUIOptions } from '../model/chatUIOptions';
import { GLookupEntry } from '../model/gLookupEntry';
import { GUserChatInfo } from '../model/gUserChatInfo';
import { PageGUserChatInfo } from '../model/pageGUserChatInfo';
import { UserChatHistory } from '../model/userChatHistory';
import { Configuration } from '../configuration';
import * as i0 from "@angular/core";
export declare class GeboUserChatsControllerService {
    protected httpClient: HttpClient;
    protected basePath: string;
    defaultHeaders: HttpHeaders;
    configuration: Configuration;
    constructor(httpClient: HttpClient, basePath: string, configuration: Configuration);
    /**
     * @param consumes string[] mime-types
     * @return true: consumes contains 'multipart/form-data', false: otherwise
     */
    private canConsumeForm;
    /**
     *
     *
     * @param body
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    changeChatDescription(body: GLookupEntry, observe?: 'body', reportProgress?: boolean): Observable<GLookupEntry>;
    changeChatDescription(body: GLookupEntry, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<GLookupEntry>>;
    changeChatDescription(body: GLookupEntry, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<GLookupEntry>>;
    /**
     *
     *
     * @param chatProfileCode
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    createCleanChatByChatProfileCode(chatProfileCode: string, observe?: 'body', reportProgress?: boolean): Observable<GUserChatInfo>;
    createCleanChatByChatProfileCode(chatProfileCode: string, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<GUserChatInfo>>;
    createCleanChatByChatProfileCode(chatProfileCode: string, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<GUserChatInfo>>;
    /**
     *
     *
     * @param modelCode
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    createCleanChatByModelCode(modelCode: string, observe?: 'body', reportProgress?: boolean): Observable<GUserChatInfo>;
    createCleanChatByModelCode(modelCode: string, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<GUserChatInfo>>;
    createCleanChatByModelCode(modelCode: string, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<GUserChatInfo>>;
    /**
     *
     *
     * @param userChatContextCode
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    deleteChat(userChatContextCode: string, observe?: 'body', reportProgress?: boolean): Observable<any>;
    deleteChat(userChatContextCode: string, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<any>>;
    deleteChat(userChatContextCode: string, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<any>>;
    /**
     *
     *
     * @param code
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    getChatHistory(code: string, observe?: 'body', reportProgress?: boolean): Observable<UserChatHistory>;
    getChatHistory(code: string, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<UserChatHistory>>;
    getChatHistory(code: string, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<UserChatHistory>>;
    /**
     *
     *
     * @param id
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    getChatInfosByCode(id: string, observe?: 'body', reportProgress?: boolean): Observable<GUserChatInfo>;
    getChatInfosByCode(id: string, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<GUserChatInfo>>;
    getChatInfosByCode(id: string, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<GUserChatInfo>>;
    /**
     *
     *
     * @param body
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    getChatInfosByQbe(body: ChatInfosByQbeParam, observe?: 'body', reportProgress?: boolean): Observable<PageGUserChatInfo>;
    getChatInfosByQbe(body: ChatInfosByQbeParam, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<PageGUserChatInfo>>;
    getChatInfosByQbe(body: ChatInfosByQbeParam, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<PageGUserChatInfo>>;
    /**
     *
     *
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    getMyChats(observe?: 'body', reportProgress?: boolean): Observable<Array<GUserChatInfo>>;
    getMyChats(observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<Array<GUserChatInfo>>>;
    getMyChats(observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<Array<GUserChatInfo>>>;
    /**
     *
     *
     * @param page
     * @param pageSize
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    getMyChatsPaged(page: number, pageSize: number, observe?: 'body', reportProgress?: boolean): Observable<PageGUserChatInfo>;
    getMyChatsPaged(page: number, pageSize: number, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<PageGUserChatInfo>>;
    getMyChatsPaged(page: number, pageSize: number, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<PageGUserChatInfo>>;
    /**
     *
     *
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    getUIConfig(observe?: 'body', reportProgress?: boolean): Observable<ChatUIOptions>;
    getUIConfig(observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<ChatUIOptions>>;
    getUIConfig(observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<ChatUIOptions>>;
    /**
     *
     *
     * @param userChatContextCode
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    suggestChatDescription(userChatContextCode: string, observe?: 'body', reportProgress?: boolean): Observable<GUserChatInfo>;
    suggestChatDescription(userChatContextCode: string, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<GUserChatInfo>>;
    suggestChatDescription(userChatContextCode: string, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<GUserChatInfo>>;
    static ɵfac: i0.ɵɵFactoryDeclaration<GeboUserChatsControllerService, [null, { optional: true; }, { optional: true; }]>;
    static ɵprov: i0.ɵɵInjectableDeclaration<GeboUserChatsControllerService>;
}
//# sourceMappingURL=geboUserChatsController.service.d.ts.map