import { HttpClient, HttpHeaders, HttpResponse, HttpEvent } from '@angular/common/http';
import { Observable } from 'rxjs';
import { DeepSearchConfig } from '../model/deepSearchConfig';
import { GBaseObject } from '../model/gBaseObject';
import { Configuration } from '../configuration';
import * as i0 from "@angular/core";
export declare class GeboDeepSearchAdminControllerService {
    protected httpClient: HttpClient;
    protected basePath: string;
    defaultHeaders: HttpHeaders;
    configuration: Configuration;
    constructor(httpClient: HttpClient, basePath: string, configuration: Configuration);
    /**
     * @param consumes string[] mime-types
     * @return true: consumes contains 'multipart/form-data', false: otherwise
     */
    private canConsumeForm;
    /**
     *
     *
     * @param body
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    deleteDeepSearchConfig(body: DeepSearchConfig, observe?: 'body', reportProgress?: boolean): Observable<any>;
    deleteDeepSearchConfig(body: DeepSearchConfig, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<any>>;
    deleteDeepSearchConfig(body: DeepSearchConfig, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<any>>;
    /**
     *
     *
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    getConfigurableDataSources(observe?: 'body', reportProgress?: boolean): Observable<Array<GBaseObject>>;
    getConfigurableDataSources(observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<Array<GBaseObject>>>;
    getConfigurableDataSources(observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<Array<GBaseObject>>>;
    /**
     *
     *
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    getDeepSeachConfigs(observe?: 'body', reportProgress?: boolean): Observable<Array<DeepSearchConfig>>;
    getDeepSeachConfigs(observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<Array<DeepSearchConfig>>>;
    getDeepSeachConfigs(observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<Array<DeepSearchConfig>>>;
    /**
     *
     *
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    getDeepSearchDefaultConfig(observe?: 'body', reportProgress?: boolean): Observable<DeepSearchConfig>;
    getDeepSearchDefaultConfig(observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<DeepSearchConfig>>;
    getDeepSearchDefaultConfig(observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<DeepSearchConfig>>;
    /**
     *
     *
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    getDeepSearchDefaultOrSystemConfig(observe?: 'body', reportProgress?: boolean): Observable<DeepSearchConfig>;
    getDeepSearchDefaultOrSystemConfig(observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<DeepSearchConfig>>;
    getDeepSearchDefaultOrSystemConfig(observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<DeepSearchConfig>>;
    /**
     *
     *
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    getDeepSearchSystemConfig(observe?: 'body', reportProgress?: boolean): Observable<DeepSearchConfig>;
    getDeepSearchSystemConfig(observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<DeepSearchConfig>>;
    getDeepSearchSystemConfig(observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<DeepSearchConfig>>;
    /**
     *
     *
     * @param body
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    insertDeepSearchConfig(body: DeepSearchConfig, observe?: 'body', reportProgress?: boolean): Observable<DeepSearchConfig>;
    insertDeepSearchConfig(body: DeepSearchConfig, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<DeepSearchConfig>>;
    insertDeepSearchConfig(body: DeepSearchConfig, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<DeepSearchConfig>>;
    /**
     *
     *
     * @param body
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    updateDeepSearchConfig(body: DeepSearchConfig, observe?: 'body', reportProgress?: boolean): Observable<DeepSearchConfig>;
    updateDeepSearchConfig(body: DeepSearchConfig, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<DeepSearchConfig>>;
    updateDeepSearchConfig(body: DeepSearchConfig, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<DeepSearchConfig>>;
    static ɵfac: i0.ɵɵFactoryDeclaration<GeboDeepSearchAdminControllerService, [null, { optional: true; }, { optional: true; }]>;
    static ɵprov: i0.ɵɵInjectableDeclaration<GeboDeepSearchAdminControllerService>;
}
