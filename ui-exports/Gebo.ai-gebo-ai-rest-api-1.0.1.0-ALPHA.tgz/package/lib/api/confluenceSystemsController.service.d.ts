import { HttpClient, HttpHeaders, HttpResponse, HttpEvent } from '@angular/common/http';
import { Observable } from 'rxjs';
import { FastConfluenceSystemInsertRequest } from '../model/fastConfluenceSystemInsertRequest';
import { GConfluenceProjectEndpoint } from '../model/gConfluenceProjectEndpoint';
import { GConfluenceSystem } from '../model/gConfluenceSystem';
import { GContentManagementSystemType } from '../model/gContentManagementSystemType';
import { OperationStatusGConfluenceSystem } from '../model/operationStatusGConfluenceSystem';
import { Configuration } from '../configuration';
import * as i0 from "@angular/core";
export declare class ConfluenceSystemsControllerService {
    protected httpClient: HttpClient;
    protected basePath: string;
    defaultHeaders: HttpHeaders;
    configuration: Configuration;
    constructor(httpClient: HttpClient, basePath: string, configuration: Configuration);
    /**
     * @param consumes string[] mime-types
     * @return true: consumes contains 'multipart/form-data', false: otherwise
     */
    private canConsumeForm;
    /**
     *
     *
     * @param body
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    deleteConfluenceEndpoint(body: GConfluenceProjectEndpoint, observe?: 'body', reportProgress?: boolean): Observable<any>;
    deleteConfluenceEndpoint(body: GConfluenceProjectEndpoint, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<any>>;
    deleteConfluenceEndpoint(body: GConfluenceProjectEndpoint, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<any>>;
    /**
     *
     *
     * @param body
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    deleteConfluenceSystem(body: GConfluenceSystem, observe?: 'body', reportProgress?: boolean): Observable<any>;
    deleteConfluenceSystem(body: GConfluenceSystem, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<any>>;
    deleteConfluenceSystem(body: GConfluenceSystem, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<any>>;
    /**
     *
     *
     * @param body
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    fastConfluenceConfig(body: FastConfluenceSystemInsertRequest, observe?: 'body', reportProgress?: boolean): Observable<OperationStatusGConfluenceSystem>;
    fastConfluenceConfig(body: FastConfluenceSystemInsertRequest, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<OperationStatusGConfluenceSystem>>;
    fastConfluenceConfig(body: FastConfluenceSystemInsertRequest, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<OperationStatusGConfluenceSystem>>;
    /**
     *
     *
     * @param code
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    findConfluenceEndpointsByCode(code: string, observe?: 'body', reportProgress?: boolean): Observable<GConfluenceProjectEndpoint>;
    findConfluenceEndpointsByCode(code: string, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<GConfluenceProjectEndpoint>>;
    findConfluenceEndpointsByCode(code: string, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<GConfluenceProjectEndpoint>>;
    /**
     *
     *
     * @param parentProjectCode
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    findConfluenceEndpointsByProject(parentProjectCode: string, observe?: 'body', reportProgress?: boolean): Observable<Array<GConfluenceProjectEndpoint>>;
    findConfluenceEndpointsByProject(parentProjectCode: string, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<Array<GConfluenceProjectEndpoint>>>;
    findConfluenceEndpointsByProject(parentProjectCode: string, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<Array<GConfluenceProjectEndpoint>>>;
    /**
     *
     *
     * @param body
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    findConfluenceEndpointsByQbe(body: GConfluenceProjectEndpoint, observe?: 'body', reportProgress?: boolean): Observable<Array<GConfluenceProjectEndpoint>>;
    findConfluenceEndpointsByQbe(body: GConfluenceProjectEndpoint, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<Array<GConfluenceProjectEndpoint>>>;
    findConfluenceEndpointsByQbe(body: GConfluenceProjectEndpoint, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<Array<GConfluenceProjectEndpoint>>>;
    /**
     *
     *
     * @param code
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    findConfluenceSystemByCode(code: string, observe?: 'body', reportProgress?: boolean): Observable<GConfluenceSystem>;
    findConfluenceSystemByCode(code: string, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<GConfluenceSystem>>;
    findConfluenceSystemByCode(code: string, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<GConfluenceSystem>>;
    /**
     *
     *
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    getConfluenceSystemTypes(observe?: 'body', reportProgress?: boolean): Observable<GContentManagementSystemType>;
    getConfluenceSystemTypes(observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<GContentManagementSystemType>>;
    getConfluenceSystemTypes(observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<GContentManagementSystemType>>;
    /**
     *
     *
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    getConfluenceSystems(observe?: 'body', reportProgress?: boolean): Observable<Array<GConfluenceSystem>>;
    getConfluenceSystems(observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<Array<GConfluenceSystem>>>;
    getConfluenceSystems(observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<Array<GConfluenceSystem>>>;
    /**
     *
     *
     * @param body
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    insertConfluenceEndpoint(body: GConfluenceProjectEndpoint, observe?: 'body', reportProgress?: boolean): Observable<GConfluenceProjectEndpoint>;
    insertConfluenceEndpoint(body: GConfluenceProjectEndpoint, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<GConfluenceProjectEndpoint>>;
    insertConfluenceEndpoint(body: GConfluenceProjectEndpoint, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<GConfluenceProjectEndpoint>>;
    /**
     *
     *
     * @param body
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    insertConfluenceSystem(body: GConfluenceSystem, observe?: 'body', reportProgress?: boolean): Observable<OperationStatusGConfluenceSystem>;
    insertConfluenceSystem(body: GConfluenceSystem, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<OperationStatusGConfluenceSystem>>;
    insertConfluenceSystem(body: GConfluenceSystem, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<OperationStatusGConfluenceSystem>>;
    /**
     *
     *
     * @param body
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    testConfluenceSystem(body: GConfluenceSystem, observe?: 'body', reportProgress?: boolean): Observable<OperationStatusGConfluenceSystem>;
    testConfluenceSystem(body: GConfluenceSystem, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<OperationStatusGConfluenceSystem>>;
    testConfluenceSystem(body: GConfluenceSystem, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<OperationStatusGConfluenceSystem>>;
    /**
     *
     *
     * @param body
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    updateConfluenceEndpoint(body: GConfluenceProjectEndpoint, observe?: 'body', reportProgress?: boolean): Observable<GConfluenceProjectEndpoint>;
    updateConfluenceEndpoint(body: GConfluenceProjectEndpoint, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<GConfluenceProjectEndpoint>>;
    updateConfluenceEndpoint(body: GConfluenceProjectEndpoint, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<GConfluenceProjectEndpoint>>;
    /**
     *
     *
     * @param body
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    updateConfluenceSystem(body: GConfluenceSystem, observe?: 'body', reportProgress?: boolean): Observable<OperationStatusGConfluenceSystem>;
    updateConfluenceSystem(body: GConfluenceSystem, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<OperationStatusGConfluenceSystem>>;
    updateConfluenceSystem(body: GConfluenceSystem, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<OperationStatusGConfluenceSystem>>;
    static ɵfac: i0.ɵɵFactoryDeclaration<ConfluenceSystemsControllerService, [null, { optional: true; }, { optional: true; }]>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ConfluenceSystemsControllerService>;
}
