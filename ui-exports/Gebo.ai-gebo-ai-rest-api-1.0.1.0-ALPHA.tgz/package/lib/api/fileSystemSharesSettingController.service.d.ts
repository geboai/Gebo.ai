import { HttpClient, HttpHeaders, HttpResponse, HttpEvent } from '@angular/common/http';
import { Observable } from 'rxjs';
import { BrowseParam } from '../model/browseParam';
import { FSReference } from '../model/fSReference';
import { GFileSystemShareReference } from '../model/gFileSystemShareReference';
import { OperationStatusGFileSystemShareReference } from '../model/operationStatusGFileSystemShareReference';
import { OperationStatusListGVirtualFilesystemRoot } from '../model/operationStatusListGVirtualFilesystemRoot';
import { OperationStatusListPathInfo } from '../model/operationStatusListPathInfo';
import { OperationStatusListVirtualFilesystemNavigationTreeStatus } from '../model/operationStatusListVirtualFilesystemNavigationTreeStatus';
import { SharedFilesystemUIConfig } from '../model/sharedFilesystemUIConfig';
import { VFilesystemReference } from '../model/vFilesystemReference';
import { Configuration } from '../configuration';
import * as i0 from "@angular/core";
export declare class FileSystemSharesSettingControllerService {
    protected httpClient: HttpClient;
    protected basePath: string;
    defaultHeaders: HttpHeaders;
    configuration: Configuration;
    constructor(httpClient: HttpClient, basePath: string, configuration: Configuration);
    /**
     * @param consumes string[] mime-types
     * @return true: consumes contains 'multipart/form-data', false: otherwise
     */
    private canConsumeForm;
    /**
     *
     *
     * @param body
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    checkCanBeInsertedFileSystemShareReference(body: GFileSystemShareReference, observe?: 'body', reportProgress?: boolean): Observable<OperationStatusGFileSystemShareReference>;
    checkCanBeInsertedFileSystemShareReference(body: GFileSystemShareReference, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<OperationStatusGFileSystemShareReference>>;
    checkCanBeInsertedFileSystemShareReference(body: GFileSystemShareReference, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<OperationStatusGFileSystemShareReference>>;
    /**
     *
     *
     * @param body
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    deleteFileSystemShareReference(body: GFileSystemShareReference, observe?: 'body', reportProgress?: boolean): Observable<any>;
    deleteFileSystemShareReference(body: GFileSystemShareReference, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<any>>;
    deleteFileSystemShareReference(body: GFileSystemShareReference, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<any>>;
    /**
     *
     *
     * @param code
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    getFileSystemShareReferenceByCode(code: string, observe?: 'body', reportProgress?: boolean): Observable<GFileSystemShareReference>;
    getFileSystemShareReferenceByCode(code: string, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<GFileSystemShareReference>>;
    getFileSystemShareReferenceByCode(code: string, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<GFileSystemShareReference>>;
    /**
     *
     *
     * @param body
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    getGFileSystemNodeChildrens(body: BrowseParam, observe?: 'body', reportProgress?: boolean): Observable<OperationStatusListPathInfo>;
    getGFileSystemNodeChildrens(body: BrowseParam, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<OperationStatusListPathInfo>>;
    getGFileSystemNodeChildrens(body: BrowseParam, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<OperationStatusListPathInfo>>;
    /**
     *
     *
     * @param body
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    getGFileSystemNodeNavigationStatus(body: Array<VFilesystemReference>, observe?: 'body', reportProgress?: boolean): Observable<OperationStatusListVirtualFilesystemNavigationTreeStatus>;
    getGFileSystemNodeNavigationStatus(body: Array<VFilesystemReference>, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<OperationStatusListVirtualFilesystemNavigationTreeStatus>>;
    getGFileSystemNodeNavigationStatus(body: Array<VFilesystemReference>, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<OperationStatusListVirtualFilesystemNavigationTreeStatus>>;
    /**
     *
     *
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    getRootGFileSystemNodes(observe?: 'body', reportProgress?: boolean): Observable<OperationStatusListGVirtualFilesystemRoot>;
    getRootGFileSystemNodes(observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<OperationStatusListGVirtualFilesystemRoot>>;
    getRootGFileSystemNodes(observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<OperationStatusListGVirtualFilesystemRoot>>;
    /**
     *
     *
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    getSharedFileSystemsActualConfiguration(observe?: 'body', reportProgress?: boolean): Observable<SharedFilesystemUIConfig>;
    getSharedFileSystemsActualConfiguration(observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<SharedFilesystemUIConfig>>;
    getSharedFileSystemsActualConfiguration(observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<SharedFilesystemUIConfig>>;
    /**
     *
     *
     * @param body
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    getUsedFilesystemShares(body: Array<string>, observe?: 'body', reportProgress?: boolean): Observable<Array<FSReference>>;
    getUsedFilesystemShares(body: Array<string>, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<Array<FSReference>>>;
    getUsedFilesystemShares(body: Array<string>, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<Array<FSReference>>>;
    /**
     *
     *
     * @param body
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    insertFileSystemShareReference(body: GFileSystemShareReference, observe?: 'body', reportProgress?: boolean): Observable<GFileSystemShareReference>;
    insertFileSystemShareReference(body: GFileSystemShareReference, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<GFileSystemShareReference>>;
    insertFileSystemShareReference(body: GFileSystemShareReference, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<GFileSystemShareReference>>;
    static ɵfac: i0.ɵɵFactoryDeclaration<FileSystemSharesSettingControllerService, [null, { optional: true; }, { optional: true; }]>;
    static ɵprov: i0.ɵɵInjectableDeclaration<FileSystemSharesSettingControllerService>;
}
//# sourceMappingURL=fileSystemSharesSettingController.service.d.ts.map