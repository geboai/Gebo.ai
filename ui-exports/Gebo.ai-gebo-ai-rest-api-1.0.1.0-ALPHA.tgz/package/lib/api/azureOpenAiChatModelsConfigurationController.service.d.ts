import { HttpClient, HttpHeaders, HttpResponse, HttpEvent } from '@angular/common/http';
import { Observable } from 'rxjs';
import { GAzureOpenAIChatModelConfig } from '../model/gAzureOpenAIChatModelConfig';
import { OperationStatusBoolean } from '../model/operationStatusBoolean';
import { OperationStatusGAzureOpenAIChatModelConfig } from '../model/operationStatusGAzureOpenAIChatModelConfig';
import { OperationStatusListGAzureOpenAIChatModelChoice } from '../model/operationStatusListGAzureOpenAIChatModelChoice';
import { Configuration } from '../configuration';
import * as i0 from "@angular/core";
export declare class AzureOpenAiChatModelsConfigurationControllerService {
    protected httpClient: HttpClient;
    protected basePath: string;
    defaultHeaders: HttpHeaders;
    configuration: Configuration;
    constructor(httpClient: HttpClient, basePath: string, configuration: Configuration);
    /**
     * @param consumes string[] mime-types
     * @return true: consumes contains 'multipart/form-data', false: otherwise
     */
    private canConsumeForm;
    /**
     *
     *
     * @param body
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    deleteAzureOpenAIChatModelConfig(body: GAzureOpenAIChatModelConfig, observe?: 'body', reportProgress?: boolean): Observable<OperationStatusBoolean>;
    deleteAzureOpenAIChatModelConfig(body: GAzureOpenAIChatModelConfig, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<OperationStatusBoolean>>;
    deleteAzureOpenAIChatModelConfig(body: GAzureOpenAIChatModelConfig, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<OperationStatusBoolean>>;
    /**
     *
     *
     * @param code
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    findAzureOpenAIChatModelConfigByCode(code: string, observe?: 'body', reportProgress?: boolean): Observable<GAzureOpenAIChatModelConfig>;
    findAzureOpenAIChatModelConfigByCode(code: string, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<GAzureOpenAIChatModelConfig>>;
    findAzureOpenAIChatModelConfigByCode(code: string, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<GAzureOpenAIChatModelConfig>>;
    /**
     *
     *
     * @param body
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    getAzureOpenAIChatModels(body: GAzureOpenAIChatModelConfig, observe?: 'body', reportProgress?: boolean): Observable<OperationStatusListGAzureOpenAIChatModelChoice>;
    getAzureOpenAIChatModels(body: GAzureOpenAIChatModelConfig, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<OperationStatusListGAzureOpenAIChatModelChoice>>;
    getAzureOpenAIChatModels(body: GAzureOpenAIChatModelConfig, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<OperationStatusListGAzureOpenAIChatModelChoice>>;
    /**
     *
     *
     * @param body
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    insertAzureOpenAIChatModelConfig(body: GAzureOpenAIChatModelConfig, observe?: 'body', reportProgress?: boolean): Observable<OperationStatusGAzureOpenAIChatModelConfig>;
    insertAzureOpenAIChatModelConfig(body: GAzureOpenAIChatModelConfig, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<OperationStatusGAzureOpenAIChatModelConfig>>;
    insertAzureOpenAIChatModelConfig(body: GAzureOpenAIChatModelConfig, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<OperationStatusGAzureOpenAIChatModelConfig>>;
    /**
     *
     *
     * @param body
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    updateAzureOpenAIChatModelConfig(body: GAzureOpenAIChatModelConfig, observe?: 'body', reportProgress?: boolean): Observable<OperationStatusGAzureOpenAIChatModelConfig>;
    updateAzureOpenAIChatModelConfig(body: GAzureOpenAIChatModelConfig, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<OperationStatusGAzureOpenAIChatModelConfig>>;
    updateAzureOpenAIChatModelConfig(body: GAzureOpenAIChatModelConfig, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<OperationStatusGAzureOpenAIChatModelConfig>>;
    static ɵfac: i0.ɵɵFactoryDeclaration<AzureOpenAiChatModelsConfigurationControllerService, [null, { optional: true; }, { optional: true; }]>;
    static ɵprov: i0.ɵɵInjectableDeclaration<AzureOpenAiChatModelsConfigurationControllerService>;
}
