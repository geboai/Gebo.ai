import { HttpClient, HttpHeaders, HttpResponse, HttpEvent } from '@angular/common/http';
import { Observable } from 'rxjs';
import { GAnthropicChatModelConfig } from '../model/gAnthropicChatModelConfig';
import { OperationStatusBoolean } from '../model/operationStatusBoolean';
import { OperationStatusGAnthropicChatModelConfig } from '../model/operationStatusGAnthropicChatModelConfig';
import { OperationStatusListGAnthropicChatModelChoice } from '../model/operationStatusListGAnthropicChatModelChoice';
import { Configuration } from '../configuration';
import * as i0 from "@angular/core";
export declare class AnthropicChatModelsConfigurationControllerService {
    protected httpClient: HttpClient;
    protected basePath: string;
    defaultHeaders: HttpHeaders;
    configuration: Configuration;
    constructor(httpClient: HttpClient, basePath: string, configuration: Configuration);
    /**
     * @param consumes string[] mime-types
     * @return true: consumes contains 'multipart/form-data', false: otherwise
     */
    private canConsumeForm;
    /**
     *
     *
     * @param body
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    deleteAnthropicChatModelConfig(body: GAnthropicChatModelConfig, observe?: 'body', reportProgress?: boolean): Observable<OperationStatusBoolean>;
    deleteAnthropicChatModelConfig(body: GAnthropicChatModelConfig, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<OperationStatusBoolean>>;
    deleteAnthropicChatModelConfig(body: GAnthropicChatModelConfig, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<OperationStatusBoolean>>;
    /**
     *
     *
     * @param code
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    findAnthropicChatModelConfigByCode(code: string, observe?: 'body', reportProgress?: boolean): Observable<GAnthropicChatModelConfig>;
    findAnthropicChatModelConfigByCode(code: string, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<GAnthropicChatModelConfig>>;
    findAnthropicChatModelConfigByCode(code: string, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<GAnthropicChatModelConfig>>;
    /**
     *
     *
     * @param body
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    getAnthropicChatModels(body: GAnthropicChatModelConfig, observe?: 'body', reportProgress?: boolean): Observable<OperationStatusListGAnthropicChatModelChoice>;
    getAnthropicChatModels(body: GAnthropicChatModelConfig, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<OperationStatusListGAnthropicChatModelChoice>>;
    getAnthropicChatModels(body: GAnthropicChatModelConfig, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<OperationStatusListGAnthropicChatModelChoice>>;
    /**
     *
     *
     * @param body
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    insertAnthropicChatModelConfig(body: GAnthropicChatModelConfig, observe?: 'body', reportProgress?: boolean): Observable<OperationStatusGAnthropicChatModelConfig>;
    insertAnthropicChatModelConfig(body: GAnthropicChatModelConfig, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<OperationStatusGAnthropicChatModelConfig>>;
    insertAnthropicChatModelConfig(body: GAnthropicChatModelConfig, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<OperationStatusGAnthropicChatModelConfig>>;
    /**
     *
     *
     * @param body
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    updateAnthropicChatModelConfig(body: GAnthropicChatModelConfig, observe?: 'body', reportProgress?: boolean): Observable<OperationStatusGAnthropicChatModelConfig>;
    updateAnthropicChatModelConfig(body: GAnthropicChatModelConfig, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<OperationStatusGAnthropicChatModelConfig>>;
    updateAnthropicChatModelConfig(body: GAnthropicChatModelConfig, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<OperationStatusGAnthropicChatModelConfig>>;
    static ɵfac: i0.ɵɵFactoryDeclaration<AnthropicChatModelsConfigurationControllerService, [null, { optional: true; }, { optional: true; }]>;
    static ɵprov: i0.ɵɵInjectableDeclaration<AnthropicChatModelsConfigurationControllerService>;
}
//# sourceMappingURL=anthropicChatModelsConfigurationController.service.d.ts.map