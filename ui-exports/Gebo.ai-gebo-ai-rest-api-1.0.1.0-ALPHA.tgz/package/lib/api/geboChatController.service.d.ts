import { HttpClient, HttpHeaders, HttpResponse, HttpEvent } from '@angular/common/http';
import { Observable } from 'rxjs';
import { GBaseChatModelChoice } from '../model/gBaseChatModelChoice';
import { GBaseObject } from '../model/gBaseObject';
import { GeboChatRequest } from '../model/geboChatRequest';
import { GeboChatResponse } from '../model/geboChatResponse';
import { GeboChatUserInfo } from '../model/geboChatUserInfo';
import { ModelProviderCapabilities } from '../model/modelProviderCapabilities';
import { ServerSentEventString } from '../model/serverSentEventString';
import { SpeechRequest } from '../model/speechRequest';
import { TranscriptResponse } from '../model/transcriptResponse';
import { Configuration } from '../configuration';
import * as i0 from "@angular/core";
export declare class GeboChatControllerService {
    protected httpClient: HttpClient;
    protected basePath: string;
    defaultHeaders: HttpHeaders;
    configuration: Configuration;
    constructor(httpClient: HttpClient, basePath: string, configuration: Configuration);
    /**
     * @param consumes string[] mime-types
     * @return true: consumes contains 'multipart/form-data', false: otherwise
     */
    private canConsumeForm;
    /**
     *
     *
     * @param body
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    chat(body: GeboChatRequest, observe?: 'body', reportProgress?: boolean): Observable<GeboChatResponse>;
    chat(body: GeboChatRequest, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<GeboChatResponse>>;
    chat(body: GeboChatRequest, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<GeboChatResponse>>;
    /**
     *
     *
     * @param modelCode
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    getChatModelMetaInfos(modelCode: string, observe?: 'body', reportProgress?: boolean): Observable<GBaseChatModelChoice>;
    getChatModelMetaInfos(modelCode: string, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<GBaseChatModelChoice>>;
    getChatModelMetaInfos(modelCode: string, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<GBaseChatModelChoice>>;
    /**
     *
     *
     * @param modelCode
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    getChatModelUserInfo(modelCode: string, observe?: 'body', reportProgress?: boolean): Observable<GeboChatUserInfo>;
    getChatModelUserInfo(modelCode: string, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<GeboChatUserInfo>>;
    getChatModelUserInfo(modelCode: string, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<GeboChatUserInfo>>;
    /**
     *
     *
     * @param modelCode
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    getProviderCapabilities(modelCode: string, observe?: 'body', reportProgress?: boolean): Observable<ModelProviderCapabilities>;
    getProviderCapabilities(modelCode: string, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<ModelProviderCapabilities>>;
    getProviderCapabilities(modelCode: string, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<ModelProviderCapabilities>>;
    /**
     *
     *
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    getVisibleKnowledgeBases(observe?: 'body', reportProgress?: boolean): Observable<Array<GBaseObject>>;
    getVisibleKnowledgeBases(observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<Array<GBaseObject>>>;
    getVisibleKnowledgeBases(observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<Array<GBaseObject>>>;
    /**
     *
     *
     * @param body
     * @param modelCode
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    speechText(body: SpeechRequest, modelCode: string, observe?: 'body', reportProgress?: boolean): Observable<Blob>;
    speechText(body: SpeechRequest, modelCode: string, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<Blob>>;
    speechText(body: SpeechRequest, modelCode: string, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<Blob>>;
    /**
     *
     *
     * @param body
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    streamResponse(body: GeboChatRequest, observe?: 'body', reportProgress?: boolean): Observable<Array<ServerSentEventString>>;
    streamResponse(body: GeboChatRequest, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<Array<ServerSentEventString>>>;
    streamResponse(body: GeboChatRequest, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<Array<ServerSentEventString>>>;
    /**
     *
     *
     * @param modelCode
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    transcriptText(modelCode: string, observe?: 'body', reportProgress?: boolean): Observable<TranscriptResponse>;
    transcriptText(modelCode: string, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<TranscriptResponse>>;
    transcriptText(modelCode: string, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<TranscriptResponse>>;
    static ɵfac: i0.ɵɵFactoryDeclaration<GeboChatControllerService, [null, { optional: true; }, { optional: true; }]>;
    static ɵprov: i0.ɵɵInjectableDeclaration<GeboChatControllerService>;
}
//# sourceMappingURL=geboChatController.service.d.ts.map