import { HttpClient, HttpHeaders, HttpResponse, HttpEvent } from '@angular/common/http';
import { Observable } from 'rxjs';
import { ComponentVectorStoreStatus } from '../model/componentVectorStoreStatus';
import { FastVectorStoreSetupData } from '../model/fastVectorStoreSetupData';
import { OperationStatusComponentVectorStoreStatus } from '../model/operationStatusComponentVectorStoreStatus';
import { Configuration } from '../configuration';
import * as i0 from "@angular/core";
export declare class GeboFastVectorStoreSetupControllerService {
    protected httpClient: HttpClient;
    protected basePath: string;
    defaultHeaders: HttpHeaders;
    configuration: Configuration;
    constructor(httpClient: HttpClient, basePath: string, configuration: Configuration);
    /**
     * @param consumes string[] mime-types
     * @return true: consumes contains 'multipart/form-data', false: otherwise
     */
    private canConsumeForm;
    /**
     *
     *
     * @param body
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    createVectorStoreConfiguration(body: FastVectorStoreSetupData, observe?: 'body', reportProgress?: boolean): Observable<OperationStatusComponentVectorStoreStatus>;
    createVectorStoreConfiguration(body: FastVectorStoreSetupData, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<OperationStatusComponentVectorStoreStatus>>;
    createVectorStoreConfiguration(body: FastVectorStoreSetupData, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<OperationStatusComponentVectorStoreStatus>>;
    /**
     *
     *
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    getVectorStoreStatus(observe?: 'body', reportProgress?: boolean): Observable<ComponentVectorStoreStatus>;
    getVectorStoreStatus(observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<ComponentVectorStoreStatus>>;
    getVectorStoreStatus(observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<ComponentVectorStoreStatus>>;
    static ɵfac: i0.ɵɵFactoryDeclaration<GeboFastVectorStoreSetupControllerService, [null, { optional: true; }, { optional: true; }]>;
    static ɵprov: i0.ɵɵInjectableDeclaration<GeboFastVectorStoreSetupControllerService>;
}
