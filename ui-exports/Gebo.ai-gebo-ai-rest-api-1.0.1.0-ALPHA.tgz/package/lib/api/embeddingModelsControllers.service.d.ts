import { HttpClient, HttpHeaders, HttpResponse, HttpEvent } from '@angular/common/http';
import { Observable } from 'rxjs';
import { ConfigurationEntry } from '../model/configurationEntry';
import { GEmbeddingModelType } from '../model/gEmbeddingModelType';
import { Configuration } from '../configuration';
import * as i0 from "@angular/core";
export declare class EmbeddingModelsControllersService {
    protected httpClient: HttpClient;
    protected basePath: string;
    defaultHeaders: HttpHeaders;
    configuration: Configuration;
    constructor(httpClient: HttpClient, basePath: string, configuration: Configuration);
    /**
     * @param consumes string[] mime-types
     * @return true: consumes contains 'multipart/form-data', false: otherwise
     */
    private canConsumeForm;
    /**
     *
     *
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    getEmbeddingModelTypes(observe?: 'body', reportProgress?: boolean): Observable<Array<GEmbeddingModelType>>;
    getEmbeddingModelTypes(observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<Array<GEmbeddingModelType>>>;
    getEmbeddingModelTypes(observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<Array<GEmbeddingModelType>>>;
    /**
     *
     *
     * @param modelTypeCode
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    getRuntimeConfiguredEmbeddingModels(modelTypeCode?: string, observe?: 'body', reportProgress?: boolean): Observable<Array<ConfigurationEntry>>;
    getRuntimeConfiguredEmbeddingModels(modelTypeCode?: string, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<Array<ConfigurationEntry>>>;
    getRuntimeConfiguredEmbeddingModels(modelTypeCode?: string, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<Array<ConfigurationEntry>>>;
    static ɵfac: i0.ɵɵFactoryDeclaration<EmbeddingModelsControllersService, [null, { optional: true; }, { optional: true; }]>;
    static ɵprov: i0.ɵɵInjectableDeclaration<EmbeddingModelsControllersService>;
}
//# sourceMappingURL=embeddingModelsControllers.service.d.ts.map