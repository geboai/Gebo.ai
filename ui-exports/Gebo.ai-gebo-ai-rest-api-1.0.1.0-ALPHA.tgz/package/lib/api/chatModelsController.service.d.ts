import { HttpClient, HttpHeaders, HttpResponse, HttpEvent } from '@angular/common/http';
import { Observable } from 'rxjs';
import { ConfigurationEntry } from '../model/configurationEntry';
import { GChatModelType } from '../model/gChatModelType';
import { Configuration } from '../configuration';
import * as i0 from "@angular/core";
export declare class ChatModelsControllerService {
    protected httpClient: HttpClient;
    protected basePath: string;
    defaultHeaders: HttpHeaders;
    configuration: Configuration;
    constructor(httpClient: HttpClient, basePath: string, configuration: Configuration);
    /**
     * @param consumes string[] mime-types
     * @return true: consumes contains 'multipart/form-data', false: otherwise
     */
    private canConsumeForm;
    /**
     *
     *
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    getChatModelTypes(observe?: 'body', reportProgress?: boolean): Observable<Array<GChatModelType>>;
    getChatModelTypes(observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<Array<GChatModelType>>>;
    getChatModelTypes(observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<Array<GChatModelType>>>;
    /**
     *
     *
     * @param modelTypeCode
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    getRuntimeConfiguredChatModels(modelTypeCode?: string, observe?: 'body', reportProgress?: boolean): Observable<Array<ConfigurationEntry>>;
    getRuntimeConfiguredChatModels(modelTypeCode?: string, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<Array<ConfigurationEntry>>>;
    getRuntimeConfiguredChatModels(modelTypeCode?: string, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<Array<ConfigurationEntry>>>;
    static ɵfac: i0.ɵɵFactoryDeclaration<ChatModelsControllerService, [null, { optional: true; }, { optional: true; }]>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ChatModelsControllerService>;
}
//# sourceMappingURL=chatModelsController.service.d.ts.map