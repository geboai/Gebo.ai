import { HttpClient, HttpHeaders, HttpResponse, HttpEvent } from '@angular/common/http';
import { Observable } from 'rxjs';
import { FastInstallationSetupData } from '../model/fastInstallationSetupData';
import { OperationStatusBoolean } from '../model/operationStatusBoolean';
import { Configuration } from '../configuration';
import * as i0 from "@angular/core";
export declare class GeboFastInstallationSetupControllerService {
    protected httpClient: HttpClient;
    protected basePath: string;
    defaultHeaders: HttpHeaders;
    configuration: Configuration;
    constructor(httpClient: HttpClient, basePath: string, configuration: Configuration);
    /**
     * @param consumes string[] mime-types
     * @return true: consumes contains 'multipart/form-data', false: otherwise
     */
    private canConsumeForm;
    /**
     *
     *
     * @param body
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    createSetup(body: FastInstallationSetupData, observe?: 'body', reportProgress?: boolean): Observable<OperationStatusBoolean>;
    createSetup(body: FastInstallationSetupData, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<OperationStatusBoolean>>;
    createSetup(body: FastInstallationSetupData, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<OperationStatusBoolean>>;
    /**
     *
     *
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    getInstallationStatus(observe?: 'body', reportProgress?: boolean): Observable<OperationStatusBoolean>;
    getInstallationStatus(observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<OperationStatusBoolean>>;
    getInstallationStatus(observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<OperationStatusBoolean>>;
    static ɵfac: i0.ɵɵFactoryDeclaration<GeboFastInstallationSetupControllerService, [null, { optional: true; }, { optional: true; }]>;
    static ɵprov: i0.ɵɵInjectableDeclaration<GeboFastInstallationSetupControllerService>;
}
