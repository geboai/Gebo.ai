import { HttpClient, HttpHeaders, HttpResponse, HttpEvent } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Configuration } from '../configuration';
import * as i0 from "@angular/core";
export declare class GeboLlmGeneratedResourceControllerService {
    protected httpClient: HttpClient;
    protected basePath: string;
    defaultHeaders: HttpHeaders;
    configuration: Configuration;
    constructor(httpClient: HttpClient, basePath: string, configuration: Configuration);
    /**
     * @param consumes string[] mime-types
     * @return true: consumes contains 'multipart/form-data', false: otherwise
     */
    private canConsumeForm;
    /**
     *
     *
     * @param userSessionCode
     * @param generatedResourceCode
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    serveLLMGeneratedContent(userSessionCode: string, generatedResourceCode: string, observe?: 'body', reportProgress?: boolean): Observable<any>;
    serveLLMGeneratedContent(userSessionCode: string, generatedResourceCode: string, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<any>>;
    serveLLMGeneratedContent(userSessionCode: string, generatedResourceCode: string, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<any>>;
    static ɵfac: i0.ɵɵFactoryDeclaration<GeboLlmGeneratedResourceControllerService, [null, { optional: true; }, { optional: true; }]>;
    static ɵprov: i0.ɵɵInjectableDeclaration<GeboLlmGeneratedResourceControllerService>;
}
