import { HttpClient, HttpHeaders, HttpResponse, HttpEvent } from '@angular/common/http';
import { Observable } from 'rxjs';
import { AuthProviderDto } from '../model/authProviderDto';
import { Oauth2ClientAuthorizativeInfo } from '../model/oauth2ClientAuthorizativeInfo';
import { Oauth2ClientConfig } from '../model/oauth2ClientConfig';
import { Configuration } from '../configuration';
import * as i0 from "@angular/core";
export declare class AuthProvidersControllerService {
    protected httpClient: HttpClient;
    protected basePath: string;
    defaultHeaders: HttpHeaders;
    configuration: Configuration;
    constructor(httpClient: HttpClient, basePath: string, configuration: Configuration);
    /**
     * @param consumes string[] mime-types
     * @return true: consumes contains 'multipart/form-data', false: otherwise
     */
    private canConsumeForm;
    /**
     *
     *
     * @param registrationId
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    getProviderClientConfig(registrationId: string, observe?: 'body', reportProgress?: boolean): Observable<Oauth2ClientConfig>;
    getProviderClientConfig(registrationId: string, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<Oauth2ClientConfig>>;
    getProviderClientConfig(registrationId: string, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<Oauth2ClientConfig>>;
    /**
     *
     *
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    listAuthProviders(observe?: 'body', reportProgress?: boolean): Observable<Array<AuthProviderDto>>;
    listAuthProviders(observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<Array<AuthProviderDto>>>;
    listAuthProviders(observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<Array<AuthProviderDto>>>;
    /**
     *
     *
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    listAvailableProvidersConfig(observe?: 'body', reportProgress?: boolean): Observable<Array<Oauth2ClientAuthorizativeInfo>>;
    listAvailableProvidersConfig(observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<Array<Oauth2ClientAuthorizativeInfo>>>;
    listAvailableProvidersConfig(observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<Array<Oauth2ClientAuthorizativeInfo>>>;
    static ɵfac: i0.ɵɵFactoryDeclaration<AuthProvidersControllerService, [null, { optional: true; }, { optional: true; }]>;
    static ɵprov: i0.ɵɵInjectableDeclaration<AuthProvidersControllerService>;
}
//# sourceMappingURL=authProvidersController.service.d.ts.map