import { HttpClient, HttpHeaders, HttpResponse, HttpEvent } from '@angular/common/http';
import { Observable } from 'rxjs';
import { GAgentConfig } from '../model/gAgentConfig';
import { GBaseObject } from '../model/gBaseObject';
import { GPromptTemplateConfig } from '../model/gPromptTemplateConfig';
import { Configuration } from '../configuration';
import * as i0 from "@angular/core";
export declare class GeboAgentAdminControllerService {
    protected httpClient: HttpClient;
    protected basePath: string;
    defaultHeaders: HttpHeaders;
    configuration: Configuration;
    constructor(httpClient: HttpClient, basePath: string, configuration: Configuration);
    /**
     * @param consumes string[] mime-types
     * @return true: consumes contains 'multipart/form-data', false: otherwise
     */
    private canConsumeForm;
    /**
     *
     *
     * @param body
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    deleteAgent(body: GAgentConfig, observe?: 'body', reportProgress?: boolean): Observable<any>;
    deleteAgent(body: GAgentConfig, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<any>>;
    deleteAgent(body: GAgentConfig, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<any>>;
    /**
     *
     *
     * @param code
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    getAgentByCode(code: string, observe?: 'body', reportProgress?: boolean): Observable<GAgentConfig>;
    getAgentByCode(code: string, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<GAgentConfig>>;
    getAgentByCode(code: string, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<GAgentConfig>>;
    /**
     *
     *
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    getAgentsChoices(observe?: 'body', reportProgress?: boolean): Observable<Array<GBaseObject>>;
    getAgentsChoices(observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<Array<GBaseObject>>>;
    getAgentsChoices(observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<Array<GBaseObject>>>;
    /**
     *
     *
     * @param agentId
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    getPromptTemplatesByAgentId(agentId: string, observe?: 'body', reportProgress?: boolean): Observable<Array<GPromptTemplateConfig>>;
    getPromptTemplatesByAgentId(agentId: string, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<Array<GPromptTemplateConfig>>>;
    getPromptTemplatesByAgentId(agentId: string, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<Array<GPromptTemplateConfig>>>;
    /**
     *
     *
     * @param body
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    insertAgent(body: GAgentConfig, observe?: 'body', reportProgress?: boolean): Observable<GAgentConfig>;
    insertAgent(body: GAgentConfig, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<GAgentConfig>>;
    insertAgent(body: GAgentConfig, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<GAgentConfig>>;
    /**
     *
     *
     * @param body
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    updateAgent(body: GAgentConfig, observe?: 'body', reportProgress?: boolean): Observable<GAgentConfig>;
    updateAgent(body: GAgentConfig, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<GAgentConfig>>;
    updateAgent(body: GAgentConfig, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<GAgentConfig>>;
    static ɵfac: i0.ɵɵFactoryDeclaration<GeboAgentAdminControllerService, [null, { optional: true; }, { optional: true; }]>;
    static ɵprov: i0.ɵɵInjectableDeclaration<GeboAgentAdminControllerService>;
}
