import { HttpClient, HttpHeaders, HttpResponse, HttpEvent } from '@angular/common/http';
import { Observable } from 'rxjs';
import { GeboModuleInfo } from '../model/geboModuleInfo';
import { Configuration } from '../configuration';
import * as i0 from "@angular/core";
export declare class GeboModulesConfigControllerService {
    protected httpClient: HttpClient;
    protected basePath: string;
    defaultHeaders: HttpHeaders;
    configuration: Configuration;
    constructor(httpClient: HttpClient, basePath: string, configuration: Configuration);
    /**
     * @param consumes string[] mime-types
     * @return true: consumes contains 'multipart/form-data', false: otherwise
     */
    private canConsumeForm;
    /**
     *
     *
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    getAllModules(observe?: 'body', reportProgress?: boolean): Observable<Array<GeboModuleInfo>>;
    getAllModules(observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<Array<GeboModuleInfo>>>;
    getAllModules(observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<Array<GeboModuleInfo>>>;
    /**
     *
     *
     * @param moduleId
     * @param observe set whether or not to return the data Observable as the body, response or events. defaults to returning the body.
     * @param reportProgress flag to report request and response progress.
     */
    getModuleInfo(moduleId: string, observe?: 'body', reportProgress?: boolean): Observable<GeboModuleInfo>;
    getModuleInfo(moduleId: string, observe?: 'response', reportProgress?: boolean): Observable<HttpResponse<GeboModuleInfo>>;
    getModuleInfo(moduleId: string, observe?: 'events', reportProgress?: boolean): Observable<HttpEvent<GeboModuleInfo>>;
    static ɵfac: i0.ɵɵFactoryDeclaration<GeboModulesConfigControllerService, [null, { optional: true; }, { optional: true; }]>;
    static ɵprov: i0.ɵɵInjectableDeclaration<GeboModulesConfigControllerService>;
}
