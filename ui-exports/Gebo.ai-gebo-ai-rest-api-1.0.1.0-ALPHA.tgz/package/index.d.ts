/**
 * Generated bundle index. Do not edit.
 */
/// <amd-module name="@Gebo.ai/gebo-ai-rest-api" />
export * from './public-api';
