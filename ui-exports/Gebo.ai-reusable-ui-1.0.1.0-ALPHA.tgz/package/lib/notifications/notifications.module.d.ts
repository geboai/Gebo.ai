import { ModuleWithProviders } from "@angular/core";
import * as i0 from "@angular/core";
import * as i1 from "./notification.component";
import * as i2 from "./display-messages.component";
import * as i3 from "@angular/common";
import * as i4 from "../controls/field-translation-container/field-container.module";
import * as i5 from "primeng/toast";
export declare class GeboAINotificationsModule {
    static forRoot(): ModuleWithProviders<GeboAINotificationsModule>;
    static ɵfac: i0.ɵɵFactoryDeclaration<GeboAINotificationsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<GeboAINotificationsModule, [typeof i1.GeboAINotificationComponent, typeof i2.GeboAIDisplayMessagesComponent], [typeof i3.CommonModule, typeof i4.GeboAIFieldTranslationContainerModule, typeof i5.ToastModule], [typeof i1.GeboAINotificationComponent, typeof i2.GeboAIDisplayMessagesComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<GeboAINotificationsModule>;
}
