import { GUserMessage } from "@Gebo.ai/gebo-ai-rest-api";
import { MessageService, ToastMessageOptions } from "primeng/api";
import { GeboAITranslationService } from "../controls/field-translation-container/gebo-translation.service";
import { ToastZIndexService } from "./toast-z-index.service";
import { NotificationLayerEnum } from "./notification-layer";
import * as i0 from "@angular/core";
export declare class GeboAIRootNotificationService {
    private messageService;
    private geboAiTranslationService;
    private zIndexService;
    constructor(messageService: MessageService, geboAiTranslationService: GeboAITranslationService, zIndexService: ToastZIndexService);
    layersComputing(): void;
    addMessage(moduleId: string, entityId: string, msg: GUserMessage | ToastMessageOptions, layer?: NotificationLayerEnum): void;
    addMessages(moduleId: string, entityId: string, msg: GUserMessage[], layer?: NotificationLayerEnum): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<GeboAIRootNotificationService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<GeboAIRootNotificationService>;
}
