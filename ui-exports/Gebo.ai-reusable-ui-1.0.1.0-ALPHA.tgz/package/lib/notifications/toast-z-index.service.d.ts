import * as i0 from "@angular/core";
export declare class ToastZIndexService {
    private _z;
    z$: import("rxjs").Observable<number>;
    bumpAboveOverlays(offset?: number, floor?: number): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ToastZIndexService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ToastZIndexService>;
}
//# sourceMappingURL=toast-z-index.service.d.ts.map