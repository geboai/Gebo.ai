import { ToastZIndexService } from "./toast-z-index.service";
import { NotificationLayerEnum } from "./notification-layer";
import * as i0 from "@angular/core";
/***********************
 * This component will be inserted in the app.component.html
 */
export declare class GeboAIDisplayMessagesComponent {
    private zIndexService;
    layer: NotificationLayerEnum;
    protected autoZIndex: number;
    constructor(zIndexService: ToastZIndexService);
    static ɵfac: i0.ɵɵFactoryDeclaration<GeboAIDisplayMessagesComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<GeboAIDisplayMessagesComponent, "gebo-ai-display-messages", never, { "layer": { "alias": "layer"; "required": false; }; }, {}, never, never, false, never>;
}
//# sourceMappingURL=display-messages.component.d.ts.map