import { OnChanges, SimpleChanges } from "@angular/core";
import { GeboAIRootNotificationService } from "./root-notification.service";
import { GeboAIFieldHost } from "../controls/field-host-component-iface/field-host-component-iface";
import { GUserMessage } from "@Gebo.ai/gebo-ai-rest-api";
import { ToastMessageOptions } from "primeng/api";
import { NotificationLayerEnum } from "./notification-layer";
import * as i0 from "@angular/core";
/*************************
 * This component will forward to the display messages area messages
 */
export declare class GeboAINotificationComponent implements OnChanges {
    private service;
    private moduleId;
    private host;
    messages: (GUserMessage | ToastMessageOptions)[];
    layer: NotificationLayerEnum;
    private oldMessages;
    constructor(service: GeboAIRootNotificationService, moduleId: string, host: GeboAIFieldHost);
    ngOnChanges(changes: SimpleChanges): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<GeboAINotificationComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<GeboAINotificationComponent, "gebo-ai-notifications", never, { "messages": { "alias": "messages"; "required": false; }; "layer": { "alias": "layer"; "required": false; }; }, {}, never, never, false, never>;
}
