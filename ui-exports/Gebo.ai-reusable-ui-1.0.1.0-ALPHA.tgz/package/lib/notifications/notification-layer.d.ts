export type NotificationLayerEnum = 'GLOBAL' | "DIALOG";
export declare const NotificationLayerEnum: {
    GLOBAL: NotificationLayerEnum;
    DIALOG: NotificationLayerEnum;
};
