/**
 * This Source Code is subject to the terms of the
 * Gebo.ai community version Mozilla Public License Version 2.0 (MPL-2.0) — With Data Protection Clauses
 * If a copy of the LICENCE was not distributed with this file, You can obtain one at
 * https://gebo.ai/gebo-ai-community-version-mozilla-public-license-version-2-0-mpl-2-0-with-data-protection-clauses/
 * and https://mozilla.org/MPL/2.0/.
 * Copyright (c) 2025+ Gebo.ai
 */
import { HttpHeaders } from '@angular/common/http';
/**
 * @file Authentication utility for Gebo.ai
 * AI generated comments
 * This file provides functions to interact with authentication credentials
 * stored in local storage.
 */
import { SecurityHeaderData } from "@Gebo.ai/gebo-ai-rest-api";
export declare const AUTHORIZATION_HEADER: string;
export declare const AUTHORIZATION_TYPE_HEADER: string;
export declare const AUTHORIZATION_PROVIDER_ID_HEADER: string;
export declare const AUTHORIZATION_TENANT_ID_HEADER: string;
export declare const DEFAULT_TENANT: string;
export declare const DEFAULT_PROVIDER_ID: string;
/**
 * Constant used as the key for storing Gebo.ai credentials in local storage
 */
export declare const geboCredenditalString: string;
/**
 * Retrieves authentication data from local storage
 *
 * This function attempts to read Gebo.ai credentials from local storage, parse them
 * from JSON into an AuthResponse object, and return them. If no credentials
 * are found in local storage, it returns undefined.
 *
 * @returns {SecurityHeaderData | undefined} The parsed authentication response or undefined if not found
 */
export declare function getAuth(): SecurityHeaderData | undefined;
/*************************
 * Returns the http standard UI auth httpheader object
 */
export declare function getAuthHeader(): any;
export declare function getHttpHeaders(): HttpHeaders;
export declare function resetAuth(): void;
export declare function saveAuth(value: SecurityHeaderData): void;
