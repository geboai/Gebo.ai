import { OnInit } from "@angular/core";
import { Router } from "@angular/router";
import { UserWorkflowsControllerService } from "@Gebo.ai/gebo-ai-rest-api";
import * as i0 from "@angular/core";
export declare class GeboAICheckDeviceActivationComponent implements OnInit {
    private service;
    private router;
    constructor(service: UserWorkflowsControllerService, router: Router);
    ngOnInit(): void;
    goToActivate(): void;
    goToLogin(): void;
    goToChat(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<GeboAICheckDeviceActivationComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<GeboAICheckDeviceActivationComponent, "gebo-ai-check-device-activation-component", never, {}, {}, never, never, false, never>;
}
//# sourceMappingURL=check-device-activation.component.d.ts.map