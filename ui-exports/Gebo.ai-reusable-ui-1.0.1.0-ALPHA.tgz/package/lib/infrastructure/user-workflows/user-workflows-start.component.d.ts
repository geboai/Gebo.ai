import { OnInit } from "@angular/core";
import { StartWorkflowData, UserWorkflowsControllerService, UserWorkFlowStartResponse } from "@Gebo.ai/gebo-ai-rest-api";
import { ActivatedRoute } from "@angular/router";
import { FormGroup } from "@angular/forms";
import { ToastMessageOptions } from "primeng/api";
import * as i0 from "@angular/core";
export declare class GeboAIUserWorkflowsStartComponent implements OnInit {
    private service;
    private activatedRoute;
    protected disabledWorkFlows: boolean;
    protected loading: boolean;
    protected workflowActivated: boolean;
    protected workflowError: boolean;
    protected formGroup: FormGroup;
    protected chooseWorkflow: boolean;
    protected userMessages: ToastMessageOptions[];
    protected processStarted: boolean;
    protected typeOptions: {
        description: string;
        code: StartWorkflowData.TypeEnum;
    }[];
    protected stepResponse?: UserWorkFlowStartResponse;
    constructor(service: UserWorkflowsControllerService, activatedRoute: ActivatedRoute);
    ngOnInit(): void;
    protected doStartWorkflow(workflow?: string): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<GeboAIUserWorkflowsStartComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<GeboAIUserWorkflowsStartComponent, "gebo-ai-user-start-workflows", never, {}, {}, never, never, false, never>;
}
//# sourceMappingURL=user-workflows-start.component.d.ts.map