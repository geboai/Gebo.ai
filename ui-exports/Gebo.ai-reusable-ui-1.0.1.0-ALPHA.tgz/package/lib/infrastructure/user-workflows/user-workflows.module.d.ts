import * as i0 from "@angular/core";
import * as i1 from "./user-workflows-land.component";
import * as i2 from "./user-workflows-start.component";
import * as i3 from "./check-device-activation.component";
import * as i4 from "@angular/common";
import * as i5 from "@angular/forms";
import * as i6 from "@angular/router";
import * as i7 from "primeng/panel";
import * as i8 from "primeng/inputtext";
import * as i9 from "primeng/button";
import * as i10 from "primeng/blockui";
import * as i11 from "primeng/select";
import * as i12 from "primeng/password";
import * as i13 from "../../controls/field-translation-container/field-container.module";
import * as i14 from "../../notifications/notifications.module";
export declare class GeboAIUserWorkflowsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<GeboAIUserWorkflowsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<GeboAIUserWorkflowsModule, [typeof i1.GeboAIUserWorkflowsLandComponent, typeof i2.GeboAIUserWorkflowsStartComponent, typeof i3.GeboAICheckDeviceActivationComponent], [typeof i4.CommonModule, typeof i5.ReactiveFormsModule, typeof i5.FormsModule, typeof i6.RouterModule, typeof i7.PanelModule, typeof i8.InputTextModule, typeof i9.ButtonModule, typeof i10.BlockUIModule, typeof i11.SelectModule, typeof i12.PasswordModule, typeof i13.GeboAIFieldTranslationContainerModule, typeof i14.GeboAINotificationsModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<GeboAIUserWorkflowsModule>;
}
//# sourceMappingURL=user-workflows.module.d.ts.map