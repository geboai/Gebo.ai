import * as i0 from "@angular/core";
import * as i1 from "./user-workflows-land.component";
import * as i2 from "./user-workflows-start.component";
import * as i3 from "@angular/common";
import * as i4 from "@angular/forms";
import * as i5 from "@angular/router";
import * as i6 from "primeng/panel";
import * as i7 from "primeng/inputtext";
import * as i8 from "primeng/button";
import * as i9 from "primeng/blockui";
import * as i10 from "primeng/select";
import * as i11 from "primeng/password";
import * as i12 from "../../controls/field-translation-container/field-container.module";
import * as i13 from "../../notifications/notifications.module";
export declare class GeboAIUserWorkflowsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<GeboAIUserWorkflowsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<GeboAIUserWorkflowsModule, [typeof i1.GeboAIUserWorkflowsLandComponent, typeof i2.GeboAIUserWorkflowsStartComponent], [typeof i3.CommonModule, typeof i4.ReactiveFormsModule, typeof i4.FormsModule, typeof i5.RouterModule, typeof i6.PanelModule, typeof i7.InputTextModule, typeof i8.ButtonModule, typeof i9.BlockUIModule, typeof i10.SelectModule, typeof i11.PasswordModule, typeof i12.GeboAIFieldTranslationContainerModule, typeof i13.GeboAINotificationsModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<GeboAIUserWorkflowsModule>;
}
//# sourceMappingURL=user-workflows.module.d.ts.map