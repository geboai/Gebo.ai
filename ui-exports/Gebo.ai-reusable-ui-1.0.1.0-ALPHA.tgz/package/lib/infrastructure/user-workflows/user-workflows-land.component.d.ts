import { OnInit } from "@angular/core";
import { UserWorkFlowChangePasswordResponse, UserWorkflowsControllerService } from "@Gebo.ai/gebo-ai-rest-api";
import { ActivatedRoute, Router } from "@angular/router";
import { FormGroup } from "@angular/forms";
import { ToastMessageOptions } from "primeng/api";
import * as i0 from "@angular/core";
export declare class GeboAIUserWorkflowsLandComponent implements OnInit {
    private service;
    private activatedRoute;
    private router;
    protected disabledWorkFlows: boolean;
    protected chooseWorkflow: boolean;
    protected loading: boolean;
    protected success: boolean;
    protected error: boolean;
    protected userMessages: ToastMessageOptions[];
    protected formGroup: FormGroup;
    protected stepResult?: UserWorkFlowChangePasswordResponse;
    constructor(service: UserWorkflowsControllerService, activatedRoute: ActivatedRoute, router: Router);
    ngOnInit(): void;
    goToLogin(): void;
    doChangePassword(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<GeboAIUserWorkflowsLandComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<GeboAIUserWorkflowsLandComponent, "gebo-ai-user-land-workflows", never, {}, {}, never, never, false, never>;
}
//# sourceMappingURL=user-workflows-land.component.d.ts.map