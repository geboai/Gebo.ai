import { SecurityHeaderData, Oauth2ClientConfig, AuthControllerService, GUserMessage } from "@Gebo.ai/gebo-ai-rest-api";
import { Subject } from "rxjs";
import { OAuthService } from 'angular-oauth2-oidc';
import { ActivatedRoute } from "@angular/router";
import * as i0 from "@angular/core";
export interface IOauth2LoginService {
    authDataSubject: Subject<SecurityHeaderData | undefined>;
    oauth2Login(config: Oauth2ClientConfig, successfullCallBack: () => void, failureCallback: (msgs?: GUserMessage[]) => void): void;
    oauth2RedirectLanding(config: Oauth2ClientConfig, successfullCallBack: () => void, failureCallback: (msgs?: GUserMessage[]) => void): void;
}
export declare class GenericOauth2ServerSideLoginService implements IOauth2LoginService {
    private basePath;
    private activatedRoute;
    private authControllerService;
    constructor(basePath: string, activatedRoute: ActivatedRoute, authControllerService: AuthControllerService);
    authDataSubject: Subject<SecurityHeaderData | undefined>;
    private createOauth2LoginUrl;
    oauth2Login(config: Oauth2ClientConfig, successfullCallBack: () => void, failureCallback: (msgs?: GUserMessage[]) => void): void;
    oauth2RedirectLanding(config: Oauth2ClientConfig, successfullCallBack: () => void, failureCallback: (msgs?: GUserMessage[]) => void): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<GenericOauth2ServerSideLoginService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<GenericOauth2ServerSideLoginService>;
}
export declare class GenericOauth2ClientLoginService implements IOauth2LoginService {
    private oauth2Service;
    private authConfig?;
    constructor(oauth2Service: OAuthService);
    authDataSubject: Subject<SecurityHeaderData | undefined>;
    private translateConfig;
    oauth2Login(value: Oauth2ClientConfig, successfullCallBack: () => void, failureCallback: (msgs?: GUserMessage[]) => void): void;
    oauth2RedirectLanding(value: Oauth2ClientConfig, successfullCallBack: () => void, failureCallback: (msgs?: GUserMessage[]) => void): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<GenericOauth2ClientLoginService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<GenericOauth2ClientLoginService>;
}
export declare class Oauth2LoginService implements IOauth2LoginService {
    private genericOauthClient2LoginService;
    private genericServerSideOauth2LoginService;
    constructor(genericOauthClient2LoginService: GenericOauth2ClientLoginService, genericServerSideOauth2LoginService: GenericOauth2ServerSideLoginService);
    private subscription?;
    authDataSubject: Subject<SecurityHeaderData | undefined>;
    oauth2Login(config: Oauth2ClientConfig, successfullCallBack: () => void, failureCallback: (msgs?: GUserMessage[]) => void): void;
    oauth2RedirectLanding(config: Oauth2ClientConfig, successfullCallBack: () => void, failureCallback: (msgs?: GUserMessage[]) => void): void;
    private switchOauth2LoginService;
    static ɵfac: i0.ɵɵFactoryDeclaration<Oauth2LoginService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<Oauth2LoginService>;
}
