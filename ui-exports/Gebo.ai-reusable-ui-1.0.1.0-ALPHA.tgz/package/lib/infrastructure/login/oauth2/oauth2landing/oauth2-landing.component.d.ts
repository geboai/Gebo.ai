import { OnInit } from "@angular/core";
import { ActivatedRoute, Router } from "@angular/router";
import { LoginService } from "../../login.service";
import * as i0 from "@angular/core";
export declare class GeboAIOauth2LandingComponent implements OnInit {
    private activeRoute;
    private router;
    private loginService;
    loading: boolean;
    constructor(activeRoute: ActivatedRoute, router: Router, loginService: LoginService);
    ngOnInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<GeboAIOauth2LandingComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<GeboAIOauth2LandingComponent, "gebo-oauth2-landing-component", never, {}, {}, never, never, false, never>;
}
//# sourceMappingURL=oauth2-landing.component.d.ts.map