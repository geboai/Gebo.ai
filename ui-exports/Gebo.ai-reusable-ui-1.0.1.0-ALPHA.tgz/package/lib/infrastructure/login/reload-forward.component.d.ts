/**
 * This Source Code is subject to the terms of the
 * Gebo.ai community version Mozilla Public License Version 2.0 (MPL-2.0) — With Data Protection Clauses
 * If a copy of the LICENCE was not distributed with this file, You can obtain one at
 * https://gebo.ai/gebo-ai-community-version-mozilla-public-license-version-2-0-mpl-2-0-with-data-protection-clauses/
 * and https://mozilla.org/MPL/2.0/.
 * Copyright (c) 2025+ Gebo.ai
 */
import { OnChanges, OnInit, SimpleChanges } from "@angular/core";
import { ActivatedRoute, Router } from "@angular/router";
import { LoginService } from "./login.service";
import * as i0 from "@angular/core";
export declare class GeboAIReloadForwardComponent implements OnInit, OnChanges {
    private actualRoute;
    private router;
    private loginService;
    state?: any;
    constructor(actualRoute: ActivatedRoute, router: Router, loginService: LoginService);
    ngOnInit(): void;
    ngOnChanges(changes: SimpleChanges): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<GeboAIReloadForwardComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<GeboAIReloadForwardComponent, "gebo-ai-reload-forward-component", never, {}, {}, never, never, false, never>;
}
