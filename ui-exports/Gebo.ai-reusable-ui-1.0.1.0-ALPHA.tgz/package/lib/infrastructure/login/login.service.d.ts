import { ActivatedRoute, Router } from "@angular/router";
import { AuthControllerService, ChangePasswordParam, ChangePasswordResponse, Oauth2ClientAuthorizativeInfo, AuthProvidersControllerService, SecurityHeaderData, UserControllerService, UserInfo, TokenRenewControllerService } from "@Gebo.ai/gebo-ai-rest-api";
import { ToastMessageOptions } from "primeng/api";
import { Observable, Subject } from "rxjs";
import { Oauth2LoginService } from "./oauth2/oauth2-login.service";
import * as i0 from "@angular/core";
/**
 * Interface representing the result of a login operation
 * Contains optional user information and an array of toast messages to display
 */
export interface LoginOperationResult {
    userInfo?: UserInfo;
    messages: ToastMessageOptions[];
}
/**
 * Service responsible for handling user authentication and related functionality.
 * Manages user sessions, login/logout operations, and password changes.
 */
export declare class LoginService {
    private basePath;
    private oauth2Service;
    private activatedRouter;
    private router;
    private authControllerService;
    private oauth2ProvidersService;
    private tokenRenewService;
    private userController;
    private actualAuthConfig?;
    private actualAuthProviderId?;
    private subscription?;
    private tokenRenewPollingPeriodMsec;
    loginActivated: Subject<boolean>;
    /**
     * Subject that emits the current logged-in user information or undefined when logged out
     */
    logged: Subject<UserInfo | undefined>;
    /**
   * Constructor for the LoginService
   * @param activatedRouter Current active route for navigation purposes
   * @param router Router for navigating between routes
   * @param authControllerService Service for authentication operations
   * @param userController Service for user profile operations
   */
    constructor(basePath: string, oauth2Service: Oauth2LoginService, activatedRouter: ActivatedRoute, router: Router, authControllerService: AuthControllerService, oauth2ProvidersService: AuthProvidersControllerService, tokenRenewService: TokenRenewControllerService, userController: UserControllerService);
    private startTokenRenew;
    private pollTokenRenew;
    authDataSubject: Subject<SecurityHeaderData | undefined>;
    /**
     * Authenticates a user with the provided credentials on local JWT
     * @param credentials Object containing username and password
     * @returns Observable of LoginOperationResult with user info and status messages
     */
    login(credentials: {
        username: string;
        password: string;
    }): Observable<LoginOperationResult>;
    /*****
     * Check if we are in oauth2 landing page
     */
    isOauth2LandingPage(): boolean;
    /**
     * Retrieves the current user's profile information
     * @returns Observable of UserInfo containing the user's profile data
     */
    loadUserProfile(): Observable<UserInfo>;
    /**
     * Changes the user's password
     * @param c ChangePasswordParam object containing old and new password information
     * @returns Observable of ChangePasswordResponse with the operation result
     */
    changePassword(c: ChangePasswordParam): Observable<ChangePasswordResponse>;
    /**
     * Logs out the current user by removing credentials from local storage,
     * notifying subscribers that user is logged out, and redirecting to the chat page
     */
    logout(): void;
    /**********************
     * Load list of oauth2 providers enabled for the user login (UI data without technical oauth2 critical infos)
     */
    getOauth2LoginOptions(): Observable<Oauth2ClientAuthorizativeInfo[]>;
    /*****************************************************************************
     * Loads the angular-oauth2-oidc AuthConfig configurations using backend specific
     * provider (get by id) infos
     */
    private loadProviderConfig;
    /******************************************************
     * Start the interactive oauth2 login for actual user by choosed Oauth2ClientAuthorizativeInfo
     */
    loginWithOauth2(clicked: Oauth2ClientAuthorizativeInfo): Observable<boolean>;
    private onSuccessfullLogin;
    private onUnsuccessfullLogin;
    /****************************
     * Called from the reloaded SPA application redirected URL component to get accessToken
     */
    oauth2RedirectionLanding(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<LoginService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<LoginService>;
}
//# sourceMappingURL=login.service.d.ts.map