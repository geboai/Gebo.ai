/**
 * This Source Code is subject to the terms of the
 * Gebo.ai community version Mozilla Public License Version 2.0 (MPL-2.0) — With Data Protection Clauses
 * If a copy of the LICENCE was not distributed with this file, You can obtain one at
 * https://gebo.ai/gebo-ai-community-version-mozilla-public-license-version-2-0-mpl-2-0-with-data-protection-clauses/
 * and https://mozilla.org/MPL/2.0/.
 * Copyright (c) 2025+ Gebo.ai
 */
/**
 * AI generated comments
 *
 * Component for handling user authentication and login functionality.
 * This component renders a login form with username and password fields,
 * manages login state, validates system setup status, and navigates users
 * accordingly based on authentication results or system status.
 */
import { OnInit } from "@angular/core";
import { LoginService } from "./login.service";
import { ToastMessageOptions } from "primeng/api";
import { FormGroup } from "@angular/forms";
import { GeboFastInstallationSetupControllerService, Oauth2ClientAuthorizativeInfo, UserWorkflowsControllerService } from "@Gebo.ai/gebo-ai-rest-api";
import { ActivatedRoute, Router } from "@angular/router";
import { GeboAITranslationService } from "../../controls/field-translation-container/gebo-translation.service";
import * as i0 from "@angular/core";
export declare class LoginComponent implements OnInit {
    loginService: LoginService;
    private geboFastSetupControllerService;
    private userWorkflowsService;
    private geboTranslationService;
    private router;
    private activatedRoute;
    /**
     * Form group containing login credentials input controls
     */
    formGroup: FormGroup;
    /**
     * Flag indicating whether a login request is in progress
     */
    loading: boolean;
    /**
     * Stores user profile information after successful authentication
     */
    profile?: any;
    /**
     * Collection of toast messages to display to the user
     */
    userMessages: ToastMessageOptions[];
    private subscription?;
    providers: Oauth2ClientAuthorizativeInfo[];
    /**
     * Component constructor initializing necessary services for authentication and navigation
     *
     * @param loginService Service handling authentication logic
     * @param geboFastSetupControllerService Service to verify system installation status
     * @param router Angular router for navigation
     * @param activatedRoute Current activated route
     */
    constructor(loginService: LoginService, geboFastSetupControllerService: GeboFastInstallationSetupControllerService, userWorkflowsService: UserWorkflowsControllerService, geboTranslationService: GeboAITranslationService, router: Router, activatedRoute: ActivatedRoute);
    onSumbit(): void;
    /**
     * Verifies if the system has been properly set up
     * Redirects to setup page if installation is incomplete
     */
    private checkSystemSetup;
    /**
     * Lifecycle hook that runs when the component initializes
     * Checks if the system is properly set up before allowing login
     */
    protected showForgotPasswordLink: boolean;
    ngOnInit(): Promise<void>;
    /**
     * Handles user login form submission
     * Attempts to authenticate the user with provided credentials
     * On success, redirects to the application main page
     * Updates user messages based on authentication result
     */
    login(): void;
    onOauth2Click(clicked: Oauth2ClientAuthorizativeInfo): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<LoginComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<LoginComponent, "gebo-ai-login-component", never, {}, {}, never, never, false, never>;
}
//# sourceMappingURL=login.component.d.ts.map