/**
 * This Source Code is subject to the terms of the
 * Gebo.ai community version Mozilla Public License Version 2.0 (MPL-2.0) — With Data Protection Clauses
 * If a copy of the LICENCE was not distributed with this file, You can obtain one at
 * https://gebo.ai/gebo-ai-community-version-mozilla-public-license-version-2-0-mpl-2-0-with-data-protection-clauses/
 * and https://mozilla.org/MPL/2.0/.
 * Copyright (c) 2025+ Gebo.ai
 */
import { OnInit } from "@angular/core";
import { LoginService } from "./login.service";
import * as i0 from "@angular/core";
export declare class LogoutComponent implements OnInit {
    private loginService;
    constructor(loginService: LoginService);
    ngOnInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<LogoutComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<LogoutComponent, "gebo-ai-logout-component", never, {}, {}, never, never, false, never>;
}
