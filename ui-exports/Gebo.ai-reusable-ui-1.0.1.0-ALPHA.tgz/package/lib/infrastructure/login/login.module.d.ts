import * as i0 from "@angular/core";
import * as i1 from "./login.component";
import * as i2 from "./oauth2/oauth2landing/oauth2-landing.component";
import * as i3 from "./logged.component";
import * as i4 from "./logout.component";
import * as i5 from "./reload-forward.component";
import * as i6 from "@angular/common";
import * as i7 from "primeng/password";
import * as i8 from "primeng/inputtext";
import * as i9 from "primeng/button";
import * as i10 from "primeng/blockui";
import * as i11 from "primeng/panel";
import * as i12 from "@angular/forms";
import * as i13 from "@angular/router";
import * as i14 from "primeng/fieldset";
import * as i15 from "../../controls/field-translation-container/field-container.module";
import * as i16 from "../../notifications/notifications.module";
export declare class LoginModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<LoginModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<LoginModule, [typeof i1.LoginComponent, typeof i2.GeboAIOauth2LandingComponent, typeof i3.LoggedComponent, typeof i4.LogoutComponent, typeof i5.GeboAIReloadForwardComponent], [typeof i6.CommonModule, typeof i7.PasswordModule, typeof i8.InputTextModule, typeof i9.ButtonModule, typeof i10.BlockUIModule, typeof i11.PanelModule, typeof i12.ReactiveFormsModule, typeof i12.FormsModule, typeof i13.RouterModule, typeof i14.FieldsetModule, typeof i15.GeboAIFieldTranslationContainerModule, typeof i16.GeboAINotificationsModule], [typeof i1.LoginComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<LoginModule>;
}
