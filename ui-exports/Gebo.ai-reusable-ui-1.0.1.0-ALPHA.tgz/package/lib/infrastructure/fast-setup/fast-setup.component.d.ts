/**
 * This Source Code is subject to the terms of the
 * Gebo.ai community version Mozilla Public License Version 2.0 (MPL-2.0) — With Data Protection Clauses
 * If a copy of the LICENCE was not distributed with this file, You can obtain one at
 * https://gebo.ai/gebo-ai-community-version-mozilla-public-license-version-2-0-mpl-2-0-with-data-protection-clauses/
 * and https://mozilla.org/MPL/2.0/.
 * Copyright (c) 2025+ Gebo.ai
 */
/**
 * AI generated comments
 *
 * This module represents the Fast Setup component for initial Gebo.ai application configuration.
 * It allows new users to create their credentials, accept the license agreement,
 * and complete the installation process.
 */
import { OnInit } from "@angular/core";
import { FormGroup } from "@angular/forms";
import { ActivatedRoute, Router } from "@angular/router";
import { GeboFastInstallationSetupControllerService, OperationStatusBoolean } from "@Gebo.ai/gebo-ai-rest-api";
import { ToastMessageOptions } from "primeng/api";
import { LoginService } from "../login/login.service";
import * as i0 from "@angular/core";
/**
 * Component responsible for the initial fast setup process of the Gebo.ai application.
 * Provides a user interface for creating the first admin account and completing installation.
 * This component handles the setup form, validation, and API communication to finalize installation.
 */
export declare class FastSetupComponent implements OnInit {
    private geboFastSetupControllerService;
    private loginService;
    private router;
    private activatedRoute;
    /**
     * Form group containing all the user input fields required for setup.
     * Includes username, password, password confirmation, and license agreement.
     */
    formGroup: FormGroup;
    /** Flag indicating if a setup operation is in progress */
    loading: boolean;
    /** Flag indicating if a login operation is in progress */
    loggingin: boolean;
    /** User profile information */
    profile?: any;
    /** Status of the installation process */
    status?: OperationStatusBoolean;
    /** Username/email that will be used for the license */
    licencee: string;
    /** Array of messages to display to the user */
    userMessages: ToastMessageOptions[];
    /**
     * Constructor initializes required services for installation, login, and navigation
     * @param geboFastSetupControllerService Service to interact with fast installation API
     * @param loginService Service to handle user authentication
     * @param router Angular router for navigation
     * @param activatedRoute Current activated route
     */
    constructor(geboFastSetupControllerService: GeboFastInstallationSetupControllerService, loginService: LoginService, router: Router, activatedRoute: ActivatedRoute);
    /**
     * Checks the system installation status.
     * If the system is already set up, redirects to login.
     */
    private checkSystemSetup;
    /**
     * Initializes the component by checking system status and setting up form validators.
     * Creates a validator to ensure passwords match and meet minimum requirements.
     */
    ngOnInit(): void;
    /**
     * Redirects the user to the reloader page after successful setup.
     * Passes state information indicating setup is complete.
     */
    doLogin(): void;
    /**
     * Performs the setup process with the provided form data.
     * Creates the initial admin account, completes installation,
     * and automatically logs in the user upon success.
     */
    doSetup(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<FastSetupComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<FastSetupComponent, "gebo-ai-fast-setup", never, {}, {}, never, never, false, never>;
}
