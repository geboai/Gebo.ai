/**
 * This Source Code is subject to the terms of the
 * Gebo.ai community version Mozilla Public License Version 2.0 (MPL-2.0) — With Data Protection Clauses
 * If a copy of the LICENCE was not distributed with this file, You can obtain one at
 * https://gebo.ai/gebo-ai-community-version-mozilla-public-license-version-2-0-mpl-2-0-with-data-protection-clauses/
 * and https://mozilla.org/MPL/2.0/.
 * Copyright (c) 2025+ Gebo.ai
 */
/**
 * AI generated comments
 * A component that handles license agreement functionality. It implements ControlValueAccessor
 * to work with Angular's form system, allowing it to be used in reactive forms.
 * The component tracks whether a user has accepted a license agreement and emits the
 * license content when accepted.
 */
import { ElementRef, OnChanges, OnInit, SimpleChanges } from "@angular/core";
import { ControlValueAccessor, FormGroup } from "@angular/forms";
import * as i0 from "@angular/core";
export declare class GeboAILicenceComponent implements ControlValueAccessor, OnInit, OnChanges {
    /**
     * Reference to the license text content element in the template
     */
    licenceBody?: ElementRef<Element>;
    /**
     * Internal form group to manage the acceptance checkbox state
     */
    internalFormGroup: FormGroup;
    /**
     * Current date used for displaying when the license is being viewed/accepted
     */
    data: Date;
    /**
     * Name of the person or entity accepting the license
     */
    licencee: string;
    /**
     * Initializes the component and sets up a subscription to the acceptMark control.
     * When the checkbox value changes, it either notifies acceptance or non-acceptance.
     */
    ngOnInit(): void;
    /**
     * Handles changes to component inputs. If the licensee name changes and the
     * license is already accepted, it re-triggers the acceptance notification.
     */
    ngOnChanges(changes: SimpleChanges): void;
    /**
     * Notifies the parent form that the license has not been accepted
     * by passing undefined to the onChange callback
     */
    notifyNotAccepted(): void;
    /**
     * Notifies the parent form that the license has been accepted
     * by passing the license HTML content through the onChange callback
     */
    notifyAccepted(): void;
    /**
     * ControlValueAccessor method to write a value to the component.
     * Not implemented as this component only outputs values.
     */
    writeValue(obj: any): void;
    /**
     * Default onChange handler - replaced when registerOnChange is called
     */
    private onChange;
    /**
     * ControlValueAccessor method to register a function to call when the control's value changes
     */
    registerOnChange(fn: any): void;
    /**
     * Default onTouched handler - replaced when registerOnTouched is called
     */
    private onTouched;
    /**
     * ControlValueAccessor method to register a function to call when the control receives a touch event
     */
    registerOnTouched(fn: any): void;
    /**
     * ControlValueAccessor method to enable/disable the component
     * Not implemented in this component
     */
    setDisabledState?(isDisabled: boolean): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<GeboAILicenceComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<GeboAILicenceComponent, "gebo-ai-licence-component", never, { "licencee": { "alias": "licencee"; "required": false; }; }, {}, never, never, false, never>;
}
//# sourceMappingURL=licence.component.d.ts.map