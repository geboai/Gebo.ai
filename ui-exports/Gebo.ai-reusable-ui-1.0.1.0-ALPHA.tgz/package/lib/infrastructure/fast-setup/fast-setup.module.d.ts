import { OnInit } from "@angular/core";
import * as i0 from "@angular/core";
import * as i1 from "./fast-setup.component";
import * as i2 from "./licence.component";
import * as i3 from "@angular/common";
import * as i4 from "@angular/forms";
import * as i5 from "primeng/panel";
import * as i6 from "primeng/blockui";
import * as i7 from "primeng/inputtext";
import * as i8 from "primeng/button";
import * as i9 from "primeng/password";
import * as i10 from "@angular/router";
import * as i11 from "primeng/dropdown";
import * as i12 from "../../controls/editable-listbox-component/editable-listbox.module";
import * as i13 from "primeng/checkbox";
import * as i14 from "primeng/radiobutton";
import * as i15 from "primeng/scrollpanel";
import * as i16 from "primeng/selectbutton";
import * as i17 from "primeng/fieldset";
import * as i18 from "../../controls/field-translation-container/field-container.module";
import * as i19 from "../../notifications/notifications.module";
/**
 * This Angular module encapsulates all the components and dependencies needed for the fast setup functionality.
 * It bundles UI components from PrimeNG library and custom components such as FastSetupComponent
 * and GeboAILicenceComponent to provide a complete setup interface.
 * The module handles routing to the setup page and provides all necessary form controls and UI elements.
 */
export declare class FastSetupModule implements OnInit {
    /**
     * Lifecycle hook that is called after data-bound properties of a directive are initialized.
     * Currently empty but can be used for module-level initialization if needed.
     */
    ngOnInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<FastSetupModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<FastSetupModule, [typeof i1.FastSetupComponent, typeof i2.GeboAILicenceComponent], [typeof i3.CommonModule, typeof i4.FormsModule, typeof i4.ReactiveFormsModule, typeof i5.PanelModule, typeof i6.BlockUIModule, typeof i7.InputTextModule, typeof i8.ButtonModule, typeof i9.PasswordModule, typeof i10.RouterModule, typeof i11.DropdownModule, typeof i12.EditableListboxModule, typeof i13.CheckboxModule, typeof i14.RadioButtonModule, typeof i15.ScrollPanelModule, typeof i16.SelectButtonModule, typeof i17.FieldsetModule, typeof i18.GeboAIFieldTranslationContainerModule, typeof i19.GeboAINotificationsModule], [typeof i1.FastSetupComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<FastSetupModule>;
}
