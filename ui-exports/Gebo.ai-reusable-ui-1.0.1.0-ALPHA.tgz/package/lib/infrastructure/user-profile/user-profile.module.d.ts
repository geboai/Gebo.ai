import * as i0 from "@angular/core";
import * as i1 from "./user-profile.component";
import * as i2 from "./change-password.component";
import * as i3 from "@angular/common";
import * as i4 from "primeng/password";
import * as i5 from "primeng/inputtext";
import * as i6 from "primeng/button";
import * as i7 from "primeng/blockui";
import * as i8 from "primeng/panel";
import * as i9 from "primeng/dialog";
import * as i10 from "@angular/forms";
import * as i11 from "@angular/router";
import * as i12 from "../../controls/field-translation-container/field-container.module";
import * as i13 from "../../notifications/notifications.module";
/**
 * NgModule that bundles all the components and dependencies required for user profile functionality.
 * It imports UI modules from PrimeNG (like Password, Panel, Dialog), form handling modules,
 * and sets up routing. It declares the user profile and password change components.
 */
export declare class GeboAIUserProfileModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<GeboAIUserProfileModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<GeboAIUserProfileModule, [typeof i1.GeboAIUserProfileComponent, typeof i2.GeboAIChangePasswordComponent], [typeof i3.CommonModule, typeof i4.PasswordModule, typeof i5.InputTextModule, typeof i6.ButtonModule, typeof i7.BlockUIModule, typeof i8.PanelModule, typeof i9.DialogModule, typeof i10.ReactiveFormsModule, typeof i10.FormsModule, typeof i11.RouterModule, typeof i12.GeboAIFieldTranslationContainerModule, typeof i13.GeboAINotificationsModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<GeboAIUserProfileModule>;
}
//# sourceMappingURL=user-profile.module.d.ts.map