/**
 * This Source Code is subject to the terms of the
 * Gebo.ai community version Mozilla Public License Version 2.0 (MPL-2.0) — With Data Protection Clauses
 * If a copy of the LICENCE was not distributed with this file, You can obtain one at
 * https://gebo.ai/gebo-ai-community-version-mozilla-public-license-version-2-0-mpl-2-0-with-data-protection-clauses/
 * and https://mozilla.org/MPL/2.0/.
 * Copyright (c) 2025+ Gebo.ai
 */
/**
 * AI generated comments
 * Component for changing user passwords in the Gebo.ai application.
 * Provides a form for users to enter their old password and a new password with confirmation.
 * Handles validation, error messages, and communication with the login service.
 */
import { EventEmitter, OnChanges, OnInit, SimpleChanges } from "@angular/core";
import { FormGroup } from "@angular/forms";
import { ChangePasswordResponse, UserInfo } from "@Gebo.ai/gebo-ai-rest-api";
import { ToastMessageOptions } from "primeng/api";
import { LoginService } from "../login/login.service";
import * as i0 from "@angular/core";
export declare class GeboAIChangePasswordComponent implements OnInit, OnChanges {
    private loginService;
    /** The user information object */
    user?: UserInfo;
    /** Controls the visibility of the change password dialog */
    visible: boolean;
    /** Event emitter that fires when the modal is closed */
    close: EventEmitter<boolean>;
    /** Flag indicating whether a password change operation is in progress */
    loading: boolean;
    /** Response from the password change API call */
    changePasswordResult?: ChangePasswordResponse;
    /** Messages to display to the user in the UI */
    userMessages: ToastMessageOptions[];
    /** Event emitter that fires when the password is successfully changed */
    changedPasswordCorrectly: EventEmitter<boolean>;
    /**
     * Constructor for the change password component
     * @param loginService Service for handling authentication and password operations
     */
    constructor(loginService: LoginService);
    /**
     * Form group containing the password change form fields
     */
    formGroup: FormGroup;
    /**
     * Handles the closing of the modal dialog
     * @param e Event object from the UI
     */
    closeModal(e: any): void;
    /**
     * Initializes the component and sets up form validators
     * Adds a custom validator to check if the new password entries match
     */
    ngOnInit(): void;
    /**
     * Responds to changes in the component's input properties
     * Updates the form values when user or auth information changes
     * @param changes SimpleChanges object containing the changed properties
     */
    ngOnChanges(changes: SimpleChanges): void;
    /**
     * Handles the password change operation
     * Calls the login service's changePassword method and processes the response
     * Updates UI messages based on the result
     */
    doChangePassword(): void;
    /**
     * Allows the user to skip the password change process
     * Emits an event indicating the user chose not to change their password
     */
    doSkip(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<GeboAIChangePasswordComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<GeboAIChangePasswordComponent, "gebo-ai-change-password-component", never, { "user": { "alias": "user"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; }, { "close": "close"; "changedPasswordCorrectly": "changedPasswordCorrectly"; }, never, never, false, never>;
}
