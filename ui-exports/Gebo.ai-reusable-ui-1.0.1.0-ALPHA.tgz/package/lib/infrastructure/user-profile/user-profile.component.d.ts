/**
 * This Source Code is subject to the terms of the
 * Gebo.ai community version Mozilla Public License Version 2.0 (MPL-2.0) — With Data Protection Clauses
 * If a copy of the LICENCE was not distributed with this file, You can obtain one at
 * https://gebo.ai/gebo-ai-community-version-mozilla-public-license-version-2-0-mpl-2-0-with-data-protection-clauses/
 * and https://mozilla.org/MPL/2.0/.
 * Copyright (c) 2025+ Gebo.ai
 */
/**
 * AI generated comments
 *
 * This component is responsible for displaying the current user's profile information.
 * It fetches user profile data upon initialization and provides functionality for
 * displaying user information and managing password changes.
 */
import { OnChanges, OnInit, SimpleChanges } from "@angular/core";
import { LoginService } from "../login/login.service";
import { UserInfo } from "@Gebo.ai/gebo-ai-rest-api";
import * as i0 from "@angular/core";
export declare class GeboAIUserProfileComponent implements OnInit, OnChanges {
    private loginService;
    /** Flag to indicate if data is currently being loaded */
    loading: boolean;
    /** Stores the user profile information */
    user?: UserInfo;
    /** Controls the visibility of the change password dialog */
    changePasswordWindowOpened: boolean;
    /**
     * Initializes the component with the LoginService for user data management
     * @param loginService Service that handles user authentication and profile data
     */
    constructor(loginService: LoginService);
    /**
     * Lifecycle hook that initializes the component
     * Loads the user profile data from the login service upon component initialization
     * Sets loading flags appropriately during the data fetch process
     */
    ngOnInit(): void;
    /**
     * Lifecycle hook that responds to changes in input properties
     * Currently not implementing any specific behavior
     * @param changes SimpleChanges object containing current and previous property values
     */
    ngOnChanges(changes: SimpleChanges): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<GeboAIUserProfileComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<GeboAIUserProfileComponent, "gebo-ai-current-user-profile", never, {}, {}, never, never, false, never>;
}
