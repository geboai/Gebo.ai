/**
 * This Source Code is subject to the terms of the
 * Gebo.ai community version Mozilla Public License Version 2.0 (MPL-2.0) — With Data Protection Clauses
 * If a copy of the LICENCE was not distributed with this file, You can obtain one at
 * https://gebo.ai/gebo-ai-community-version-mozilla-public-license-version-2-0-mpl-2-0-with-data-protection-clauses/
 * and https://mozilla.org/MPL/2.0/.
 * Copyright (c) 2025+ Gebo.ai
 */
/**
 * AI generated comments
 *
 * This file contains the EditableListboxComponent, which provides a customizable dropdown/listbox
 * that can display selectable options and optionally allow creating new entries.
 * The component implements ControlValueAccessor to integrate with Angular's form controls.
 */
import { ChangeDetectorRef, EventEmitter, OnChanges, OnInit, SimpleChanges } from "@angular/core";
import { ControlValueAccessor, NgControl } from "@angular/forms";
import { Observable } from "rxjs";
import { GeboUIActionRequest } from "../../architecture/actions.model";
import { GeboUIActionRoutingService } from "../../architecture/gebo-ui-action-routing.service";
import { SelectChangeEvent } from "primeng/select";
import * as i0 from "@angular/core";
/**
 * EditableListboxComponent provides a dropdown/listbox component that can display a list of options and
 * optionally allow creation of new records.
 *
 * Features:
 * - Integrates with Angular forms via ControlValueAccessor
 * - Can load options from an Observable or static data array
 * - Supports creating new items through a configurable action request
 * - Can automatically select an option when there's only one available
 * - Provides loading state indication
 */
export declare class EditableListboxComponent implements ControlValueAccessor, OnInit, OnChanges {
    private changeDetection;
    ngControl: NgControl;
    private actionsService?;
    /** Unique code to identify when "Create new" option is selected */
    createNewValueCodeConstant: string;
    /** Object representing the "Create new" option */
    private newRecordSelectable;
    /** Flag indicating data is being loaded */
    loading: boolean;
    /** Available options for the dropdown */
    options?: {
        code?: string;
        description?: string;
    }[];
    /** Currently selected option */
    selectedOption?: {
        code?: string;
        description?: string;
    };
    /** Flag indicating if the component is disabled */
    disabled: boolean;
    /** Whether to automatically select an option when there's only one available */
    onSingleOptionAutomaticallySelect: boolean;
    /** Placeholder text to display when no option is selected */
    placeholder?: string;
    /** Flag indicating if the component is in readonly mode */
    readonly: boolean;
    required?: boolean;
    /** The current value of the component */
    value?: string;
    /** Observable to fetch options dynamically */
    optionsObservable?: Observable<{
        code?: string;
        description?: string;
    }[]>;
    /** Static data array to populate options */
    data?: {
        code?: string;
        description?: string;
    }[];
    /** Configuration for creating new records */
    createNewRecordRequest?: GeboUIActionRequest;
    /** Event emitted when selection changes */
    selectionChanged: EventEmitter<any>;
    /**
     * Determines if the "Create new" option should be available
     * @returns True if the component is configured to support creating new records
     */
    private get canCreateRecord();
    /**
     * Creates an instance of EditableListboxComponent
     * @param changeDetection Reference to Angular's change detection mechanism
     * @param actionsService Service for routing UI actions
     */
    constructor(changeDetection: ChangeDetectorRef, ngControl: NgControl, actionsService?: GeboUIActionRoutingService | undefined);
    /**
     * Determines if the field is required based on input or validator
     */
    get isRequired(): boolean;
    /**
     * Angular lifecycle hook called after component initialization
     */
    ngOnInit(): void;
    /**
     * Opens the edit window for creating a new record
     * Configures the action request and handles responses from the edit window
     */
    private doOpenEditWindow;
    /**
     * Automatically selects an option if there's only one available and the auto-select flag is enabled
     * or if the field is required.
     */
    private checkSingleOptionPresent;
    /**
     * Reloads the options data from either the observable or static data array
     * Adds the "Create new" option if enabled
     */
    private reloadData;
    /**
     * Angular lifecycle hook that responds to input changes
     * Reloads data when the options observable or data array changes
     * @param changes SimpleChanges object containing changed properties
     */
    ngOnChanges(changes: SimpleChanges): void;
    /**
     * ControlValueAccessor method to write a value to the component
     * @param obj The value to write
     */
    writeValue(obj: any): void;
    /** Function to call when the value changes */
    onChange?: (v: any) => void;
    /**
     * ControlValueAccessor method to register a callback to be triggered when the value changes
     * @param fn The callback function
     */
    registerOnChange(fn: any): void;
    /** Function to call when the control is touched */
    onTouch?: (v: any) => void;
    /**
     * ControlValueAccessor method to register a callback to be triggered when the control is touched
     * @param fn The callback function
     */
    registerOnTouched(fn: any): void;
    /**
     * ControlValueAccessor method to enable/disable the component
     * @param isDisabled Whether the component should be disabled
     */
    setDisabledState?(isDisabled: boolean): void;
    /**
     * Finds and selects the option that matches the current value
     * Updates the UI through change detection
     */
    private selectCorrectValue;
    /**
     * Handles value change events from the UI
     * Opens the edit window if "Create new" is selected
     * @param event The selection change event
     */
    changedValue(event: SelectChangeEvent): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<EditableListboxComponent, [null, { optional: true; self: true; }, null]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<EditableListboxComponent, "geboai-editable-listbox-component", never, { "loading": { "alias": "loading"; "required": false; }; "onSingleOptionAutomaticallySelect": { "alias": "onSingleOptionAutomaticallySelect"; "required": false; }; "placeholder": { "alias": "placeholder"; "required": false; }; "readonly": { "alias": "readonly"; "required": false; }; "required": { "alias": "required"; "required": false; }; "optionsObservable": { "alias": "optionsObservable"; "required": false; }; "data": { "alias": "data"; "required": false; }; "createNewRecordRequest": { "alias": "createNewRecordRequest"; "required": false; }; }, { "selectionChanged": "selectionChanged"; }, never, never, false, never>;
}
