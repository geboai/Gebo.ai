/**
 * This Source Code is subject to the terms of the
 * Gebo.ai community version Mozilla Public License Version 2.0 (MPL-2.0) — With Data Protection Clauses
 * If a copy of the LICENCE was not distributed with this file, You can obtain one at
 * https://gebo.ai/gebo-ai-community-version-mozilla-public-license-version-2-0-mpl-2-0-with-data-protection-clauses/
 * and https://mozilla.org/MPL/2.0/.
 * Copyright (c) 2025+ Gebo.ai
 */
/**
 * AI generated comments
 *
 * This module provides a component that adapts an editable listbox for use with object data.
 * It implements ControlValueAccessor to work with Angular forms, allowing binding to objects
 * with code and description properties.
 */
import { EventEmitter, OnChanges, OnInit, SimpleChanges } from "@angular/core";
import { ControlValueAccessor, FormControl } from "@angular/forms";
import { Observable } from "rxjs";
import { GeboUIActionRequest } from "../../architecture/actions.model";
import * as i0 from "@angular/core";
/**
 * A component that wraps an editable listbox component for binding to objects with code/description properties.
 * It serves as an adapter that handles the communication between form controls and the underlying editable listbox.
 * Implements ControlValueAccessor to work within Angular's form ecosystem.
 */
export declare class EditableListboxBoundObjectAdapterComponent implements ControlValueAccessor, OnInit, OnChanges {
    /** Indicates whether data is currently being loaded */
    loading: boolean;
    /** The currently selected object value with code and description */
    value?: {
        code?: string;
        description?: string;
    };
    /** Controls whether a single option should be automatically selected */
    onSingleOptionAutomaticallySelect: boolean;
    /** Placeholder text to display when no value is selected */
    placeholder?: string;
    /** Controls whether the component is in read-only mode */
    readonly: boolean;
    /** Form control for managing the selected value */
    formControl: FormControl;
    /** Observable that provides the options data */
    optionsObservable?: Observable<{
        code?: string;
        description?: string;
    }[]>;
    /** Static data array for options */
    data?: {
        code?: string;
        description?: string;
    }[];
    /** Configuration for creating new records */
    createNewRecordRequest?: GeboUIActionRequest;
    /** The processed data source used by the component */
    dataSource?: {
        code?: string;
        description?: string;
    }[];
    /** Event emitter for selection changes */
    selectionChanged: EventEmitter<any>;
    /**
     * Lifecycle hook that is called after data-bound properties are initialized
     */
    ngOnInit(): void;
    /**
     * Lifecycle hook that is called when any data-bound property changes
     * Handles updates to data sources and subscribes to observables when provided
     * @param changes Object containing all changed properties
     */
    ngOnChanges(changes: SimpleChanges): void;
    /** Function to call when the value changes */
    onChange?: (v: any) => void;
    /**
     * Registers a callback function that is called when the control's value changes in the UI
     * Part of the ControlValueAccessor interface
     * @param fn The callback function to register
     */
    registerOnChange(fn: any): void;
    /** Function to call when the control receives a touch event */
    onTouch?: (v: any) => void;
    /**
     * Registers a callback function that is called when the control receives a touch event
     * Part of the ControlValueAccessor interface
     * @param fn The callback function to register
     */
    registerOnTouched(fn: any): void;
    /**
     * Used by the forms API to disable the control
     * @param isDisabled Whether the control should be disabled
     */
    setDisabledState?(isDisabled: boolean): void;
    /**
     * Writes a new value to the element
     * Part of the ControlValueAccessor interface
     * @param obj The new value to write
     */
    writeValue(obj: any): void;
    /**
     * Handles selection change events from the inner component
     * Updates the current value and notifies Angular forms system of changes
     * @param chaData The selected code value
     */
    onSelectionChanged(chaData?: any): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<EditableListboxBoundObjectAdapterComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<EditableListboxBoundObjectAdapterComponent, "geboai-editable-listbox-bound-object-component", never, { "onSingleOptionAutomaticallySelect": { "alias": "onSingleOptionAutomaticallySelect"; "required": false; }; "placeholder": { "alias": "placeholder"; "required": false; }; "readonly": { "alias": "readonly"; "required": false; }; "optionsObservable": { "alias": "optionsObservable"; "required": false; }; "data": { "alias": "data"; "required": false; }; "createNewRecordRequest": { "alias": "createNewRecordRequest"; "required": false; }; }, { "selectionChanged": "selectionChanged"; }, never, never, false, never>;
}
