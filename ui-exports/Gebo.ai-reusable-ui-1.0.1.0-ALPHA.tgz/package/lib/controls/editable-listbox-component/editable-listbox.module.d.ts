import * as i0 from "@angular/core";
import * as i1 from "./editable-listbox.component";
import * as i2 from "./editable-listbox-bound-object-adapter.component";
import * as i3 from "@angular/common";
import * as i4 from "@angular/forms";
import * as i5 from "primeng/select";
import * as i6 from "primeng/blockui";
import * as i7 from "primeng/dialog";
import * as i8 from "primeng/button";
export declare class EditableListboxModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<EditableListboxModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<EditableListboxModule, [typeof i1.EditableListboxComponent, typeof i2.EditableListboxBoundObjectAdapterComponent], [typeof i3.CommonModule, typeof i4.ReactiveFormsModule, typeof i4.FormsModule, typeof i5.SelectModule, typeof i6.BlockUIModule, typeof i7.DialogModule, typeof i8.ButtonModule], [typeof i1.EditableListboxComponent, typeof i2.EditableListboxBoundObjectAdapterComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<EditableListboxModule>;
}
