import * as i0 from "@angular/core";
import * as i1 from "./string-list.component";
import * as i2 from "@angular/common";
import * as i3 from "@angular/forms";
import * as i4 from "primeng/button";
import * as i5 from "primeng/chip";
import * as i6 from "primeng/dialog";
import * as i7 from "primeng/panel";
import * as i8 from "primeng/inputtext";
export declare class GeboAIStringListModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<GeboAIStringListModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<GeboAIStringListModule, [typeof i1.GeboAIStringListComponent], [typeof i2.CommonModule, typeof i3.ReactiveFormsModule, typeof i3.FormsModule, typeof i4.ButtonModule, typeof i5.ChipModule, typeof i5.ChipModule, typeof i6.DialogModule, typeof i7.PanelModule, typeof i8.InputTextModule], [typeof i1.GeboAIStringListComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<GeboAIStringListModule>;
}
