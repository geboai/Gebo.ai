/**
 * This Source Code is subject to the terms of the
 * Gebo.ai community version Mozilla Public License Version 2.0 (MPL-2.0) — With Data Protection Clauses
 * If a copy of the LICENCE was not distributed with this file, You can obtain one at
 * https://gebo.ai/gebo-ai-community-version-mozilla-public-license-version-2-0-mpl-2-0-with-data-protection-clauses/
 * and https://mozilla.org/MPL/2.0/.
 * Copyright (c) 2025+ Gebo.ai
 */
/**
 * AI generated comments
 *
 * A component that allows users to manage a list of strings with specific validation rules.
 * This component implements ControlValueAccessor to integrate with Angular's form controls.
 * It supports different types of string validation like URLs and hostnames with protocol options.
 */
import { OnChanges, OnInit, SimpleChanges } from "@angular/core";
import { ControlValueAccessor, FormArray, FormBuilder, FormGroup } from "@angular/forms";
import * as i0 from "@angular/core";
export declare class GeboAIStringListComponent implements OnInit, OnChanges, ControlValueAccessor {
    private fb;
    /** Title to display for the string list */
    title?: string;
    /** Types of strings allowed in the list (url or hostname) */
    allowedTypes: ("url" | "hostname")[];
    /** Allowed protocols for the URLs (none, http, https, ftp) */
    allowedProtocols: ("none" | "http" | "https" | "ftp")[];
    /** Whether the component is in read-only mode */
    readonly: boolean;
    /** Form array to manage the string entries */
    formArray?: FormArray;
    /** Internal storage for the string values */
    internalValue: string[];
    /** Flag to control the visibility of the edit window */
    openEditWindow: boolean;
    /**
     * Initializes the component with an empty form array
     * @param fb FormBuilder service for creating form controls
     */
    constructor(fb: FormBuilder);
    /**
     * Creates an array of protocol prefixes based on the allowed protocols
     * @returns Array of protocol prefixes (e.g., "http://", "https://")
     */
    private allowedPrefixes;
    /**
     * Adds a new row to the form array
     * @param value Optional initial value for the new row
     * @param options Optional configuration options, including whether to emit an event
     */
    addRow(value?: string, options?: {
        emitEvent?: boolean;
    }): void;
    /**
     * Removes a row from the form array at the specified index
     * @param index The index of the row to remove
     * @param options Optional configuration options, including whether to emit an event
     */
    removeRow(index: number, options?: {
        emitEvent?: boolean;
    }): void;
    /**
     * Clears all data from the form array
     * @param options Optional configuration options, including whether to emit an event
     */
    clearData(options?: {
        emitEvent?: boolean;
    }): void;
    /**
     * Updates the form array with a new set of values
     * @param newValue Array of string values to populate the form
     */
    private editValue;
    /**
     * Gets a FormGroup from the form array at the specified index
     * @param index The index of the FormGroup to retrieve
     * @returns The FormGroup at the specified index
     */
    getFg(index: number): FormGroup<any>;
    /**
     * Opens the edit mode by populating the form array with the current values
     */
    openEditMode(): void;
    /**
     * Removes an item from the main panel at the specified index
     * @param i The index of the item to remove
     */
    removeFromMainPanel(i: number): void;
    /**
     * Confirms the current values in the form array
     * This method appears to be incomplete as it only retrieves the values but doesn't update anything
     */
    confirmValue(): void;
    /**
     * Angular lifecycle hook that is called after component initialization
     */
    ngOnInit(): void;
    /**
     * Angular lifecycle hook that is called when input properties change
     * @param changes SimpleChanges object containing the changed properties
     */
    ngOnChanges(changes: SimpleChanges): void;
    /**
     * ControlValueAccessor method to write a value to the component
     * @param obj The value to write
     */
    writeValue(obj: any): void;
    /**
     * Function to call when the value changes
     */
    private onChange;
    /**
     * ControlValueAccessor method to register a callback function for change events
     * @param fn The callback function
     */
    registerOnChange(fn: any): void;
    /**
     * Function to call when the control is touched
     */
    private onTouched;
    /**
     * ControlValueAccessor method to register a callback function for touched events
     * @param fn The callback function
     */
    registerOnTouched(fn: any): void;
    /**
     * ControlValueAccessor method to set the disabled state of the component
     * @param isDisabled Whether the component should be disabled
     */
    setDisabledState?(isDisabled: boolean): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<GeboAIStringListComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<GeboAIStringListComponent, "gebo-ai-strings-list-component", never, { "title": { "alias": "title"; "required": false; }; "allowedTypes": { "alias": "allowedTypes"; "required": false; }; "allowedProtocols": { "alias": "allowedProtocols"; "required": false; }; "readonly": { "alias": "readonly"; "required": false; }; }, {}, never, never, false, never>;
}
