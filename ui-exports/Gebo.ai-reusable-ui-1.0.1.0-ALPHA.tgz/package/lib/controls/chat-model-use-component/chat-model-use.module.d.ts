import * as i0 from "@angular/core";
import * as i1 from "./chat-model-use.component";
import * as i2 from "@angular/common";
import * as i3 from "@angular/forms";
import * as i4 from "primeng/checkbox";
export declare class GeboAIChatModelUseModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<GeboAIChatModelUseModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<GeboAIChatModelUseModule, [typeof i1.GeboAIChatModelUseComponent], [typeof i2.CommonModule, typeof i3.ReactiveFormsModule, typeof i3.FormsModule, typeof i4.CheckboxModule], [typeof i1.GeboAIChatModelUseComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<GeboAIChatModelUseModule>;
}
