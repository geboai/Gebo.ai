import { OnInit } from "@angular/core";
import { ControlValueAccessor, FormGroup } from "@angular/forms";
import { GBaseChatModelConfig } from "@Gebo.ai/gebo-ai-rest-api";
import { GeboAITranslationService } from "../field-translation-container/gebo-translation.service";
import * as i0 from "@angular/core";
export declare class GeboAIChatModelUseComponent implements ControlValueAccessor, OnInit {
    private geboTranslation;
    protected formGroup: FormGroup;
    private chatModelUses;
    protected options: {
        code: GBaseChatModelConfig.ForUsesEnum;
        description: string;
    }[];
    placeholder: string;
    constructor(geboTranslation: GeboAITranslationService);
    ngOnInit(): void;
    writeValue(obj: any): void;
    private onChange;
    registerOnChange(fn: any): void;
    private onTouch;
    registerOnTouched(fn: any): void;
    setDisabledState?(isDisabled: boolean): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<GeboAIChatModelUseComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<GeboAIChatModelUseComponent, "gebo-ai-chat-model-use-component", never, { "placeholder": { "alias": "placeholder"; "required": false; }; }, {}, never, never, false, never>;
}
//# sourceMappingURL=chat-model-use.component.d.ts.map