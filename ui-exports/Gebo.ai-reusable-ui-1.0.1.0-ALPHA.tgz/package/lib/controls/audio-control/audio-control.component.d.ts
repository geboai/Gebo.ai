/**
 * This Source Code is subject to the terms of the
 * Gebo.ai community version Mozilla Public License Version 2.0 (MPL-2.0) — With Data Protection Clauses
 * If a copy of the LICENCE was not distributed with this file, You can obtain one at
 * https://gebo.ai/gebo-ai-community-version-mozilla-public-license-version-2-0-mpl-2-0-with-data-protection-clauses/
 * and https://mozilla.org/MPL/2.0/.
 * Copyright (c) 2025+ Gebo.ai
 */
/**
 * AI generated comments
 *
 * This component provides audio recording and playback functionality.
 * It allows users to record audio through their device's microphone and play back
 * previously recorded or provided audio. The component implements lifecycle hooks
 * to handle initialization, changes to inputs, and cleanup.
 */
import { EventEmitter, OnChanges, OnDestroy, OnInit, SimpleChanges } from "@angular/core";
import * as i0 from "@angular/core";
export declare class GeboAIAudioControlComponent implements OnInit, OnChanges, OnDestroy {
    /** Indicates whether audio recording is in progress */
    recording: boolean;
    /** Indicates if there was an error during recording */
    errorState: boolean;
    /** MediaRecorder instance used to capture audio */
    private mediaRecorder?;
    /** Array to store audio data chunks during recording */
    private audioChunks;
    /** Indicates if audio is currently playing */
    playMode: boolean;
    /** Indicates if audio playback is paused */
    playPaused: boolean;
    /** Input to disable the audio control component */
    disabled: boolean;
    viewLabels: boolean;
    /** Input for audio blob to be played */
    playAudioTrack?: Blob;
    /** Event emitter that fires when audio recording is completed */
    onAudioTrack: EventEmitter<Blob>;
    /**
     * Lifecycle hook that is called after data-bound properties are initialized
     */
    ngOnInit(): void;
    /**
     * Lifecycle hook that is called when any data-bound property changes
     * Starts audio playback when playAudioTrack input changes
     */
    ngOnChanges(changes: SimpleChanges): void;
    /**
     * Lifecycle hook that is called when the component is destroyed
     */
    ngOnDestroy(): void;
    /** HTML Audio element for playback control */
    private audio?;
    /**
     * Starts playing the audio track that was provided as input
     * Creates an audio element and begins playback
     */
    play(): void;
    /**
     * Pauses the currently playing audio
     */
    pausePlay(): void;
    /**
     * Resumes playback of a paused audio track
     */
    continuePlay(): void;
    /**
     * Cancels an ongoing recording session and discards any recorded data
     */
    abortRecording(): void;
    /**
     * Begins recording audio from the user's microphone
     * Handles browser permissions and sets up the MediaRecorder
     */
    startRecording(): void;
    /**
     * Stops the current recording, processes the audio data,
     * and emits the completed audio blob to parent components
     */
    stopRecording(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<GeboAIAudioControlComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<GeboAIAudioControlComponent, "gebo-ai-audio-component", never, { "disabled": { "alias": "disabled"; "required": false; }; "viewLabels": { "alias": "viewLabels"; "required": false; }; "playAudioTrack": { "alias": "playAudioTrack"; "required": false; }; }, { "onAudioTrack": "onAudioTrack"; }, never, never, false, never>;
}
//# sourceMappingURL=audio-control.component.d.ts.map