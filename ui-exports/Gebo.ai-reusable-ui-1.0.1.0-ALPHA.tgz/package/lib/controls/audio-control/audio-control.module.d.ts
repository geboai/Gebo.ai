import * as i0 from "@angular/core";
import * as i1 from "./audio-control.component";
import * as i2 from "@angular/common";
import * as i3 from "@angular/forms";
import * as i4 from "primeng/button";
import * as i5 from "../field-translation-container/field-container.module";
/**
 * AI generated comments
 *
 * This module provides audio recording functionality for Gebo AI applications.
 * It encapsulates the GeboAIAudioControlComponent which handles audio recording and playback.
 * The module imports common Angular modules and PrimeNG's ButtonModule for UI elements,
 * declares the audio control component, and exports it for use in other modules.
 */
export declare class GeboAIAudioRecorderModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<GeboAIAudioRecorderModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<GeboAIAudioRecorderModule, [typeof i1.GeboAIAudioControlComponent], [typeof i2.CommonModule, typeof i3.ReactiveFormsModule, typeof i4.ButtonModule, typeof i5.GeboAIFieldTranslationContainerModule], [typeof i1.GeboAIAudioControlComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<GeboAIAudioRecorderModule>;
}
//# sourceMappingURL=audio-control.module.d.ts.map