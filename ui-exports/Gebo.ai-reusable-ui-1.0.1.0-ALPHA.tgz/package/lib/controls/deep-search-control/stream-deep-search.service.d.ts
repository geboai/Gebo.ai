import { DeepSearchRequest, GeboChatRequest } from "@Gebo.ai/gebo-ai-rest-api";
import { GeboAIBaseStreamingService } from "../../services/base-streaming.service";
import { IGeboChatMessage } from "../../services/gebo-chat-message";
import * as i0 from "@angular/core";
export declare class GeboAIStreamDeepSearchService extends GeboAIBaseStreamingService {
    private basePath;
    constructor(basePath: string);
    streamDeepSearch(request: DeepSearchRequest, onMessage: (msg: IGeboChatMessage | string) => void, onError?: (err: any) => void): void;
    streamDeepSearchInChat(request: GeboChatRequest, onMessage: (msg: IGeboChatMessage | string) => void, onError?: (err: any) => void): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<GeboAIStreamDeepSearchService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<GeboAIStreamDeepSearchService>;
}
