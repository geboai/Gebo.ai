import { EventEmitter, OnChanges, OnInit, SimpleChanges } from "@angular/core";
import { FormGroup } from "@angular/forms";
import { GeboChatRequest } from "@Gebo.ai/gebo-ai-rest-api";
import * as i0 from "@angular/core";
export declare class GeboAIDeepSearchComponent implements OnInit, OnChanges {
    currentChatRequest?: GeboChatRequest;
    nextRequestMode: "standard-chat" | "deep-search";
    chatProfileCode?: string;
    skipDeepSearchEvent: EventEmitter<boolean>;
    protected selectedDeepSearchDataSources?: string[];
    protected selectedKnowledgeBases?: string[];
    protected programmaticStreaming: boolean;
    protected formGroup: FormGroup;
    constructor();
    ngOnInit(): void;
    ngOnChanges(changes: SimpleChanges): void;
    protected onSourcesChoosed(): void;
    protected skipDeepSearchOnDataSourceChoice(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<GeboAIDeepSearchComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<GeboAIDeepSearchComponent, "gebo-ai-deep-search-component", never, { "currentChatRequest": { "alias": "currentChatRequest"; "required": false; }; "nextRequestMode": { "alias": "nextRequestMode"; "required": false; }; "chatProfileCode": { "alias": "chatProfileCode"; "required": false; }; }, { "skipDeepSearchEvent": "skipDeepSearchEvent"; }, never, never, false, never>;
}
