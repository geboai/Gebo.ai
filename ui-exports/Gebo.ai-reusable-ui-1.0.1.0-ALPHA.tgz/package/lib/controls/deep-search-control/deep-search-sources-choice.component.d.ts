import { EventEmitter, OnChanges, OnInit, SimpleChanges } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { GBaseObject, GeboChatControllerService, GeboDeepSearchControllerService, GeboRagChatControllerService } from '@Gebo.ai/gebo-ai-rest-api';
import * as i0 from "@angular/core";
export interface IChooseSources {
    deepSearchDataSources?: string[];
    knowledgeBases?: string[];
}
export declare class GeboAIDeepSearchSoucesChoiceComponent implements OnInit, OnChanges {
    private deepSearchControllerService;
    private ragChatService;
    private chatService;
    chatProfileCode?: string;
    nextRequestMode: "standard-chat" | "deep-search";
    programmaticStreaming: boolean;
    visible: boolean;
    visibleChange: EventEmitter<boolean>;
    deepSearchDataSources?: string[];
    deepSearchDataSourcesChange: EventEmitter<string[]>;
    knowledgeBases?: string[];
    knowledgeBasesChange: EventEmitter<string[]>;
    onChoosed: EventEmitter<IChooseSources>;
    onSkip: EventEmitter<void>;
    protected choosableDataSources: GBaseObject[];
    protected choosableKnowledgeBases: GBaseObject[];
    protected loadingRelatedBackend: boolean;
    protected chooseDeepSearchDataSourcesFormGroup: FormGroup;
    constructor(deepSearchControllerService: GeboDeepSearchControllerService, ragChatService: GeboRagChatControllerService, chatService: GeboChatControllerService);
    ngOnInit(): void;
    ngOnChanges(changes: SimpleChanges): void;
    private chooseSources;
    private chooseDataSources;
    protected doChoosedSources(): void;
    protected skipDeepSearchOnDataSourceChoice(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<GeboAIDeepSearchSoucesChoiceComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<GeboAIDeepSearchSoucesChoiceComponent, "gebo-ai-deep-search-sources-choice", never, { "chatProfileCode": { "alias": "chatProfileCode"; "required": false; }; "nextRequestMode": { "alias": "nextRequestMode"; "required": false; }; "programmaticStreaming": { "alias": "programmaticStreaming"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "deepSearchDataSources": { "alias": "deepSearchDataSources"; "required": false; }; "knowledgeBases": { "alias": "knowledgeBases"; "required": false; }; }, { "visibleChange": "visibleChange"; "deepSearchDataSourcesChange": "deepSearchDataSourcesChange"; "knowledgeBasesChange": "knowledgeBasesChange"; "onChoosed": "onChoosed"; "onSkip": "onSkip"; }, never, never, false, never>;
}
