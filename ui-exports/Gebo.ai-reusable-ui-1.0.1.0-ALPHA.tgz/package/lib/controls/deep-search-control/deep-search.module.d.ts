import * as i0 from "@angular/core";
import * as i1 from "./deep-search.component";
import * as i2 from "./deep-search-details.component";
import * as i3 from "./deep-search-sources-choice.component";
import * as i4 from "@angular/common";
import * as i5 from "@angular/forms";
import * as i6 from "primeng/tabs";
import * as i7 from "primeng/button";
import * as i8 from "primeng/fieldset";
import * as i9 from "primeng/panel";
import * as i10 from "primeng/blockui";
import * as i11 from "../field-translation-container/field-container.module";
import * as i12 from "primeng/progressbar";
import * as i13 from "primeng/dialog";
import * as i14 from "primeng/selectbutton";
import * as i15 from "../../notifications/notifications.module";
import * as i16 from "ngx-markdown";
import * as i17 from "primeng/accordion";
export declare class GeboAIDeepSearchModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<GeboAIDeepSearchModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<GeboAIDeepSearchModule, [typeof i1.GeboAIDeepSearchComponent, typeof i2.GeboAIDeepSearchDetailsComponent, typeof i3.GeboAIDeepSearchSoucesChoiceComponent], [typeof i4.CommonModule, typeof i5.ReactiveFormsModule, typeof i5.FormsModule, typeof i6.TabsModule, typeof i7.ButtonModule, typeof i8.FieldsetModule, typeof i9.PanelModule, typeof i10.BlockUIModule, typeof i11.GeboAIFieldTranslationContainerModule, typeof i12.ProgressBarModule, typeof i13.DialogModule, typeof i14.SelectButtonModule, typeof i8.FieldsetModule, typeof i15.GeboAINotificationsModule, typeof i16.MarkdownComponent, typeof i17.AccordionModule], [typeof i1.GeboAIDeepSearchComponent, typeof i2.GeboAIDeepSearchDetailsComponent, typeof i3.GeboAIDeepSearchSoucesChoiceComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<GeboAIDeepSearchModule>;
}
