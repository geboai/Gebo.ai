import * as i0 from "@angular/core";
import * as i1 from "./deep-search.component";
import * as i2 from "./deep-search-sources-choice.component";
import * as i3 from "@angular/common";
import * as i4 from "@angular/forms";
import * as i5 from "primeng/tabs";
import * as i6 from "primeng/button";
import * as i7 from "primeng/fieldset";
import * as i8 from "primeng/panel";
import * as i9 from "primeng/blockui";
import * as i10 from "../field-translation-container/field-container.module";
import * as i11 from "primeng/progressbar";
import * as i12 from "primeng/dialog";
import * as i13 from "primeng/selectbutton";
import * as i14 from "../../notifications/notifications.module";
import * as i15 from "ngx-markdown";
import * as i16 from "primeng/accordion";
export declare class GeboAIDeepSearchModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<GeboAIDeepSearchModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<GeboAIDeepSearchModule, [typeof i1.GeboAIDeepSearchComponent, typeof i2.GeboAIDeepSearchSoucesChoiceComponent], [typeof i3.CommonModule, typeof i4.ReactiveFormsModule, typeof i4.FormsModule, typeof i5.TabsModule, typeof i6.ButtonModule, typeof i7.FieldsetModule, typeof i8.PanelModule, typeof i9.BlockUIModule, typeof i10.GeboAIFieldTranslationContainerModule, typeof i11.ProgressBarModule, typeof i12.DialogModule, typeof i13.SelectButtonModule, typeof i7.FieldsetModule, typeof i14.GeboAINotificationsModule, typeof i15.MarkdownComponent, typeof i16.AccordionModule], [typeof i1.GeboAIDeepSearchComponent, typeof i2.GeboAIDeepSearchSoucesChoiceComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<GeboAIDeepSearchModule>;
}
//# sourceMappingURL=deep-search.module.d.ts.map