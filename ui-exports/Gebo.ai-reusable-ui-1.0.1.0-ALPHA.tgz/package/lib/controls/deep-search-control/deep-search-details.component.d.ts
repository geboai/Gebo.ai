import { OnChanges, OnInit, SimpleChanges } from "@angular/core";
import { DeepSearchDataSourceDocumentResult, DeepSearchDocumentAnalisysResultStep, DeepSearchResponse, GeboDeepSearchControllerService } from "@Gebo.ai/gebo-ai-rest-api";
import * as i0 from "@angular/core";
export declare class GeboAIDeepSearchDetailsComponent implements OnInit, OnChanges {
    private deepSearchService;
    deepSearchRequestCode?: string;
    protected data: (DeepSearchDataSourceDocumentResult | DeepSearchDocumentAnalisysResultStep)[];
    protected result?: DeepSearchResponse;
    protected loading: boolean;
    protected thereAreDetails: boolean;
    protected listIsShowed: boolean;
    constructor(deepSearchService: GeboDeepSearchControllerService);
    ngOnInit(): void;
    toggleShowedList(): void;
    loadData(code: string): void;
    checkDetailsPresent(code: string): void;
    ngOnChanges(changes: SimpleChanges): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<GeboAIDeepSearchDetailsComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<GeboAIDeepSearchDetailsComponent, "gebo-ai-deep-search-details", never, { "deepSearchRequestCode": { "alias": "deepSearchRequestCode"; "required": false; }; }, {}, never, never, false, never>;
}
