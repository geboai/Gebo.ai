import { BaseEntityEditingComponent } from "./base-entity-editing.component";
import { Observable } from "rxjs";
import * as i0 from "@angular/core";
export declare abstract class BaseEntityEditingComponentAutoDeleteCheck<RecordType extends {
    code?: string;
    description?: string;
}> extends BaseEntityEditingComponent<RecordType> {
    canBeDeleted(value: RecordType): Observable<{
        canBeDeleted: boolean;
        message: string;
    }>;
    static ɵfac: i0.ɵɵFactoryDeclaration<BaseEntityEditingComponentAutoDeleteCheck<any>, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<BaseEntityEditingComponentAutoDeleteCheck<any>, "base-entity-auto-delete-component", never, {}, {}, never, never, false, never>;
}
