/**
 * This Source Code is subject to the terms of the
 * Gebo.ai community version Mozilla Public License Version 2.0 (MPL-2.0) — With Data Protection Clauses
 * If a copy of the LICENCE was not distributed with this file, You can obtain one at
 * https://gebo.ai/gebo-ai-community-version-mozilla-public-license-version-2-0-mpl-2-0-with-data-protection-clauses/
 * and https://mozilla.org/MPL/2.0/.
 * Copyright (c) 2025+ Gebo.ai
 */
/**
 * AI generated comments
 *
 * BaseEntityEditingComponent is an abstract class that provides a foundation for entity editing components
 * in Angular applications. It handles the common functionality for creating, editing, deleting,
 * and validating entities with form controls. This component also supports wizard-based workflows
 * for multi-step entity editing processes.
 *
 * The component manages various states including loading, validation, backend operations,
 * and user messages, providing a consistent interface for entity management operations.
 */
import { EventEmitter, Injector, OnChanges, OnDestroy, OnInit, SimpleChanges } from "@angular/core";
import { FormGroup } from "@angular/forms";
import { ToastMessageOptions } from "primeng/api";
import { Observable, Subject } from "rxjs";
import { GeboUIOutputForwardingService } from "../../architecture/gebo-ui-output-forwarding.service";
import { GeboFormGroupsService } from "../../architecture/gebo-form-groups.service";
import { ConfirmationService } from "primeng/api";
import { GObjectRef, GUserMessage } from "@Gebo.ai/gebo-ai-rest-api";
import { GeboAIEntitiesSettingWizardConfiguration } from "./entities-modification-wizard";
import { IOperationStatus } from "./operation-status";
import { GeboWizardActionPerformedCallback } from "../../architecture/actions.model";
import { GeboUIActionRoutingService } from "../../architecture/gebo-ui-action-routing.service";
import { GeboAIFieldHost } from "../field-host-component-iface/field-host-component-iface";
import * as i0 from "@angular/core";
/**
 * Base component for entity editing functionality that can be extended by specific entity editors.
 * This component provides standard CRUD operations, validation handling, and wizard step navigation.
 *
 * @template RecordType - The type of entity being edited, which should include optional code and description properties
 */
export declare abstract class BaseEntityEditingComponent<RecordType extends {
    code?: string;
    description?: string;
}> implements OnInit, OnChanges, OnDestroy, GeboAIFieldHost {
    protected injector: Injector;
    private geboFormGroupsService;
    private confirmationService;
    private geboUIActionRoutingService;
    private outputForwardingService?;
    /** Flag to track if a save operation is in progress */
    private savingBackend;
    /** Flag to track if a delete operation is in progress */
    private deletingBackend;
    /** Flag to track if duplicate checking is in progress */
    private checkingDuplicatesBackend;
    /** Flag to track if a can-be-deleted check is in progress */
    private canBeDeletedCheckBackend;
    /** Flag to track if controls are being loaded */
    private missingControlLoading;
    /** Flag to track if related backend operations are in progress */
    protected loadingRelatedBackend: boolean;
    protected manageOperationStatus: boolean;
    /** Backend class name for object reference */
    protected backendClassName?: string;
    /** Flag to track if code was not present */
    codeWhasNotPresent: boolean;
    /** Flag to determine if entity can be deleted */
    canDelete: boolean;
    /** Collection of messages to display to the user */
    userMessages: ToastMessageOptions[];
    /** Flag to determine if entity can be saved */
    canSave: boolean;
    /** Reference to the object in the backend */
    objectReference?: GObjectRef;
    /** Flag to indicate if entity data has been loaded */
    entityDataLoaded: boolean;
    /** Flag to indicate if backend processing is running */
    relatedBackendProcessingRunning: boolean;
    /** Flag to enable periodic backend processing checks */
    protected doPeriodicBackendProcessingCheck: boolean;
    /** Abstract property for the entity name that must be defined by child classes */
    protected abstract entityName: string;
    /** Last operation status for tracking results of operations */
    private lastOperationStatus?;
    /** Timer for periodic validation checks */
    private programmed?;
    private _msgsSubscription?;
    /**
     * Returns the name of the entity being edited
     */
    get actualEntityName(): string;
    /** The mode of operation: NEW, EDIT, or EDIT_OR_NEW */
    mode: "NEW" | "EDIT" | "EDIT_OR_NEW";
    /** Storage for wizard session data */
    wizardSessionStorage?: any;
    /** Configuration for wizard steps */
    wizardStepsConfigurations?: GeboAIEntitiesSettingWizardConfiguration[];
    /** Callback for when a wizard action is performed */
    onWizardActionPerformed?: GeboWizardActionPerformedCallback;
    /** ID of the current wizard step configuration */
    actualWizardStepConfigrationId?: string;
    /** The entity being edited */
    entity?: RecordType;
    /** Event emitted when a new entity is created */
    createdNew: EventEmitter<RecordType>;
    /** Event emitted when an entity is updated */
    updated: EventEmitter<RecordType>;
    /** Event emitted when an entity is deleted */
    deleted: EventEmitter<boolean>;
    /** Event emitted when editing is cancelled */
    cancelAction: EventEmitter<boolean>;
    /** Subject for tracking form validity */
    formInvalid: Subject<boolean>;
    /** Flag to track if entity has been refreshed by code */
    private refreshedByCode;
    /**
     * Determines if any backend operation is in progress
     */
    get loading(): boolean;
    /** The form group for the entity being edited */
    abstract formGroup: FormGroup;
    /**
     * Constructor for BaseEntityEditingComponent
     *
     * @param injector - Angular injector for dependency injection
     * @param geboFormGroupsService - Service for managing form groups
     * @param confirmationService - Service for handling confirmation dialogs
     * @param geboUIActionRoutingService - Service for routing UI actions
     * @param outputForwardingService - Optional service for forwarding outputs
     */
    constructor(injector: Injector, geboFormGroupsService: GeboFormGroupsService, confirmationService: ConfirmationService, geboUIActionRoutingService: GeboUIActionRoutingService, outputForwardingService?: GeboUIOutputForwardingService | undefined);
    getEntityName(): string;
    /**
     * Lifecycle hook that is called when the component is destroyed
     */
    ngOnDestroy(): void;
    /**
     * Updates the object reference based on the entity code and backend class name
     */
    protected updateObjectReference(): void;
    /**
     * Hook method called when persistent data is loaded
     * Can be overridden by child classes to perform custom logic
     *
     * @param actualValue - The loaded entity data
     */
    protected onLoadedPersistentData(actualValue: RecordType): void;
    /**
     * Hook method called when new data is loaded
     * Can be overridden by child classes to perform custom logic
     *
     * @param actualValue - The new entity data
     */
    protected onNewData(actualValue: RecordType): void;
    /**
     * Updates the last operation status and user messages
     *
     * @param opStatus - The operation status to update
     */
    protected updateLastOperationStatus(opStatus: IOperationStatus<RecordType>): void;
    /**
     * Periodically checks if the backend is processing the viewed data
     */
    protected periodicBackendProcessingCheck(): void;
    /**
     * Sets up periodic form validation
     */
    private pollValidation;
    /**
     * Registers the component as a guest with the output forwarding service
     */
    private registerGuest;
    /**
     * Lifecycle hook that is called when the component is initialized
     */
    ngOnInit(): void;
    /**
     * Gets the current wizard step configuration
     *
     * @returns The current wizard step configuration or undefined
     */
    getActualWizardStep(): GeboAIEntitiesSettingWizardConfiguration | undefined;
    /**
     * Determines if the component is in wizard mode
     */
    get isWizardMode(): boolean;
    /**
     * Determines if there is a next step in the wizardoverride
     */
    get hasNextStep(): boolean;
    /**
     * Determines if there is a previous step in the wizard
     */
    get hasPreviusStep(): boolean;
    /**
     * Gets the icon for the previous step button
     */
    get previusStepIcon(): string;
    /**
     * Gets the icon for the next step button
     */
    get nextStepIcon(): string;
    /**
     * Gets the label for the previous step button
     */
    get previusStepLabel(): string;
    /**
     * Gets the label for the next step button
     */
    get nextStepLabel(): string;
    /**
     * Navigates to the next step in the wizard
     * Saves the current data before proceeding
     */
    nextStep(): void;
    /**
     * Navigates to the previous step in the wizard
     */
    private previusStep;
    /**
     * Lifecycle hook that is called when component inputs change
     *
     * @param changes - The changes that occurred
     */
    ngOnChanges(changes: SimpleChanges): void;
    /**
     * Checks whether to edit an existing entity or create a new one
     * based on whether the entity exists in the backend
     */
    private doCheckEditOrNew;
    /**
     * Checks if the entity can be deleted and updates UI accordingly
     *
     * @param value - The entity to check
     */
    private checkCanBeDeleted;
    /**
     * Creates an artificial operation status for success scenarios
     *
     * @param value - The entity data
     */
    protected callArtificiallyOperationStatus(value: RecordType): void;
    /**
     * Calls the update operation for an existing entity
     *
     * @param value - The entity to update
     * @param successfulActionCallback - Optional callback to execute on success
     */
    private callUpdate;
    /**
     * Calls the insert operation for a new entity
     *
     * @param value - The entity to insert
     * @param successfulActionCallback - Optional callback to execute on success
     */
    private callInsert;
    /**
     * Saves the entity (creates a new one or updates an existing one)
     *
     * @param successfulActionCallback - Optional callback to execute on success
     */
    doSave(successfulActionCallback?: (data: RecordType) => void): void;
    /******************************
     * Translates standard messages and show them to user if found or
     * assigns the original one if no translation is present or the translation
     * service is not reachable
     */
    protected assignBackendMessages(messages?: GUserMessage[]): void;
    /**
     * Deletes the entity after confirmation
     *
     * @param successfulActionCallback - Optional callback to execute on success
     */
    doDelete(successfulActionCallback?: (data: RecordType) => void): void;
    /**
     * Finds an entity by its code
     * Must be implemented by child classes
     *
     * @param code - The code to look up
     * @returns An Observable that resolves to the entity or null
     */
    abstract findByCode(code: string): Observable<RecordType | null>;
    /**
     * Saves an existing entity
     * Must be implemented by child classes
     *
     * @param value - The entity to save
     * @returns An Observable that resolves to the saved entity
     */
    abstract save(value: RecordType): Observable<RecordType>;
    /**
     * Inserts a new entity
     * Must be implemented by child classes
     *
     * @param value - The entity to insert
     * @returns An Observable that resolves to the inserted entity
     */
    abstract insert(value: RecordType): Observable<RecordType>;
    /**
     * Deletes an entity
     * Must be implemented by child classes
     *
     * @param value - The entity to delete
     * @returns An Observable that resolves to a boolean indicating success
     */
    abstract delete(value: RecordType): Observable<boolean>;
    /**
     * Checks if the backend is processing the referenced entity
     * Can be overridden by child classes to implement custom logic
     *
     * @param reference - The object reference to check
     * @returns An Observable that resolves to a boolean indicating if processing is happening
     */
    protected checkBackendProcessing(reference: {
        className?: string;
        code?: string;
    }): Observable<boolean>;
    /**
     * Checks if an entity can be inserted
     * Can be overridden by child classes to implement custom validation
     *
     * @param value - The entity to check
     * @returns An Observable that resolves to an object indicating if insertion is allowed
     */
    canBeInserted(value: RecordType): Observable<{
        canBeInserted: boolean;
        message: string;
    }>;
    /**
     * Checks if an entity can be deleted
     * Must be implemented by child classes
     *
     * @param value - The entity to check
     * @returns An Observable that resolves to an object indicating if deletion is allowed
     */
    abstract canBeDeleted(value: RecordType): Observable<{
        canBeDeleted: boolean;
        message: string;
    }>;
    /**
     * Creates a reference to the backend object
     *
     * @returns An object with code and class name
     */
    protected createBackendObjectReference(): {
        code?: string;
        className?: string;
    };
    /**
     * Reloads the entity data by its code
     */
    doReloadByCode(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<BaseEntityEditingComponent<any>, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<BaseEntityEditingComponent<any>, "base-entity-component", never, { "mode": { "alias": "mode"; "required": false; }; "wizardSessionStorage": { "alias": "wizardSessionStorage"; "required": false; }; "wizardStepsConfigurations": { "alias": "wizardStepsConfigurations"; "required": false; }; "onWizardActionPerformed": { "alias": "onWizardActionPerformed"; "required": false; }; "actualWizardStepConfigrationId": { "alias": "actualWizardStepConfigrationId"; "required": false; }; "entity": { "alias": "entity"; "required": false; }; }, { "createdNew": "createdNew"; "updated": "updated"; "deleted": "deleted"; "cancelAction": "cancelAction"; }, never, never, false, never>;
}
//# sourceMappingURL=base-entity-editing.component.d.ts.map