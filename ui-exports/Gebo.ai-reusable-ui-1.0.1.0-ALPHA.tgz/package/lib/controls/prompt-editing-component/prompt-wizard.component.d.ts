/**
 * This Source Code is subject to the terms of the
 * Gebo.ai community version Mozilla Public License Version 2.0 (MPL-2.0) — With Data Protection Clauses
 * If a copy of the LICENCE was not distributed with this file, You can obtain one at
 * https://gebo.ai/gebo-ai-community-version-mozilla-public-license-version-2-0-mpl-2-0-with-data-protection-clauses/
 * and https://mozilla.org/MPL/2.0/.
 * Copyright (c) 2025+ Gebo.ai
 */
import { OnChanges, OnInit, SimpleChanges } from "@angular/core";
import { FormGroup } from "@angular/forms";
import { ChatModelsLookupControllerService, GLookupEntry } from "@Gebo.ai/gebo-ai-rest-api";
import { ToastMessageOptions } from "primeng/api";
import { IOperationStatus } from "../base-entity-editing-component/operation-status";
import * as i0 from "@angular/core";
/**
 * AI generated comments
 *
 * Component that provides a wizard interface for generating AI prompt templates.
 * It allows users to select a model and enter a query to get AI-assisted prompt generation.
 * The component can be integrated with parent forms to deliver the generated prompt
 * back to a specified form control.
 */
export declare class GeboAIPromptWizardComponent implements OnInit, OnChanges {
    private modelsLookupService;
    /** Name of the form control in the parent form group where the prompt template will be delivered */
    deliveryPromptControlName?: string;
    /** Parent form group that will receive the generated prompt template */
    deliveryFormGroup?: FormGroup;
    /** Initial placeholder text for the prompt template input */
    promptTemplatePlaceholderText?: string;
    /** Flag to determine if the wizard is operating in RAG mode */
    ragWizardMode: boolean;
    /** Default placeholder text for the prompt template */
    defaultTemplatePlaceHolderText?: string;
    /** Controls visibility of the prompt wizard dialog */
    dialogVisible: boolean;
    /** Messages to display to the user in the UI */
    userMessages: ToastMessageOptions[];
    /** Indicates if any operation is in progress */
    loading: boolean;
    /** Form group for user input containing model selection and query text */
    formGroup: FormGroup;
    /** Form group for the response from the AI prompt generation */
    responseFormGroup: FormGroup;
    /** The last response received from the prompt template generation service */
    lastResponse?: IOperationStatus<any>;
    /** Available chat models for selection */
    chatModels?: GLookupEntry[];
    /**
     * Constructor for the GeboAIPromptWizardComponent
     * @param promptWizardControllerService Service for prompt template generation
     * @param modelsLookupService Service for retrieving available chat models
     */
    constructor(modelsLookupService: ChatModelsLookupControllerService);
    /**
     * Method to close the modal dialog
     * @param a Event object from the modal close action
     */
    closeModal(a: any): void;
    /**
     * Initializes the component by loading chat models and wizard configurations.
     * Sets the default prompt template if a placeholder text isn't provided.
     */
    ngOnInit(): void;
    /**
     * Responds to changes in component inputs.
     * Updates the query form control when promptTemplatePlaceholderText changes.
     * @param changes SimpleChanges object containing changed properties
     */
    ngOnChanges(changes: SimpleChanges): void;
    /**
     * Triggers the prompt template generation using the selected model and query.
     * Updates the response form group and user messages when the operation completes.
     */
    doGeneratePrompt(): void;
    /**
     * Cancels the prompt generation operation and closes the dialog
     */
    doCancelAction(): void;
    /**
     * Accepts the generated prompt template and sends it to the parent form control.
     * Closes the dialog after delivering the prompt.
     */
    doAcceptPrompt(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<GeboAIPromptWizardComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<GeboAIPromptWizardComponent, "gebo-ai-prompt-wizard-control", never, { "deliveryPromptControlName": { "alias": "deliveryPromptControlName"; "required": false; }; "deliveryFormGroup": { "alias": "deliveryFormGroup"; "required": false; }; "promptTemplatePlaceholderText": { "alias": "promptTemplatePlaceholderText"; "required": false; }; "ragWizardMode": { "alias": "ragWizardMode"; "required": false; }; }, {}, never, never, false, never>;
}
//# sourceMappingURL=prompt-wizard.component.d.ts.map