import * as i0 from "@angular/core";
import * as i1 from "./prompt-editing.component";
import * as i2 from "./prompt-wizard.component";
import * as i3 from "@angular/common";
import * as i4 from "@angular/forms";
import * as i5 from "primeng/textarea";
import * as i6 from "primeng/panel";
import * as i7 from "primeng/dialog";
import * as i8 from "primeng/button";
import * as i9 from "primeng/blockui";
import * as i10 from "../editable-listbox-component/editable-listbox.module";
import * as i11 from "ngx-monaco-editor-v2";
import * as i12 from "../field-translation-container/field-container.module";
import * as i13 from "../../notifications/notifications.module";
export declare class PromptEditingModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<PromptEditingModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<PromptEditingModule, [typeof i1.GeboAIPromptEditingComponent, typeof i2.GeboAIPromptWizardComponent], [typeof i3.CommonModule, typeof i4.ReactiveFormsModule, typeof i4.FormsModule, typeof i5.TextareaModule, typeof i6.PanelModule, typeof i7.DialogModule, typeof i8.ButtonModule, typeof i9.BlockUIModule, typeof i10.EditableListboxModule, typeof i11.MonacoEditorModule, typeof i12.GeboAIFieldTranslationContainerModule, typeof i13.GeboAINotificationsModule], [typeof i1.GeboAIPromptEditingComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<PromptEditingModule>;
}
//# sourceMappingURL=prompt-editing.module.d.ts.map