/**
 * This Source Code is subject to the terms of the
 * Gebo.ai community version Mozilla Public License Version 2.0 (MPL-2.0) — With Data Protection Clauses
 * If a copy of the LICENCE was not distributed with this file, You can obtain one at
 * https://gebo.ai/gebo-ai-community-version-mozilla-public-license-version-2-0-mpl-2-0-with-data-protection-clauses/
 * and https://mozilla.org/MPL/2.0/.
 * Copyright (c) 2025+ Gebo.ai
 */
/**
 * AI generated comments
 * This component provides a prompt editing interface using the Monaco editor.
 * It implements ControlValueAccessor to integrate with Angular forms, allowing
 * it to be used within form controls. The component supports customizable rows,
 * columns, and placeholders for the editor.
 */
import { OnChanges, OnInit, SimpleChanges } from "@angular/core";
import { ControlValueAccessor, FormGroup } from "@angular/forms";
import { NgxEditorModel } from "ngx-monaco-editor-v2";
import * as i0 from "@angular/core";
/**
 * A component for editing AI prompts using Monaco editor.
 * This component provides a rich text editing experience for prompts
 * and integrates with Angular's form system via ControlValueAccessor.
 */
export declare class GeboAIPromptEditingComponent implements ControlValueAccessor, OnChanges, OnInit {
    /**
     * Stores the current prompt text value
     */
    private promptText?;
    /**
     * Configuration options for the Monaco editor
     */
    options: {
        theme: string;
        language: string;
    };
    /**
     * Model configuration for the Monaco editor
     */
    model: NgxEditorModel;
    /**
     * Number of rows to display in the editor
     */
    rows: number;
    /**
     * Number of columns to display in the editor
     */
    cols: number;
    /**
     * Placeholder definitions that can be used in the prompt
     * Each placeholder has a code, description, and required flag
     */
    placeHolders: {
        code: string;
        description: string;
        required: boolean;
    }[];
    /**
     * Form group that contains the prompt control
     */
    formGroup: FormGroup;
    /**
     * Initializes the component
     */
    ngOnInit(): void;
    /**
     * Handles changes to the component's input properties
     * @param changes The changes object containing all changed inputs
     */
    ngOnChanges(changes: SimpleChanges): void;
    /**
     * Writes a value to the editor from the form model
     * @param obj The value to write to the editor
     */
    writeValue(obj: any): void;
    /**
     * Function to call when the input value changes
     */
    private onChange;
    /**
     * Registers a callback function that is called when the value changes
     * @param fn The callback function
     */
    registerOnChange(fn: any): void;
    /**
     * Function to call when the input is touched
     */
    private onTouched;
    /**
     * Registers a callback function that is called when the input is touched
     * @param fn The callback function
     */
    registerOnTouched(fn: any): void;
    /**
     * Sets the disabled state of the editor
     * @param isDisabled Whether the editor should be disabled
     */
    setDisabledState?(isDisabled: boolean): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<GeboAIPromptEditingComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<GeboAIPromptEditingComponent, "gebo-ai-prompt-editing-component", never, { "rows": { "alias": "rows"; "required": false; }; "cols": { "alias": "cols"; "required": false; }; "placeHolders": { "alias": "placeHolders"; "required": false; }; }, {}, never, never, false, never>;
}
//# sourceMappingURL=prompt-editing.component.d.ts.map