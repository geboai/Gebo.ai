import { EnrichedDocumentReferenceView, EnrichedLLMGeneratedResource, EnrichedUserUploadedContentView } from "./enriched-document-reference-view.service";
import * as i0 from "@angular/core";
/**
 * AI generated comments
 * Angular component that provides a button for opening and viewing documents.
 * The component receives a document reference as input and keeps track of the
 * currently viewed document code. It handles document selection actions.
 */
export declare class GeboUIDocumentOpenerButton {
    /**
     * Input property that accepts an EnrichedDocumentReferenceView object
     * to be displayed and potentially opened by this component.
     */
    document?: EnrichedDocumentReferenceView;
    uploadedContent?: EnrichedUserUploadedContentView;
    generatedContent?: EnrichedLLMGeneratedResource;
    /**
     * Stores the code/identifier of the currently viewed document.
     */
    protected currentViewedDocumentCode?: string;
    protected currentViewedUploadedContent?: EnrichedUserUploadedContentView;
    protected currentViewedGeneratedContent?: EnrichedLLMGeneratedResource;
    /**
     * Handles the click event when a file/document is selected.
     * Updates the currentViewedDocumentCode with the code of the selected document.
     *
     * @param item The document reference that was clicked/selected
     */
    onClickFile(item: EnrichedDocumentReferenceView): void;
    onClickUploadedContent(arg0: EnrichedUserUploadedContentView): void;
    onClickGeneratedContent(arg0: EnrichedLLMGeneratedResource): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<GeboUIDocumentOpenerButton, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<GeboUIDocumentOpenerButton, "gebo-ui-document-opener-button", never, { "document": { "alias": "document"; "required": false; }; "uploadedContent": { "alias": "uploadedContent"; "required": false; }; "generatedContent": { "alias": "generatedContent"; "required": false; }; }, {}, never, never, false, never>;
}
