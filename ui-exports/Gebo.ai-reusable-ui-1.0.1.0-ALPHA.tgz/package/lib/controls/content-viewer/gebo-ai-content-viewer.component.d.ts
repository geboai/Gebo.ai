/**
 * This Source Code is subject to the terms of the
 * Gebo.ai community version Mozilla Public License Version 2.0 (MPL-2.0) — With Data Protection Clauses
 * If a copy of the LICENCE was not distributed with this file, You can obtain one at
 * https://gebo.ai/gebo-ai-community-version-mozilla-public-license-version-2-0-mpl-2-0-with-data-protection-clauses/
 * and https://mozilla.org/MPL/2.0/.
 * Copyright (c) 2025+ Gebo.ai
 */
/**
 * AI generated comments
 * This module provides a content viewer component for the Gebo.ai platform that can display
 * various types of content based on file types. It handles different content formats
 * including source code, plain text, PDF, and browsable web content.
 */
import { HttpClient } from "@angular/common/http";
import { OnChanges, OnInit, SimpleChanges, EventEmitter } from "@angular/core";
import { ContentMetaInfo, ContentMetaInfosControllerService, ContentObject, IngestionFileType, IngestionFileTypesLibraryControllerService } from "@Gebo.ai/gebo-ai-rest-api";
import { EnrichedLLMGeneratedResource, EnrichedUserUploadedContentView } from "./enriched-document-reference-view.service";
import * as i0 from "@angular/core";
/**
 * @Component GeboAIContentViewerComponent
 * A component responsible for rendering different types of content based on their file type.
 * It supports viewing source code, plain text, PDFs, and web content, with appropriate
 * rendering for each content type.
 */
export declare class GeboAIContentViewerComponent implements OnInit, OnChanges {
    private contentMetaControllerService;
    private ingestionMetaInfoService;
    private httpClient;
    private path;
    /** Unique identifier for the content to be displayed */
    code: string;
    userUploadedContent?: EnrichedUserUploadedContentView;
    generatedContent?: EnrichedLLMGeneratedResource;
    /** Flag to determine if the viewer should be active */
    activate: boolean;
    /** Controls the visibility of the content viewer */
    protected visible: boolean;
    /** Indicates if content is being loaded */
    protected loading: boolean;
    /** Metadata information about the content */
    protected contentMetaInfo?: ContentMetaInfo;
    /** Information about the file type of the content */
    protected ingestionFileType?: IngestionFileType;
    /** Programming language of the source code content */
    protected sourceCodeLanguage: string;
    /** Flag indicating if the content is source code */
    protected sourceCodeContent: boolean;
    /** Flag indicating if the content is browsable web content */
    protected browsableContent: boolean;
    /** Flag indicating if the content should be downloaded rather than viewed */
    protected downloadableContent: boolean;
    /** Flag indicating if the content is plain text */
    protected plainTextContent: boolean;
    /** Flag indicating if the content is a PDF document */
    protected pdfContent: boolean;
    /** The actual content object with data */
    protected contentObject?: ContentObject;
    /** URL for external content viewing */
    protected externalContentUrl: string;
    /*** if true the url is served by gebo and requires an authorization token */
    protected contentServedByGebo: boolean;
    /** Event emitter that fires when the content viewer is closed */
    close: EventEmitter<boolean>;
    /**
     * Constructor for the GeboAIContentViewerComponent
     *
     * @param contentMetaControllerService Service for fetching content metadata
     * @param ingestionMetaInfoService Service for getting file type information
     * @param httpClient Angular HTTP client for API requests
     * @param path Base API path injected from application config
     */
    constructor(contentMetaControllerService: ContentMetaInfosControllerService, ingestionMetaInfoService: IngestionFileTypesLibraryControllerService, httpClient: HttpClient, path: string);
    /**
     * Angular lifecycle hook that initializes the component
     */
    ngOnInit(): void;
    /**
     * Closes the content viewer and emits a close event
     *
     * @param evt The event that triggered the close action
     */
    protected closeMe(evt: any): void;
    /**
     * Processes the content metadata to determine how to display the content
     * Sets flags for different content types and prepares the external content URL
     */
    private handleMetaInfo;
    /**
     * Angular lifecycle hook that responds to input changes
     * Fetches content metadata when the content code changes and the component is activated
     *
     * @param changes SimpleChanges object containing the changed properties
     */
    ngOnChanges(changes: SimpleChanges): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<GeboAIContentViewerComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<GeboAIContentViewerComponent, "gebo-ai-content-viewer", never, { "code": { "alias": "code"; "required": false; }; "userUploadedContent": { "alias": "userUploadedContent"; "required": false; }; "generatedContent": { "alias": "generatedContent"; "required": false; }; "activate": { "alias": "activate"; "required": false; }; }, { "close": "close"; }, never, never, false, never>;
}
