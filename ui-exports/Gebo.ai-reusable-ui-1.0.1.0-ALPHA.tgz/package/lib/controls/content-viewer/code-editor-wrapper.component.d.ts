/**
 * This Source Code is subject to the terms of the
 * Gebo.ai community version Mozilla Public License Version 2.0 (MPL-2.0) — With Data Protection Clauses
 * If a copy of the LICENCE was not distributed with this file, You can obtain one at
 * https://gebo.ai/gebo-ai-community-version-mozilla-public-license-version-2-0-mpl-2-0-with-data-protection-clauses/
 * and https://mozilla.org/MPL/2.0/.
 * Copyright (c) 2025+ Gebo.ai
 */
/**
 * AI generated comments
 * This module provides a wrapper component for the Monaco code editor.
 * It integrates with Angular's form system and allows for customizing the editor
 * with different languages, themes, and content.
 */
import { AfterViewInit, OnChanges, OnInit, SimpleChanges } from "@angular/core";
import { FormGroup } from "@angular/forms";
import { ContentObject } from "@Gebo.ai/gebo-ai-rest-api";
import { EditorComponent, NgxEditorModel } from "ngx-monaco-editor-v2";
import * as i0 from "@angular/core";
/**
 * Component that wraps the Monaco editor to provide code editing functionality
 * within Angular applications. It supports customization through inputs for language,
 * height, and content. Integrates with Angular's FormGroup for form handling.
 */
export declare class CodeEditorWrapperComponent implements OnInit, OnChanges, AfterViewInit {
    /**
     * Configuration options for the Monaco editor.
     * Sets the theme and default language.
     */
    options: {
        theme: string;
        language: string;
    };
    /**
     * Model configuration for the Monaco editor.
     * Defines the initial value and language mode.
     */
    model: NgxEditorModel;
    /** Input to set the programming language for syntax highlighting */
    language?: string;
    /** Input to set the component's height (defaults to 100%) */
    componentHeight: string;
    /** Input to populate the editor with content */
    contentObject?: ContentObject;
    /**
     * Form group that contains the editor content as a form control.
     * Used to bind the editor to Angular's form system.
     */
    formGroup: FormGroup;
    /** Reference to the Monaco editor component */
    monaco?: EditorComponent;
    /**
     * Initializes the component with default values
     */
    constructor();
    /**
     * Lifecycle hook called after the component's view has been initialized.
     * Sets a flag to indicate the editor is inside an Angular context.
     */
    ngAfterViewInit(): void;
    /**
     * Lifecycle hook called when the component is initialized.
     * Sets a flag to indicate the editor is inside an Angular context.
     */
    ngOnInit(): void;
    /**
     * Lifecycle hook called when input properties change.
     * Updates the model and options when language changes.
     * Updates form values when contentObject changes.
     *
     * @param changes Simple changes object containing current and previous values
     */
    ngOnChanges(changes: SimpleChanges): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CodeEditorWrapperComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CodeEditorWrapperComponent, "gebo-ai-code-editor", never, { "language": { "alias": "language"; "required": false; }; "componentHeight": { "alias": "componentHeight"; "required": false; }; "contentObject": { "alias": "contentObject"; "required": false; }; }, {}, never, never, false, never>;
}
