/**
 * This Source Code is subject to the terms of the
 * Gebo.ai community version Mozilla Public License Version 2.0 (MPL-2.0) — With Data Protection Clauses
 * If a copy of the LICENCE was not distributed with this file, You can obtain one at
 * https://gebo.ai/gebo-ai-community-version-mozilla-public-license-version-2-0-mpl-2-0-with-data-protection-clauses/
 * and https://mozilla.org/MPL/2.0/.
 * Copyright (c) 2025+ Gebo.ai
 */
/**
 * AI generated comments
 * This module provides a wrapper component for PDF viewing using ngx-extended-pdf-viewer.
 * It handles authentication and PDF rendering with proper headers.
 */
import { HttpClient } from "@angular/common/http";
import { OnChanges, OnInit, SimpleChanges } from "@angular/core";
import * as i0 from "@angular/core";
/**
 * Interface defining the structure for PDF source configuration.
 * Allows specifying a URL, HTTP headers, credentials settings, or raw PDF data.
 */
interface PDFSrc {
    url?: string;
    httpHeaders?: any;
    withCredentials?: boolean;
    data?: any;
}
/**
 * Component that wraps the ngx-extended-pdf-viewer to display PDF documents.
 * It handles authentication by automatically adding authorization headers to requests.
 * The component will only render when a PDF source is provided.
 */
export declare class PDFViewerWrapper2Component implements OnInit, OnChanges {
    private path;
    private httpClient;
    /**
     * Input property for the PDF source URL to be displayed
     */
    pdfSrc?: string;
    /**
     * Object containing PDF source configuration
     */
    pdfInfos?: PDFSrc;
    /**
     * HTTP headers to be sent with PDF requests, including authorization
     */
    httpHeaders?: any;
    /**
     * Initializes the component with the necessary dependencies and sets up the PDF viewer
     * @param path Base path for API requests
     * @param httpClient HTTP client for making requests
     */
    constructor(path: string, httpClient: HttpClient);
    /**
     * Handles errors that occur during PDF loading or rendering
     * @param error The error object from the PDF viewer
     */
    onError(error: any): void;
    /**
     * Lifecycle hook that runs when the component initializes
     */
    ngOnInit(): void;
    /**
     * Lifecycle hook that runs when component inputs change
     * Detects changes to the pdfSrc input and updates the viewer accordingly
     * @param changes Object containing all changed properties
     */
    ngOnChanges(changes: SimpleChanges): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<PDFViewerWrapper2Component, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<PDFViewerWrapper2Component, "gebo-ai-pdf-viewer-wrapper2", never, { "pdfSrc": { "alias": "pdfSrc"; "required": false; }; }, {}, never, never, false, never>;
}
export {};
//# sourceMappingURL=pdf-viewer-wrapper2.component.d.ts.map