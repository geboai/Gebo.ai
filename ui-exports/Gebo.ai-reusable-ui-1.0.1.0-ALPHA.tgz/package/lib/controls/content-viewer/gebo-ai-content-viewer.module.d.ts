import * as i0 from "@angular/core";
import * as i1 from "./gebo-ai-content-viewer.component";
import * as i2 from "./code-editor-wrapper.component";
import * as i3 from "./download-link-wrapper.component";
import * as i4 from "./pdf-viewer-wrapper2.component";
import * as i5 from "./document-opener-button.component";
import * as i6 from "@angular/common";
import * as i7 from "@angular/forms";
import * as i8 from "primeng/panel";
import * as i9 from "primeng/blockui";
import * as i10 from "../browse-content-component/browse-content.module";
import * as i11 from "ngx-monaco-editor-v2";
import * as i12 from "primeng/dialog";
import * as i13 from "ngx-extended-pdf-viewer";
import * as i14 from "primeng/button";
import * as i15 from "../web-viewer/web-viewer.module";
export declare class GeboAIContentViewerModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<GeboAIContentViewerModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<GeboAIContentViewerModule, [typeof i1.GeboAIContentViewerComponent, typeof i2.CodeEditorWrapperComponent, typeof i3.DownloadLinkViewerWrapperComponent, typeof i4.PDFViewerWrapper2Component, typeof i5.GeboUIDocumentOpenerButton], [typeof i6.CommonModule, typeof i7.ReactiveFormsModule, typeof i8.PanelModule, typeof i9.BlockUIModule, typeof i10.BrowseContentModule, typeof i11.MonacoEditorModule, typeof i12.DialogModule, typeof i13.NgxExtendedPdfViewerModule, typeof i14.ButtonModule, typeof i15.WebViewerModule], [typeof i1.GeboAIContentViewerComponent, typeof i2.CodeEditorWrapperComponent, typeof i5.GeboUIDocumentOpenerButton]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<GeboAIContentViewerModule>;
}
//# sourceMappingURL=gebo-ai-content-viewer.module.d.ts.map