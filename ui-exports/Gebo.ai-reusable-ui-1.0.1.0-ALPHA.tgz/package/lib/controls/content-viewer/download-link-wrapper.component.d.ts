/**
 * This Source Code is subject to the terms of the
 * Gebo.ai community version Mozilla Public License Version 2.0 (MPL-2.0) — With Data Protection Clauses
 * If a copy of the LICENCE was not distributed with this file, You can obtain one at
 * https://gebo.ai/gebo-ai-community-version-mozilla-public-license-version-2-0-mpl-2-0-with-data-protection-clauses/
 * and https://mozilla.org/MPL/2.0/.
 * Copyright (c) 2025+ Gebo.ai
 */
/**
 * AI generated comments
 * This file defines a wrapper component that provides a download link for content from the Gebo.ai system.
 * It handles retrieving content URLs and formatting them for user download.
 */
import { HttpClient } from "@angular/common/http";
import { ElementRef, OnChanges, OnInit, SimpleChanges } from "@angular/core";
import { ContentMetaInfo, IngestionFileType } from "@Gebo.ai/gebo-ai-rest-api";
import * as i0 from "@angular/core";
/**
 * Component that renders a download link for content accessible via the Gebo.ai platform.
 * It creates a simple anchor tag that allows users to download files based on content metadata.
 */
export declare class DownloadLinkViewerWrapperComponent implements OnInit, OnChanges {
    private path;
    private httpClient;
    /**
     * Reference to an iframe element that may be used for document display
     */
    iframe?: ElementRef<Element>;
    /**
     * Metadata information about the content to be downloaded
     */
    contentMetaInfo?: ContentMetaInfo;
    /**
     * Type of file being ingested
     */
    ingestionFileType?: IngestionFileType;
    /**
     * URL to the external content that will be downloaded
     */
    externalContentUrl?: string;
    /**
     * Processed URL used for the download link
     */
    downloadableContentUrl?: string;
    /**
     * Data storage for component
     */
    data: any;
    /**
     * Content MIME type of the downloadable file
     */
    contentType?: string;
    /**
     * Initializes the component with dependency injection
     * @param path Base API path from the application configuration
     * @param httpClient HTTP client for making API requests
     */
    constructor(path: string, httpClient: HttpClient);
    /**
     * Fetches the content from the provided URL and creates a downloadable object URL
     * Adds the asDownload parameter to the URL and includes authentication token in the request
     * @param externalContentUrl URL to the content that needs to be downloaded
     */
    downloadURL(externalContentUrl: string): Promise<void>;
    /**
     * Lifecycle hook that initializes the component
     */
    ngOnInit(): void;
    /**
     * Lifecycle hook that responds to changes in component inputs
     * Processes the download URL when content metadata and external URL are available
     * @param changes SimpleChanges object containing changed properties
     */
    ngOnChanges(changes: SimpleChanges): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DownloadLinkViewerWrapperComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DownloadLinkViewerWrapperComponent, "gebo-ai-download-link-viewer-wrapper", never, { "contentMetaInfo": { "alias": "contentMetaInfo"; "required": false; }; "ingestionFileType": { "alias": "ingestionFileType"; "required": false; }; "externalContentUrl": { "alias": "externalContentUrl"; "required": false; }; }, {}, never, never, false, never>;
}
//# sourceMappingURL=download-link-wrapper.component.d.ts.map