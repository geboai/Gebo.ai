import { ContentMetaInfosControllerService, DocumentReferenceView, GeboUserKnowledgeBaseSemanticSearchControllerService, IngestionFileType, IngestionFileTypesLibraryControllerService, LLMGeneratedResource, SearchDocumentByNameParam, SemanticQueryParam, UserUploadedContent } from "@Gebo.ai/gebo-ai-rest-api";
import { Observable } from "rxjs";
import * as i0 from "@angular/core";
/**
 * AI generated comments
 * This file provides services for retrieving and enriching document references with additional metadata
 * like file type information and appropriate icons for UI rendering.
 */
/**
 * Interface that extends IngestionFileType to include an icon property for UI rendering.
 * This allows file types to be visually represented in the interface.
 */
export interface EnrichedIngestionFileType extends IngestionFileType {
    icon: string;
}
/**
 * Interface that extends DocumentReferenceView to include file type information.
 * This enriched version provides additional metadata about the document's file type.
 */
export interface EnrichedDocumentReferenceView extends DocumentReferenceView {
    fileType?: EnrichedIngestionFileType;
}
/*********************************************************************
 * interface that adds to UserUploadedContent metainformations usefull
 * for its handling
 */
export interface EnrichedUserUploadedContentView extends UserUploadedContent {
    fileType?: EnrichedIngestionFileType;
}
export interface EnrichedLLMGeneratedResource extends LLMGeneratedResource {
    fileType?: EnrichedIngestionFileType;
}
/**
 * Service responsible for retrieving document references and enriching them with additional metadata.
 * This service caches file types and provides methods to search documents by name or code,
 * as well as semantic search capabilities.
 */
export declare class EnrichedDocumentReferenceViewRetrieveService {
    private filetypesControllerService;
    private userKnowledgeBaseSemanticSearchService;
    private documentsMetaInfosService;
    /**
     * Static cache of file types to avoid repeated API calls
     */
    private static fileTypes;
    /**
     * Constructor that injects necessary services for document retrieval and enrichment
     *
     * @param filetypesControllerService Service for retrieving file type information
     * @param userKnowledgeBaseSemanticSearchService Service for semantic searching
     * @param documentsMetaInfosService Service for accessing document metadata
     */
    constructor(filetypesControllerService: IngestionFileTypesLibraryControllerService, userKnowledgeBaseSemanticSearchService: GeboUserKnowledgeBaseSemanticSearchControllerService, documentsMetaInfosService: ContentMetaInfosControllerService);
    /**
     * Determines the appropriate icon to display based on the file type's treatment category
     *
     * @param child The file type to get an icon for
     * @returns A string representing the PrimeNG icon class to use
     */
    private getFileIcon;
    /**
     * Retrieves the enriched file type information based on file extension
     *
     * @param extension The file extension to look up
     * @returns The matching EnrichedIngestionFileType or undefined if not found
     */
    private static getEnrichedFileType;
    /**
     * Enriches a DocumentReferenceView with file type information
     *
     * @param d The document reference to enrich
     * @returns An EnrichedDocumentReferenceView with file type data
     */
    private static enrich;
    enrichUserUploadedContent(content: UserUploadedContent): Promise<EnrichedUserUploadedContentView>;
    enrichLLMGeneratedResource(content: LLMGeneratedResource): Promise<EnrichedLLMGeneratedResource>;
    private preloadFileTypes;
    private enrichFileType;
    /**
     * Searches for documents by name and enriches the results with file type information
     *
     * @param param The search parameters
     * @returns An Observable of enriched document reference views
     */
    searchByDocumentName(param: SearchDocumentByNameParam): Observable<EnrichedDocumentReferenceView[]>;
    /**
     * Finds document references by their internal codes and enriches them with file type information
     *
     * @param internalValue Array of internal codes to search for
     * @returns An Observable of enriched document reference views
     */
    findDocumentReferenceViewByCode(internalValue: string[]): Observable<EnrichedDocumentReferenceView[]>;
    /**
     * Performs a semantic search using the provided query parameters
     *
     * @param body The semantic query parameters
     * @returns An Observable with the semantic search results
     */
    semanticSearch(body: SemanticQueryParam): Observable<string[]>;
    static ɵfac: i0.ɵɵFactoryDeclaration<EnrichedDocumentReferenceViewRetrieveService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<EnrichedDocumentReferenceViewRetrieveService>;
}
