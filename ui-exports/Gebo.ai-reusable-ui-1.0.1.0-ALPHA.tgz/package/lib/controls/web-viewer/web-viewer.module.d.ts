import * as i0 from "@angular/core";
import * as i1 from "./web-viewer.component";
import * as i2 from "@angular/common";
import * as i3 from "primeng/card";
import * as i4 from "primeng/message";
import * as i5 from "primeng/blockui";
import * as i6 from "../field-translation-container/field-container.module";
export declare class WebViewerModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<WebViewerModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<WebViewerModule, [typeof i1.WebViewerComponent], [typeof i2.CommonModule, typeof i3.CardModule, typeof i4.MessageModule, typeof i5.BlockUIModule, typeof i6.GeboAIFieldTranslationContainerModule], [typeof i1.WebViewerComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<WebViewerModule>;
}
//# sourceMappingURL=web-viewer.module.d.ts.map