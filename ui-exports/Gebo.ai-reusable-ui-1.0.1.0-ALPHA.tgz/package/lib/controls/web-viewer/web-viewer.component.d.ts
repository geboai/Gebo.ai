import { HttpClient } from '@angular/common/http';
import { OnChanges, SimpleChanges } from '@angular/core';
import { DomSanitizer, SafeHtml, SafeResourceUrl } from '@angular/platform-browser';
import * as i0 from "@angular/core";
export declare class WebViewerComponent implements OnChanges {
    private sanitizer;
    private httpClient;
    /**
     * URL da visualizzare nel componente.
     * Esempio: https://www.gebo.ai/ oppure /assets/demo.html
     */
    url: string | null;
    contentServedByGebo?: boolean;
    geboServedFileName?: string;
    /**
     * URL sanificata da passare all'iframe.
     */
    safeUrl: SafeResourceUrl | null;
    safeHtml: SafeHtml | null;
    protected loading: boolean;
    constructor(sanitizer: DomSanitizer, httpClient: HttpClient);
    ngOnChanges(changes: SimpleChanges): void;
    private loadBody;
    private updateSafeUrl;
    static ɵfac: i0.ɵɵFactoryDeclaration<WebViewerComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<WebViewerComponent, "gebo-ai-web-viewer", never, { "url": { "alias": "url"; "required": false; }; "contentServedByGebo": { "alias": "contentServedByGebo"; "required": false; }; "geboServedFileName": { "alias": "geboServedFileName"; "required": false; }; }, {}, never, never, false, never>;
}
//# sourceMappingURL=web-viewer.component.d.ts.map