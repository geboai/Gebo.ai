import * as i0 from "@angular/core";
import * as i1 from "./browse-content.component";
import * as i2 from "./view-html-content.component";
import * as i3 from "@angular/common";
import * as i4 from "primeng/panel";
/**
 * @NgModule BrowseContentModule
 * @description Angular module that encapsulates content browsing functionality.
 * This module imports common Angular modules and PrimeNG's Panel module for UI components.
 * It declares and exports two main components:
 * - BrowseContentComponent: Likely handles the main content browsing interface
 * - GeboAIViewHtmlComponent: Specialized component for viewing HTML content
 */
export declare class BrowseContentModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<BrowseContentModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<BrowseContentModule, [typeof i1.BrowseContentComponent, typeof i2.GeboAIViewHtmlComponent], [typeof i3.CommonModule, typeof i4.PanelModule], [typeof i1.BrowseContentComponent, typeof i2.GeboAIViewHtmlComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<BrowseContentModule>;
}
//# sourceMappingURL=browse-content.module.d.ts.map