/**
 * This Source Code is subject to the terms of the
 * Gebo.ai community version Mozilla Public License Version 2.0 (MPL-2.0) — With Data Protection Clauses
 * If a copy of the LICENCE was not distributed with this file, You can obtain one at
 * https://gebo.ai/gebo-ai-community-version-mozilla-public-license-version-2-0-mpl-2-0-with-data-protection-clauses/
 * and https://mozilla.org/MPL/2.0/.
 * Copyright (c) 2025+ Gebo.ai
 */
import { AfterViewInit, ElementRef, OnChanges, SimpleChanges } from "@angular/core";
import * as i0 from "@angular/core";
export declare class BrowseContentComponent implements OnChanges, AfterViewInit {
    /**
     * Reference to the iframe element in the template
     * Used to set the src attribute when the URL changes
     */
    iframe?: ElementRef<Element>;
    /**
     * The title to display for the browsed content
     * Defaults to "Browsing external content"
     */
    title: string;
    /**
     * The URL of the external content to be loaded in the iframe
     */
    url?: string;
    /**
     * Initializes a new instance of the BrowseContentComponent
     */
    constructor();
    /**
     * Lifecycle hook that is called after the component's view has been initialized
     * Sets the iframe src attribute to the URL if available
     */
    ngAfterViewInit(): void;
    /**
     * Lifecycle hook that is called when any data-bound property of the component changes
     * Updates the iframe src attribute when the URL input changes
     * @param changes - Object containing all changed properties with current and previous values
     */
    ngOnChanges(changes: SimpleChanges): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<BrowseContentComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<BrowseContentComponent, "gebo-ai-browse-content-component", never, { "title": { "alias": "title"; "required": false; }; "url": { "alias": "url"; "required": false; }; }, {}, never, never, false, never>;
}
//# sourceMappingURL=browse-content.component.d.ts.map