import { InjectionToken } from '@angular/core';
/******************************************************************
 * With the following putting in the implementation of GeboAIThisComponent that implements GeboAIFieldHost:
 * providers: [{ provide: GEBO_AI_FIELD_HOST, useExisting: forwardRef(() => GeboAIThisComponent) }]
 */
export interface GeboAIFieldHost {
    getEntityName(): string;
}
export declare function fieldHostComponentName(entityName: string): GeboAIFieldHost;
export declare const GEBO_AI_FIELD_HOST: InjectionToken<GeboAIFieldHost>;
export declare const GEBO_AI_MODULE: InjectionToken<string>;
