/**
 * This Source Code is subject to the terms of the
 * Gebo.ai community version Mozilla Public License Version 2.0 (MPL-2.0) — With Data Protection Clauses
 * If a copy of the LICENCE was not distributed with this file, You can obtain one at
 * https://gebo.ai/gebo-ai-community-version-mozilla-public-license-version-2-0-mpl-2-0-with-data-protection-clauses/
 * and https://mozilla.org/MPL/2.0/.
 * Copyright (c) 2025+ Gebo.ai
 */
/**
 * AI generated comments
 * This component provides a selectable and editable list of relations or items.
 * It implements ControlValueAccessor to integrate with Angular's form controls,
 * allowing it to be used in reactive forms. The component manages a list of
 * selectable items (objects with code and description properties) and tracks
 * both selected values and available options.
 */
import { ChangeDetectorRef, OnChanges, OnInit, SimpleChanges } from "@angular/core";
import { ControlValueAccessor, FormGroup } from "@angular/forms";
import { Observable } from "rxjs";
import * as i0 from "@angular/core";
/**
 * Component that displays and manages a list of selectable relation items.
 * It provides functionality to add and remove items from the list, with support
 * for loading options dynamically through Observables.
 */
export declare class GeboAiRelationListComponent implements ControlValueAccessor, OnInit, OnChanges {
    private changeDetection;
    /** Flag indicating if all values are currently loading */
    private loadingAllValues;
    /** Flag indicating if remaining selectable values are currently loading */
    private loadingRemainingValues;
    /**
     * Returns whether any loading operation is in progress
     */
    get loading(): boolean;
    /** Array of selected value codes */
    selectedValues: string[];
    /** Array of selected objects with code and description */
    selectedObjects: {
        code?: string;
        description?: string;
    }[];
    /** Array of objects that can be chosen/selected */
    choosableObjects: {
        code?: string;
        description?: string;
    }[];
    /** Complete collection of all available objects */
    private allObjects;
    /** Observable that provides all available options */
    allOptionsObservable?: Observable<{
        code?: string;
        description?: string;
    }[]>;
    /** Observable that provides remaining selectable options */
    remainingObjectsObservable?: Observable<{
        code?: string;
        description?: string;
    }[]>;
    /** Flag to set the component in read-only mode */
    readonly: boolean;
    /** Controls visibility of the add window/dialog */
    viewAddWindow: boolean;
    /** Form group for the selection list */
    formGroup: FormGroup;
    /** Form group for currently selected objects */
    selectedFormGroup: FormGroup;
    /**
     * Creates an instance of the relation list component
     * @param changeDetection Reference to Angular's change detection mechanism
     */
    constructor(changeDetection: ChangeDetectorRef);
    /**
     * Initializes the component and sets up form control subscriptions.
     * Listens for changes to the list control and updates selected values accordingly.
     */
    ngOnInit(): void;
    /**
     * Handles the removal of a chip/item from the selected items
     * @param event The event containing the value to be removed
     */
    removeChip(event: any): void;
    /**
     * Responds to changes in component inputs by subscribing to observables
     * and updating the available and selected items.
     * @param changes Simple changes object containing changed input properties
     */
    ngOnChanges(changes: SimpleChanges): void;
    /**
     * ControlValueAccessor implementation method that writes a new value to the component
     * @param obj The value to set for the component
     */
    writeValue(obj: any): void;
    /**
     * Updates the selectedObjects array based on the current selectedValues
     * and updates the form control value accordingly
     */
    private showCorrectValues;
    /** Function to call when the value changes */
    onChange?: (v: any) => void;
    /**
     * ControlValueAccessor implementation method to register the onChange callback
     * @param fn The callback function to register
     */
    registerOnChange(fn: any): void;
    /** Function to call when the control is touched */
    onTouch?: (v: any) => void;
    /**
     * ControlValueAccessor implementation method to register the onTouched callback
     * @param fn The callback function to register
     */
    registerOnTouched(fn: any): void;
    /**
     * ControlValueAccessor implementation method to handle disabled state
     * @param isDisabled Flag indicating if the control should be disabled
     */
    setDisabledState?(isDisabled: boolean): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<GeboAiRelationListComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<GeboAiRelationListComponent, "gebo-ai-relation-list", never, { "allOptionsObservable": { "alias": "allOptionsObservable"; "required": false; }; "remainingObjectsObservable": { "alias": "remainingObjectsObservable"; "required": false; }; "readonly": { "alias": "readonly"; "required": false; }; }, {}, never, never, false, never>;
}
//# sourceMappingURL=relation-list.component.d.ts.map