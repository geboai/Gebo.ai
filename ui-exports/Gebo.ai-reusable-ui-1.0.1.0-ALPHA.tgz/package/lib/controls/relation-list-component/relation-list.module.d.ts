import * as i0 from "@angular/core";
import * as i1 from "./relation-list.component";
import * as i2 from "@angular/common";
import * as i3 from "primeng/chip";
import * as i4 from "primeng/blockui";
import * as i5 from "primeng/button";
import * as i6 from "../editable-listbox-component/editable-listbox.module";
import * as i7 from "@angular/forms";
import * as i8 from "primeng/dialog";
import * as i9 from "primeng/panel";
/**
 * Module that encapsulates the GeboAiRelationListComponent.
 *
 * Imports necessary UI components from PrimeNG and Angular modules needed for forms handling.
 * The module makes the GeboAiRelationListComponent available to other modules through its exports.
 */
export declare class GeboAiRelationListModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<GeboAiRelationListModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<GeboAiRelationListModule, [typeof i1.GeboAiRelationListComponent], [typeof i2.CommonModule, typeof i3.ChipModule, typeof i4.BlockUIModule, typeof i5.ButtonModule, typeof i6.EditableListboxModule, typeof i7.FormsModule, typeof i7.ReactiveFormsModule, typeof i8.DialogModule, typeof i9.PanelModule], [typeof i1.GeboAiRelationListComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<GeboAiRelationListModule>;
}
