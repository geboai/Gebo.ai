import { OnChanges, OnInit, SimpleChanges } from "@angular/core";
import { ControlValueAccessor, FormGroup } from "@angular/forms";
import { GUserMessage, SecretInfo, SecretsControllerService } from "@Gebo.ai/gebo-ai-rest-api";
import { Observable } from "rxjs";
import { IOperationStatus } from "../base-entity-editing-component/operation-status";
import * as i0 from "@angular/core";
export declare class GeboAIApiKeyComponent implements OnInit, OnChanges, ControlValueAccessor {
    private secretController;
    contextCode?: string;
    apiKeyDescription?: string;
    backendValidationOnChange: boolean;
    backendValidation: (credentials: SecretInfo) => Observable<IOperationStatus<any>>;
    protected secretFormGroup: FormGroup;
    protected messages?: GUserMessage[];
    protected view: "COMPACT" | "FULL";
    protected existingOrNewShow: boolean;
    protected saveDisabled: boolean;
    protected get loading(): boolean;
    protected loadingBackend: boolean;
    protected validating: boolean;
    protected deleting: boolean;
    protected secrets: SecretInfo[];
    protected secretId?: string;
    protected useExistingOrNew: "EXISTING" | "NEW";
    protected useExistingOrNewOptions: {
        label: string;
        value: string;
    }[];
    protected enabled: boolean;
    constructor(secretController: SecretsControllerService);
    private switchControlsRequired;
    protected createCredentials(): void;
    ngOnInit(): void;
    ngOnChanges(changes: SimpleChanges): void;
    writeValue(obj: any): void;
    private onChange?;
    registerOnChange(fn: any): void;
    private onTouch?;
    registerOnTouched(fn: any): void;
    setDisabledState?(isDisabled: boolean): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<GeboAIApiKeyComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<GeboAIApiKeyComponent, "gebo-ai-api-key-component", never, { "contextCode": { "alias": "contextCode"; "required": true; }; "apiKeyDescription": { "alias": "apiKeyDescription"; "required": true; }; "backendValidationOnChange": { "alias": "backendValidationOnChange"; "required": false; }; "backendValidation": { "alias": "backendValidation"; "required": false; }; }, {}, never, never, false, never>;
}
//# sourceMappingURL=api-key.component.d.ts.map