import * as i0 from "@angular/core";
import * as i1 from "./api-key.component";
import * as i2 from "@angular/common";
import * as i3 from "@angular/forms";
import * as i4 from "primeng/panel";
import * as i5 from "primeng/fieldset";
import * as i6 from "../editable-listbox-component/editable-listbox.module";
import * as i7 from "../field-translation-container/field-container.module";
import * as i8 from "primeng/selectbutton";
import * as i9 from "primeng/button";
import * as i10 from "primeng/blockui";
import * as i11 from "primeng/inputtext";
import * as i12 from "../../notifications/notifications.module";
export declare class GeboAIApiKeyModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<GeboAIApiKeyModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<GeboAIApiKeyModule, [typeof i1.GeboAIApiKeyComponent], [typeof i2.CommonModule, typeof i3.ReactiveFormsModule, typeof i4.PanelModule, typeof i5.FieldsetModule, typeof i6.EditableListboxModule, typeof i7.GeboAIFieldTranslationContainerModule, typeof i8.SelectButtonModule, typeof i9.ButtonModule, typeof i10.BlockUIModule, typeof i11.InputTextModule, typeof i12.GeboAINotificationsModule], [typeof i1.GeboAIApiKeyComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<GeboAIApiKeyModule>;
}
//# sourceMappingURL=api-key.module.d.ts.map