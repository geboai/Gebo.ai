import { ValidationErrors } from "@angular/forms";
import { GContentSelectionFilterCriteria } from "@Gebo.ai/gebo-ai-rest-api";
export declare function validateCriteria(value: GContentSelectionFilterCriteria): ValidationErrors | null;
//# sourceMappingURL=validate-content-selection-filter-criteria.d.ts.map