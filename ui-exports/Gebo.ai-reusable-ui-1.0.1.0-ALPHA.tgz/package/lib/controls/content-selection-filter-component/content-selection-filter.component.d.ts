import { OnChanges, OnInit, SimpleChanges } from "@angular/core";
import { AbstractControl, ControlValueAccessor, FormArray, FormGroup, ValidationErrors, Validator } from "@angular/forms";
import { GContentSelectionFilter, IngestionFileTypesLibraryControllerService } from "@Gebo.ai/gebo-ai-rest-api";
import * as i0 from "@angular/core";
export declare class GeboAIContentSelectionFilterComponent implements OnInit, OnChanges, ControlValueAccessor, Validator {
    private fileTypeLibraryControllerService;
    title: string;
    protected internalValue?: GContentSelectionFilter;
    protected formGroup: FormGroup;
    protected loading: boolean;
    protected fileTypes: {
        code: string;
        description: string;
    }[];
    protected createNewCriteria(): FormGroup;
    constructor(fileTypeLibraryControllerService: IngestionFileTypesLibraryControllerService);
    /*************************************************
     * All empty conditions notifies undefined and all validated notifies all conditions
     */
    private changedValueNotification;
    protected get criterias(): FormArray;
    protected criteriaAt(index: number): FormGroup;
    private adaptFormGroup;
    ngOnInit(): void;
    ngOnChanges(changes: SimpleChanges): void;
    writeValue(obj: any): void;
    private onChange;
    registerOnChange(fn: any): void;
    private onTouched;
    registerOnTouched(fn: any): void;
    setDisabledState?(isDisabled: boolean): void;
    validate(control: AbstractControl): ValidationErrors | null;
    fn: () => void;
    registerOnValidatorChange?(fn: () => void): void;
    addRow(): void;
    removeRow(index: number): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<GeboAIContentSelectionFilterComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<GeboAIContentSelectionFilterComponent, "gebo-ai-content-selection-filter-component", never, { "title": { "alias": "title"; "required": false; }; }, {}, never, never, false, never>;
}
