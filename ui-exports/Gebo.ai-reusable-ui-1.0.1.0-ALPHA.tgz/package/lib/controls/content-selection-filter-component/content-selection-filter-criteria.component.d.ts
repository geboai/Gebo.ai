import { FormGroup } from "@angular/forms";
import { GeboAIFieldHost } from "../field-host-component-iface/field-host-component-iface";
import * as i0 from "@angular/core";
export declare class GeboAISelectionFilterCriteriaComponent implements GeboAIFieldHost {
    fg?: FormGroup;
    fileTypes: {
        code: string;
        description: string;
    }[];
    protected filterFormCriterias: {
        code?: string;
        description: string;
    }[];
    getEntityName(): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<GeboAISelectionFilterCriteriaComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<GeboAISelectionFilterCriteriaComponent, "gebo-ai-selection-filter-criteria-component", never, { "fg": { "alias": "fg"; "required": false; }; "fileTypes": { "alias": "fileTypes"; "required": false; }; }, {}, never, never, false, never>;
}
