import * as i0 from "@angular/core";
import * as i1 from "./content-selection-filter.component";
import * as i2 from "./content-selection-filter-criteria.component";
import * as i3 from "@angular/common";
import * as i4 from "@angular/forms";
import * as i5 from "primeng/blockui";
import * as i6 from "primeng/panel";
import * as i7 from "primeng/fieldset";
import * as i8 from "primeng/button";
import * as i9 from "primeng/inputnumber";
import * as i10 from "primeng/inputtext";
import * as i11 from "../editable-listbox-component/editable-listbox.module";
import * as i12 from "primeng/multiselect";
import * as i13 from "../field-translation-container/field-container.module";
export declare class GeboAIContentSelectionFilterModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<GeboAIContentSelectionFilterModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<GeboAIContentSelectionFilterModule, [typeof i1.GeboAIContentSelectionFilterComponent, typeof i2.GeboAISelectionFilterCriteriaComponent], [typeof i3.CommonModule, typeof i4.FormsModule, typeof i4.ReactiveFormsModule, typeof i5.BlockUIModule, typeof i6.PanelModule, typeof i7.Fieldset, typeof i8.Button, typeof i9.InputNumber, typeof i10.InputTextModule, typeof i11.EditableListboxModule, typeof i12.MultiSelect, typeof i13.GeboAIFieldTranslationContainerModule], [typeof i1.GeboAIContentSelectionFilterComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<GeboAIContentSelectionFilterModule>;
}
//# sourceMappingURL=content-selection-filter.module.d.ts.map