import { OnChanges, OnInit, SimpleChanges } from "@angular/core";
import { AbstractControl, ControlValueAccessor, FormControl, FormGroup, ValidationErrors, Validator } from "@angular/forms";
import { AuthProviderDto, OAuth2AdminControllerService, Oauth2CustomAttribute } from "@Gebo.ai/gebo-ai-rest-api";
import * as i0 from "@angular/core";
export declare class GeboOauth2SecretComponent implements OnInit, OnChanges, ControlValueAccessor, Validator {
    private oAuth2AdminControllerService;
    protected formGroup: FormGroup;
    hideProviderChoice: boolean;
    forcedProviderName?: string;
    oauth2ChoosableScopes: {
        code: string;
        description: string;
    }[];
    oauth2MandatoryScopes: {
        code: string;
        description: string;
    }[];
    private oldProviderName?;
    private value?;
    protected loading: boolean;
    protected providers: AuthProviderDto[];
    protected providersData: {
        code: string;
        description: string;
    }[];
    protected actualEditableCustomAttributes: Oauth2CustomAttribute[];
    private formGroupChangeValueSubscription?;
    protected actualProvider?: AuthProviderDto;
    constructor(oAuth2AdminControllerService: OAuth2AdminControllerService);
    validate(control: AbstractControl): ValidationErrors | null;
    ngOnInit(): void;
    private validatorChange?;
    registerOnValidatorChange(fn: () => void): void;
    private triggerRevalidate;
    ngOnChanges(changes: SimpleChanges): void;
    writeValue(obj: any): void;
    restructureFormGroup(providerName: string): void;
    onChange: (v: any) => void;
    registerOnChange(fn: any): void;
    onTouched: (v: any) => void;
    registerOnTouched(fn: any): void;
    setDisabledState?(isDisabled: boolean): void;
    protected customAttribute(attr?: string): FormControl<any>;
    static ɵfac: i0.ɵɵFactoryDeclaration<GeboOauth2SecretComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<GeboOauth2SecretComponent, "gebo-ui-oauth2-secret-component", never, { "hideProviderChoice": { "alias": "hideProviderChoice"; "required": false; }; "forcedProviderName": { "alias": "forcedProviderName"; "required": false; }; "oauth2ChoosableScopes": { "alias": "oauth2ChoosableScopes"; "required": false; }; "oauth2MandatoryScopes": { "alias": "oauth2MandatoryScopes"; "required": false; }; }, {}, never, never, false, never>;
}
