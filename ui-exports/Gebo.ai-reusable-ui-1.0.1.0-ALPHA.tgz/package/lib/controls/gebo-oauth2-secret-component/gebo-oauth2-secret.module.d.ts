import * as i0 from "@angular/core";
import * as i1 from "./gebo-oauth2-secret.component";
import * as i2 from "@angular/common";
import * as i3 from "@angular/forms";
import * as i4 from "primeng/blockui";
import * as i5 from "primeng/panel";
import * as i6 from "primeng/inputtext";
import * as i7 from "../editable-listbox-component/editable-listbox.module";
import * as i8 from "primeng/multiselect";
import * as i9 from "primeng/fieldset";
import * as i10 from "../field-translation-container/field-container.module";
export declare class GeboOauth2SecretModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<GeboOauth2SecretModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<GeboOauth2SecretModule, [typeof i1.GeboOauth2SecretComponent], [typeof i2.CommonModule, typeof i3.FormsModule, typeof i3.ReactiveFormsModule, typeof i4.BlockUIModule, typeof i5.PanelModule, typeof i6.InputTextModule, typeof i7.EditableListboxModule, typeof i8.MultiSelectModule, typeof i9.FieldsetModule, typeof i10.GeboAIFieldTranslationContainerModule], [typeof i1.GeboOauth2SecretComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<GeboOauth2SecretModule>;
}
