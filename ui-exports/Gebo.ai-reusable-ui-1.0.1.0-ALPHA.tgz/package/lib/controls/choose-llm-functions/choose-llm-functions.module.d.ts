import * as i0 from "@angular/core";
import * as i1 from "./choose-llm-functions.component";
import * as i2 from "@angular/common";
import * as i3 from "primeng/treeselect";
import * as i4 from "@angular/forms";
import * as i5 from "primeng/panel";
import * as i6 from "primeng/blockui";
/**
 * Module that encapsulates the GeboAIChooseLLMFunctionscomponent.
 *
 * This module imports essential UI libraries for form handling (FormsModule, ReactiveFormsModule),
 * PrimeNG components (PanelModule, BlockUIModule, TreeSelectModule) for the UI interface,
 * and the standard CommonModule for Angular directives.
 * It declares and exports the GeboAIChooseLLMFunctionscomponent so it can be used in other modules.
 */
export declare class GeboAIChooseLLMFunctionsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<GeboAIChooseLLMFunctionsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<GeboAIChooseLLMFunctionsModule, [typeof i1.GeboAIChooseLLMFunctionscomponent], [typeof i2.CommonModule, typeof i3.TreeSelectModule, typeof i4.FormsModule, typeof i4.ReactiveFormsModule, typeof i5.PanelModule, typeof i6.BlockUIModule], [typeof i1.GeboAIChooseLLMFunctionscomponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<GeboAIChooseLLMFunctionsModule>;
}
