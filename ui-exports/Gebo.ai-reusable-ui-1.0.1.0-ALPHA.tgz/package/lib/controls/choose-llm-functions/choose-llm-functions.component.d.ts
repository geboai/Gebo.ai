/**
 * This Source Code is subject to the terms of the
 * Gebo.ai community version Mozilla Public License Version 2.0 (MPL-2.0) — With Data Protection Clauses
 * If a copy of the LICENCE was not distributed with this file, You can obtain one at
 * https://gebo.ai/gebo-ai-community-version-mozilla-public-license-version-2-0-mpl-2-0-with-data-protection-clauses/
 * and https://mozilla.org/MPL/2.0/.
 * Copyright (c) 2025+ Gebo.ai
 */
/**
 * AI generated comments
 *
 * This component allows users to select LLM (Large Language Model) functions from a tree structure.
 * It implements ControlValueAccessor to work with Angular forms, allowing it to be used in form controls.
 * The component fetches available functions from a service and displays them in a hierarchical tree view,
 * enabling selection of specific functions which can be used in the context of knowledge bases.
 */
import { OnChanges, OnInit, SimpleChanges } from "@angular/core";
import { ControlValueAccessor, FormGroup } from "@angular/forms";
import { FunctionsLookupControllerService } from "@Gebo.ai/gebo-ai-rest-api";
import { TreeNode } from "primeng/api";
import * as i0 from "@angular/core";
export declare class GeboAIChooseLLMFunctionscomponent implements ControlValueAccessor, OnInit, OnChanges {
    private functionsLookupService;
    /**
     * Optional input to determine if the component is being used in a knowledge base context,
     * which affects which functions are available for selection.
     */
    knowledgeBaseContext?: boolean;
    /**
     * Flag to track if writeValue has been called to prevent premature onChange events
     * during initialization.
     */
    private writeValueHasBeenCalled;
    /**
     * Stores the tree structure of functions that will be displayed in the UI.
     */
    root: TreeNode<any>[];
    /**
     * Form group that manages the selected functions in the tree component.
     */
    formGroup: FormGroup;
    /**
     * Initializes the component with the functions lookup service.
     * @param functionsLookupService Service to fetch available LLM functions
     */
    constructor(functionsLookupService: FunctionsLookupControllerService);
    /**
     * Array of selected function names that serves as the component's value.
     */
    private functionsList;
    /**
     * Flag to indicate when the component is loading data.
     */
    loading: boolean;
    /**
     * Initializes the component and sets up value change subscription to track
     * selected functions and propagate changes via the ControlValueAccessor interface.
     */
    ngOnInit(): void;
    /**
     * Responds to changes in inputs, specifically knowledgeBaseContext.
     * Fetches the function tree from the service when the context is defined.
     * @param changes SimpleChanges object containing information about changed properties
     */
    ngOnChanges(changes: SimpleChanges): void;
    /**
     * Updates the UI selection based on the current functionsList.
     * It finds the tree nodes that match the function names in functionsList
     * and updates the form control without triggering change events.
     */
    private tryDisplay;
    /**
     * ControlValueAccessor method to write a new value to the component.
     * @param obj The new value for the component (array of function names)
     */
    writeValue(obj: any): void;
    /**
     * Change handler function passed by the form
     */
    onChange: any;
    /**
     * ControlValueAccessor method to register the onChange function
     * @param fn Function to call when the value changes
     */
    registerOnChange(fn: any): void;
    /**
     * Touch handler function passed by the form
     */
    onTouched: any;
    /**
     * ControlValueAccessor method to register the onTouched function
     * @param fn Function to call when the control is touched
     */
    registerOnTouched(fn: any): void;
    /**
     * ControlValueAccessor method to enable/disable the component
     * @param isDisabled Boolean indicating if the component should be disabled
     */
    setDisabledState?(isDisabled: boolean): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<GeboAIChooseLLMFunctionscomponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<GeboAIChooseLLMFunctionscomponent, "gebo-ai-choose-llm-functions-component", never, { "knowledgeBaseContext": { "alias": "knowledgeBaseContext"; "required": false; }; }, {}, never, never, false, never>;
}
