import * as i0 from "@angular/core";
import * as i1 from "./view-table.component";
import * as i2 from "@angular/common";
import * as i3 from "primeng/table";
/**
 * AI generated comments
 *
 * This module provides the packaging and configuration for the GeboAIViewTable functionality.
 * It imports necessary Angular and PrimeNG dependencies, declares the GeboAIViewTableComponent,
 * and exports it to make it available for other modules to use. This follows the standard
 * Angular module pattern for encapsulating and organizing related components.
 */
export declare class GeboAIViewTableModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<GeboAIViewTableModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<GeboAIViewTableModule, [typeof i1.GeboAIViewTableComponent], [typeof i2.CommonModule, typeof i3.TableModule], [typeof i1.GeboAIViewTableComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<GeboAIViewTableModule>;
}
//# sourceMappingURL=view-table.module.d.ts.map