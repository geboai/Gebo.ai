/**
 * This Source Code is subject to the terms of the
 * Gebo.ai community version Mozilla Public License Version 2.0 (MPL-2.0) — With Data Protection Clauses
 * If a copy of the LICENCE was not distributed with this file, You can obtain one at
 * https://gebo.ai/gebo-ai-community-version-mozilla-public-license-version-2-0-mpl-2-0-with-data-protection-clauses/
 * and https://mozilla.org/MPL/2.0/.
 * Copyright (c) 2025+ Gebo.ai
 */
/**
 * AI generated comments
 * This file contains a component for uploading files to a userspace in the Gebo.ai system.
 * It extends BaseEntityEditingComponent to provide editing capabilities for UserspaceFilesUploadModel.
 */
import { Injector } from "@angular/core";
import { FormGroup } from "@angular/forms";
import { ConfirmationService } from "primeng/api";
import { Observable } from "rxjs";
import { UserspaceFilesUploadModel, UserspaceFilesUploadModelService } from "./userspace-files-upload.service";
import { FileBeforeUploadEvent, FileProgressEvent, FileUploadEvent } from "primeng/fileupload";
import { IngestionFileTypesLibraryControllerService } from "@Gebo.ai/gebo-ai-rest-api";
import { BaseEntityEditingComponent } from "../base-entity-editing-component/base-entity-editing.component";
import { GeboFormGroupsService } from "../../architecture/gebo-form-groups.service";
import { GeboUIActionRoutingService } from "../../architecture/gebo-ui-action-routing.service";
import { GeboUIOutputForwardingService } from "../../architecture/gebo-ui-output-forwarding.service";
import * as i0 from "@angular/core";
/**
 * Component responsible for managing file uploads to user workspace.
 * This component handles the upload process, validation of file types,
 * and provides user feedback during the upload process.
 */
export declare class GeboAIUserspaceFilesUploadComponent extends BaseEntityEditingComponent<UserspaceFilesUploadModel> {
    private userspaceService;
    baseUrl: string;
    private contentTypeService;
    /**
     * The entity name used for identification in the parent component.
     */
    protected entityName: string;
    /**
     * Flat list of allowed file extensions separated by commas.
     */
    filesExtensionsFlatList: string;
    /**
     * Form group for managing the upload form controls.
     */
    formGroup: FormGroup<any>;
    /**
     * Form group for managing file deletion.
     */
    deleteFormGroup: FormGroup<any>;
    /**
     * Flag indicating whether the server is currently executing a process.
     * Used to prevent concurrent operations.
     */
    private serverExecuting;
    /**
     * Component constructor that initializes services and dependencies.
     * @param injector The Angular injector service
     * @param geboFormGroupsService Service for managing form groups
     * @param confirmationService Service for handling user confirmations
     * @param geboUIActionRoutingService Service for UI action routing
     * @param userspaceService Service for userspace file operations
     * @param baseUrl Base URL for API calls
     * @param contentTypeService Service for handling file type information
     * @param outputForwardingService Optional service for forwarding outputs
     */
    constructor(injector: Injector, geboFormGroupsService: GeboFormGroupsService, confirmationService: ConfirmationService, geboUIActionRoutingService: GeboUIActionRoutingService, userspaceService: UserspaceFilesUploadModelService, baseUrl: string, contentTypeService: IngestionFileTypesLibraryControllerService, outputForwardingService?: GeboUIOutputForwardingService);
    /**
     * Periodically checks if the backend is busy processing files.
     * Sets the serverExecuting flag based on the response.
     */
    private checkBusyBackend;
    /**
     * Initializes the component, sets up validators, and loads file type information.
     * Also starts the periodic background check for server status.
     */
    ngOnInit(): void;
    /**
     * Called when persistent data is loaded from the backend.
     * @param actualValue The loaded UserspaceFilesUploadModel
     */
    protected onLoadedPersistentData(actualValue: UserspaceFilesUploadModel): void;
    /**
     * Finds an upload model by its code identifier.
     * @param code The unique code of the upload model
     * @returns An observable of the found model or null
     */
    findByCode(code: string): Observable<UserspaceFilesUploadModel | null>;
    /**
     * Publishes the upload model to the server.
     * @param value The upload model to publish
     * @returns An observable of the published model
     */
    private publish;
    /**
     * Saves changes to an existing upload model.
     * @param value The upload model to save
     * @returns An observable of the saved model
     */
    save(value: UserspaceFilesUploadModel): Observable<UserspaceFilesUploadModel>;
    /**
     * Inserts a new upload model.
     * @param value The upload model to insert
     * @returns An observable of the inserted model
     */
    insert(value: UserspaceFilesUploadModel): Observable<UserspaceFilesUploadModel>;
    /**
     * Delete operation (not implemented).
     * @param value The upload model to delete
     * @throws Error as this method is not implemented
     */
    delete(value: UserspaceFilesUploadModel): Observable<boolean>;
    /**
     * Checks if a model can be deleted.
     * @param value The upload model to check
     * @returns An observable containing deletion status and message
     */
    canBeDeleted(value: UserspaceFilesUploadModel): Observable<{
        canBeDeleted: boolean;
        message: string;
    }>;
    /**
     * Handles the completion of the automatic upload process.
     * @param event The upload event data
     */
    onBasicUploadAuto(event: FileUploadEvent): void;
    /**
     * Handles the event before the upload begins.
     * @param event The before upload event data
     */
    onBeforeUpload(event: FileBeforeUploadEvent): void;
    /**
     * Tracks upload progress and handles different HTTP event types.
     * @param event The progress event data
     */
    onProgress(event: FileProgressEvent): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<GeboAIUserspaceFilesUploadComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<GeboAIUserspaceFilesUploadComponent, "gebo-ui-userspace-fileuploads-component", never, {}, {}, never, never, false, never>;
}
//# sourceMappingURL=userspace-files-upload.component.d.ts.map