import { GeboUIEntityFormsLauncherService } from "../../architecture/gebo-ui-entity-forms-launcher.service";
import { GeboUIEntityFormConfig } from "../../architecture/gebo-ui-entity-form-config";
import * as i0 from "@angular/core";
import * as i1 from "./userspace-files.component";
import * as i2 from "./userspace-folder.component";
import * as i3 from "./user-knowledgebase.component";
import * as i4 from "./userspace-browse.component";
import * as i5 from "./userspace-files-upload.component";
import * as i6 from "@angular/common";
import * as i7 from "@angular/forms";
import * as i8 from "primeng/panel";
import * as i9 from "primeng/dialog";
import * as i10 from "primeng/tree";
import * as i11 from "primeng/blockui";
import * as i12 from "primeng/button";
import * as i13 from "../content-viewer/gebo-ai-content-viewer.module";
import * as i14 from "primeng/checkbox";
import * as i15 from "primeng/fileupload";
import * as i16 from "../../architecture/gebo-ui-architecture.module";
import * as i17 from "primeng/inputtext";
import * as i18 from "primeng/multiselect";
import * as i19 from "primeng/chip";
import * as i20 from "primeng/fieldset";
import * as i21 from "../field-translation-container/field-container.module";
/**
 * Service responsible for providing entity form configurations for userspace-related entities.
 * Extends the base GeboUIEntityFormsLauncherService to specialize in userspace forms.
 */
export declare class UserspaceFormsListService extends GeboUIEntityFormsLauncherService {
    /**
     * Overrides the base method to return configurations specific to userspace entities.
     * @returns An array of GeboUIEntityFormConfig objects for userspace entities
     */
    getCurrentConfigurations(): GeboUIEntityFormConfig[];
    static ɵfac: i0.ɵɵFactoryDeclaration<UserspaceFormsListService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<UserspaceFormsListService>;
}
/**
 * Angular module that packages all components, services, and dependencies related to
 * userspace files functionality. It imports necessary Angular and PrimeNG modules and
 * declares components related to userspace file management.
 */
export declare class GeboAIUserspaceFilesModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<GeboAIUserspaceFilesModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<GeboAIUserspaceFilesModule, [typeof i1.GeboAIUserpaceFilesComponent, typeof i2.GeboAIUserspaceFolderComponent, typeof i3.GeboAIUserspaceKnowledgebaseComponent, typeof i4.GeboAIUserspaceBrowseComponent, typeof i5.GeboAIUserspaceFilesUploadComponent], [typeof i6.CommonModule, typeof i7.ReactiveFormsModule, typeof i7.FormsModule, typeof i8.PanelModule, typeof i9.DialogModule, typeof i10.TreeModule, typeof i11.BlockUIModule, typeof i12.ButtonModule, typeof i13.GeboAIContentViewerModule, typeof i10.TreeModule, typeof i14.CheckboxModule, typeof i15.FileUploadModule, typeof i16.GeboUIArchitectureModule, typeof i17.InputTextModule, typeof i18.MultiSelectModule, typeof i19.ChipModule, typeof i20.FieldsetModule, typeof i21.GeboAIFieldTranslationContainerModule], [typeof i1.GeboAIUserpaceFilesComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<GeboAIUserspaceFilesModule>;
}
//# sourceMappingURL=userspace-files.module.d.ts.map