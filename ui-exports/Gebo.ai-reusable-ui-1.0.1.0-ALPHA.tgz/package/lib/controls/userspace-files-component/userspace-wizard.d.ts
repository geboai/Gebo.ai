/**
 * This Source Code is subject to the terms of the
 * Gebo.ai community version Mozilla Public License Version 2.0 (MPL-2.0) — With Data Protection Clauses
 * If a copy of the LICENCE was not distributed with this file, You can obtain one at
 * https://gebo.ai/gebo-ai-community-version-mozilla-public-license-version-2-0-mpl-2-0-with-data-protection-clauses/
 * and https://mozilla.org/MPL/2.0/.
 * Copyright (c) 2025+ Gebo.ai
 */
import { GeboAIEntitiesSettingWizardConfiguration } from "../base-entity-editing-component/entities-modification-wizard";
/**
 * Configuration array for the userspace uploads wizard.
 * This defines a multi-step wizard with configurations for navigating between steps
 * and handling data transitions between the different screens of the wizard.
 */
export declare const USERSPACE_UPLOADS_WIZARD: GeboAIEntitiesSettingWizardConfiguration[];
