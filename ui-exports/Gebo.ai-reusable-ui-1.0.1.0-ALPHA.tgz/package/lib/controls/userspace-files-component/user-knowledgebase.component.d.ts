/**
 * This Source Code is subject to the terms of the
 * Gebo.ai community version Mozilla Public License Version 2.0 (MPL-2.0) — With Data Protection Clauses
 * If a copy of the LICENCE was not distributed with this file, You can obtain one at
 * https://gebo.ai/gebo-ai-community-version-mozilla-public-license-version-2-0-mpl-2-0-with-data-protection-clauses/
 * and https://mozilla.org/MPL/2.0/.
 * Copyright (c) 2025+ Gebo.ai
 */
import { Injector } from "@angular/core";
import { FormGroup } from "@angular/forms";
import { GroupInfo, UserControllerService, UserspaceControllerService, UserspaceKnowledgebaseDto } from "@Gebo.ai/gebo-ai-rest-api";
import { ConfirmationService } from "primeng/api";
import { Observable } from "rxjs";
import { BaseEntityEditingComponent } from "../base-entity-editing-component/base-entity-editing.component";
import { GeboFormGroupsService } from "../../architecture/gebo-form-groups.service";
import { GeboUIActionRoutingService } from "../../architecture/gebo-ui-action-routing.service";
import { GeboUIOutputForwardingService } from "../../architecture/gebo-ui-output-forwarding.service";
import * as i0 from "@angular/core";
/**
 * AI generated comments
 *
 * Component responsible for managing userspace knowledgebase entities.
 * Provides UI for creating, reading, updating, and deleting userspace knowledgebases.
 * Extends the BaseEntityEditingComponent to leverage common CRUD functionality.
 * Connects to backend services to perform operations on knowledgebase entities.
 */
export declare class GeboAIUserspaceKnowledgebaseComponent extends BaseEntityEditingComponent<UserspaceKnowledgebaseDto> {
    private userspaceControllerService;
    private userControllerService;
    /**
     * Identifies the type of entity being edited
     */
    protected entityName: string;
    /**
     * Form group that contains all form controls for the knowledgebase entity
     */
    formGroup: FormGroup<any>;
    /**
     * Stores the user groups that can be assigned to the knowledgebase
     */
    userGroups: GroupInfo[];
    /**
     * Constructor initializes the component with required services
     * @param injector Angular dependency injector
     * @param geboFormGroupsService Service for form group management
     * @param confirmationService Service for confirmation dialogs
     * @param geboUIActionRoutingService Service for UI action routing
     * @param userspaceControllerService Service for userspace operations
     * @param userControllerService Service for user-related operations
     * @param outputForwardingService Optional service for output forwarding
     */
    constructor(injector: Injector, geboFormGroupsService: GeboFormGroupsService, confirmationService: ConfirmationService, geboUIActionRoutingService: GeboUIActionRoutingService, userspaceControllerService: UserspaceControllerService, userControllerService: UserControllerService, outputForwardingService?: GeboUIOutputForwardingService);
    /**
     * Lifecycle hook that initializes the component.
     * Loads user groups from the backend service.
     */
    ngOnInit(): void;
    /**
     * Retrieves a userspace knowledgebase by its code
     * @param code The unique identifier for the knowledgebase
     * @returns An Observable containing the found knowledgebase or null
     */
    findByCode(code: string): Observable<UserspaceKnowledgebaseDto | null>;
    /**
     * Updates an existing userspace knowledgebase
     * @param value The knowledgebase data to update
     * @returns An Observable containing the updated knowledgebase
     */
    save(value: UserspaceKnowledgebaseDto): Observable<UserspaceKnowledgebaseDto>;
    /**
     * Creates a new userspace knowledgebase
     * @param value The knowledgebase data to create
     * @returns An Observable containing the newly created knowledgebase
     */
    insert(value: UserspaceKnowledgebaseDto): Observable<UserspaceKnowledgebaseDto>;
    /**
     * Deletes a userspace knowledgebase
     * @param value The knowledgebase to delete
     * @returns An Observable containing a boolean indicating success
     */
    delete(value: UserspaceKnowledgebaseDto): Observable<boolean>;
    /**
     * Determines if a knowledgebase can be deleted
     * Currently always returns true with no validation
     * @param value The knowledgebase to check
     * @returns An Observable containing deletion eligibility information
     */
    canBeDeleted(value: UserspaceKnowledgebaseDto): Observable<{
        canBeDeleted: boolean;
        message: string;
    }>;
    static ɵfac: i0.ɵɵFactoryDeclaration<GeboAIUserspaceKnowledgebaseComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<GeboAIUserspaceKnowledgebaseComponent, "gebo-ai-userspace-knowledgebase-component", never, {}, {}, never, never, false, never>;
}
//# sourceMappingURL=user-knowledgebase.component.d.ts.map