/**
 * This Source Code is subject to the terms of the
 * Gebo.ai community version Mozilla Public License Version 2.0 (MPL-2.0) — With Data Protection Clauses
 * If a copy of the LICENCE was not distributed with this file, You can obtain one at
 * https://gebo.ai/gebo-ai-community-version-mozilla-public-license-version-2-0-mpl-2-0-with-data-protection-clauses/
 * and https://mozilla.org/MPL/2.0/.
 * Copyright (c) 2025+ Gebo.ai
 */
/**
 * AI generated comments
 *
 * This file defines a component for managing userspace folders in the Gebo.ai application.
 * It extends the BaseEntityEditingComponent class to provide CRUD operations for UserspaceFolderDto objects.
 */
import { Injector } from "@angular/core";
import { FormGroup } from "@angular/forms";
import { UserspaceControllerService, UserspaceFolderDto, UserspaceKnowledgebaseDto } from "@Gebo.ai/gebo-ai-rest-api";
import { ConfirmationService } from "primeng/api";
import { Observable } from "rxjs";
import { BaseEntityEditingComponent } from "../base-entity-editing-component/base-entity-editing.component";
import { GeboFormGroupsService } from "../../architecture/gebo-form-groups.service";
import { GeboUIActionRoutingService } from "../../architecture/gebo-ui-action-routing.service";
import { GeboUIOutputForwardingService } from "../../architecture/gebo-ui-output-forwarding.service";
import * as i0 from "@angular/core";
/**
 * Component responsible for editing and managing userspace folders.
 * Provides a form interface for creating, updating, and deleting UserspaceFolderDto objects.
 * Extends BaseEntityEditingComponent to inherit common editing functionality.
 */
export declare class GeboAIUserspaceFolderComponent extends BaseEntityEditingComponent<UserspaceFolderDto> {
    private userspaceControllerService;
    /**
     * The entity name used for identification and form generation
     */
    protected entityName: string;
    /**
     * FormGroup containing form controls for the userspace folder properties
     * Includes controls for code, description, parent knowledgebase code, upload code, and owner
     */
    formGroup: FormGroup<any>;
    /**
     * Constructor initializes the component with required services
     *
     * @param injector Angular injector for dependency injection
     * @param geboFormGroupsService Service for handling form groups
     * @param confirmationService Service for user confirmations
     * @param geboUIActionRoutingService Service for UI action routing
     * @param userspaceControllerService Service for userspace CRUD operations
     * @param outputForwardingService Optional service for forwarding outputs
     */
    constructor(injector: Injector, geboFormGroupsService: GeboFormGroupsService, confirmationService: ConfirmationService, geboUIActionRoutingService: GeboUIActionRoutingService, userspaceControllerService: UserspaceControllerService, outputForwardingService?: GeboUIOutputForwardingService);
    /**
     * Retrieves a userspace folder by its unique code
     *
     * @param code The unique identifier for the userspace folder
     * @returns An Observable containing the found UserspaceFolderDto or null
     */
    findByCode(code: string): Observable<UserspaceFolderDto | null>;
    /**
     * Updates an existing userspace folder
     *
     * @param value The UserspaceFolderDto with updated values
     * @returns An Observable containing the updated UserspaceFolderDto
     */
    save(value: UserspaceFolderDto): Observable<UserspaceFolderDto>;
    /**
     * Creates a new userspace folder
     *
     * @param value The UserspaceFolderDto to create
     * @returns An Observable containing the newly created UserspaceFolderDto
     */
    insert(value: UserspaceFolderDto): Observable<UserspaceFolderDto>;
    /**
     * Deletes a userspace folder
     *
     * @param value The UserspaceFolderDto to delete
     * @returns An Observable containing a boolean indicating success
     */
    delete(value: UserspaceFolderDto): Observable<boolean>;
    /**
     * Checks if a userspace knowledgebase can be deleted
     * Currently always returns true with no message
     *
     * @param value The UserspaceKnowledgebaseDto to check
     * @returns An Observable containing an object with canBeDeleted flag and message
     */
    canBeDeleted(value: UserspaceKnowledgebaseDto): Observable<{
        canBeDeleted: boolean;
        message: string;
    }>;
    static ɵfac: i0.ɵɵFactoryDeclaration<GeboAIUserspaceFolderComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<GeboAIUserspaceFolderComponent, "gebo-ai-userspace-edit-component", never, {}, {}, never, never, false, never>;
}
//# sourceMappingURL=userspace-folder.component.d.ts.map