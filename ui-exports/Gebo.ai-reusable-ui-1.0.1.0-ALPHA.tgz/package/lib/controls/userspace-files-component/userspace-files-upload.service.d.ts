import { UserspaceFolderDto, UserspaceFileDto, UserspaceControllerService, PublishingStatus } from "@Gebo.ai/gebo-ai-rest-api";
import { Observable } from "rxjs";
import { IOperationStatus } from "../base-entity-editing-component/operation-status";
import * as i0 from "@angular/core";
/**
 * AI generated comments
 * Module for managing userspace files and folders, providing functionality for uploading,
 * finding, and publishing userspace content.
 */
/**
 * Interface representing a model for userspace files upload operation.
 * Contains information about the userspace folder, files, and optional code and description.
 */
export interface UserspaceFilesUploadModel {
    /** Unique identifier code for the userspace folder */
    code?: string;
    /** Description of the userspace folder */
    description?: string;
    /** The userspace folder this model represents */
    userspaceFolder: UserspaceFolderDto;
    /** Collection of userspace files associated with this folder */
    userspaceFiles: UserspaceFileDto[];
}
/**
 * Service for managing userspace files upload operations.
 * Provides methods to find, publish, and poll status of userspace files and folders.
 */
export declare class UserspaceFilesUploadModelService {
    private userspaceServiceController;
    /**
     * Creates an instance of UserspaceFilesUploadModelService.
     * @param userspaceServiceController The controller service for userspace operations
     */
    constructor(userspaceServiceController: UserspaceControllerService);
    /**
     * Finds a userspace folder and its associated files by the folder code.
     * @param code The unique identifier of the userspace folder to find
     * @returns Observable of the complete UserspaceFilesUploadModel including folder and files
     */
    findByCode(code: string): Observable<UserspaceFilesUploadModel>;
    /**
     * Publishes a userspace folder and retrieves the updated model after publishing.
     * @param value The UserspaceFilesUploadModel to publish
     * @returns Observable containing operation status and the updated model after publishing
     */
    publish(value: UserspaceFilesUploadModel): Observable<IOperationStatus<UserspaceFilesUploadModel>>;
    /**
     * Polls the publishing status of a userspace folder.
     * @param dto The UserspaceFolderDto to check status for
     * @returns Observable of the current publishing status
     */
    pollStatus(dto: UserspaceFolderDto): Observable<PublishingStatus>;
    static ɵfac: i0.ɵɵFactoryDeclaration<UserspaceFilesUploadModelService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<UserspaceFilesUploadModelService>;
}
//# sourceMappingURL=userspace-files-upload.service.d.ts.map