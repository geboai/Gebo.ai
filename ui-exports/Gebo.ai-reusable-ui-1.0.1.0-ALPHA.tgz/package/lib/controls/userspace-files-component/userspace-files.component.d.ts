/**
 * This Source Code is subject to the terms of the
 * Gebo.ai community version Mozilla Public License Version 2.0 (MPL-2.0) — With Data Protection Clauses
 * If a copy of the LICENCE was not distributed with this file, You can obtain one at
 * https://gebo.ai/gebo-ai-community-version-mozilla-public-license-version-2-0-mpl-2-0-with-data-protection-clauses/
 * and https://mozilla.org/MPL/2.0/.
 * Copyright (c) 2025+ Gebo.ai
 */
/**
 * AI generated comments
 * This component manages the selection and display of userspace files in the Gebo.ai application.
 * It implements ControlValueAccessor to integrate with Angular forms, allowing it to be used in form controls.
 * The component provides functionality to browse, select, and display files from the user's workspace.
 */
import { OnChanges, OnInit, SimpleChanges } from "@angular/core";
import { ControlValueAccessor, FormGroup } from "@angular/forms";
import { UserspaceControllerService, UserspaceFileDto } from "@Gebo.ai/gebo-ai-rest-api";
import { GeboAIUserspaceFolderComponent } from "./userspace-folder.component";
import { GeboAIUserspaceKnowledgebaseComponent } from "./user-knowledgebase.component";
import { GeboAIUserspaceFilesUploadComponent } from "./userspace-files-upload.component";
import * as i0 from "@angular/core";
/**
 * Component that handles userspace files functionality in the Gebo.ai application.
 * Implements ControlValueAccessor to work with Angular forms, allowing for selection and management
 * of files from user's workspace. It can display files, allow browsing, and handle selection changes.
 */
export declare class GeboAIUserpaceFilesComponent implements OnInit, OnChanges, ControlValueAccessor {
    private userspaceControllerService;
    /** Array of knowledge base codes that can be used for filtering or contextual display */
    knowledgeBaseCodes: string[];
    /** Flag to indicate if knowledge bases should not be displayed or used */
    noKnowledgeBases: boolean;
    /** Indicates if data is currently being loaded */
    loading: boolean;
    /** Controls visibility of the userspace browse window */
    openedUserspaceBrowseWindow: boolean;
    /** List of user files retrieved from the backend */
    userFiles: UserspaceFileDto[];
    /** Form group for editing file selection */
    editingFormGroup: FormGroup;
    /** Internal storage for the list of file codes */
    private codesList;
    /** Reference to the folder component for browsing */
    userspaceFolderComponent: typeof GeboAIUserspaceFolderComponent;
    /** Reference to the knowledge base component */
    userspaceKnowledgebaseComponent: typeof GeboAIUserspaceKnowledgebaseComponent;
    /** Reference to the file upload component */
    userspaceFilesUploadComponent: typeof GeboAIUserspaceFilesUploadComponent;
    /**
     * Constructor that injects the userspace controller service for API interactions
     * @param userspaceControllerService Service to interact with userspace files API
     */
    constructor(userspaceControllerService: UserspaceControllerService);
    /**
     * Lifecycle hook that initializes the component
     */
    ngOnInit(): void;
    /**
     * Lifecycle hook that responds to changes in input properties
     * @param changes Simple changes object containing current and previous values
     */
    ngOnChanges(changes: SimpleChanges): void;
    /**
     * Synchronizes the displayed files with the selected codes
     * Fetches file details from the API based on the selected codes
     */
    private syncDisplay;
    /**
     * ControlValueAccessor method that updates the component's value when the form control value changes
     * @param obj The value received from the form model
     */
    writeValue(obj: any): void;
    /**
     * Handles the confirmation of file selection from the form
     * Updates the internal state and notifies form subscribers
     */
    onConfirmed(): void;
    /** Function to call when the value changes */
    private onChange;
    /**
     * ControlValueAccessor method that registers a callback function for value changes
     * @param fn The callback function
     */
    registerOnChange(fn: any): void;
    /** Function to call when the control is touched */
    private onTouch;
    /**
     * ControlValueAccessor method that registers a callback function for touched events
     * @param fn The callback function
     */
    registerOnTouched(fn: any): void;
    /**
     * ControlValueAccessor method to enable/disable the component
     * @param isDisabled Whether the component should be disabled
     */
    setDisabledState?(isDisabled: boolean): void;
    /**
     * Opens the userspace browse window for file selection
     */
    openUserSpaceBrowseWindow(): void;
    /**
     * Handles the removal of a file from the selected list
     * @param f The file to be removed
     */
    doRemoveFile(f: UserspaceFileDto): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<GeboAIUserpaceFilesComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<GeboAIUserpaceFilesComponent, "gebo-ai-userspace-files-component", never, { "knowledgeBaseCodes": { "alias": "knowledgeBaseCodes"; "required": false; }; "noKnowledgeBases": { "alias": "noKnowledgeBases"; "required": false; }; }, {}, never, never, false, never>;
}
