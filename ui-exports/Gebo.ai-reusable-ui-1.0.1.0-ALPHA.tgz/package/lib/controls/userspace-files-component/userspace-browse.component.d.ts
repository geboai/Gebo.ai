/**
 * This Source Code is subject to the terms of the
 * Gebo.ai community version Mozilla Public License Version 2.0 (MPL-2.0) — With Data Protection Clauses
 * If a copy of the LICENCE was not distributed with this file, You can obtain one at
 * https://gebo.ai/gebo-ai-community-version-mozilla-public-license-version-2-0-mpl-2-0-with-data-protection-clauses/
 * and https://mozilla.org/MPL/2.0/.
 * Copyright (c) 2025+ Gebo.ai
 */
/**
 * AI generated comments
 * This file contains the implementation of the GeboAIUserspaceBrowseComponent, a component that
 * provides a user interface for browsing and selecting files from the user's workspace.
 * It displays files and folders in a tree structure and allows for navigation and selection.
 */
import { EventEmitter, OnChanges, OnInit, SimpleChanges } from "@angular/core";
import { ControlValueAccessor, FormGroup } from "@angular/forms";
import { UserspaceControllerService, UserspaceFileDto, UserspaceFolderDto, UserspaceKnowledgebaseDto } from "@Gebo.ai/gebo-ai-rest-api";
import { TreeNode } from "primeng/api";
import { TreeNodeExpandEvent } from "primeng/tree";
import { GeboUIActionRoutingService } from "../../architecture/gebo-ui-action-routing.service";
import * as i0 from "@angular/core";
/**
 * Interface representing an item in the userspace tree structure.
 * It can represent a knowledge base, user knowledge base, folder, or file,
 * with the corresponding data attached.
 */
interface UserspaceTreeItem {
    isKnowledgeBase?: boolean;
    isUserKnowledgeBase?: boolean;
    isUserspaceFolder?: boolean;
    isFile?: boolean;
    data: UserspaceKnowledgebaseDto | UserspaceFolderDto | UserspaceFileDto;
}
/**
 * Component for browsing and selecting files from the user's workspace.
 * Implements ControlValueAccessor to integrate with Angular forms.
 * Uses a tree structure to represent the hierarchy of knowledge bases, folders, and files.
 */
export declare class GeboAIUserspaceBrowseComponent implements OnInit, OnChanges, ControlValueAccessor {
    private userspaceControllerService;
    private geboUIActionRoutingService;
    /** Knowledge base codes to filter the displayed items */
    knowledgeBaseCodes: string[];
    /** Flag to indicate whether to show knowledge bases or not */
    noKnowledgeBases: boolean;
    /** Event emitter when the browser is closed */
    closeMe: EventEmitter<boolean>;
    /** Event emitter when the selection is confirmed */
    confirmed: EventEmitter<boolean>;
    /** Array of currently selected files to display */
    choosedDisplay: UserspaceFileDto[];
    /** Flag indicating if data is being loaded */
    loading: boolean;
    /** Root nodes of the tree structure */
    root: TreeNode<UserspaceTreeItem>[];
    /** Form group for handling the selection */
    formGroup: FormGroup;
    /**
     * Constructor initializes required services
     * @param userspaceControllerService Service for interacting with userspace API
     * @param geboUIActionRoutingService Service for routing UI actions
     */
    constructor(userspaceControllerService: UserspaceControllerService, geboUIActionRoutingService: GeboUIActionRoutingService);
    /**
     * Creates a folder node for the tree structure
     * @param node The userspace item to create a node for
     * @param parent The parent node in the tree
     * @returns A TreeNode representation of the folder
     */
    private createFolderNode;
    /**
     * Loads the root nodes of the tree structure based on the input parameters
     */
    loadRoots(): void;
    /**
     * Initialize the component, set up form validation and subscribe to value changes
     */
    ngOnInit(): void;
    /**
     * Updates the display of selected files based on their codes
     * @param codes Array of file codes to display
     * @param confirmedEntries Optional callback to execute after files are found
     */
    private showChoosedDisplay;
    /**
     * Recursively searches the tree for files with the specified codes
     * @param codes Array of file codes to search for
     * @param root Root nodes to start the search from
     * @returns Array of found UserspaceFileDto objects
     */
    private searchTree;
    /**
     * Refreshes a node by simulating its parent's expand event
     * @param node The node to refresh
     * @param evt The mouse event that triggered the refresh
     */
    refreshThis(node: TreeNode<UserspaceTreeItem>, evt: MouseEvent): void;
    /**
     * Responds to changes in component inputs
     * @param changes The changed input properties
     */
    ngOnChanges(changes: SimpleChanges): void;
    /**
     * Opens a folder in the UI action system
     * @param item The tree node representing the folder to open
     */
    openFolder(item: TreeNode<UserspaceTreeItem>): void;
    /**
     * Creates a new child folder under the selected knowledge base
     * @param item The tree node representing the parent knowledge base
     */
    newChildFolder(item: TreeNode<UserspaceTreeItem>): void;
    /**
     * Creates a new child knowledge base under the selected knowledge base
     * @param item The tree node representing the parent knowledge base
     */
    newChildKnowledgebase(item: TreeNode<UserspaceTreeItem>): void;
    /**
     * Opens the edit interface for a knowledge base
     * @param item The tree node representing the knowledge base to edit
     */
    editChildKnowledgebase(item: TreeNode<UserspaceTreeItem>): void;
    /**
     * Handles the expansion of a tree node, loading its children as needed
     * @param item The expand event containing the node being expanded
     */
    nodeExpand(item: TreeNodeExpandEvent): void;
    /**
     * Creates a file node for the tree structure
     * @param x The file DTO to create a node for
     * @param parent The parent node in the tree
     * @returns A TreeNode representation of the file
     */
    createFileNode(x: UserspaceFileDto, parent: TreeNode<UserspaceTreeItem>): TreeNode<UserspaceTreeItem>;
    /**
     * Confirms the current selection and emits the appropriate events
     */
    confirmEditing(): void;
    /**
     * Writes a value to the control - part of ControlValueAccessor implementation
     * @param obj The value to write to the control
     */
    writeValue(obj: any): void;
    /** Function to call when the value changes */
    private onChange;
    /**
     * Registers a callback function for value changes - part of ControlValueAccessor implementation
     * @param fn The callback function
     */
    registerOnChange(fn: any): void;
    /** Function to call when the control is touched */
    private onTouched;
    /**
     * Registers a callback function for touched events - part of ControlValueAccessor implementation
     * @param fn The callback function
     */
    registerOnTouched(fn: any): void;
    /**
     * Sets the disabled state of the control - part of ControlValueAccessor implementation
     * @param isDisabled Whether the control should be disabled
     */
    setDisabledState?(isDisabled: boolean): void;
    /**
     * Removes a selected file from the current selection
     * @param file The file to remove from selection
     */
    removeChip(file: UserspaceFileDto): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<GeboAIUserspaceBrowseComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<GeboAIUserspaceBrowseComponent, "gebo-ai-userspace-browser-compoent", never, { "knowledgeBaseCodes": { "alias": "knowledgeBaseCodes"; "required": false; }; "noKnowledgeBases": { "alias": "noKnowledgeBases"; "required": false; }; }, { "closeMe": "closeMe"; "confirmed": "confirmed"; }, never, never, false, never>;
}
export {};
//# sourceMappingURL=userspace-browse.component.d.ts.map