/**
 * This Source Code is subject to the terms of the
 * Gebo.ai community version Mozilla Public License Version 2.0 (MPL-2.0) — With Data Protection Clauses
 * If a copy of the LICENCE was not distributed with this file, You can obtain one at
 * https://gebo.ai/gebo-ai-community-version-mozilla-public-license-version-2-0-mpl-2-0-with-data-protection-clauses/
 * and https://mozilla.org/MPL/2.0/.
 * Copyright (c) 2025+ Gebo.ai
 */
import { EventEmitter, OnChanges, OnInit, SimpleChanges } from "@angular/core";
import { GResponseDocumentRef } from "@Gebo.ai/gebo-ai-rest-api";
import * as i0 from "@angular/core";
export declare class DocumentRefComponent implements OnInit, OnChanges {
    /**
     * The document reference to be displayed by this component
     */
    ref?: GResponseDocumentRef;
    /**
     * Indicates if this document has been selected in the current context
     */
    choosed: boolean;
    /**
     * Controls visibility of the document viewing window
     */
    openDocumentWindow: boolean;
    /**
     * Stores the document code to be displayed when the document is opened
     */
    openDocumentCode: string;
    /**
     * CSS class for the document icon, based on document type
     */
    contentCssClass: string;
    /**
     * Display name for the document, derived from name, shortCode, or documentCode
     */
    name?: string;
    /**
     * Event emitted when this document is selected by the user
     */
    addToChoosed: EventEmitter<GResponseDocumentRef>;
    /**
     * Component initialization lifecycle hook
     */
    ngOnInit(): void;
    /**
     * Handles changes to component inputs
     * Updates icon and name when the document reference changes
     */
    ngOnChanges(changes: SimpleChanges): void;
    /**
     * Opens the document viewer if the document has a valid document code
     * @param g The document reference to display
     */
    showDocument(g: GResponseDocumentRef): void;
    /**
     * Closes the document viewer and clears the document code
     */
    closeDocument(): void;
    /**
     * Determines the appropriate icon to use based on document type
     * @param child The document reference
     * @returns A CSS class string for the appropriate icon
     */
    getIcon(child: GResponseDocumentRef): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<DocumentRefComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DocumentRefComponent, "gebo-ai-chat-docref", never, { "ref": { "alias": "ref"; "required": false; }; "choosed": { "alias": "choosed"; "required": false; }; }, { "addToChoosed": "addToChoosed"; }, never, never, false, never>;
}
//# sourceMappingURL=document-ref.component.d.ts.map