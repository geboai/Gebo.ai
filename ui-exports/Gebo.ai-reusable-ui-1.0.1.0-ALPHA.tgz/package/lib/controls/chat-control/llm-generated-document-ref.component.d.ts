import { OnChanges, OnInit, SimpleChanges } from "@angular/core";
import { LLMGeneratedResource } from "@Gebo.ai/gebo-ai-rest-api";
import { EnrichedDocumentReferenceViewRetrieveService } from "../content-viewer/enriched-document-reference-view.service";
import * as i0 from "@angular/core";
export declare class GeboAIGeneratedDocumentRefComponent implements OnInit, OnChanges {
    private enrichedDocumentReferenceViewService;
    ref?: LLMGeneratedResource;
    protected extendedRef?: LLMGeneratedResource;
    constructor(enrichedDocumentReferenceViewService: EnrichedDocumentReferenceViewRetrieveService);
    ngOnInit(): void;
    ngOnChanges(changes: SimpleChanges): Promise<void>;
    static ɵfac: i0.ɵɵFactoryDeclaration<GeboAIGeneratedDocumentRefComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<GeboAIGeneratedDocumentRefComponent, "llm-generated-document-ref", never, { "ref": { "alias": "ref"; "required": false; }; }, {}, never, never, false, never>;
}
