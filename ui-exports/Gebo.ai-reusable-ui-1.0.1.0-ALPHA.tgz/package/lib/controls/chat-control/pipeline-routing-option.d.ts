export interface PipelineRoutingOption {
    defaultOption?: boolean;
    chatPipelineProcessId?: string;
    pipelineParams?: any;
    description?: string;
    optionId?: string;
    icon?: string;
}
//# sourceMappingURL=pipeline-routing-option.d.ts.map