import { OnChanges, SimpleChanges } from "@angular/core";
import * as i0 from "@angular/core";
export declare class GeboAIExtensiblePipelineRouteDisplayComponent implements OnChanges {
    protected visible: boolean;
    ngOnChanges(changes: SimpleChanges): void;
    pipelineRouterDecisionCode?: string;
    static ɵfac: i0.ɵɵFactoryDeclaration<GeboAIExtensiblePipelineRouteDisplayComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<GeboAIExtensiblePipelineRouteDisplayComponent, "gebo-ai-pipline-route-display", never, { "pipelineRouterDecisionCode": { "alias": "pipelineRouterDecisionCode"; "required": false; }; }, {}, never, never, false, never>;
}
