import { IGeboChatMessage } from "../../services/gebo-chat-message";
import { DeepSearchDataSourceDocumentResult, DeepSearchDataSourceResponse, DeepSearchDocumentAnalisysResultStep } from "@Gebo.ai/gebo-ai-rest-api";
import { GeboAIRootNotificationService } from "../../notifications/root-notification.service";
import { PipelineRoutingOption } from "./pipeline-routing-option";
import * as i0 from "@angular/core";
interface ChatNotificationContent {
    code: string;
    message: string;
    icon?: string;
    duration?: number;
    notificationType: "INFO" | "DEBUG";
}
export declare class GeboAIChatStreamEventsDisplayComponent {
    private messageService;
    streaming: boolean;
    protected currentChatMessage?: IGeboChatMessage;
    routingChoiceSelector?: string;
    actualPipelineRoutingOption?: PipelineRoutingOption;
    protected analisysStep?: DeepSearchDocumentAnalisysResultStep;
    protected deepSearchDataSourceDocumentResult?: DeepSearchDataSourceDocumentResult;
    protected deepSearchDataSourceResponse?: DeepSearchDataSourceResponse;
    protected deepSearchNotification?: {
        content?: string;
        dataSourceDescription?: string;
    };
    protected currentNotification?: ChatNotificationContent;
    protected completionPercent: number;
    private timer?;
    constructor(messageService: GeboAIRootNotificationService);
    protected get inEventsLoop(): boolean;
    protected get isDisplayingDeepSearchProcess(): boolean;
    private clearNotifiationTimer;
    private clearEventsDisplay;
    private startNotificationTimer;
    clearUI(): void;
    onMessage(msg?: IGeboChatMessage): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<GeboAIChatStreamEventsDisplayComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<GeboAIChatStreamEventsDisplayComponent, "gebo-ai-chat-stream-events-display", never, { "streaming": { "alias": "streaming"; "required": false; }; "routingChoiceSelector": { "alias": "routingChoiceSelector"; "required": false; }; "actualPipelineRoutingOption": { "alias": "actualPipelineRoutingOption"; "required": false; }; }, {}, never, never, false, never>;
}
export {};
