import { OnChanges, SimpleChanges } from "@angular/core";
import { IGeboChatMessage } from "../../services/gebo-chat-message";
import { GResponseDocumentRef } from "@Gebo.ai/gebo-ai-rest-api";
import { GeboAIRootNotificationService } from "../../notifications/root-notification.service";
import { PipelineRoutingOption } from "./pipeline-routing-option";
import * as i0 from "@angular/core";
interface ChatNotificationContent {
    code: string;
    message: string;
    icon?: string;
    duration?: number;
    notificationType: "INFO" | "DEBUG";
}
export declare class GeboAIChatStreamEventsDisplayComponent implements OnChanges {
    private messageService;
    streaming: boolean;
    protected currentChatMessage?: IGeboChatMessage;
    routingChoiceSelector?: string;
    actualPipelineRoutingOption?: PipelineRoutingOption;
    protected currentNotification?: ChatNotificationContent;
    protected inputProcessingEvent?: {
        document: GResponseDocumentRef;
    };
    protected notifiedPipelineRouting?: PipelineRoutingOption;
    private timer?;
    constructor(messageService: GeboAIRootNotificationService);
    ngOnChanges(changes: SimpleChanges): void;
    protected get inEventsLoop(): boolean;
    private clearNotifiationTimer;
    private clearEventsDisplay;
    private startNotificationTimer;
    clearUI(): void;
    onMessage(msg?: IGeboChatMessage): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<GeboAIChatStreamEventsDisplayComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<GeboAIChatStreamEventsDisplayComponent, "gebo-ai-chat-stream-events-display", never, { "streaming": { "alias": "streaming"; "required": false; }; "routingChoiceSelector": { "alias": "routingChoiceSelector"; "required": false; }; "actualPipelineRoutingOption": { "alias": "actualPipelineRoutingOption"; "required": false; }; }, {}, never, never, false, never>;
}
export {};
