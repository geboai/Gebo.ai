import { GeboChatRequest } from "@Gebo.ai/gebo-ai-rest-api";
import { GeboAIBaseStreamingService } from "../../services/base-streaming.service";
import { IGeboChatMessage } from "../../services/gebo-chat-message";
import * as i0 from "@angular/core";
export interface AgenticChatRequestBody {
    request: GeboChatRequest;
    environment?: any;
}
/**
 * Service that handles streaming chat interactions with the Gebo AI API.
 * Uses fetch API to establish streaming connections and process server-sent events.
 */
export declare class ReactiveRagChatService extends GeboAIBaseStreamingService {
    private basePath;
    /**
     * Creates an instance of the ReactiveRagChatService.
     *
     * @param basePath - Base URL path for API requests, injected from the BASE_PATH token
     * @param ragChatService - Service for RAG-based chat interactions
     * @param httpClient - Angular's HTTP client for making requests
     */
    constructor(basePath: string);
    /**
     * Initiates a streaming chat session with the direct model chat endpoint.
     *
     * @param request - The chat request containing messages and parameters
     * @param onMessage - Callback function that processes each received message
     * @param onError - Optional callback function for handling errors
     */
    streamChat(request: GeboChatRequest, onMessage: (msg: IGeboChatMessage | string) => void, onError?: (err: any) => void, onComplete?: () => void): void;
    /**
     * Initiates a streaming chat session with the RAG (Retrieval Augmented Generation) endpoint.
     * RAG enhances responses with additional context retrieved from knowledge bases.
     *
     * @param request - The chat request containing messages and parameters
     * @param onMessage - Callback function that processes each received message
     * @param onError - Optional callback function for handling errors
     */
    streamRagChat(request: GeboChatRequest, onMessage: (msg: IGeboChatMessage | string) => void, onError?: (err: any) => void, onComplete?: () => void): void;
    streamAgenticChat(request: AgenticChatRequestBody, onMessage: (msg: IGeboChatMessage | string) => void, onError?: (err: any) => void, onComplete?: () => void): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ReactiveRagChatService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ReactiveRagChatService>;
}
//# sourceMappingURL=reactive-chat.service.d.ts.map