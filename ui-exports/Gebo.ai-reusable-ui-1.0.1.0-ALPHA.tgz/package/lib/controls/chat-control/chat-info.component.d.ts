import { GeboChatUserInfo } from "@Gebo.ai/gebo-ai-rest-api";
import * as i0 from "@angular/core";
/**
 * Represents a component that displays chat user information.
 * This component is used to show details about a user in a chat context.
 * It can be closed by the user, triggering the close event.
 */
export declare class GeboChatUserInfoComponent {
    /**
     * Input property to receive user information data to be displayed
     * Expected to be of type GeboChatUserInfo from the Gebo.ai API
     */
    data?: GeboChatUserInfo;
    static ɵfac: i0.ɵɵFactoryDeclaration<GeboChatUserInfoComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<GeboChatUserInfoComponent, "gebo-user-chat-info-component", never, { "data": { "alias": "data"; "required": false; }; }, {}, never, never, false, never>;
}
//# sourceMappingURL=chat-info.component.d.ts.map