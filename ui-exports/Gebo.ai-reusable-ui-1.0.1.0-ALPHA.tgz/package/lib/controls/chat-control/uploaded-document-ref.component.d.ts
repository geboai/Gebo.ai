import { OnChanges, OnInit, SimpleChanges } from "@angular/core";
import { UserUploadedContent } from "@Gebo.ai/gebo-ai-rest-api";
import { EnrichedDocumentReferenceViewRetrieveService, EnrichedUserUploadedContentView } from "../content-viewer/enriched-document-reference-view.service";
import * as i0 from "@angular/core";
export declare class GeboAIUploadedDocumentRefComponent implements OnInit, OnChanges {
    private enrichedDocumentReferenceViewService;
    ref?: UserUploadedContent;
    protected extendedRef?: EnrichedUserUploadedContentView;
    constructor(enrichedDocumentReferenceViewService: EnrichedDocumentReferenceViewRetrieveService);
    ngOnInit(): void;
    ngOnChanges(changes: SimpleChanges): Promise<void>;
    static ɵfac: i0.ɵɵFactoryDeclaration<GeboAIUploadedDocumentRefComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<GeboAIUploadedDocumentRefComponent, "uploaded-document-ref", never, { "ref": { "alias": "ref"; "required": false; }; }, {}, never, never, false, never>;
}
//# sourceMappingURL=uploaded-document-ref.component.d.ts.map