/**
 * This Source Code is subject to the terms of the
 * Gebo.ai community version Mozilla Public License Version 2.0 (MPL-2.0) — With Data Protection Clauses
 * If a copy of the LICENCE was not distributed with this file, You can obtain one at
 * https://gebo.ai/gebo-ai-community-version-mozilla-public-license-version-2-0-mpl-2-0-with-data-protection-clauses/
 * and https://mozilla.org/MPL/2.0/.
 * Copyright (c) 2025+ Gebo.ai
 */
/**
 * AI generated comments
 *
 * This module implements a reusable chat component for the Gebo.ai system. It provides a flexible
 * chat interface that can work with both regular and RAG (Retrieval Augmented Generation) enabled
 * chat models. The component supports various features like streaming responses, speech-to-text,
 * text-to-speech, and chat history management.
 */
import { HttpClient } from "@angular/common/http";
import { EventEmitter, OnChanges, OnInit, SimpleChanges } from "@angular/core";
import { FormGroup } from "@angular/forms";
import { CalledFunction, GBaseChatModelChoice, GeboChatControllerService, GeboChatPipelinesControllerService, GeboChatRequest, GeboChatResponse, GeboChatUserInfo, GeboRagChatControllerService, GeboUserChatsControllerService, GResponseDocumentRef, GUserChatInfo, GUserMessage, LLMGeneratedResource, ModelProviderCapabilities, PipelineChatMenu } from "@Gebo.ai/gebo-ai-rest-api";
import { MermaidAPI } from "ngx-markdown";
import { ConfirmationService, ToastMessageOptions } from "primeng/api";
import { ReactiveRagChatService } from "./reactive-chat.service";
import { GeboAIFieldHost } from "../field-host-component-iface/field-host-component-iface";
import { GeboAIRootNotificationService } from "../../notifications/root-notification.service";
import { GeboAITranslationService } from "../field-translation-container/gebo-translation.service";
import { GeboAIChatInputShellComponent } from "./chat-input-shell.component";
import { PipelineRoutingOption } from "./pipeline-routing-option";
import * as i0 from "@angular/core";
/**
 * Interface representing a single chat interaction between the user and the AI,
 * containing both the request and potential response.
 */
interface GeboChatInteraction {
    request: GeboChatRequest;
    response?: GeboChatTemplatedResponse;
    loading?: boolean;
    pipelineRouterDecisionCode?: string;
    streamingModelName?: string;
}
/**
 * Interface representing the structured response from the Gebo chat system,
 * including the model information, response content, and any referenced documents.
 */
interface GeboChatTemplatedResponse {
    userChatContextCode?: string;
    usedChatModelCode?: string;
    usedChatModelProvider?: string;
    queryResponse?: any;
    query?: string;
    backendMessages?: Array<GUserMessage>;
    documentsRef?: Array<GResponseDocumentRef>;
    calledFunctions?: Array<CalledFunction>;
    generatedResources?: LLMGeneratedResource[];
}
/**
 * Component that provides a reusable chat interface for Gebo.ai models.
 * Supports both standard chat and RAG-enabled conversations, with features like
 * streaming responses, speech recognition, and voice output. Manages chat history
 * and document references.
 */
export declare class GeboAIReusableChatComponent implements OnInit, OnChanges, GeboAIFieldHost {
    private geboUserChatsControllerService;
    private confirmService;
    private chatService;
    private messageService;
    private ragChatService;
    private reactiveChatService;
    private geboAiTranslationService;
    private geboChatPipelineService;
    private userChatControllerService;
    private httpClient;
    private basePath;
    /**
     * Stores the capabilities of the current model provider
     */
    capabilities?: ModelProviderCapabilities;
    /**
     * List of knowledge base codes available for this chat
     */
    knowledgeBaseCodes: string[];
    protected userChatContextCode: string | undefined;
    protected currentPipelineRouterDecisionCode?: string;
    protected chatPipelinesMenu: PipelineChatMenu[];
    /**
     * Determines if any loading operation is currently in progress
     */
    get loading(): boolean;
    /**
     * Flag indicating if chat loading
     */
    loadingSearchResult: boolean;
    /**
     * Flag indicating if chat history is being loaded
     */
    private loadingChatHistory;
    /**
     * Flag indicating if a chat response is being loaded
     */
    protected loadingChatResponse: boolean;
    /**
     * Flag indicating if model metadata is being loaded
     */
    private loadingModelMetaInfo;
    /**
     * Flag indicating if waiting for speech-to-text transcript
     */
    private waitingForTranscript;
    /**
     * Flag indicating if waiting for audio content to load
     */
    private waitingForAudiocontent;
    /**
     * Maximum number of documents to display inline for an interaction before requiring a toggle
     */
    maxDisplayedDocs: number;
    /**
     * Map tracking which interactions have their full document list expanded
     */
    expandedInteractionsDocs: Map<string, boolean>;
    /**
     * Flag indicating if a chat response is currently streaming
     */
    chatStreaming: boolean;
    /**
     * Timestamp of the last update received during chat streaming
     */
    private chatStreamingUpdatedTime?;
    /**
     * Flag indicating if an error occurred during chat streaming
     */
    private chatStreamingErrorOccurred;
    protected openSelectDocumentsWindow: boolean;
    protected openedUploadDocumentsWindow: boolean;
    /**
     * Determines if the chat streaming might be failing based on timeout
     */
    get isChatStreamingProbabilyFailing(): boolean;
    /**
     * Array of chat interactions (request-response pairs)
     */
    interactions: GeboChatInteraction[];
    /**
     * Toast messages from the last interaction
     */
    lastInteractionMessages: ToastMessageOptions[];
    /**
     * Current audio file being played
     */
    currentAudioTrack?: Blob;
    /**
     * Time in milliseconds after which streaming is considered failed
     */
    streamingTimeout: number;
    /**
     * Flag to use only REST API calls (no WebSockets)
     */
    useRestOnly: boolean;
    /**
     * Information about the current chat
     */
    chatInfo?: GUserChatInfo;
    /**
     * Title displayed for the chat
     */
    title?: string;
    /**
     * Subtitle displayed for the chat
     */
    subtitle?: string;
    /**
     * Name of the model being used
     */
    modelName: string;
    /**
     * Flag indicating if RAG system should be used
     */
    ragsystem: boolean;
    /**
     * Event emitted when a cancel action is triggered
     */
    cancelAction: EventEmitter<boolean>;
    /**
     * Event emitted when a chat is deleted
     */
    deleteChatAction: EventEmitter<GUserChatInfo>;
    /**
     * Event emitted when a new chat is added
     */
    addedChatAction: EventEmitter<GUserChatInfo>;
    updatedChatAction: EventEmitter<GUserChatInfo>;
    chatInputShell: GeboAIChatInputShellComponent;
    /**
     * Configuration options for Mermaid diagrams
     */
    options: MermaidAPI.MermaidConfig;
    /**
     * Form group for chat input and configuration
     */
    formGroup: FormGroup;
    protected currentPipelineRoutingOption?: PipelineRoutingOption;
    /**
     * Form group for chat information
     */
    chatInfoFormGroup: FormGroup;
    /**
     * Scroll buttons
     */
    showTopButton: boolean;
    showBottomButton: boolean;
    /**
     * Metadata about the current chat model
     */
    modelMetaInfos?: GBaseChatModelChoice;
    /**
     * User info relevant to the chat
     */
    chatUserInfos?: GeboChatUserInfo;
    /**
     * Flag to control visibility of user info overlay
     */
    userInfoOverlayVisible: boolean;
    /**
     * Map tracking which documents are selected
     */
    private docSelectedMap;
    /**
     * Flag to control visibility of the description change dialog
     */
    protected changeDescriptionDialogOpened: boolean;
    /**
     * Constructor - injects all required services
     */
    constructor(geboUserChatsControllerService: GeboUserChatsControllerService, confirmService: ConfirmationService, chatService: GeboChatControllerService, messageService: GeboAIRootNotificationService, ragChatService: GeboRagChatControllerService, reactiveChatService: ReactiveRagChatService, geboAiTranslationService: GeboAITranslationService, geboChatPipelineService: GeboChatPipelinesControllerService, userChatControllerService: GeboUserChatsControllerService, httpClient: HttpClient, basePath: string);
    onWindowScroll(): void;
    scrollToTop(): void;
    scrollToBottom(): void;
    getEntityName(): string;
    /**
     * Checks if a document reference is chosen/selected
     *
     * @param dr Document reference to check
     * @returns True if the document is selected
     */
    isChoosed(dr: GResponseDocumentRef): boolean;
    /**
     * Adds a document to the selected documents list
     *
     * @param dr Document reference to add
     */
    addToChoosed(dr: GResponseDocumentRef): void;
    /**
     * Handles changes to input properties
     * Loads model info and chat history when chatInfo changes
     */
    ngOnChanges(changes: SimpleChanges): void;
    /**
     * Loads chat history for the current chat
     */
    loadChatHistory(): void;
    /**
     * Initializes the component by setting up form value change subscriptions
     */
    ngOnInit(): void;
    /**
     * Gets document references from an interaction
     *
     * @param interaction Chat interaction to extract documents from
     * @returns Array of document references
     */
    getDocs(interaction: GeboChatInteraction): GResponseDocumentRef[];
    /**
     * Toggles the document list expansion for a specific interaction
     * @param interactionId The ID of the interaction request
     */
    toggleInteractionDocs(interactionId?: string): void;
    /**
     * Checks if the document list for a specific interaction is expanded
     * @param interactionId The ID of the interaction request
     * @returns True if expanded, false otherwise
     */
    isInteractionDocsExpanded(interactionId?: string): boolean;
    /**
     * Opens the dialog to change chat description
     */
    doChangeDescription(): void;
    /**
     * Saves the changed chat description
     */
    doSaveChangedDescription(): void;
    /**
     * Handles chat deletion with confirmation
     */
    doDeleteChat(): void;
    /**
     * Performs a chat request using REST API
     *
     * @param r Chat request to send
     * @param doSpeach Flag to trigger speech playback of response
     */
    private callRestChat;
    /**
     * Performs a chat request using reactive/streaming API
     *
     * @param r Chat request to send
     * @param doSpeach Flag to trigger speech playback of response
     */ private handleGeboChatResponse;
    private callReactiveChat;
    onSumbit(): void;
    stopReactiveChat(userChatContextCode?: string): void;
    /**
     * Sends a message to the chat system
     *
     * @param speechOutput Flag to indicate if speech output is desired
     */
    sendMessage(speechOutput?: boolean): void;
    /**
     * Sends a text-to-speech request and plays the audio
     *
     * @param text Text to convert to speech
     */
    speechPlay(text: string): void;
    onNewSessionCreatedOnUpload(info: GUserChatInfo): void;
    onExternalModuleRequest(request: GeboChatRequest): void;
    onExternalModuleResponse(response: GeboChatResponse): void;
    /**
     * Handles speech-to-text conversion events
     *
     * @param event Event containing the audio data to transcribe
     */
    onSpeechEvent(event: {
        data: Blob;
        url: string;
    }): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<GeboAIReusableChatComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<GeboAIReusableChatComponent, "gebo-ai-reusable-chat-component", never, { "maxDisplayedDocs": { "alias": "maxDisplayedDocs"; "required": false; }; "streamingTimeout": { "alias": "streamingTimeout"; "required": false; }; "useRestOnly": { "alias": "useRestOnly"; "required": false; }; "chatInfo": { "alias": "chatInfo"; "required": false; }; "title": { "alias": "title"; "required": false; }; "subtitle": { "alias": "subtitle"; "required": false; }; "modelName": { "alias": "modelName"; "required": false; }; "ragsystem": { "alias": "ragsystem"; "required": false; }; }, { "cancelAction": "cancelAction"; "deleteChatAction": "deleteChatAction"; "addedChatAction": "addedChatAction"; "updatedChatAction": "updatedChatAction"; }, never, never, false, never>;
}
export {};
//# sourceMappingURL=gebo-ai-reusable-chat.component.d.ts.map