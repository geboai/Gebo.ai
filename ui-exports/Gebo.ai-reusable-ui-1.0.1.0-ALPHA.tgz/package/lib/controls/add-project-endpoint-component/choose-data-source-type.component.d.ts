/**
 * This Source Code is subject to the terms of the
 * Gebo.ai community version Mozilla Public License Version 2.0 (MPL-2.0) — With Data Protection Clauses
 * If a copy of the LICENCE was not distributed with this file, You can obtain one at
 * https://gebo.ai/gebo-ai-community-version-mozilla-public-license-version-2-0-mpl-2-0-with-data-protection-clauses/
 * and https://mozilla.org/MPL/2.0/.
 * Copyright (c) 2025+ Gebo.ai
 */
/**
 * AI generated comments
 *
 * This component allows users to choose a data source type for a project.
 * It extends BaseEntityEditingComponent to handle the editing of ChooseDataSourceType entities,
 * providing UI for selecting the type of data source to be added to a Gebo project.
 */
import { Injector } from "@angular/core";
import { FormGroup } from "@angular/forms";
import { Observable } from "rxjs";
import { ChooseDataSourceType } from "./choose-data-source-type";
import { ConfirmationService, MenuItem } from "primeng/api";
import { GProject, ProjectsControllerService } from "@Gebo.ai/gebo-ai-rest-api";
import { BaseEntityEditingComponent } from "../base-entity-editing-component/base-entity-editing.component";
import { GeboFormGroupsService } from "../../architecture/gebo-form-groups.service";
import { GeboUIActionRoutingService } from "../../architecture/gebo-ui-action-routing.service";
import { GeboAIPluggableKnowledgeAdminBaseTreeSearchService } from "../../services/pluggable-knowledge-base-admin-tree-search.service";
import { GeboUIOutputForwardingService } from "../../architecture/gebo-ui-output-forwarding.service";
import * as i0 from "@angular/core";
/**
 * Component responsible for selecting a data source type for a project.
 * It provides a UI interface to choose from various data source types
 * that can be added to a Gebo AI project.
 */
export declare class GeboAIChooseDataSourceTypeComponent extends BaseEntityEditingComponent<ChooseDataSourceType> {
    private projectsControllerService;
    private kbTreeSearchService;
    /**
     * The entity name for this component, used for identification in the base component
     */
    protected entityName: string;
    /**
     * Menu items used to display available data source types
     */
    items: MenuItem[];
    /**
     * Form group containing controls for the ChooseDataSourceType entity
     */
    formGroup: FormGroup<any>;
    /**
     * The project associated with this data source type selection
     */
    project?: GProject;
    private subscription?;
    /**
     * Component constructor that injects required services
     */
    constructor(injector: Injector, geboFormGroupsService: GeboFormGroupsService, confirmationService: ConfirmationService, geboUIActionRoutingService: GeboUIActionRoutingService, projectsControllerService: ProjectsControllerService, kbTreeSearchService: GeboAIPluggableKnowledgeAdminBaseTreeSearchService, outputForwardingService?: GeboUIOutputForwardingService);
    /**
     * Lifecycle hook that initializes the component.
     * Sets up form validation to ensure entityType is selected.
     */
    ngOnInit(): void;
    /**
     * Refreshes the UI based on the current ChooseDataSourceType data.
     * Fetches project details if the project code has changed and
     * regenerates the menu with available data source types.
     *
     * @param actualValue The current ChooseDataSourceType data
     */
    private refreshUI;
    /**
     * Toggles selection of a data source type in the form.
     * If the same item is clicked again, it deselects it.
     *
     * @param item The menu item representing a data source type
     */
    toggle(item: MenuItem): void;
    /**
     * Called when persistent data is loaded into the component.
     * Refreshes the UI based on the loaded data.
     *
     * @param actualValue The loaded ChooseDataSourceType data
     */
    protected onLoadedPersistentData(actualValue: ChooseDataSourceType): void;
    /**
     * Called when new data is created in the component.
     * Refreshes the UI based on the new data.
     *
     * @param actualValue The new ChooseDataSourceType data
     */
    protected onNewData(actualValue: ChooseDataSourceType): void;
    /**
     * Finds a ChooseDataSourceType entity by its code.
     * In this implementation, it returns the current entity or null.
     *
     * @param code The code to search for
     * @returns An Observable with the found entity or null
     */
    findByCode(code: string): Observable<ChooseDataSourceType | null>;
    /**
     * Saves changes to an existing ChooseDataSourceType entity.
     * In this implementation, it simply returns the value back.
     *
     * @param value The entity to save
     * @returns An Observable with the saved entity
     */
    save(value: ChooseDataSourceType): Observable<ChooseDataSourceType>;
    /**
     * Inserts a new ChooseDataSourceType entity.
     * In this implementation, it simply returns the value back.
     *
     * @param value The entity to insert
     * @returns An Observable with the inserted entity
     */
    insert(value: ChooseDataSourceType): Observable<ChooseDataSourceType>;
    /**
     * Deletes a ChooseDataSourceType entity.
     * In this implementation, it always returns true.
     *
     * @param value The entity to delete
     * @returns An Observable with a boolean indicating success
     */
    delete(value: ChooseDataSourceType): Observable<boolean>;
    /**
     * Checks if a ChooseDataSourceType entity can be deleted.
     * In this implementation, it always returns false.
     *
     * @param value The entity to check
     * @returns An Observable with an object containing deletion status and message
     */
    canBeDeleted(value: ChooseDataSourceType): Observable<{
        canBeDeleted: boolean;
        message: string;
    }>;
    static ɵfac: i0.ɵɵFactoryDeclaration<GeboAIChooseDataSourceTypeComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<GeboAIChooseDataSourceTypeComponent, "gebo-ui-choose-data-source-type-component", never, {}, {}, never, never, false, never>;
}
