/**
 * This Source Code is subject to the terms of the
 * Gebo.ai community version Mozilla Public License Version 2.0 (MPL-2.0) — With Data Protection Clauses
 * If a copy of the LICENCE was not distributed with this file, You can obtain one at
 * https://gebo.ai/gebo-ai-community-version-mozilla-public-license-version-2-0-mpl-2-0-with-data-protection-clauses/
 * and https://mozilla.org/MPL/2.0/.
 * Copyright (c) 2025+ Gebo.ai
 */
import { EventEmitter, OnChanges, OnInit, SimpleChanges } from "@angular/core";
import { GProject, GeboModulesConfigControllerService } from "@Gebo.ai/gebo-ai-rest-api";
import { MenuItem } from "primeng/api";
import { GeboAIEntitiesSettingWizardConfiguration } from "../base-entity-editing-component/entities-modification-wizard";
import { GeboUIActionRoutingService } from "../../architecture/gebo-ui-action-routing.service";
import { GeboAIPluggableKnowledgeAdminBaseTreeSearchService } from "../../services/pluggable-knowledge-base-admin-tree-search.service";
import { GeboActionPerformedEvent } from "../../architecture/actions.model";
import * as i0 from "@angular/core";
/**
 * Component that provides a context menu for adding various items to a project.
 * This can be displayed as buttons, menu items, or as a full page depending on the configuration.
 * It handles the generation of menu items based on the project data and available modules.
 */
export declare class ProjectAddContextMenuComponent implements OnInit, OnChanges {
    private actionServices;
    private geboModulesConfigService;
    private kbTreeSearchService;
    /**
     * The project data to which items will be added
     */
    data?: GProject;
    /**
     * Flag to determine if options should be displayed as buttons instead of menu items
     */
    showAsButtons: boolean;
    /**
     * Flag to enable/disable sub-project addition functionality
     */
    subProjectAddEnabled: boolean;
    /**
     * Flag to display the menu as a full page rather than a dropdown
     */
    showAsPage: boolean;
    /**
     * Configuration for wizard steps if this is part of a multi-step wizard
     */
    wizardStepsConfigurations?: GeboAIEntitiesSettingWizardConfiguration[];
    /**
     * The ID of the current wizard step configuration
     */
    actualWizardStepConfigrationId?: string;
    /**
     * Event emitter that triggers when the UI needs to be refreshed after an action
     */
    refreshUIEvent: EventEmitter<GeboActionPerformedEvent>;
    /**
     * Array of menu items to be displayed in the context menu
     */
    items: MenuItem[];
    private subscription?;
    /**
     * Constructor initializes the required services for action routing and menu generation
     */
    constructor(actionServices: GeboUIActionRoutingService, geboModulesConfigService: GeboModulesConfigControllerService, kbTreeSearchService: GeboAIPluggableKnowledgeAdminBaseTreeSearchService);
    /**
     * Lifecycle hook that responds to input changes, specifically when project data changes
     */
    ngOnChanges(changes: SimpleChanges): void;
    /**
     * Refreshes the UI by generating the menu items based on the current project data
     * Uses the knowledge tree search service to generate appropriate menu options
     */
    refreshUI(): void;
    /**
     * Lifecycle hook for component initialization
     */
    ngOnInit(): void;
    /**
     * Executes the command associated with a menu item when it is clicked
     * @param cfg The menu item configuration that was selected
     */
    execute(cfg: MenuItem): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ProjectAddContextMenuComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ProjectAddContextMenuComponent, "project-add-context-menu", never, { "data": { "alias": "data"; "required": false; }; "showAsButtons": { "alias": "showAsButtons"; "required": false; }; "subProjectAddEnabled": { "alias": "subProjectAddEnabled"; "required": false; }; "showAsPage": { "alias": "showAsPage"; "required": false; }; "wizardStepsConfigurations": { "alias": "wizardStepsConfigurations"; "required": false; }; "actualWizardStepConfigrationId": { "alias": "actualWizardStepConfigrationId"; "required": false; }; }, { "refreshUIEvent": "refreshUIEvent"; }, never, never, false, never>;
}
