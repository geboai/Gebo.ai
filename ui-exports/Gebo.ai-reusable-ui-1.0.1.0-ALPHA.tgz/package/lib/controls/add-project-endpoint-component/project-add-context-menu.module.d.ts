import * as i0 from "@angular/core";
import * as i1 from "./project-add-context-menu.component";
import * as i2 from "./choose-data-source-type.component";
import * as i3 from "@angular/common";
import * as i4 from "@angular/forms";
import * as i5 from "primeng/button";
import * as i6 from "primeng/contextmenu";
import * as i7 from "../../architecture/gebo-ui-architecture.module";
import * as i8 from "primeng/panel";
import * as i9 from "primeng/radiobutton";
/**
 * @fileoverview This module provides components for project data source management in a Gebo.ai application.
 * AI generated comments
 */
/**
 * @NgModule ProjectAddContextMenuModule
 *
 * A module that bundles components related to project addition and data source selection.
 * It provides context menu functionality for adding projects and a component for selecting
 * data source types.
 *
 * This module imports common Angular modules like CommonModule and ReactiveFormsModule
 * along with PrimeNG UI components (Button, ContextMenu, Panel, RadioButton) and
 * Gebo's reusable UI architecture module.
 *
 * The main components declared and exported are:
 * - ProjectAddContextMenuComponent: For displaying contextual options when adding projects
 * - GeboAIChooseDataSourceTypeComponent: For selecting between different data source types
 */
export declare class ProjectAddContextMenuModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<ProjectAddContextMenuModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ProjectAddContextMenuModule, [typeof i1.ProjectAddContextMenuComponent, typeof i2.GeboAIChooseDataSourceTypeComponent], [typeof i3.CommonModule, typeof i4.ReactiveFormsModule, typeof i5.ButtonModule, typeof i6.ContextMenuModule, typeof i7.GeboUIArchitectureModule, typeof i8.PanelModule, typeof i9.RadioButtonModule], [typeof i1.ProjectAddContextMenuComponent, typeof i2.GeboAIChooseDataSourceTypeComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ProjectAddContextMenuModule>;
}
//# sourceMappingURL=project-add-context-menu.module.d.ts.map