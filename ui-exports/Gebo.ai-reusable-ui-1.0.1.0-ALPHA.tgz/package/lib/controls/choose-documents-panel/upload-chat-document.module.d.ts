import * as i0 from "@angular/core";
import * as i1 from "./upload-chat-document.component";
import * as i2 from "@angular/common";
import * as i3 from "@angular/forms";
import * as i4 from "primeng/fileupload";
import * as i5 from "primeng/button";
import * as i6 from "primeng/progressbar";
import * as i7 from "primeng/dialog";
import * as i8 from "primeng/badge";
import * as i9 from "primeng/panel";
import * as i10 from "primeng/blockui";
import * as i11 from "../field-translation-container/field-container.module";
import * as i12 from "../../notifications/notifications.module";
import * as i13 from "@angular/cdk/drag-drop";
export declare class GeboAIUploadChatDocumentModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<GeboAIUploadChatDocumentModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<GeboAIUploadChatDocumentModule, [typeof i1.GeboAIUploadChatDocumentComponent], [typeof i2.CommonModule, typeof i3.ReactiveFormsModule, typeof i3.FormsModule, typeof i4.FileUploadModule, typeof i5.ButtonModule, typeof i6.ProgressBarModule, typeof i7.DialogModule, typeof i8.BadgeModule, typeof i9.PanelModule, typeof i10.BlockUIModule, typeof i11.GeboAIFieldTranslationContainerModule, typeof i12.GeboAINotificationsModule, typeof i12.GeboAINotificationsModule, typeof i13.CdkDragPlaceholder], [typeof i1.GeboAIUploadChatDocumentComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<GeboAIUploadChatDocumentModule>;
}
