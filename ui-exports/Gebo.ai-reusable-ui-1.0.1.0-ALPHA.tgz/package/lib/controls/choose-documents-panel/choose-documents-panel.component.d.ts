/**
 * This Source Code is subject to the terms of the
 * Gebo.ai community version Mozilla Public License Version 2.0 (MPL-2.0) — With Data Protection Clauses
 * If a copy of the LICENCE was not distributed with this file, You can obtain one at
 * https://gebo.ai/gebo-ai-community-version-mozilla-public-license-version-2-0-mpl-2-0-with-data-protection-clauses/
 * and https://mozilla.org/MPL/2.0/.
 * Copyright (c) 2025+ Gebo.ai
 */
/**
 * AI generated comments
 * This component provides a panel for selecting and managing documents.
 * It implements ControlValueAccessor to work with Angular forms, allowing it to be used
 * as a form control. The component displays a list of documents, allows viewing document details,
 * and supports adding/removing documents from the selection.
 */
import { EventEmitter, OnChanges, OnInit, SimpleChanges } from "@angular/core";
import { ControlValueAccessor, FormGroup } from "@angular/forms";
import { EnrichedDocumentReferenceView, EnrichedDocumentReferenceViewRetrieveService } from "../content-viewer/enriched-document-reference-view.service";
import { GeboAIFieldHost } from "../field-host-component-iface/field-host-component-iface";
import * as i0 from "@angular/core";
/**
 * A component that provides a UI panel for choosing and managing documents.
 * It registers itself as a form control through NG_VALUE_ACCESSOR to be usable within Angular forms.
 * The component manages a list of document references and provides various operations like
 * viewing, removing, and selecting documents from knowledge bases.
 */
export declare class GeboAIChooseDocumentsPanelComponent implements OnInit, OnChanges, ControlValueAccessor, GeboAIFieldHost {
    private documentsMetaInfosService;
    /**
     * Optional array of knowledge base codes to filter document selection
     */
    knowledgeBaseCodes?: string[];
    /**
     * Flag to set the component in read-only mode
     */
    readonly: boolean;
    /**
     * Flag to disable user interactions with the component
     */
    interactionDisabled: boolean;
    /**
     * Maximum number of documents to display inline before showing the "..." button
     */
    maxDisplayedDocuments?: number;
    /**
     * Flag to control visibility of the full list of documents window
     */
    openedFullListDocumentsWindow: boolean;
    /**
     * Flag to track if documents are currently being loaded
     */
    private loadingDocuments;
    /**
     * Flag to track if file types are currently being loaded
     */
    private loadingFileTypes;
    /**
     * Code of the document currently being viewed
     */
    currentViewedDocumentCode?: string;
    /**
     * Flag to control the visibility of the search documents window
     */
    openedSearchDocumentsWindows: boolean;
    openedSearchDocumentsWindowsChange: EventEmitter<boolean>;
    openedUploadDocumentsWindow: boolean;
    openedUploadDocumentsWindowChange: EventEmitter<boolean>;
    successfullDocumentChosen: EventEmitter<boolean>;
    choosenDocumentsListCleared: EventEmitter<boolean>;
    /**
     * Getter that returns the overall loading state by checking if documents or file types are loading
     */
    get loading(): boolean;
    /**
     * List of document references displayed in the component
     */
    listedDocuments: EnrichedDocumentReferenceView[];
    /**
     * Getter for the documents to display inline
     */
    get displayedDocuments(): EnrichedDocumentReferenceView[];
    /**
     * Getter to check if there are more documents than maxDisplayedDocuments
     */
    get hasMoreDocuments(): boolean;
    /**
     * Form group for managing document selection edits
     */
    editingFormGroup: FormGroup;
    /**
     * Constructor for the component
     * @param documentsMetaInfosService Service for retrieving document reference metadata
     */
    constructor(documentsMetaInfosService: EnrichedDocumentReferenceViewRetrieveService);
    getEntityName(): string;
    /**
     * Retrieves metadata for documents based on the internal value (document codes)
     * Updates the listedDocuments array with the retrieved document references
     */
    private retrieveDocsMetaData;
    /**
     * Internal array of document codes that represents the component's value
     */
    private internalValue;
    /**
     * ControlValueAccessor method to update the internal value from the form model
     * @param obj Array of document codes
     */
    writeValue(obj: any): void;
    /**
     * Default change handler function
     */
    private onChange;
    /**
     * Default touch handler function
     */
    private onTouch;
    /**
     * ControlValueAccessor method to register the onChange callback
     * @param fn Callback function to be called when the value changes
     */
    registerOnChange(fn: any): void;
    /**
     * ControlValueAccessor method to register the onTouch callback
     * @param fn Callback function to be called when the control is touched
     */
    registerOnTouched(fn: any): void;
    /**
     * ControlValueAccessor method to handle the disabled state
     * @param isDisabled Flag indicating if the control should be disabled
     */
    setDisabledState?(isDisabled: boolean): void;
    /**
     * Angular lifecycle hook that runs when the component initializes
     */
    ngOnInit(): void;
    /**
     * Removes a document from the selection
     * @param item Document reference to remove
     */
    doRemoveFile(item: EnrichedDocumentReferenceView): void;
    /**
     * Handles click events on document items to view their details
     * @param item Document reference that was clicked
     */
    onClickFile(item: EnrichedDocumentReferenceView): void;
    /**
     * Opens the document selection window and initializes the form with current values
     */
    openSelectDocumentsWindow(): void;
    /**
     * Angular lifecycle hook that runs when component inputs change
     * @param changes SimpleChanges object containing the changed properties
     */
    ngOnChanges(changes: SimpleChanges): void;
    /**
     * Applies the selected documents from the search window and updates the component value
     */
    acceptedValues(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<GeboAIChooseDocumentsPanelComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<GeboAIChooseDocumentsPanelComponent, "gebo-ai-choose-documents-panel-component", never, { "knowledgeBaseCodes": { "alias": "knowledgeBaseCodes"; "required": false; }; "readonly": { "alias": "readonly"; "required": false; }; "interactionDisabled": { "alias": "interactionDisabled"; "required": false; }; "maxDisplayedDocuments": { "alias": "maxDisplayedDocuments"; "required": false; }; "openedSearchDocumentsWindows": { "alias": "openedSearchDocumentsWindows"; "required": false; }; "openedUploadDocumentsWindow": { "alias": "openedUploadDocumentsWindow"; "required": false; }; }, { "openedSearchDocumentsWindowsChange": "openedSearchDocumentsWindowsChange"; "openedUploadDocumentsWindowChange": "openedUploadDocumentsWindowChange"; "successfullDocumentChosen": "successfullDocumentChosen"; "choosenDocumentsListCleared": "choosenDocumentsListCleared"; }, never, never, false, never>;
}
