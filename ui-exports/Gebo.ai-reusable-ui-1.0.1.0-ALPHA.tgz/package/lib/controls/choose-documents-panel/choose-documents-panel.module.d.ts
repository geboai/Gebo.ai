import * as i0 from "@angular/core";
import * as i1 from "./choose-documents-panel.component";
import * as i2 from "./search-documents.component";
import * as i3 from "./documents-list-panel.component";
import * as i4 from "@angular/common";
import * as i5 from "@angular/forms";
import * as i6 from "../vfilesystem-selector/vfilesystem-selector.module";
import * as i7 from "primeng/panel";
import * as i8 from "primeng/dialog";
import * as i9 from "primeng/blockui";
import * as i10 from "primeng/button";
import * as i11 from "primeng/tabs";
import * as i12 from "../content-viewer/gebo-ai-content-viewer.module";
import * as i13 from "primeng/inputtext";
import * as i14 from "primeng/checkbox";
import * as i15 from "primeng/picklist";
import * as i16 from "@angular/cdk/drag-drop";
import * as i17 from "../userspace-files-component/userspace-files.module";
import * as i18 from "../field-translation-container/field-container.module";
/**
 * AI generated comments
 *
 * @NgModule GeboAIChooseDocumentsPanelModule
 * This module organizes and exports components related to document selection, searching, and display
 * functionality within the Gebo.ai application. It bundles together multiple UI components that
 * handle document selection, searching, and listing operations.
 *
 * The module imports various Angular and PrimeNG modules that provide UI components and functionality:
 * - Angular core modules (CommonModule, ReactiveFormsModule, DragDropModule)
 * - PrimeNG UI components (PanelModule, TabsModule, DialogModule, etc.)
 * - Gebo.ai custom modules (VFilesystemSelectorModule, GeboAIContentViewerModule, etc.)
 *
 * It declares and exports three main components:
 * - GeboAIChooseDocumentsPanelComponent: Main component for document selection
 * - GeboAISearchDocumentsComponent: Provides document search functionality
 * - GeboAIDocumentsListPanelComponent: Displays lists of selected documents
 */
export declare class GeboAIChooseDocumentsPanelModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<GeboAIChooseDocumentsPanelModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<GeboAIChooseDocumentsPanelModule, [typeof i1.GeboAIChooseDocumentsPanelComponent, typeof i2.GeboAISearchDocumentsComponent, typeof i3.GeboAIDocumentsListPanelComponent], [typeof i4.CommonModule, typeof i5.ReactiveFormsModule, typeof i5.FormsModule, typeof i6.VFilesystemSelectorModule, typeof i7.PanelModule, typeof i8.DialogModule, typeof i9.BlockUIModule, typeof i10.ButtonModule, typeof i11.TabsModule, typeof i12.GeboAIContentViewerModule, typeof i13.InputTextModule, typeof i14.CheckboxModule, typeof i15.PickListModule, typeof i16.DragDropModule, typeof i17.GeboAIUserspaceFilesModule, typeof i18.GeboAIFieldTranslationContainerModule], [typeof i1.GeboAIChooseDocumentsPanelComponent, typeof i2.GeboAISearchDocumentsComponent, typeof i3.GeboAIDocumentsListPanelComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<GeboAIChooseDocumentsPanelModule>;
}
//# sourceMappingURL=choose-documents-panel.module.d.ts.map