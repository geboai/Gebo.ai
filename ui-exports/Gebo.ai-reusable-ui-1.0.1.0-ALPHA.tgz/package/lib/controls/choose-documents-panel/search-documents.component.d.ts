/**
 * This Source Code is subject to the terms of the
 * Gebo.ai community version Mozilla Public License Version 2.0 (MPL-2.0) — With Data Protection Clauses
 * If a copy of the LICENCE was not distributed with this file, You can obtain one at
 * https://gebo.ai/gebo-ai-community-version-mozilla-public-license-version-2-0-mpl-2-0-with-data-protection-clauses/
 * and https://mozilla.org/MPL/2.0/.
 * Copyright (c) 2025+ Gebo.ai
 */
/**
 * AI generated comments
 *
 * This file implements a search component for the Gebo.ai application that allows users to search for documents
 * across various knowledge bases using different search methods including semantic search, filename search,
 * and directory browsing.
 */
import { EventEmitter, OnChanges, OnInit, SimpleChanges } from "@angular/core";
import { FormGroup } from "@angular/forms";
import { DocumentReferenceView, UserKnowledgeBaseBrowsingControllerService } from "@Gebo.ai/gebo-ai-rest-api";
import { EnrichedDocumentReferenceView, EnrichedDocumentReferenceViewRetrieveService } from "../content-viewer/enriched-document-reference-view.service";
import { browsePathObservableCallback, loadRootsObservableCallback, reconstructNavigationObservableCallback } from "../vfilesystem-selector/vfilesystem-types";
import { GeboAIFieldHost } from "../field-host-component-iface/field-host-component-iface";
import * as i0 from "@angular/core";
/**
 * Component that provides document searching functionality through multiple methods:
 * - Semantic search (natural language queries)
 * - Filename search
 * - Directory browsing
 * - Userspace file selection
 *
 * Implements ControlValueAccessor to work as a form control and supports multi-selection of documents.
 */
export declare class GeboAISearchDocumentsComponent implements OnInit, OnChanges, GeboAIFieldHost {
    private userKnowledgeBaseBrowsing;
    private enrichedDocumentsMetaInfosService;
    /** Knowledge base codes to search within */
    knowledgeBaseCodes?: string[];
    /** Flag indicating if documents are currently being loaded */
    loadingDocuments: boolean;
    /** Flag indicating if semantic search is currently running */
    runningSemanticSearch: boolean;
    /** Flag indicating if filename search is currently running */
    runningFileNameSearch: boolean;
    /** Observable callback to load root directories */
    loadRootsObservable: loadRootsObservableCallback;
    /** Observable callback to browse a specific path */
    browsePathObservable: browsePathObservableCallback;
    /** Observable callback to reconstruct navigation points */
    reconstructNavigationObservableCallback: reconstructNavigationObservableCallback;
    /** Form group for browsing documents */
    browseFormGroup: FormGroup;
    /** Form group for semantic search */
    semanticSearchFormGroup: FormGroup;
    /** Form group for filename search */
    fileNameSearchFormGroup: FormGroup;
    /** Form group for userspace files */
    userspaceFilesFormGroup: FormGroup;
    /** Form group for output documents */
    outFormGroup: FormGroup;
    /** Master list of all documents found from various search methods */
    sourceDocuments: EnrichedDocumentReferenceView[];
    /** Documents found via filename search */
    searchByFileNameResultsDocuments: EnrichedDocumentReferenceView[];
    /** Documents found via semantic search */
    semanticSearchResultsDocuments: EnrichedDocumentReferenceView[];
    /** Documents found via directory browsing */
    browsingResultsDocuments: EnrichedDocumentReferenceView[];
    /** Documents found in user workspace */
    userspaceResultsDocuments: EnrichedDocumentReferenceView[];
    /** Final selected documents */
    outputDocuments: EnrichedDocumentReferenceView[];
    /** Event emitter for closing the component */
    closeMe: EventEmitter<boolean>;
    /** Event emitter for when document selection is confirmed */
    confirmed: EventEmitter<boolean>;
    /**
     * Constructor initializes services needed for document searching
     *
     * @param userKnowledgeBaseBrowsing Service for browsing knowledge base structure
     * @param enrichedDocumentsMetaInfosService Service for retrieving document metadata
     */
    constructor(userKnowledgeBaseBrowsing: UserKnowledgeBaseBrowsingControllerService, enrichedDocumentsMetaInfosService: EnrichedDocumentReferenceViewRetrieveService);
    getEntityName(): string;
    protected get loading(): boolean;
    /**
     * Determines if knowledge bases are available for searching
     *
     * @returns True if knowledge bases are available, false otherwise
     */
    get hasKnowledgeBases(): boolean;
    /**
     * Retrieves metadata for documents in the main panel based on their codes
     * Updates the outputDocuments array with enriched document information
     */
    private retrieveMainPanelDocsMetaData;
    /** Internal storage for selected document codes */
    private internalValue;
    /**
     * Implements ControlValueAccessor.writeValue
     * Sets the internal value and retrieves document metadata
     *
     * @param obj Array of document codes
     */
    writeValue(obj: any): void;
    /** Function called when value changes */
    private onChange;
    /** Function called when control is touched */
    private onTouch;
    /**
     * Implements ControlValueAccessor.registerOnChange
     *
     * @param fn Change handler function
     */
    registerOnChange(fn: any): void;
    /**
     * Implements ControlValueAccessor.registerOnTouched
     *
     * @param fn Touch handler function
     */
    registerOnTouched(fn: any): void;
    /**
     * Implements ControlValueAccessor.setDisabledState
     *
     * @param isDisabled Whether the control should be disabled
     */
    setDisabledState?(isDisabled: boolean): void;
    /**
     * Initializes the component and sets up form value change subscriptions
     * for browsing and userspace files
     */
    ngOnInit(): void;
    /**
     * Handles changes to component inputs, particularly knowledgeBaseCodes
     * Updates form controls and observable callbacks when knowledge base codes change
     *
     * @param changes SimpleChanges object containing changed properties
     */
    ngOnChanges(changes: SimpleChanges): void;
    /**
     * Executes a semantic search based on the query in the semantic search form
     * Updates semanticSearchResultsDocuments with the results
     */
    doSemanticSearch(): void;
    /**
     * Appends document codes to the internal value and refreshes document metadata
     *
     * @param values Document codes to append
     */
    appendResults(values: string[]): void;
    /**
     * Executes a filename search based on the filename in the search form
     * Updates searchByFileNameResultsDocuments with the results
     */
    doSearchByFileName(): void;
    /**
     * Adds documents to the source documents collection if they aren't already present
     * Ensures no duplicates are added
     *
     * @param docsList List of documents to add
     */
    addSourceDocuments(docsList: DocumentReferenceView[]): void;
    /**
     * Confirms selected documents and emits them
     *
     * @param eventList List of selected documents
     */
    confirmDocuments(eventList: DocumentReferenceView[]): void;
    /**
     * Confirms documents from the pick list and emits the selection
     * Updates the internal value and calls the onChange handler
     */
    confirmDocumentsPickList(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<GeboAISearchDocumentsComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<GeboAISearchDocumentsComponent, "gebo-ai-search-documents-component", never, { "knowledgeBaseCodes": { "alias": "knowledgeBaseCodes"; "required": false; }; }, { "closeMe": "closeMe"; "confirmed": "confirmed"; }, never, never, false, never>;
}
//# sourceMappingURL=search-documents.component.d.ts.map