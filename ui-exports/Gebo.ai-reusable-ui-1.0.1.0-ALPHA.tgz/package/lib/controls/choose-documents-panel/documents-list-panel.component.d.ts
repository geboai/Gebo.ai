/**
 * This Source Code is subject to the terms of the
 * Gebo.ai community version Mozilla Public License Version 2.0 (MPL-2.0) — With Data Protection Clauses
 * If a copy of the LICENCE was not distributed with this file, You can obtain one at
 * https://gebo.ai/gebo-ai-community-version-mozilla-public-license-version-2-0-mpl-2-0-with-data-protection-clauses/
 * and https://mozilla.org/MPL/2.0/.
 * Copyright (c) 2025+ Gebo.ai
 */
/**
 * AI generated comments
 *
 * This file contains the GeboAIDocumentsListPanelComponent which provides functionality for displaying
 * and selecting documents from a list. The component allows users to view a list of documents,
 * select one or more documents, and emit the selection back to a parent component.
 */
import { EventEmitter, OnChanges, OnInit, SimpleChanges } from "@angular/core";
import { FormGroup } from "@angular/forms";
import { DocumentReferenceView } from "@Gebo.ai/gebo-ai-rest-api";
import { GeboAIFieldHost } from "../field-host-component-iface/field-host-component-iface";
import * as i0 from "@angular/core";
/**
 * A component that displays a list of documents and allows users to select from them.
 * This panel component can be customized with a title and handles the document selection process.
 * It uses Angular's reactive forms to track and validate document selections.
 */
export declare class GeboAIDocumentsListPanelComponent implements OnChanges, OnInit, GeboAIFieldHost {
    /** List of documents to display and select from */
    documentsList: DocumentReferenceView[];
    /** Customizable title for the panel */
    title: string;
    /** Indicates whether the document list is currently loading */
    loading: boolean;
    /** Event emitter that sends the selected documents to parent components */
    documentsSelection: EventEmitter<DocumentReferenceView[]>;
    /** Form group to handle document selection */
    formGroup: FormGroup;
    /**
     * Responds to changes in input properties.
     * If the documentsList input changes, updates the form control value to reflect the new list.
     *
     * @param changes The input properties that have changed
     */
    ngOnChanges(changes: SimpleChanges): void;
    /**
     * Initializes the component by setting validators for the form control.
     * Makes document selection required.
     */
    ngOnInit(): void;
    /**
     * Handles the submission of selected documents.
     * Emits the selected documents through the documentsSelection output event and
     * clears the documentsList to reset the component state.
     */
    onOkFiles(): void;
    getEntityName(): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<GeboAIDocumentsListPanelComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<GeboAIDocumentsListPanelComponent, "gebo-ai-documents-list-panel-component", never, { "documentsList": { "alias": "documentsList"; "required": false; }; "title": { "alias": "title"; "required": false; }; "loading": { "alias": "loading"; "required": false; }; }, { "documentsSelection": "documentsSelection"; }, never, never, false, never>;
}
//# sourceMappingURL=documents-list-panel.component.d.ts.map