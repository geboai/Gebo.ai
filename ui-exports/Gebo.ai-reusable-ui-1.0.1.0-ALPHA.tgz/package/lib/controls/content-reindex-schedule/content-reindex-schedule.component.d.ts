/**
 * This Source Code is subject to the terms of the
 * Gebo.ai community version Mozilla Public License Version 2.0 (MPL-2.0) — With Data Protection Clauses
 * If a copy of the LICENCE was not distributed with this file, You can obtain one at
 * https://gebo.ai/gebo-ai-community-version-mozilla-public-license-version-2-0-mpl-2-0-with-data-protection-clauses/
 * and https://mozilla.org/MPL/2.0/.
 * Copyright (c) 2025+ Gebo.ai
 */
import { OnChanges, OnInit, SimpleChanges } from "@angular/core";
import { ControlValueAccessor, FormGroup } from "@angular/forms";
import { ReindexingFrequencyOptionsControllerService, ReindexingProgrammedTable, ReindexTimeStructureMetaInfo } from "@Gebo.ai/gebo-ai-rest-api";
import * as i0 from "@angular/core";
/**
 * Interface for period options used in the scheduling component
 * Contains a code representing the frequency type and a human-readable description
 */
interface PeriodOption {
    code: ReindexingProgrammedTable.FrequencyEnum;
    description: string;
}
/**
 * Component responsible for managing content reindexing schedules
 * Provides a UI for setting, editing, and displaying reindexing schedules with various frequency options
 * Implements ControlValueAccessor to integrate with Angular forms
 */
export declare class GeboAIContentReindexScheduleComponent implements OnChanges, OnInit, ControlValueAccessor {
    private reindexingFrequencyController;
    /**
     * Input property that allows specifying which frequency types should be available in the component
     */
    frequencyTypes?: ReindexingProgrammedTable.FrequencyEnum[];
    /**
     * List of frequency periods that can be scheduled based on input configuration
     */
    availableSchedulablePeriods?: ReindexingProgrammedTable.FrequencyEnum[];
    /**
     * Current value of the scheduled reindexing configurations
     */
    value?: ReindexingProgrammedTable[];
    /**
     * Temporarily edited value during modification process
     */
    editedValue?: ReindexingProgrammedTable[];
    /**
     * Current UI mode - either displaying schedules or editing them
     */
    mode: "DISPLAY" | "EDITING";
    /**
     * Human-readable representations of configured time schedules
     */
    displayTimes: string[];
    /**
     * Flag indicating if data is being loaded or processed
     */
    loading: boolean;
    /**
     * Metadata about time structures for different frequency types
     */
    timeMetaInfos: ReindexTimeStructureMetaInfo[];
    /**
     * Controls whether value changes should be emitted or not
     */
    private emitValue;
    /**
     * Form group for managing the schedule editing UI
     */
    formGroup: FormGroup;
    /**
     * Returns periods that haven't been scheduled yet
     * Filters the available periods to only show ones that aren't already configured
     */
    get unscheduledPeriods(): PeriodOption[];
    /**
     * Constructor initializes the component with required services
     * @param reindexingFrequencyController Service to handle reindexing frequency operations
     */
    constructor(reindexingFrequencyController: ReindexingFrequencyOptionsControllerService);
    /**
     * Lifecycle hook that responds to changes in input properties
     * @param changes SimpleChanges object containing changed properties
     */
    ngOnChanges(changes: SimpleChanges): void;
    /**
     * Validates a reindexing programmed table entry based on its frequency and values
     * Checks if the time components match the expected format for the given frequency
     * @param frequency The frequency type to validate
     * @param value The time slot values to validate
     * @returns Boolean indicating whether the values are valid for the given frequency
     */
    private validateReindexingProgrammedTable;
    /**
     * Initializes the component and sets up form validation
     * Fetches time structure metadata required for validation
     */
    ngOnInit(): void;
    /**
     * Confirms changes made in the edit mode and updates the schedule values
     * Propagates changes through the ControlValueAccessor
     */
    confirmEditedValues(): void;
    /**
     * Adds a new scheduling entry based on the selected frequency
     * Prepares the new entry for editing
     */
    addScheduling(): void;
    /**
     * Switches to edit mode and populates form with current values
     * Sets form controls based on the current schedule configuration
     */
    showEdit(): void;
    /**
     * Cancels the current editing operation and reverts to display mode
     * Discards any unsaved changes
     */
    abandonEdit(): void;
    /**
     * Enters edit mode and initializes edited value with current value
     * Creates a copy of the current schedule for editing
     */
    enterEdit(): void;
    /**
     * Updates the component value and notifies the form
     * Called when schedule values have changed
     * @param newValue The new schedule configuration
     */
    private notifyValuesChanges;
    /**
     * Creates a ReindexingProgrammedTable array for a specific frequency
     * Constructs the data structure for a single frequency type
     * @param frequency The frequency type
     * @param data The time slots for this frequency
     * @returns Array of ReindexingProgrammedTable entries
     */
    private readVector;
    /**
     * Transforms the internal form representation to the API's expected format
     * Combines data from different frequency controls into a unified structure
     * @param newValue The form value in InternalRappr format
     * @returns Array of ReindexingProgrammedTable with valid configurations
     */
    private readDataInput;
    /**
     * ControlValueAccessor implementation: writes a value to the component
     * Updates the component's internal state with the new value
     * @param obj The value to write
     */
    writeValue(obj: any): void;
    /**
     * Fetches human-readable representations of the schedule values
     * Converts technical time specifications to user-friendly display strings
     */
    private displayValue;
    /**
     * Function to call when value changes, used by ControlValueAccessor
     */
    private onChange;
    /**
     * ControlValueAccessor implementation: registers a callback for value changes
     * @param fn The callback function
     */
    registerOnChange(fn: any): void;
    /**
     * ControlValueAccessor implementation: registers a callback for touched state
     * @param fn The callback function
     */
    registerOnTouched(fn: any): void;
    /**
     * ControlValueAccessor implementation: handles disabled state changes
     * @param isDisabled Whether the control should be disabled
     */
    setDisabledState?(isDisabled: boolean): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<GeboAIContentReindexScheduleComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<GeboAIContentReindexScheduleComponent, "gebo-ai-content-reindex-scheduler-component", never, { "frequencyTypes": { "alias": "frequencyTypes"; "required": false; }; }, {}, never, never, false, never>;
}
export {};
//# sourceMappingURL=content-reindex-schedule.component.d.ts.map