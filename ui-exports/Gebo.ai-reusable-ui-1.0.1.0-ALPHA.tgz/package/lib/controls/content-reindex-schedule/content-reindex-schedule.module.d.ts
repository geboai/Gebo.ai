import * as i0 from "@angular/core";
import * as i1 from "./periods-base.component";
import * as i2 from "./time-set.component";
import * as i3 from "./content-reindex-schedule.component";
import * as i4 from "@angular/common";
import * as i5 from "@angular/forms";
import * as i6 from "primeng/dialog";
import * as i7 from "primeng/panel";
import * as i8 from "primeng/blockui";
import * as i9 from "primeng/chip";
import * as i10 from "primeng/button";
import * as i11 from "primeng/select";
import * as i12 from "primeng/calendar";
import * as i13 from "primeng/inputnumber";
import * as i14 from "primeng/fieldset";
import * as i15 from "../field-translation-container/field-container.module";
/**
 * NgModule for content reindexing functionality.
 *
 * This module encapsulates all components needed for the content reindexing feature.
 * It imports necessary UI modules from PrimeNG like calendar, buttons, dialogs, etc.,
 * and Angular's form handling modules.
 *
 * The module declares three components:
 * - GeboAIPeriodsSchedulingBaseComponent: Base component for period scheduling
 * - TimeSetComponent: Component for setting specific times
 * - GeboAIContentReindexScheduleComponent: Main component for content reindexing schedule
 *
 * Only the GeboAIContentReindexScheduleComponent is exported for use in other modules.
 */
export declare class GeboAIContentReindexModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<GeboAIContentReindexModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<GeboAIContentReindexModule, [typeof i1.GeboAIPeriodsSchedulingBaseComponent, typeof i2.TimeSetComponent, typeof i3.GeboAIContentReindexScheduleComponent], [typeof i4.CommonModule, typeof i5.ReactiveFormsModule, typeof i5.FormsModule, typeof i6.DialogModule, typeof i7.PanelModule, typeof i8.BlockUIModule, typeof i9.ChipModule, typeof i10.ButtonModule, typeof i11.SelectModule, typeof i12.CalendarModule, typeof i13.InputNumberModule, typeof i14.FieldsetModule, typeof i15.GeboAIFieldTranslationContainerModule], [typeof i3.GeboAIContentReindexScheduleComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<GeboAIContentReindexModule>;
}
//# sourceMappingURL=content-reindex-schedule.module.d.ts.map