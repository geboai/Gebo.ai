/**
 * This Source Code is subject to the terms of the
 * Gebo.ai community version Mozilla Public License Version 2.0 (MPL-2.0) — With Data Protection Clauses
 * If a copy of the LICENCE was not distributed with this file, You can obtain one at
 * https://gebo.ai/gebo-ai-community-version-mozilla-public-license-version-2-0-mpl-2-0-with-data-protection-clauses/
 * and https://mozilla.org/MPL/2.0/.
 * Copyright (c) 2025+ Gebo.ai
 */
import { EventEmitter, OnChanges, OnInit, SimpleChanges } from "@angular/core";
import { ControlValueAccessor, FormControl } from "@angular/forms";
import { ReindexTimeComponentMetaInfo } from "@Gebo.ai/gebo-ai-rest-api";
import * as i0 from "@angular/core";
/**
 * AI generated comments
 *
 * Interface representing configuration for choice values in time component.
 * Defines the structure for configuring min/max values or a list of predefined choices.
 */
interface ChoiceCfg {
    minValue?: number;
    maxValue?: number;
    choices?: {
        id: number;
        label: string;
    }[];
}
/**
 * AI generated comments
 *
 * A reusable Angular component for configuring time-related values.
 * This component can be used to select time values from predefined choices or date values.
 * It implements ControlValueAccessor to work seamlessly with Angular forms.
 * Can handle multiple time dimensions based on provided metadata.
 */
export declare class TimeSetComponent implements OnInit, OnChanges, ControlValueAccessor {
    /**
     * Configuration metadata for time component, defines the time units and available options
     */
    metaInfo?: ReindexTimeComponentMetaInfo[];
    /**
     * Flag indicating if the component should display date selection (true) or numeric selection (false)
     */
    dateComponent: boolean;
    /**
     * Array of selected values for each time unit
     */
    values: (number | undefined)[];
    /**
     * Configuration for each choice field in the component
     */
    choices: ChoiceCfg[];
    /**
     * Form controls array for each time selection field
     */
    formControl: FormControl[];
    /**
     * Form control for created timestamp
     */
    createdTime: FormControl;
    /**
     * Event emitter to notify parent when this component should be removed
     */
    remove: EventEmitter<boolean>;
    /**
     * Component initialization logic
     */
    ngOnInit(): void;
    /**
     * Collects and emits the current component values when changes occur
     * Converts date values to timestamps if in date mode
     */
    private emitChange;
    /**
     * Syncs the form controls with the current values
     * Handles conversion between timestamp and date objects if in date mode
     */
    private setControls;
    /**
     * Utility function to convert Date object to timestamp (milliseconds)
     * @param d Date object to convert
     * @returns Timestamp in milliseconds or 0 if no date provided
     */
    private date2int;
    /**
     * Utility function to convert timestamp to Date object
     * @param i Timestamp in milliseconds
     * @returns Date object or undefined if no timestamp provided
     */
    private int2date;
    /**
     * Handles component input changes, particularly when metaInfo changes
     * Sets up the component based on the new metadata including form controls and choice configurations
     * @param changes Angular SimpleChanges object containing changed inputs
     */
    ngOnChanges(changes: SimpleChanges): void;
    /**
     * ControlValueAccessor implementation: Sets the component's value from form model
     * @param obj The value from the form model
     */
    writeValue(obj: any): void;
    /**
     * Default onChange handler for ControlValueAccessor
     */
    private onChange;
    /**
     * ControlValueAccessor implementation: Registers onChange handler
     * @param fn Function to call when the value changes
     */
    registerOnChange(fn: any): void;
    /**
     * Default onTouch handler for ControlValueAccessor
     */
    private onTouch;
    /**
     * ControlValueAccessor implementation: Registers onTouched handler
     * @param fn Function to call when the control is touched
     */
    registerOnTouched(fn: any): void;
    /**
     * ControlValueAccessor implementation: Sets the disabled state
     * @param isDisabled Whether the control should be disabled
     */
    setDisabledState?(isDisabled: boolean): void;
    /**
     * Emits remove event to notify parent that this component should be removed
     */
    removeThis(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<TimeSetComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<TimeSetComponent, "time-set-component", never, { "metaInfo": { "alias": "metaInfo"; "required": false; }; }, { "remove": "remove"; }, never, never, false, never>;
}
export {};
//# sourceMappingURL=time-set.component.d.ts.map