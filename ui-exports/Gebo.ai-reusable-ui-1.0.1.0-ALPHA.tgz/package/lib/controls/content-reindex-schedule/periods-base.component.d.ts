/**
 * This Source Code is subject to the terms of the
 * Gebo.ai community version Mozilla Public License Version 2.0 (MPL-2.0) — With Data Protection Clauses
 * If a copy of the LICENCE was not distributed with this file, You can obtain one at
 * https://gebo.ai/gebo-ai-community-version-mozilla-public-license-version-2-0-mpl-2-0-with-data-protection-clauses/
 * and https://mozilla.org/MPL/2.0/.
 * Copyright (c) 2025+ Gebo.ai
 */
/**
 * AI generated comments
 *
 * This file defines a component for managing periodic scheduling in the Gebo.ai application.
 * It implements Angular's ControlValueAccessor interface to integrate with reactive forms.
 */
import { OnChanges, OnInit, SimpleChanges } from "@angular/core";
import { ControlValueAccessor, FormArray, FormGroup } from "@angular/forms";
import { ReindexingProgrammedTable, ReindexingTime, ReindexTimeStructureMetaInfo } from "@Gebo.ai/gebo-ai-rest-api";
import * as i0 from "@angular/core";
/**
 * Component responsible for managing period scheduling.
 * This component provides a UI for creating, editing and removing time periods
 * and integrates with Angular's form system through ControlValueAccessor.
 * It handles transformation between the form model and the ReindexingTime data structure.
 */
export declare class GeboAIPeriodsSchedulingBaseComponent implements ControlValueAccessor, OnChanges, OnInit {
    /** Input array of time metadata information */
    timeMetaInfos: ReindexTimeStructureMetaInfo[];
    /** Frequency input to determine which metadata info to use */
    frequency?: ReindexingProgrammedTable.FrequencyEnum;
    /** The selected time metadata info based on the provided frequency */
    controlTimeMetaInfos: ReindexTimeStructureMetaInfo | undefined;
    /** The internal value representation of reindexing times */
    value?: ReindexingTime[];
    /** FormArray used to manage the UI form controls */
    formArray: FormArray<any>;
    /**
     * Responds to input changes by finding the appropriate time metadata
     * for the current frequency setting
     * @param changes The SimpleChanges object containing current and previous values
     */
    ngOnChanges(changes: SimpleChanges): void;
    /**
     * Initializes the component by subscribing to form value changes
     * and propagating those changes through the onChange handler
     */
    ngOnInit(): void;
    /**
     * ControlValueAccessor method that writes a new value to the component
     * @param obj The new value to write
     */
    writeValue(obj: any): void;
    /**
     * Gets a FormGroup at the specified index
     * @param i The index of the FormGroup to retrieve
     * @returns The FormGroup at the specified index
     */
    get(i: number): FormGroup;
    /**
     * Adds a new entry to the value array and restructures the form
     */
    addEntry(): void;
    /**
     * Synchronizes the FormArray with the current value.
     * Adds or removes FormGroups as needed and updates values.
     */
    private restructure;
    /** Function to call when the value changes */
    onChange: (v: any) => void;
    /**
     * ControlValueAccessor method to register a callback function for value changes
     * @param fn The callback function
     */
    registerOnChange(fn: any): void;
    /** Function to call when the control is touched */
    onTouch: (v: any) => void;
    /**
     * ControlValueAccessor method to register a callback function for touch events
     * @param fn The callback function
     */
    registerOnTouched(fn: any): void;
    /**
     * ControlValueAccessor method to set the disabled state of the component
     * @param isDisabled Whether the control should be disabled
     */
    setDisabledState?(isDisabled: boolean): void;
    /**
     * Removes a period at the specified index
     * @param i The index of the period to remove
     */
    remove(i: number): void;
    /**
     * Adds a new period to the form array
     */
    addPeriod(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<GeboAIPeriodsSchedulingBaseComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<GeboAIPeriodsSchedulingBaseComponent, "gebo-ai-periods-component", never, { "timeMetaInfos": { "alias": "timeMetaInfos"; "required": false; }; "frequency": { "alias": "frequency"; "required": false; }; }, {}, never, never, false, never>;
}
//# sourceMappingURL=periods-base.component.d.ts.map