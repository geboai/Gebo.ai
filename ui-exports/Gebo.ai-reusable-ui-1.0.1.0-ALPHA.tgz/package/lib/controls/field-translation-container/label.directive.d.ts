import { AfterContentInit, ChangeDetectorRef, ElementRef, OnInit } from "@angular/core";
import { GeboAIFieldHost } from "../field-host-component-iface/field-host-component-iface";
import { GeboAITranslationService } from "./gebo-translation.service";
import { LabelTarget } from "./primeng-components-multilanguage-adapters.directive";
import { BaseComponent } from "primeng/basecomponent";
import * as i0 from "@angular/core";
export declare class GeboAILabelDirective implements AfterContentInit, OnInit {
    private el;
    private translationService;
    private changeDetectionRef;
    private baseComponent;
    private target?;
    private moduleId?;
    private host?;
    constructor(el: ElementRef<HTMLElement>, translationService: GeboAITranslationService, changeDetectionRef: ChangeDetectorRef, baseComponent: BaseComponent, target?: LabelTarget | undefined, moduleId?: string | undefined, host?: GeboAIFieldHost | undefined);
    private componentId;
    private existingTexts;
    ngOnInit(): Promise<void>;
    ngAfterContentInit(): void;
    private checkLabelAttribute;
    static ɵfac: i0.ɵɵFactoryDeclaration<GeboAILabelDirective, [null, null, null, { optional: true; host: true; }, { optional: true; }, { optional: true; }, { optional: true; }]>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<GeboAILabelDirective, "[gebo-ai-label]", never, {}, {}, never, never, false, never>;
}
//# sourceMappingURL=label.directive.d.ts.map