import { AfterContentInit, ElementRef, Renderer2 } from '@angular/core';
import { GeboAIFieldContainerComponent } from './field-container.component';
import { NgControl } from '@angular/forms';
import * as i0 from "@angular/core";
export declare class GeboAIFieldContainerDirective implements AfterContentInit {
    private el;
    private renderer;
    private wrapper;
    private ngControl?;
    constructor(el: ElementRef<HTMLElement>, renderer: Renderer2, wrapper: GeboAIFieldContainerComponent | null, ngControl?: NgControl | undefined);
    ngAfterContentInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<GeboAIFieldContainerDirective, [null, null, { optional: true; }, { optional: true; }]>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<GeboAIFieldContainerDirective, "[gebo-ai-field-element]", never, {}, {}, never, never, false, never>;
}
//# sourceMappingURL=field-container.directive.d.ts.map