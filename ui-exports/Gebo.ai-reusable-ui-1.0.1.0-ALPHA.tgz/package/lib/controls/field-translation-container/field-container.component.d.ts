import { OnChanges, OnInit, SimpleChanges } from "@angular/core";
import { GeboAIFieldHost } from "../field-host-component-iface/field-host-component-iface";
import { Subject } from "rxjs";
import { GeboAITranslationService } from "./gebo-translation.service";
import * as i0 from "@angular/core";
export declare class GeboAIFieldContainerComponent implements OnInit, OnChanges {
    private translationService;
    private moduleId?;
    private host?;
    id: string;
    label: string;
    placeholder: string;
    help: string;
    required: boolean;
    internalLabel: string;
    internalPlaceholder: string;
    internalHelp: string;
    computedRequired: boolean;
    constructor(translationService: GeboAITranslationService, moduleId?: string | undefined, host?: GeboAIFieldHost | undefined);
    localizationSubject: Subject<{
        label?: string;
        help?: string;
        placeholder?: string;
    }>;
    ngOnChanges(changes: SimpleChanges): void;
    ngOnInit(): Promise<void>;
    get helpId(): string;
    setRequiredFromControl(isRequired: boolean): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<GeboAIFieldContainerComponent, [null, { optional: true; }, { optional: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<GeboAIFieldContainerComponent, "gebo-ai-field", never, { "id": { "alias": "id"; "required": true; }; "label": { "alias": "label"; "required": true; }; "placeholder": { "alias": "placeholder"; "required": false; }; "help": { "alias": "help"; "required": false; }; "required": { "alias": "required"; "required": false; }; }, {}, never, ["*"], false, never>;
}
