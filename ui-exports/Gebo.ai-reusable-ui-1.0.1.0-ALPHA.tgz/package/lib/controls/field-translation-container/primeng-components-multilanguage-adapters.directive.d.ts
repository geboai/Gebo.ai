import { InjectionToken } from '@angular/core';
import { Button } from 'primeng/button';
import { Fieldset } from 'primeng/fieldset';
import { Panel } from 'primeng/panel';
import { Dialog } from 'primeng/dialog';
import { Sidebar } from 'primeng/sidebar';
import { Card } from 'primeng/card';
import { TabPanel } from 'primeng/tabview';
import { AccordionTab } from 'primeng/accordion';
import { Toolbar } from 'primeng/toolbar';
import { Chip } from 'primeng/chip';
import { Badge } from 'primeng/badge';
import { Tag } from 'primeng/tag';
import { Checkbox } from 'primeng/checkbox';
import { RadioButton } from 'primeng/radiobutton';
import { ToggleButton } from 'primeng/togglebutton';
import { InputText } from 'primeng/inputtext';
import { InputTextarea } from 'primeng/inputtextarea';
import { InputNumber } from 'primeng/inputnumber';
import { Dropdown } from 'primeng/dropdown';
import { MultiSelect } from 'primeng/multiselect';
import { Listbox } from 'primeng/listbox';
import { Calendar } from 'primeng/calendar';
import { Slider } from 'primeng/slider';
import { ProgressBar } from 'primeng/progressbar';
import { Steps } from 'primeng/steps';
import { Galleria } from 'primeng/galleria';
import * as i0 from "@angular/core";
export interface LabelTarget {
    set(key: string, value: string): void;
}
export declare const GEBO_MULILANGUAGE_TARGET: InjectionToken<LabelTarget>;
export declare function safeSet(instance: any, key: string, value: any): void;
export declare class LabelTargetParent implements LabelTarget {
    private applied?;
    constructor(applied?: any | undefined);
    set(key: string, value: string): void;
}
export declare class PButtonLabelTarget extends LabelTargetParent {
    private btn;
    constructor(btn: Button);
    static ɵfac: i0.ɵɵFactoryDeclaration<PButtonLabelTarget, [{ optional: true; host: true; }]>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<PButtonLabelTarget, "p-button[gebo-ai-label]", never, {}, {}, never, never, false, never>;
}
export declare class PFieldSetLabelTarget extends LabelTargetParent {
    private fs;
    constructor(fs: Fieldset);
    static ɵfac: i0.ɵɵFactoryDeclaration<PFieldSetLabelTarget, [{ optional: true; host: true; }]>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<PFieldSetLabelTarget, "p-fieldset[gebo-ai-label]", never, {}, {}, never, never, false, never>;
}
export declare class PPanelLabelTarget extends LabelTargetParent {
    private pnl;
    constructor(pnl: Panel);
    set(key: string, value: string): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<PPanelLabelTarget, [{ optional: true; self: true; }]>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<PPanelLabelTarget, "p-panel[gebo-ai-label]", never, {}, {}, never, never, false, never>;
}
export declare class PDialogLabelTarget extends LabelTargetParent {
    private dlg;
    constructor(dlg: Dialog);
    static ɵfac: i0.ɵɵFactoryDeclaration<PDialogLabelTarget, [{ optional: true; host: true; }]>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<PDialogLabelTarget, "p-dialog[gebo-ai-label]", never, {}, {}, never, never, false, never>;
}
export declare class PSidebarLabelTarget extends LabelTargetParent {
    private sb;
    constructor(sb: Sidebar);
    static ɵfac: i0.ɵɵFactoryDeclaration<PSidebarLabelTarget, [{ optional: true; host: true; }]>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<PSidebarLabelTarget, "p-sidebar[gebo-ai-label]", never, {}, {}, never, never, false, never>;
}
export declare class PCardLabelTarget extends LabelTargetParent {
    private card;
    constructor(card: Card);
    static ɵfac: i0.ɵɵFactoryDeclaration<PCardLabelTarget, [{ optional: true; host: true; }]>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<PCardLabelTarget, "p-card[gebo-ai-label]", never, {}, {}, never, never, false, never>;
}
export declare class PTabPanelLabelTarget extends LabelTargetParent {
    private tp;
    constructor(tp: TabPanel);
    static ɵfac: i0.ɵɵFactoryDeclaration<PTabPanelLabelTarget, [{ optional: true; self: true; }]>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<PTabPanelLabelTarget, "p-tabPanel[gebo-ai-label]", never, {}, {}, never, never, false, never>;
}
export declare class PAccordionTabLabelTarget extends LabelTargetParent {
    private tab;
    constructor(tab: AccordionTab);
    static ɵfac: i0.ɵɵFactoryDeclaration<PAccordionTabLabelTarget, [{ optional: true; host: true; }]>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<PAccordionTabLabelTarget, "p-accordiontab[gebo-ai-label]", never, {}, {}, never, never, false, never>;
}
export declare class PToolbarLabelTarget extends LabelTargetParent {
    private tb;
    constructor(tb: Toolbar);
    static ɵfac: i0.ɵɵFactoryDeclaration<PToolbarLabelTarget, [{ optional: true; host: true; }]>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<PToolbarLabelTarget, "p-toolbar[gebo-ai-label]", never, {}, {}, never, never, false, never>;
}
export declare class PBadgeLabelTarget extends LabelTargetParent {
    private b;
    constructor(b: Badge);
    static ɵfac: i0.ɵɵFactoryDeclaration<PBadgeLabelTarget, [{ optional: true; host: true; }]>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<PBadgeLabelTarget, "p-badge[gebo-ai-label]", never, {}, {}, never, never, false, never>;
}
export declare class PTagLabelTarget extends LabelTargetParent {
    private t;
    constructor(t: Tag);
    static ɵfac: i0.ɵɵFactoryDeclaration<PTagLabelTarget, [{ optional: true; host: true; }]>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<PTagLabelTarget, "p-tag[gebo-ai-label]", never, {}, {}, never, never, false, never>;
}
export declare class PChipLabelTarget extends LabelTargetParent {
    private c;
    constructor(c: Chip);
    static ɵfac: i0.ɵɵFactoryDeclaration<PChipLabelTarget, [{ optional: true; host: true; }]>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<PChipLabelTarget, "p-chip[gebo-ai-label]", never, {}, {}, never, never, false, never>;
}
export declare class PCheckboxLabelTarget extends LabelTargetParent {
    private ckb;
    constructor(ckb: Checkbox);
    static ɵfac: i0.ɵɵFactoryDeclaration<PCheckboxLabelTarget, [{ optional: true; host: true; }]>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<PCheckboxLabelTarget, "p-checkbox[gebo-ai-label]", never, {}, {}, never, never, false, never>;
}
export declare class PRadioLabelTarget extends LabelTargetParent {
    private rb;
    constructor(rb: RadioButton);
    static ɵfac: i0.ɵɵFactoryDeclaration<PRadioLabelTarget, [{ optional: true; host: true; }]>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<PRadioLabelTarget, "p-radiobutton[gebo-ai-label]", never, {}, {}, never, never, false, never>;
}
export declare class PToggleLabelTarget extends LabelTargetParent {
    private tb;
    constructor(tb: ToggleButton);
    static ɵfac: i0.ɵɵFactoryDeclaration<PToggleLabelTarget, [{ optional: true; host: true; }]>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<PToggleLabelTarget, "p-togglebutton[gebo-ai-label]", never, {}, {}, never, never, false, never>;
}
export declare class PInputTextLabelTarget extends LabelTargetParent {
    private it;
    constructor(it: InputText);
    static ɵfac: i0.ɵɵFactoryDeclaration<PInputTextLabelTarget, [{ optional: true; host: true; }]>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<PInputTextLabelTarget, "p-inputtext[gebo-ai-label], input[pInputText][gebo-ai-label]", never, {}, {}, never, never, false, never>;
}
export declare class PInputTextareaLabelTarget extends LabelTargetParent {
    private ta;
    constructor(ta: InputTextarea);
    static ɵfac: i0.ɵɵFactoryDeclaration<PInputTextareaLabelTarget, [{ optional: true; host: true; }]>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<PInputTextareaLabelTarget, "p-inputtextarea[gebo-ai-label], textarea[pInputTextarea][gebo-ai-label]", never, {}, {}, never, never, false, never>;
}
export declare class PInputNumberLabelTarget extends LabelTargetParent {
    private inn;
    constructor(inn: InputNumber);
    static ɵfac: i0.ɵɵFactoryDeclaration<PInputNumberLabelTarget, [{ optional: true; host: true; }]>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<PInputNumberLabelTarget, "p-inputnumber[gebo-ai-label]", never, {}, {}, never, never, false, never>;
}
export declare class PDropdownLabelTarget extends LabelTargetParent {
    private dd;
    constructor(dd: Dropdown);
    static ɵfac: i0.ɵɵFactoryDeclaration<PDropdownLabelTarget, [{ optional: true; host: true; }]>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<PDropdownLabelTarget, "p-dropdown[gebo-ai-label]", never, {}, {}, never, never, false, never>;
}
export declare class PMultiSelectLabelTarget extends LabelTargetParent {
    private ms;
    constructor(ms: MultiSelect);
    static ɵfac: i0.ɵɵFactoryDeclaration<PMultiSelectLabelTarget, [{ optional: true; host: true; }]>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<PMultiSelectLabelTarget, "p-multiselect[gebo-ai-label]", never, {}, {}, never, never, false, never>;
}
export declare class PListboxLabelTarget extends LabelTargetParent {
    private lb;
    constructor(lb: Listbox);
    static ɵfac: i0.ɵɵFactoryDeclaration<PListboxLabelTarget, [{ optional: true; host: true; }]>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<PListboxLabelTarget, "p-listbox[gebo-ai-label]", never, {}, {}, never, never, false, never>;
}
export declare class PCalendarLabelTarget extends LabelTargetParent {
    private cal;
    constructor(cal: Calendar);
    static ɵfac: i0.ɵɵFactoryDeclaration<PCalendarLabelTarget, [{ optional: true; host: true; }]>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<PCalendarLabelTarget, "p-calendar[gebo-ai-label]", never, {}, {}, never, never, false, never>;
}
export declare class PSliderLabelTarget extends LabelTargetParent {
    private sl;
    constructor(sl: Slider);
    static ɵfac: i0.ɵɵFactoryDeclaration<PSliderLabelTarget, [{ optional: true; host: true; }]>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<PSliderLabelTarget, "p-slider[gebo-ai-label]", never, {}, {}, never, never, false, never>;
}
export declare class PProgressBarLabelTarget extends LabelTargetParent {
    private pb;
    constructor(pb: ProgressBar);
    static ɵfac: i0.ɵɵFactoryDeclaration<PProgressBarLabelTarget, [{ optional: true; host: true; }]>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<PProgressBarLabelTarget, "p-progressbar[gebo-ai-label]", never, {}, {}, never, never, false, never>;
}
export declare class PStepsLabelTarget extends LabelTargetParent {
    private st;
    constructor(st: Steps);
    static ɵfac: i0.ɵɵFactoryDeclaration<PStepsLabelTarget, [{ optional: true; host: true; }]>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<PStepsLabelTarget, "p-steps[gebo-ai-label]", never, {}, {}, never, never, false, never>;
}
export declare class PGalleriaLabelTarget extends LabelTargetParent {
    private gal;
    constructor(gal: Galleria);
    static ɵfac: i0.ɵɵFactoryDeclaration<PGalleriaLabelTarget, [{ optional: true; host: true; }]>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<PGalleriaLabelTarget, "p-galleria[gebo-ai-label]", never, {}, {}, never, never, false, never>;
}
