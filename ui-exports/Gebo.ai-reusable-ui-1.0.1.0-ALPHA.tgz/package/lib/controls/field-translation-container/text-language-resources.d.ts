export declare const DEFAULT_LANGUAGE: string;
export interface UIExistingText {
    moduleId?: string | null;
    entityId?: string | null;
    componentId?: string | null;
    key: string;
    fieldId: string;
    text: string;
    translation?: string;
}
export type UILanguageResources = {
    [key: string]: (UILanguageResources | string);
};
export declare function extractUIExistingText(item: UIExistingText, data: UILanguageResources): UIExistingText | undefined;
export declare function findMatchingTranslation(example: UIExistingText, data: UILanguageResources): UIExistingText | undefined;
export declare function findMatchingTranlations(examples: UIExistingText[], data: UILanguageResources): UIExistingText[] | undefined;
//# sourceMappingURL=text-language-resources.d.ts.map