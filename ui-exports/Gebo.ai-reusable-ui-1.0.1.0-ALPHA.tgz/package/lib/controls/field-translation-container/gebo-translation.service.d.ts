import { UIExistingText, UILanguageResources } from "./text-language-resources";
import { Observable, Subject } from "rxjs";
import { UiTextResourcesControllerService, GUserMessage } from "@Gebo.ai/gebo-ai-rest-api";
import { Language, TranslateService } from "@ngx-translate/core";
import { Confirmation, MegaMenuItem, MenuItem, ToastMessageOptions } from "primeng/api";
import { HttpClient } from "@angular/common/http";
import { GeboLanguage } from "./language-choice.component";
import * as i0 from "@angular/core";
export interface ExtendedConfirmation extends Confirmation {
    id: string;
}
/*******************************************************************************
 * The actual UI resources are all written in english, used as a default language
 * resources source, once the language is changed this service will publish all
 * the translations and respond to immediate text resources lookups (translateOnActualLanguage)
 */
export declare class GeboAITranslationService {
    private uiTextResourcesService;
    private translateService;
    private httpClient;
    private static actualLanguage;
    static recordingOn: boolean;
    private static initialized;
    private static currentTextResources;
    private static languageChoices;
    constructor(uiTextResourcesService: UiTextResourcesControllerService, translateService: TranslateService, httpClient: HttpClient);
    protected get assetsUrl(): string;
    private loadLanguagesResource;
    get browserLanguage(): Language | undefined;
    tryInit(): Promise<void>;
    languageChanges: Subject<UILanguageResources | undefined>;
    get languagesList(): GeboLanguage[];
    translateOnActualLanguage(textResources: UIExistingText[]): Observable<UILanguageResources | undefined>;
    translateConfirmation(moduleId: string, entityId: string, confirmation: ExtendedConfirmation): Observable<ExtendedConfirmation | undefined>;
    translateText(moduleId: string, entityId: string, componentId: string, resources: {
        fieldId: string;
        text: string;
    }[]): Observable<{
        fieldId: string;
        translation: string;
    }[] | undefined>;
    translateBackendMessage(message: GUserMessage): Observable<GUserMessage | undefined>;
    private declareBackendMessage;
    translateBackendMessages(messages: GUserMessage[]): Observable<GUserMessage[] | undefined>;
    translateMessage(moduleId: string, entityId: string, componentId: string, option: ToastMessageOptions): Observable<ToastMessageOptions | undefined>;
    changeActualLanguage(language: string): void;
    translateMegaMenuItems(moduleId: string, entityId: string, menuItems: MegaMenuItem[]): Observable<MegaMenuItem[]>;
    translateMenuItems(moduleId: string, entityId: string, menuItems: MenuItem[]): Observable<MenuItem[]>;
    getActualLanguage(): string;
    download(): Observable<Blob>;
    getLanguages(): readonly string[];
    static ɵfac: i0.ɵɵFactoryDeclaration<GeboAITranslationService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<GeboAITranslationService>;
}
