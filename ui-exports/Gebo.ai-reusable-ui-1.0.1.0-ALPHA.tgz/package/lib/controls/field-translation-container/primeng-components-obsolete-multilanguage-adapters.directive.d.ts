import { LabelTargetParent } from "./primeng-components-multilanguage-adapters.directive";
import { TabPanel } from 'primeng/tabs';
import * as i0 from "@angular/core";
export declare class POldTabPanelLabelTarget extends LabelTargetParent {
    private gal;
    constructor(gal: TabPanel);
    static ɵfac: i0.ɵɵFactoryDeclaration<POldTabPanelLabelTarget, [{ optional: true; self: true; }]>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<POldTabPanelLabelTarget, "p-tab[gebo-ai-label]", never, {}, {}, never, never, false, never>;
}
