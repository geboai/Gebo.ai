import { EventEmitter, OnChanges, OnInit, SimpleChanges } from "@angular/core";
import { FormGroup } from "@angular/forms";
import { GeboAITranslationService } from "./gebo-translation.service";
import { MegaMenuItem } from "primeng/api";
import * as i0 from "@angular/core";
export declare class GeboAIMainLanguageChoiceComponent implements OnInit, OnChanges {
    private geboTranslationService;
    formGroup: FormGroup;
    protected currentLanguageCodeIcon: string;
    protected currentLanguageCode: string;
    menuItem?: MegaMenuItem;
    appendTo?: any;
    languageChange: EventEmitter<string>;
    languageChoice: any;
    constructor(geboTranslationService: GeboAITranslationService);
    ngOnChanges(changes: SimpleChanges): void;
    ngOnInit(): Promise<void>;
    static ɵfac: i0.ɵɵFactoryDeclaration<GeboAIMainLanguageChoiceComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<GeboAIMainLanguageChoiceComponent, "gebo-ai-main-language-choice", never, { "menuItem": { "alias": "menuItem"; "required": false; }; "appendTo": { "alias": "appendTo"; "required": false; }; }, { "languageChange": "languageChange"; }, never, never, false, never>;
}
//# sourceMappingURL=main-language-choice.component.d.ts.map