import { GeboAITranslationService } from "./gebo-translation.service";
import * as i0 from "@angular/core";
export declare class GeboAILanguageResourcesDownloadComponent {
    private translationService;
    constructor(translationService: GeboAITranslationService);
    get enabled(): boolean;
    download(): void;
    private doDownload;
    protected get languages(): readonly string[];
    protected changeLanguage(lang: string): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<GeboAILanguageResourcesDownloadComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<GeboAILanguageResourcesDownloadComponent, "gebo-ai-language-resource-download", never, {}, {}, never, never, false, never>;
}
