import { ModuleWithProviders } from "@angular/core";
import * as i0 from "@angular/core";
import * as i1 from "./field-container.component";
import * as i2 from "./field-container.directive";
import * as i3 from "./label.directive";
import * as i4 from "./text.directive";
import * as i5 from "./language-resources-download.component";
import * as i6 from "./language-choice.component";
import * as i7 from "./main-language-choice.component";
import * as i8 from "./primeng-components-multilanguage-adapters.directive";
import * as i9 from "./primeng-components-obsolete-multilanguage-adapters.directive";
import * as i10 from "@angular/common";
import * as i11 from "@angular/forms";
import * as i12 from "primeng/button";
import * as i13 from "primeng/select";
import * as i14 from "primeng/popover";
export declare class GeboAIFieldTranslationContainerModule {
    static forRoot(): ModuleWithProviders<GeboAIFieldTranslationContainerModule>;
    static ɵfac: i0.ɵɵFactoryDeclaration<GeboAIFieldTranslationContainerModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<GeboAIFieldTranslationContainerModule, [typeof i1.GeboAIFieldContainerComponent, typeof i2.GeboAIFieldContainerDirective, typeof i3.GeboAILabelDirective, typeof i4.GeboAITextDirective, typeof i5.GeboAILanguageResourcesDownloadComponent, typeof i6.GeboAILanguageChoiceComponent, typeof i7.GeboAIMainLanguageChoiceComponent, typeof i8.PButtonLabelTarget, typeof i8.PFieldSetLabelTarget, typeof i8.PPanelLabelTarget, typeof i8.PDialogLabelTarget, typeof i8.PSidebarLabelTarget, typeof i8.PCardLabelTarget, typeof i8.PTabPanelLabelTarget, typeof i8.PAccordionTabLabelTarget, typeof i8.PToolbarLabelTarget, typeof i8.PBadgeLabelTarget, typeof i8.PTagLabelTarget, typeof i8.PChipLabelTarget, typeof i8.PCheckboxLabelTarget, typeof i8.PRadioLabelTarget, typeof i8.PToggleLabelTarget, typeof i8.PInputTextLabelTarget, typeof i8.PInputTextareaLabelTarget, typeof i8.PInputNumberLabelTarget, typeof i8.PDropdownLabelTarget, typeof i8.PMultiSelectLabelTarget, typeof i8.PListboxLabelTarget, typeof i8.PCalendarLabelTarget, typeof i8.PSliderLabelTarget, typeof i8.PProgressBarLabelTarget, typeof i8.PStepsLabelTarget, typeof i8.PGalleriaLabelTarget, typeof i9.POldTabPanelLabelTarget], [typeof i10.CommonModule, typeof i11.ReactiveFormsModule, typeof i11.FormsModule, typeof i12.ButtonModule, typeof i13.SelectModule, typeof i14.PopoverModule], [typeof i1.GeboAIFieldContainerComponent, typeof i2.GeboAIFieldContainerDirective, typeof i3.GeboAILabelDirective, typeof i4.GeboAITextDirective, typeof i5.GeboAILanguageResourcesDownloadComponent, typeof i6.GeboAILanguageChoiceComponent, typeof i7.GeboAIMainLanguageChoiceComponent, typeof i8.PButtonLabelTarget, typeof i8.PFieldSetLabelTarget, typeof i8.PPanelLabelTarget, typeof i8.PDialogLabelTarget, typeof i8.PSidebarLabelTarget, typeof i8.PCardLabelTarget, typeof i8.PTabPanelLabelTarget, typeof i8.PAccordionTabLabelTarget, typeof i8.PToolbarLabelTarget, typeof i8.PBadgeLabelTarget, typeof i8.PTagLabelTarget, typeof i8.PChipLabelTarget, typeof i8.PCheckboxLabelTarget, typeof i8.PRadioLabelTarget, typeof i8.PToggleLabelTarget, typeof i8.PInputTextLabelTarget, typeof i8.PInputTextareaLabelTarget, typeof i8.PInputNumberLabelTarget, typeof i8.PDropdownLabelTarget, typeof i8.PMultiSelectLabelTarget, typeof i8.PListboxLabelTarget, typeof i8.PCalendarLabelTarget, typeof i8.PSliderLabelTarget, typeof i8.PProgressBarLabelTarget, typeof i8.PStepsLabelTarget, typeof i8.PGalleriaLabelTarget, typeof i9.POldTabPanelLabelTarget]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<GeboAIFieldTranslationContainerModule>;
}
//# sourceMappingURL=field-container.module.d.ts.map