import { AfterContentInit, ElementRef, OnInit } from "@angular/core";
import { GeboAITranslationService } from "./gebo-translation.service";
import { GeboAIFieldHost } from "../field-host-component-iface/field-host-component-iface";
import * as i0 from "@angular/core";
export declare class GeboAITextDirective implements AfterContentInit, OnInit {
    private el;
    private translationService;
    private moduleId?;
    private host?;
    private componentId;
    private existingTexts?;
    constructor(el: ElementRef<HTMLElement>, translationService: GeboAITranslationService, moduleId?: string | undefined, host?: GeboAIFieldHost | undefined);
    ngOnInit(): Promise<void>;
    ngAfterContentInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<GeboAITextDirective, [null, null, { optional: true; }, { optional: true; }]>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<GeboAITextDirective, "[gebo-ai-text]", never, {}, {}, never, never, false, never>;
}
