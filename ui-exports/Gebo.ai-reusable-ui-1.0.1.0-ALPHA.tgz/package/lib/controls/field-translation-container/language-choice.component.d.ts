import { OnInit } from "@angular/core";
import { GeboAITranslationService } from "./gebo-translation.service";
import { ControlValueAccessor, FormGroup } from "@angular/forms";
import * as i0 from "@angular/core";
export interface GeboLanguage {
    langCode: string;
    description: string;
}
export declare class GeboAILanguageChoiceComponent implements OnInit, ControlValueAccessor {
    private geboTranslationService;
    private currentLanguage;
    private languages;
    protected choosableLanguages: GeboLanguage[];
    protected formGroup: FormGroup;
    constructor(geboTranslationService: GeboAITranslationService);
    ngOnInit(): Promise<void>;
    writeValue(obj: any): void;
    private onChange;
    registerOnChange(fn: any): void;
    private onTouched;
    registerOnTouched(fn: any): void;
    setDisabledState?(isDisabled: boolean): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<GeboAILanguageChoiceComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<GeboAILanguageChoiceComponent, "gebo-ai-language-choice-component", never, {}, {}, never, never, false, never>;
}
