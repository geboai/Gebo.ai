import * as i0 from "@angular/core";
import * as i1 from "./vfilesystem-selector.component";
import * as i2 from "@angular/common";
import * as i3 from "@angular/forms";
import * as i4 from "primeng/treeselect";
import * as i5 from "primeng/tree";
import * as i6 from "primeng/dialog";
import * as i7 from "primeng/chip";
import * as i8 from "primeng/button";
import * as i9 from "primeng/blockui";
import * as i10 from "primeng/panel";
import * as i11 from "primeng/radiobutton";
import * as i12 from "primeng/checkbox";
import * as i13 from "primeng/fieldset";
import * as i14 from "../field-translation-container/field-container.module";
import * as i15 from "../../notifications/notifications.module";
export declare class VFilesystemSelectorModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<VFilesystemSelectorModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<VFilesystemSelectorModule, [typeof i1.VFilesystemSelectorComponent], [typeof i2.CommonModule, typeof i3.FormsModule, typeof i3.ReactiveFormsModule, typeof i4.TreeSelectModule, typeof i5.TreeModule, typeof i6.DialogModule, typeof i7.ChipModule, typeof i8.ButtonModule, typeof i9.BlockUIModule, typeof i10.PanelModule, typeof i11.RadioButtonModule, typeof i12.CheckboxModule, typeof i13.FieldsetModule, typeof i14.GeboAIFieldTranslationContainerModule, typeof i15.GeboAINotificationsModule], [typeof i1.VFilesystemSelectorComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<VFilesystemSelectorModule>;
}
