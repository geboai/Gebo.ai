/**
 * This Source Code is subject to the terms of the
 * Gebo.ai community version Mozilla Public License Version 2.0 (MPL-2.0) — With Data Protection Clauses
 * If a copy of the LICENCE was not distributed with this file, You can obtain one at
 * https://gebo.ai/gebo-ai-community-version-mozilla-public-license-version-2-0-mpl-2-0-with-data-protection-clauses/
 * and https://mozilla.org/MPL/2.0/.
 * Copyright (c) 2025+ Gebo.ai
 */
/**
 * AI generated comments
 *
 * This module provides a virtual filesystem selector component for Angular applications.
 * It allows users to browse and select files and folders from a virtual filesystem.
 */
import { ChangeDetectorRef, OnChanges, OnInit, SimpleChanges } from "@angular/core";
import { ControlValueAccessor, FormGroup } from "@angular/forms";
import { ToastMessageOptions, TreeNode } from "primeng/api";
import { TreeNodeExpandEvent, TreeNodeSelectEvent, TreeNodeUnSelectEvent } from "primeng/tree";
import { loadRootsObservableCallback, browsePathObservableCallback, VFilesystemReference, reconstructNavigationObservableCallback } from "./vfilesystem-types";
import * as i0 from "@angular/core";
/**
 * Extended interface for VFilesystemReference that includes UI selection state information
 * and a unique identifier for tree node management.
 */
interface EnrichedFilesystemReference extends VFilesystemReference {
    uniqueCode: string;
    selected: boolean;
    parentSelected: boolean;
}
/**
 * Component that provides a tree-based interface for selecting files and folders from a virtual filesystem.
 * Implements ControlValueAccessor for integration with Angular forms.
 */
export declare class VFilesystemSelectorComponent implements OnInit, OnChanges, ControlValueAccessor {
    private checkChanges;
    /**
     * Flag indicating whether the component is currently loading data
     */
    loading: boolean;
    /**
     * Whether the component should be in read-only mode
     */
    readonly: boolean;
    /**
     * Whether folders can be selected
     */
    canChooseFolders: boolean;
    /**
     * Whether files can be selected
     */
    canChooseFiles: boolean;
    /**
     * Observable callback for loading filesystem roots
     */
    loadRootsObservable: loadRootsObservableCallback;
    /**
     * Observable callback for browsing a path within the filesystem
     */
    browsePathObservable: browsePathObservableCallback;
    /**
     * Optional callback for reconstructing navigation paths
     */
    reconstructNavigationCallback?: reconstructNavigationObservableCallback;
    /**
     * Whether to allow single or multiple selection
     */
    selectionMode: "single" | "multiple";
    /**
     * Placeholder text for the selection input
     */
    placeholder: string;
    /**
     * The root nodes of the filesystem tree
     */
    roots: TreeNode<EnrichedFilesystemReference>[];
    /**
     * Currently selected filesystem references
     */
    internalValue: EnrichedFilesystemReference[];
    /**
     * Whether the edit dialog is open
     */
    openEditWindow: boolean;
    /**
     * References currently being edited in the dialog
     */
    editingNodeValues: EnrichedFilesystemReference[];
    /**
     * Toast messages to display to the user
     */
    messages: ToastMessageOptions[];
    /**
     * Flag to indicate whether tree consistency needs to be checked
     */
    private checkTreeConsistency;
    /**
     * Map of node unique codes to their tree nodes for quick lookup
     */
    private nodesMap;
    /**
     * Form group for the selection control
     */
    formGroup: FormGroup;
    /**
     * Creates an instance of the VFilesystemSelectorComponent
     * @param checkChanges - Angular's change detector reference for manual change detection
     */
    constructor(checkChanges: ChangeDetectorRef);
    /**
     * Adds a node to the lookup map
     * @param node - The node to add to the map
     */
    private addMap;
    /**
     * Returns CSS styles for a tree node based on its selection state
     * @param item - The tree node to style
     * @returns CSS style string
     */
    onlineStyle(item: TreeNode<EnrichedFilesystemReference>): string;
    /**
     * Determines whether to show a checkbox for a tree node
     * @param item - The tree node to check
     * @returns true if a checkbox should be shown, false otherwise
     */
    showCheckbox(item: TreeNode<EnrichedFilesystemReference>): boolean;
    /**
     * Determines whether to show a radio button for a tree node
     * @param item - The tree node to check
     * @returns true if a radio button should be shown, false otherwise
     */
    showRadio(item: TreeNode<EnrichedFilesystemReference>): boolean;
    /**
     * Opens the edit dialog with the current selection
     */
    openEditMode(): void;
    /**
     * Synchronizes the editing chips with the current form control value
     */
    private resyncEditingChips;
    /**
     * Maintains the selection state of all root nodes
     * @param roots - The root nodes to process
     * @returns An array of node IDs that should be removed from selection
     */
    private mantainSelected;
    /**
     * Maintains the selection state of a tree node and its children
     * @param root - The root node to process
     * @param selectionHierarchy - Whether the node is in a selection hierarchy
     * @returns An array of node IDs that should be removed from selection
     */
    private mantainTree;
    /**
     * Filters out success messages from the message array
     * @param m - The array of messages to filter
     * @returns An array of non-success messages
     */
    private removeSuccess;
    /**
     * Loads the navigation tree for a set of nodes
     * @param nodes - The nodes to load the navigation tree for
     */
    private loadNavigationStatusTree;
    /**
     * Reassigns the root nodes based on a navigation tree status
     * @param result - The navigation tree status to use
     */
    private reassignRoots;
    /**
     * Transforms child nodes into tree nodes
     * @param childs - The child nodes to transform
     * @param parentNode - The parent node
     * @returns An array of tree nodes
     */
    private transformChilds;
    /**
     * Checks if nodes are contained in the tree
     * @param nodes - The nodes to check
     * @returns true if all nodes are contained in the tree, false otherwise
     */
    private containedInTree;
    /**
     * Finds nodes that are not contained in the tree
     * @param roots - The root nodes to search in
     * @param matchingNodes - The nodes to check
     * @returns An array of nodes that are not in the tree
     */
    private containedInTreeNodes;
    /**
     * Angular lifecycle hook that initializes the component
     */
    ngOnInit(): void;
    /**
     * Angular lifecycle hook that responds to input changes
     * @param changes - The changes that occurred
     */
    ngOnChanges(changes: SimpleChanges): void;
    /**
     * ControlValueAccessor method that writes a value to the component
     * @param obj - The value to write
     */
    writeValue(obj: any): void;
    /**
     * Change handler function for ControlValueAccessor
     */
    onChange: (p: any) => void;
    /**
     * ControlValueAccessor method to register a change handler
     * @param fn - The function to call when the value changes
     */
    registerOnChange(fn: any): void;
    /**
     * Touch handler function for ControlValueAccessor
     */
    onTouched: (p: any) => void;
    /**
     * ControlValueAccessor method to register a touch handler
     * @param fn - The function to call when the control is touched
     */
    registerOnTouched(fn: any): void;
    /**
     * ControlValueAccessor method to set the disabled state
     * @param isDisabled - Whether the control should be disabled
     */
    setDisabledState?(isDisabled: boolean): void;
    /**
     * Loads the root nodes of the filesystem
     */
    loadRoots(): void;
    /**
     * Finds the root node of a tree node
     * @param item - The tree node to find the root of
     * @returns The root of the tree node
     */
    private findRoot;
    /**
     * Handles a node expand event
     * @param event - The expand event
     */
    nodeExpand(event: TreeNodeExpandEvent): void;
    /**
     * Handles a node select event
     * @param event - The select event
     */
    nodeSelect(event: TreeNodeSelectEvent): void;
    /**
     * Confirms the editing and updates the component value
     */
    confirmEditing(): void;
    /**
     * Handles a node unselect event
     * @param event - The unselect event
     */
    nodeUnselect(event: TreeNodeUnSelectEvent): void;
    /**
     * Handles a node collapse event
     * @param node - The node that was collapsed
     */
    nodeCollapse(node: any): void;
    /**
     * Removes an item from the main selection panel
     * @param item - The item to remove
     */
    removeFromMainPanel(item: EnrichedFilesystemReference): void;
    /**
     * Removes an item from the edit panel
     * @param item - The item to remove
     */
    removeFromEditPanel(item: EnrichedFilesystemReference): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<VFilesystemSelectorComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<VFilesystemSelectorComponent, "gebo-ai-vfilesystem-selector-component", never, { "readonly": { "alias": "readonly"; "required": false; }; "canChooseFolders": { "alias": "canChooseFolders"; "required": false; }; "canChooseFiles": { "alias": "canChooseFiles"; "required": false; }; "loadRootsObservable": { "alias": "loadRootsObservable"; "required": false; }; "browsePathObservable": { "alias": "browsePathObservable"; "required": false; }; "reconstructNavigationCallback": { "alias": "reconstructNavigationCallback"; "required": false; }; "selectionMode": { "alias": "selectionMode"; "required": false; }; "placeholder": { "alias": "placeholder"; "required": false; }; }, {}, never, never, false, never>;
}
export {};
