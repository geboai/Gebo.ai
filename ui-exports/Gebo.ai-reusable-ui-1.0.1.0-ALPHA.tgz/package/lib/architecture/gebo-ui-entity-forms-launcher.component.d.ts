/**
 * This Source Code is subject to the terms of the
 * Gebo.ai community version Mozilla Public License Version 2.0 (MPL-2.0) — With Data Protection Clauses
 * If a copy of the LICENCE was not distributed with this file, You can obtain one at
 * https://gebo.ai/gebo-ai-community-version-mozilla-public-license-version-2-0-mpl-2-0-with-data-protection-clauses/
 * and https://mozilla.org/MPL/2.0/.
 * Copyright (c) 2025+ Gebo.ai
 */
/**
 * AI generated comments
 *
 * This component serves as a launcher for entity forms in the Gebo UI.
 * It's responsible for retrieving entity form configurations from the
 * GeboUIEntityFormsLauncherService and making them available to the template.
 * The component is designed to be a centralized point for launching and
 * managing various entity forms within the application.
 */
import { AfterViewInit, EnvironmentInjector, Injector, OnInit, ViewContainerRef } from "@angular/core";
import * as i0 from "@angular/core";
export declare class GeboUIEntityFormsLauncherComponent implements OnInit, AfterViewInit {
    private injector;
    private environmentInjector;
    container: ViewContainerRef;
    /**
     * Stores the configurations obtained from the GeboUIEntityFormsLauncherService
     * These configurations define the entity forms that can be launched
     */
    private injectedConfigs;
    /**
     * Constructor that injects the Angular Injector
     * @param injector Angular's Injector service used to retrieve the GeboUIEntityFormsLauncherService
     */
    constructor(injector: Injector, environmentInjector: EnvironmentInjector);
    ngAfterViewInit(): void;
    /**
     * Lifecycle hook that initializes the component
     * Retrieves the current entity form configurations from the GeboUIEntityFormsLauncherService
     * and assigns them to injectedConfigs for use in the template
     */
    ngOnInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<GeboUIEntityFormsLauncherComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<GeboUIEntityFormsLauncherComponent, "gebo-ui-entities-forms-launcher-component", never, {}, {}, never, never, false, never>;
}
