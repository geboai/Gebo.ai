/**
 * This Source Code is subject to the terms of the
 * Gebo.ai community version Mozilla Public License Version 2.0 (MPL-2.0) — With Data Protection Clauses
 * If a copy of the LICENCE was not distributed with this file, You can obtain one at
 * https://gebo.ai/gebo-ai-community-version-mozilla-public-license-version-2-0-mpl-2-0-with-data-protection-clauses/
 * and https://mozilla.org/MPL/2.0/.
 * Copyright (c) 2025+ Gebo.ai
 */
import { OnInit } from '@angular/core';
import { UserInfo } from '@Gebo.ai/gebo-ai-rest-api';
import { MegaMenuItem } from 'primeng/api';
import { LoginService } from '../../infrastructure/login/login.service';
import { PrimeNG } from 'primeng/config';
import { GeboAITranslationService } from '../../controls/field-translation-container/gebo-translation.service';
import { ApplicationMenuProviderService } from './application-menu-provider.service';
import * as i0 from "@angular/core";
export declare class GeboAIDesktopComponent implements OnInit {
    private primengConfig;
    private loginService;
    private geboTranslationService;
    private applicationMenuProviderService?;
    version: string;
    userLogged: boolean;
    userInfo?: UserInfo;
    menuItems: MegaMenuItem[];
    private subscription?;
    constructor(primengConfig: PrimeNG, loginService: LoginService, geboTranslationService: GeboAITranslationService, applicationMenuProviderService?: ApplicationMenuProviderService | undefined);
    private loadUserAndMenu;
    ngOnInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<GeboAIDesktopComponent, [null, null, null, { optional: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<GeboAIDesktopComponent, "gebo-ai-desktop", never, { "version": { "alias": "version"; "required": false; }; }, {}, never, never, false, never>;
}
