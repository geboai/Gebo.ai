import { GeboUIEntityFormConfig } from "./gebo-ui-entity-form-config";
import * as i0 from "@angular/core";
/**
 * Injectable service that provides functionality for launching entity forms in the Gebo UI.
 * This is an abstract class that must be implemented by concrete services.
 * The service is provided at the root level so it's available throughout the application.
 */
export declare abstract class GeboUIEntityFormsLauncherService {
    /**
     * Gets the current entity form configurations available in the application.
     * Implementations should return all active form configurations that can be used.
     *
     * @returns An array of GeboUIEntityFormConfig objects representing available form configurations
     */
    abstract getCurrentConfigurations(): GeboUIEntityFormConfig[];
    static ɵfac: i0.ɵɵFactoryDeclaration<GeboUIEntityFormsLauncherService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<GeboUIEntityFormsLauncherService>;
}
export declare class GeboUIEntityFormsLauncherByInjectionService extends GeboUIEntityFormsLauncherService {
    private forms;
    constructor(forms: GeboUIEntityFormConfig[]);
    getCurrentConfigurations(): GeboUIEntityFormConfig[];
    static ɵfac: i0.ɵɵFactoryDeclaration<GeboUIEntityFormsLauncherByInjectionService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<GeboUIEntityFormsLauncherByInjectionService>;
}
