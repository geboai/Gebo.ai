import * as i0 from "@angular/core";
import * as i1 from "./gebo-ui-modal-opener.component";
import * as i2 from "./gebo-ui-modal-wrapper.component";
import * as i3 from "./gebo-ui-entity-forms-launcher.component";
import * as i4 from "./gebo-ui-modal.component";
import * as i5 from "@angular/common";
import * as i6 from "@angular/forms";
import * as i7 from "primeng/dialog";
import * as i8 from "primeng/button";
import * as i9 from "primeng/steps";
import * as i10 from "../notifications/notifications.module";
/**
 * @NgModule GeboUIArchitectureModule
 *
 * AI generated comments
 *
 * This module provides a comprehensive architecture for UI components focused on modals, forms, and entity management.
 * It bundles together components for opening and managing modals, launching entity forms, and handling form configurations.
 *
 * The module imports several Angular and PrimeNG modules for form handling, dialog management, and UI components:
 * - CommonModule: Angular's common directives and pipes
 * - ReactiveFormsModule & FormsModule: Angular's form handling modules
 * - DialogModule: PrimeNG's dialog component for modal windows
 * - ButtonModule: PrimeNG's button components
 * - StepsModule: PrimeNG's multi-step component
 *
 * It provides services for:
 * - Action routing (GeboUIActionRoutingService)
 * - Form group management (GeboFormGroupsService)
 *
 * And exports components for:
 * - Modal opening and management
 * - Entity form launching
 * - Modal display
 */
export declare class GeboUIArchitectureModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<GeboUIArchitectureModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<GeboUIArchitectureModule, [typeof i1.GeboUIModalOpenerComponent, typeof i2.GeboUIModalOpenerWrapperComponent, typeof i3.GeboUIEntityFormsLauncherComponent, typeof i4.GeboUIModalComponent], [typeof i5.CommonModule, typeof i6.ReactiveFormsModule, typeof i6.FormsModule, typeof i7.DialogModule, typeof i8.ButtonModule, typeof i9.StepsModule, typeof i10.GeboAINotificationsModule], [typeof i1.GeboUIModalOpenerComponent, typeof i3.GeboUIEntityFormsLauncherComponent, typeof i4.GeboUIModalComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<GeboUIArchitectureModule>;
}
