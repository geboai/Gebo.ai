import { ValidatorFn, Validators } from "@angular/forms";
export declare class GeboAIValidators extends Validators {
    static baseUrl(required: boolean): ValidatorFn;
}
//# sourceMappingURL=validation.d.ts.map