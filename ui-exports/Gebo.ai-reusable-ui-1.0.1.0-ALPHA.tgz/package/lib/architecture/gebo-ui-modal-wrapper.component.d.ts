/**
 * This Source Code is subject to the terms of the
 * Gebo.ai community version Mozilla Public License Version 2.0 (MPL-2.0) — With Data Protection Clauses
 * If a copy of the LICENCE was not distributed with this file, You can obtain one at
 * https://gebo.ai/gebo-ai-community-version-mozilla-public-license-version-2-0-mpl-2-0-with-data-protection-clauses/
 * and https://mozilla.org/MPL/2.0/.
 * Copyright (c) 2025+ Gebo.ai
 */
/**
 * AI generated comments
 *
 * This component serves as a wrapper for modals in the Gebo UI system. It dynamically loads components
 * inside a modal and manages their lifecycle and interactions. It also provides support for wizard-style
 * modal interfaces with step navigation.
 */
import { AfterViewInit, ElementRef, EventEmitter, OnChanges, OnDestroy, OnInit, SimpleChanges, Type } from "@angular/core";
import { GeboUIActionRoutingService } from "./gebo-ui-action-routing.service";
import { BaseEntityEditingComponent } from "../controls/base-entity-editing-component/base-entity-editing.component";
import { OpenedModals } from "./opened-modals";
import { GeboUIOutputForwardingService } from "./gebo-ui-output-forwarding.service";
import { MenuItem } from "primeng/api";
import { WizardButtonsBarData } from "../controls/base-entity-editing-component/entities-modification-wizard";
import { GeboAIRootNotificationService } from "../notifications/root-notification.service";
import * as i0 from "@angular/core";
export declare class GeboUIModalOpenerWrapperComponent implements OnChanges, OnInit, AfterViewInit, OnDestroy {
    private actionRouting;
    outForwardingService: GeboUIOutputForwardingService;
    private notificationService;
    /**
     * Reference to the container element where the dynamic component will be loaded
     */
    containerItem?: ElementRef<Element>;
    /**
     * Type of component that should be loaded inside the modal
     */
    componentType?: Type<BaseEntityEditingComponent<any>>;
    /**
     * Modal configuration data including entity and mode information
     */
    modal?: OpenedModals;
    /**
     * Event emitted when a new entity is created in the modal
     */
    createdNew: EventEmitter<any>;
    /**
     * Event emitted when an entity is updated in the modal
     */
    updated: EventEmitter<any>;
    /**
     * Event emitted when an entity is deleted in the modal
     */
    deleted: EventEmitter<boolean>;
    /**
     * Event emitted when the modal action is cancelled
     */
    cancelAction: EventEmitter<boolean>;
    /**
     * Collection of inputs to be passed to the dynamically loaded component
     */
    composedInputs: {
        [key: string]: any;
    };
    /**
     * Constructor initializes the action routing and output forwarding services
     */
    constructor(actionRouting: GeboUIActionRoutingService, outForwardingService: GeboUIOutputForwardingService, notificationService: GeboAIRootNotificationService);
    /**
     * Cleanup method called when component is destroyed
     */
    ngOnDestroy(): void;
    /**
     * Flag indicating if the modal is in wizard mode
     */
    isWizardMode: boolean;
    /**
     * Configuration data for the wizard buttons and steps
     */
    wizardButtonsBarData: WizardButtonsBarData | undefined;
    /**
     * Menu items representing the wizard steps
     */
    items: MenuItem[];
    /**
     * Initializes the wizard mode with the provided configuration
     * @param wizard The wizard configuration data
     */
    initializeWizardStatus(wizard: WizardButtonsBarData): void;
    /**
     * Keeps track of the current step index in wizard mode
     */
    private _index;
    /**
     * Gets the active index of the current wizard step
     */
    get activeIndex(): number;
    /**
     * Navigates to the next step in the wizard
     */
    goNext(): void;
    /**
     * Navigates to the previous step in the wizard
     */
    goPrev(): void;
    /**
     * Gets the icon for the previous step button
     */
    get previusStepIcon(): string;
    /**
     * Gets the icon for the next step button
     */
    get nextStepIcon(): string;
    /**
     * Gets the label for the previous step button
     */
    get previusStepLabel(): string;
    /**
     * Gets the label for the next step button
     */
    get nextStepLabel(): string;
    /**
     * Lifecycle hook called after the view has been initialized
     */
    ngAfterViewInit(): void;
    /**
     * Lifecycle hook called during component initialization
     * Registers this component with the output forwarding service
     */
    ngOnInit(): void;
    /**
     * Lifecycle hook called when component inputs change
     * Updates the composed inputs when the modal configuration changes
     * @param changes SimpleChanges object containing changes to inputs
     */
    ngOnChanges(changes: SimpleChanges): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<GeboUIModalOpenerWrapperComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<GeboUIModalOpenerWrapperComponent, "gebo-ui-modal-wrapper", never, { "componentType": { "alias": "componentType"; "required": false; }; "modal": { "alias": "modal"; "required": false; }; }, { "createdNew": "createdNew"; "updated": "updated"; "deleted": "deleted"; "cancelAction": "cancelAction"; }, never, never, false, never>;
}
