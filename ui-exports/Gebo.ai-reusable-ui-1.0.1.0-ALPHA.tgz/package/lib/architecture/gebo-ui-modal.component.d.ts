/**
 * This Source Code is subject to the terms of the
 * Gebo.ai community version Mozilla Public License Version 2.0 (MPL-2.0) — With Data Protection Clauses
 * If a copy of the LICENCE was not distributed with this file, You can obtain one at
 * https://gebo.ai/gebo-ai-community-version-mozilla-public-license-version-2-0-mpl-2-0-with-data-protection-clauses/
 * and https://mozilla.org/MPL/2.0/.
 * Copyright (c) 2025+ Gebo.ai
 */
import { EventEmitter } from "@angular/core";
import * as i0 from "@angular/core";
/**
 * A reusable modal dialog component for Angular applications.
 * This component provides a customizable modal overlay that can be shown or hidden.
 * AI generated comments
 */
export declare class GeboUIModalComponent {
    /** Flag indicating if this is a modal dialog (prevents clicking outside) */
    modal: boolean;
    /** Controls the visibility state of the modal */
    visible: boolean;
    /** Custom CSS styles for the modal */
    style: any;
    /** Text to display in the modal header */
    header: string;
    /** Event emitter that outputs the current visibility state */
    visibleOutput: EventEmitter<boolean>;
    /** Event emitter triggered when the modal is hidden */
    onHide: EventEmitter<any>;
    /** Two-way binding event emitter for the visible property */
    visibleChange: EventEmitter<boolean>;
    static ɵfac: i0.ɵɵFactoryDeclaration<GeboUIModalComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<GeboUIModalComponent, "gebo-ai-modal", never, { "modal": { "alias": "modal"; "required": false; }; "visible": { "alias": "visible"; "required": false; }; "style": { "alias": "style"; "required": false; }; "header": { "alias": "header"; "required": false; }; }, { "visibleOutput": "visible"; "onHide": "onHide"; "visibleChange": "visibleChange"; }, never, ["*"], false, never>;
}
//# sourceMappingURL=gebo-ui-modal.component.d.ts.map