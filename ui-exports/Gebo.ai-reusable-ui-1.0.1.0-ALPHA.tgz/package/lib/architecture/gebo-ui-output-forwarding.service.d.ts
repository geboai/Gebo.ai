/**
 * This Source Code is subject to the terms of the
 * Gebo.ai community version Mozilla Public License Version 2.0 (MPL-2.0) — With Data Protection Clauses
 * If a copy of the LICENCE was not distributed with this file, You can obtain one at
 * https://gebo.ai/gebo-ai-community-version-mozilla-public-license-version-2-0-mpl-2-0-with-data-protection-clauses/
 * and https://mozilla.org/MPL/2.0/.
 * Copyright (c) 2025+ Gebo.ai
 */
/**
 * AI generated comments
 *
 * This service manages communication between host components and guest components in modal dialogs.
 * It acts as a mediator that forwards events from guest components to host components, handling
 * subscriptions and cleanup to prevent memory leaks.
 */
import { EventEmitter } from "@angular/core";
import { Observable } from "rxjs";
import { GeboUIModalOpenerWrapperComponent } from "./gebo-ui-modal-wrapper.component";
import { WizardButtonsBarData } from "../controls/base-entity-editing-component/entities-modification-wizard";
import * as i0 from "@angular/core";
/**
 * Service responsible for forwarding events and managing communication between
 * modal components (guest) and their container/wrapper (host).
 * This facilitates data exchange and event propagation between components
 * that may not have direct parent-child relationships.
 */
export declare class GeboUIOutputForwardingService {
    /** Reference to the host component (modal wrapper) */
    private host?;
    /** Reference to the guest component with its event emitters and form validity observable */
    private guest?;
    /** Subscription for the createdNew event */
    private cNewSub?;
    /** Subscription for the updated event */
    private updatedSub?;
    /** Subscription for the deleted event */
    private deletedSub?;
    /** Subscription for the cancelAction event */
    private cancelActionSub?;
    /** Subscription for the form invalid state */
    private cancelInvalidSub?;
    /** Current form validity state */
    actualFormInvalid: boolean;
    /** Configuration data for wizard buttons */
    wizardButtonsBarData: WizardButtonsBarData | undefined;
    /**
     * Sets up event forwarding from guest to host by subscribing to guest events
     * and emitting corresponding events on the host when they occur.
     * This creates a bridge between the two components.
     */
    private registerGuestHostForward;
    /**
     * Cleans up all subscriptions to prevent memory leaks when
     * the guest-host connection is no longer needed.
     */
    private removeGuestHostForward;
    /**
     * Registers a host component with the service and sets up the event forwarding.
     * If wizard button data is available, it initializes the wizard status on the host.
     *
     * @param host The modal wrapper component to register as host
     */
    registerHost(host: GeboUIModalOpenerWrapperComponent): void;
    /**
     * Registers a guest component with the service and sets up event forwarding.
     * First removes any existing guest to prevent multiple subscriptions.
     * If wizard button data is provided, it initializes the wizard status on the host.
     *
     * @param guest The component with event emitters to register as guest
     * @param toBeNotified Optional wizard buttons configuration data
     */
    registerGuest(guest: {
        createdNew: EventEmitter<any>;
        updated: EventEmitter<any>;
        deleted: EventEmitter<boolean>;
        cancelAction: EventEmitter<boolean>;
        formInvalid: Observable<boolean>;
    }, toBeNotified?: WizardButtonsBarData): void;
    /**
     * Removes the host component and cleans up any event forwarding.
     */
    removeHost(): void;
    /**
     * Removes the guest component and cleans up any event forwarding.
     */
    removeGuest(): void;
    /**
     * Checks if a host component is currently registered.
     * @returns Boolean indicating whether a host is present
     */
    get hostIsPresent(): boolean;
    /**
     * Checks if a guest component is currently registered.
     * @returns Boolean indicating whether a guest is present
     */
    get guestIsPresent(): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<GeboUIOutputForwardingService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<GeboUIOutputForwardingService>;
}
//# sourceMappingURL=gebo-ui-output-forwarding.service.d.ts.map