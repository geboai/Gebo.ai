import { GeboUIActionRequestListener, GeboUIActionRequest } from "./actions.model";
import * as i0 from "@angular/core";
/**
 * Service responsible for managing UI action request routing within the application.
 * This acts as a centralized hub where UI action requests can be routed to the
 * appropriate listeners based on the targetType of the action.
 * The service maintains a registry of listeners and provides methods for registration,
 * removal, and action routing.
 */
export declare class GeboUIActionRoutingService {
    /**
     * Array of registered action request listeners
     */
    private listeners;
    /**
     * Registers a new action request listener to the service
     * @param listener The listener to be registered
     */
    registerListener(listener: GeboUIActionRequestListener): void;
    /**
     * Removes a specific listener from the service
     * @param listener The listener to be removed
     */
    removeListener(listener: GeboUIActionRequestListener): void;
    /**
     * Routes an action request to the appropriate listener based on targetType
     * @param action The action request to be routed
     * @returns boolean indicating whether the action was successfully handled
     */
    routeEvent(action: GeboUIActionRequest): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<GeboUIActionRoutingService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<GeboUIActionRoutingService>;
}
//# sourceMappingURL=gebo-ui-action-routing.service.d.ts.map