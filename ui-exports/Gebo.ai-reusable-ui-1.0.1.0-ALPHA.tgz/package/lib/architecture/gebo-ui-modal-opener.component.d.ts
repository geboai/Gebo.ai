/**
 * This Source Code is subject to the terms of the
 * Gebo.ai community version Mozilla Public License Version 2.0 (MPL-2.0) — With Data Protection Clauses
 * If a copy of the LICENCE was not distributed with this file, You can obtain one at
 * https://gebo.ai/gebo-ai-community-version-mozilla-public-license-version-2-0-mpl-2-0-with-data-protection-clauses/
 * and https://mozilla.org/MPL/2.0/.
 * Copyright (c) 2025+ Gebo.ai
 */
/**
 * AI generated comments
 *
 * This file implements a modal opener component within an Angular application.
 * It handles opening, displaying, and managing modal dialogs for different entity editing operations.
 */
import { EventEmitter, OnChanges, OnDestroy, OnInit, SimpleChanges, Type } from "@angular/core";
import { GeboUIActionRoutingService } from "./gebo-ui-action-routing.service";
import { GeboUIActionRequestListener, GeboUIActionRequest, GeboActionPerformedCallback } from "./actions.model";
import { BaseEntityEditingComponent } from "../controls/base-entity-editing-component/base-entity-editing.component";
import { OpenedModals } from "./opened-modals";
import * as i0 from "@angular/core";
/**
 * Component responsible for managing modals in the Gebo UI.
 *
 * This component listens for action requests and opens appropriate modals for entity creation,
 * editing, or viewing. It handles the lifecycle of modals and communicates results back through
 * event emitters and callbacks.
 *
 * The component implements multiple interfaces:
 * - GeboUIActionRequestListener: To receive and process action requests
 * - OnChanges: To respond to input property changes
 * - OnDestroy: For cleanup operations
 * - OnInit: For initialization logic
 */
export declare class GeboUIModalOpenerComponent implements GeboUIActionRequestListener, OnChanges, OnDestroy, OnInit {
    private actionRouting;
    /** Type of component to render in the modal */
    componentType?: Type<BaseEntityEditingComponent<any>>;
    /** Target entity type identifier */
    targetType?: string;
    /** Currently opened modal information */
    modal?: OpenedModals;
    /** Controls visibility of the modal */
    visible: boolean;
    /** Event emitted when a new entity is created */
    createdNew: EventEmitter<any>;
    /** Event emitted when an entity is updated */
    updated: EventEmitter<any>;
    /** Event emitted when an entity is deleted */
    deleted: EventEmitter<boolean>;
    /** Event emitted when a modal action is cancelled */
    cancelAction: EventEmitter<boolean>;
    /** Optional callback function that is invoked when actions are performed */
    actionPerformedCallback?: GeboActionPerformedCallback;
    /**
     * Constructor that injects the action routing service
     * @param actionRouting Service for registering and handling UI actions
     */
    constructor(actionRouting: GeboUIActionRoutingService);
    /**
     * Lifecycle hook that initializes the component.
     *
     * Registers this component with the action routing service and sets up
     * subscriptions to the various event emitters, forwarding events to the
     * actionPerformedCallback when provided.
     */
    ngOnInit(): void;
    /**
     * Lifecycle hook called when the component is being destroyed.
     * Unregisters this component from the action routing service.
     */
    ngOnDestroy(): void;
    /**
     * Lifecycle hook called when input properties change.
     * Currently doesn't implement any specific behavior.
     *
     * @param changes Object containing all the changed input properties
     */
    ngOnChanges(changes: SimpleChanges): void;
    /**
     * Closes the currently open modal and emits a cancel action event.
     *
     * @param modal The modal to close
     */
    closeModal(modal: OpenedModals): void;
    /**
     * Handles incoming action requests by opening appropriate modals.
     *
     * This method determines the modal mode (NEW, EDIT, or EDIT_OR_NEW) based on
     * the action type, sets up the modal inputs, and stores the callback function.
     *
     * @param action The action request to handle
     * @returns true if the action was handled, false otherwise
     */
    handleAction(action: GeboUIActionRequest): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<GeboUIModalOpenerComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<GeboUIModalOpenerComponent, "gebo-ui-modal-opener", never, { "componentType": { "alias": "componentType"; "required": false; }; "targetType": { "alias": "targetType"; "required": false; }; "actionPerformedCallback": { "alias": "actionPerformedCallback"; "required": false; }; }, { "createdNew": "createdNew"; "updated": "updated"; "deleted": "deleted"; "cancelAction": "cancelAction"; }, never, never, false, never>;
}
