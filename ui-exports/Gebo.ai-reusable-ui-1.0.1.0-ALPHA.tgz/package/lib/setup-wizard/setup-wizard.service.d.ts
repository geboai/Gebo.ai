/**
 * This Source Code is subject to the terms of the
 * Gebo.ai community version Mozilla Public License Version 2.0 (MPL-2.0) — With Data Protection Clauses
 * If a copy of the LICENCE was not distributed with this file, You can obtain one at
 * https://gebo.ai/gebo-ai-community-version-mozilla-public-license-version-2-0-mpl-2-0-with-data-protection-clauses/
 * and https://mozilla.org/MPL/2.0/.
 * Copyright (c) 2025+ Gebo.ai
 */
/**
 * AI generated comments
 * This file implements a service for managing setup wizard configurations in an Angular application.
 * It provides functionality to track the status of various setup steps, determine if mandatory configurations
 * are completed, and organize wizard sections in priority order.
 */
import { Injector } from "@angular/core";
import { SetupWizardItem, SetupWizardsSection } from "./setup-wizard-step";
import { Observable } from "rxjs";
import * as i0 from "@angular/core";
/**
 * Represents the overall status of the setup process.
 * - 'incomplete': Mandatory setups are missing
 * - 'complete': All mandatory setups are completed, but some optional setups are missing
 * - 'full': All setups are completed (mandatory and optional)
 */
export type SetupStatus = "incomplete" | "complete" | "full";
/**
 * Injectable service that manages setup wizard configurations and their statuses.
 * This service is responsible for:
 * - Ordering wizard sections by priority
 * - Initializing required service instances
 * - Determining the overall setup status
 * - Tracking completion of mandatory and optional setup steps
 */
export declare class SetupWizardService {
    private injector;
    private _configurations;
    /**
     * Initializes the SetupWizardService by organizing configurations in priority order
     * and resolving all required service instances.
     *
     * @param injector Angular injector to resolve service instances
     * @param configs Optional array of wizard section configurations
     */
    constructor(injector: Injector, configs?: SetupWizardsSection[]);
    /**
     * Gets the ordered list of configuration sections.
     *
     * @returns Array of setup wizard sections in priority order
     */
    get configurations(): SetupWizardsSection[];
    /**
     * Calculates the overall setup status based on the provided list of setup items.
     *
     * @param items Array of setup wizard items to evaluate
     * @returns Status of the setup process as 'incomplete', 'complete', or 'full'
     */
    calculateSetupStatus(items: SetupWizardItem[]): SetupStatus;
    /**
     * Retrieves the current setup status by getting the actual status of all items
     * and then calculating the overall status.
     *
     * @returns Observable that emits the current setup status
     */
    getSetupStatus(): Observable<SetupStatus>;
    /**
     * Retrieves the current status of all wizard items by checking if they are installed,
     * enabled, and completed.
     *
     * @returns Observable that emits an array of setup wizard items with their current status
     */
    getActualStatus(): Observable<SetupWizardItem[]>;
    /**
     * Checks if all mandatory configurations are properly set up.
     * A mandatory configuration is considered properly set if it is enabled and completed.
     *
     * @returns Observable that emits true if all mandatory configurations are set, false otherwise
     */
    getMandatoryConfigurationsAreSet(): Observable<boolean>;
    static ɵfac: i0.ɵɵFactoryDeclaration<SetupWizardService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<SetupWizardService>;
}
