import * as i0 from "@angular/core";
import * as i1 from "./setup-wizard-panel.component";
import * as i2 from "./setup-wizard-step";
import * as i3 from "@angular/common";
import * as i4 from "@angular/forms";
import * as i5 from "@angular/router";
import * as i6 from "primeng/panel";
import * as i7 from "primeng/blockui";
import * as i8 from "primeng/button";
import * as i9 from "../notifications/notifications.module";
import * as i10 from "primeng/breadcrumb";
import * as i11 from "../controls/field-translation-container/field-container.module";
import * as i12 from "primeng/dialog";
import * as i13 from "primeng/tabview";
/**
 * The SetupWizardPanelModule encapsulates all required elements for the setup wizard
 * functionality in the application.
 *
 * Imports:
 * - CommonModule: For common Angular directives
 * - ReactiveFormsModule/FormsModule: For form handling
 * - RouterModule: For navigation within the wizard
 * - PrimNG modules: For UI components (panels, buttons, messages, etc.)
 *
 * Components:
 * - SetupWizardPanelComponent: Main panel for the wizard
 * - WizardSectionWithNoUI: Support component for wizard sections without UI
 *
 * Services:
 * - AlwaysTrueStatusService: Service that always returns true for status checks
 * - SetupWizardService: Main service managing the wizard workflow
 */
export declare class SetupWizardPanelModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<SetupWizardPanelModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<SetupWizardPanelModule, [typeof i1.SetupWizardPanelComponent, typeof i2.WizardSectionWithNoUI], [typeof i3.CommonModule, typeof i4.ReactiveFormsModule, typeof i4.FormsModule, typeof i5.RouterModule, typeof i6.PanelModule, typeof i7.BlockUIModule, typeof i8.ButtonModule, typeof i9.GeboAINotificationsModule, typeof i10.BreadcrumbModule, typeof i11.GeboAIFieldTranslationContainerModule, typeof i12.DialogModule, typeof i13.TabViewModule], [typeof i1.SetupWizardPanelComponent, typeof i2.WizardSectionWithNoUI]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<SetupWizardPanelModule>;
}
