import { SetupWizardPanelComponent } from "./setup-wizard-panel.component";
import * as i0 from "@angular/core";
/**
 * AI generated comments
 *
 * Service responsible for facilitating communication with the SetupWizardPanel component.
 * This injectable service acts as a bridge between different components that need to
 * interact with the setup wizard panel, allowing them to control the wizard without
 * direct reference to the panel component.
 */
export declare class SetupWizardComunicationService {
    /**
     * Reference to the SetupWizardPanelComponent instance.
     * This is set via the setWizardPanel method and used to control the wizard.
     */
    private setupWizardPanelComponent?;
    /**
     * Initializes a new instance of the SetupWizardComunicationService.
     */
    constructor();
    /**
     * Sets the reference to the SetupWizardPanelComponent.
     * This method should be called by the panel component itself during initialization
     * to register with the communication service.
     *
     * @param setupWizardPanelComponent The panel component instance to be controlled
     */
    setWizardPanel(setupWizardPanelComponent: SetupWizardPanelComponent): void;
    /**
     * Closes the wizard panel if a reference to it exists.
     * This method can be called by any component that has access to this service
     * without needing direct access to the panel component.
     */
    closeWizard(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<SetupWizardComunicationService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<SetupWizardComunicationService>;
}
//# sourceMappingURL=setup-wizard-comunication.service.d.ts.map