/**
 * This Source Code is subject to the terms of the
 * Gebo.ai community version Mozilla Public License Version 2.0 (MPL-2.0) — With Data Protection Clauses
 * If a copy of the LICENCE was not distributed with this file, You can obtain one at
 * https://gebo.ai/gebo-ai-community-version-mozilla-public-license-version-2-0-mpl-2-0-with-data-protection-clauses/
 * and https://mozilla.org/MPL/2.0/.
 * Copyright (c) 2025+ Gebo.ai
 */
import { EventEmitter, OnChanges, OnInit, SimpleChanges, Type } from "@angular/core";
import { SetupWizardItem } from "./setup-wizard-step";
import { SetupStatus, SetupWizardService } from "./setup-wizard.service";
import { BaseWizardSectionComponent } from "./base-wizard-section.component";
import { SetupWizardComunicationService } from "./setup-wizard-comunication.service";
import { MenuItem, ToastMessageOptions } from "primeng/api";
import { GeboAITranslationService } from "../controls/field-translation-container/gebo-translation.service";
import * as i0 from "@angular/core";
interface MandatoryUIEntry {
    config: SetupWizardItem;
    wizardComponent: Type<BaseWizardSectionComponent>;
}
/**
 * Component that renders a wizard panel to guide users through a sequence of setup steps.
 * This component manages the navigation, state, and validation of a multi-step setup process.
 * It communicates with services to track setup status and displays appropriate messages to the user.
 */
export declare class SetupWizardPanelComponent implements OnInit, OnChanges {
    private setupWizardService;
    private setupWizardComunicationService;
    private geboLanguageService;
    /** Flag indicating if data is being loaded */
    loading: boolean;
    /** Collection of messages to be displayed to the user */
    userMessages: ToastMessageOptions[];
    /** List of all wizard steps available to the user */
    wizardsEntries: SetupWizardItem[];
    /** List of mandatory unsatisfied wizard steps to display in a popup */
    mandatoryUnsatisfiedEntries: MandatoryUIEntry[];
    mandatoryUnsatisfiedEntriesWindowOpened: boolean;
    userShowedMandatoryUnsatisfiedEntries: boolean;
    popupOnMandatoryUnsatisfiedEntriesExisting: boolean;
    /** Currently selected wizard item */
    actualItem?: SetupWizardItem;
    /** Component type for the currently active wizard section */
    wizardComponent?: Type<BaseWizardSectionComponent>;
    /** Current overall setup status */
    actualSetupStatus?: SetupStatus;
    /** Breadcrumb navigation items */
    bcItems: MenuItem[];
    /** Home breadcrumb item with navigation back to main wizard */
    home: MenuItem;
    /** Title to display for the wizard panel */
    title: string;
    /** ID of the step to display initially */
    stepId?: string;
    /** Event emitter for notifying parent components about setup status changes */
    setupStatusRefresh: EventEmitter<SetupStatus>;
    /**
     * Constructor initializes required services for the wizard panel
     * @param setupWizardService Service for managing the setup workflow and state
     * @param setupWizardComunicationService Service for communication between wizard components
     * @param messagesService Service for displaying toast messages
     */
    constructor(setupWizardService: SetupWizardService, setupWizardComunicationService: SetupWizardComunicationService, geboLanguageService: GeboAITranslationService);
    private actualLanguage;
    private subscription?;
    /**
     * Reloads the current setup status from the service and updates the UI accordingly.
     * Sets appropriate messages based on completion status.
     */
    reloadStatus(): void;
    /**
     * Navigates to a specific step in the setup wizard by its ID
     * @param step The ID of the step to view, undefined will return to the main wizard view
     */
    private viewSelectedStep;
    /**
     * Angular lifecycle hook that initializes the component and loads initial data
     */
    ngOnInit(): void;
    /**
     * Angular lifecycle hook that responds to changes in @Input properties
     * @param changes Object containing the changed properties
     */
    ngOnChanges(changes: SimpleChanges): void;
    /**
     * Checks if all required preconditions are met before allowing a step to be opened
     * @param item The wizard step item to check preconditions for
     * @returns Object with precondition status and any warning messages
     */
    private preconditionsCheck;
    /**
     * Opens a specific wizard step if all preconditions are met
     * @param item The wizard step item to open
     */
    openWizard(item: SetupWizardItem): void;
    /**
     * Closes the current wizard step and returns to the main wizard view
     */
    closeWizard(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<SetupWizardPanelComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SetupWizardPanelComponent, "gebo-setup-wizard-panel-component", never, { "popupOnMandatoryUnsatisfiedEntriesExisting": { "alias": "popupOnMandatoryUnsatisfiedEntriesExisting"; "required": false; }; "title": { "alias": "title"; "required": false; }; "stepId": { "alias": "stepId"; "required": false; }; }, { "setupStatusRefresh": "setupStatusRefresh"; }, never, never, false, never>;
}
export {};
//# sourceMappingURL=setup-wizard-panel.component.d.ts.map