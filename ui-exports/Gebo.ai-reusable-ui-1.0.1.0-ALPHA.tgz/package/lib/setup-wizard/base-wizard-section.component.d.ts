/**
 * This Source Code is subject to the terms of the
 * Gebo.ai community version Mozilla Public License Version 2.0 (MPL-2.0) — With Data Protection Clauses
 * If a copy of the LICENCE was not distributed with this file, You can obtain one at
 * https://gebo.ai/gebo-ai-community-version-mozilla-public-license-version-2-0-mpl-2-0-with-data-protection-clauses/
 * and https://mozilla.org/MPL/2.0/.
 * Copyright (c) 2025+ Gebo.ai
 */
import { OnChanges, OnInit, SimpleChanges } from "@angular/core";
import { SetupWizardComunicationService } from "./setup-wizard-comunication.service";
import { ToastMessageOptions } from "primeng/api";
import * as i0 from "@angular/core";
/**
 * AI generated comments
 * This directive serves as a base class for wizard section components in a setup wizard.
 * It implements common functionality such as data loading, user message handling, and
 * loading state management. All specific wizard sections should extend this class and
 * implement the required abstract methods.
 */
export declare abstract class BaseWizardSectionComponent implements OnInit, OnChanges {
    private setupWizardComunicationService;
    /**
     * Abstract method that must be implemented by subclasses to load or refresh
     * their specific data.
     */
    abstract reloadData(): void;
    /**
     * Array to store toast messages that will be displayed to the user
     * during the wizard flow.
     */
    userMessages: ToastMessageOptions[];
    /**
     * Flag indicating whether data is currently being loaded.
     * Used to show loading indicators.
     */
    loading: boolean;
    /**
     * Flag indicating whether the setup process for this section has been completed.
     */
    isSetupCompleted: boolean;
    /**
     * Constructs the BaseWizardSectionComponent.
     * @param setupWizardComunicationService Service for communication between wizard components
     */
    constructor(setupWizardComunicationService: SetupWizardComunicationService);
    /**
     * Lifecycle hook that is called after component initialization.
     * Calls reloadData to initialize the component with data.
     */
    ngOnInit(): void;
    /**
     * Lifecycle hook that is called when any component input properties change.
     * Can be overridden by subclasses to react to input changes.
     * @param changes Object containing the changed properties
     */
    ngOnChanges(changes: SimpleChanges): void;
    /**
     * Closes the wizard by communicating with the setup wizard service.
     * This method can be called when the user wants to exit the wizard.
     */
    closeWizard(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<BaseWizardSectionComponent, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<BaseWizardSectionComponent, never, never, {}, {}, never, never, true, never>;
}
