import { ModuleWithProviders } from "@angular/core";
import * as i0 from "@angular/core";
import * as i1 from "@angular/common";
/**
 * AI generated comments
 *
 * This is the main module for Gebo AI functionality. It provides services for
 * module configuration, project endpoints, and knowledge base administration.
 * The module uses Angular's modular architecture to expose services that can be
 * consumed by other parts of the application.
 */
export declare class GeboAIModulesModule {
    /**
     * Static method that provides the module with its required providers.
     * This follows the Angular pattern for feature modules that need to be imported
     * only once in the application. The forRoot pattern ensures singleton services.
     *
     * @returns ModuleWithProviders configuration for the GeboAIModulesModule
     */
    static forRoot(): ModuleWithProviders<GeboAIModulesModule>;
    static ɵfac: i0.ɵɵFactoryDeclaration<GeboAIModulesModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<GeboAIModulesModule, never, [typeof i1.CommonModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<GeboAIModulesModule>;
}
