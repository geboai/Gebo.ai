/**
 * This Source Code is subject to the terms of the
 * Gebo.ai community version Mozilla Public License Version 2.0 (MPL-2.0) — With Data Protection Clauses
 * If a copy of the LICENCE was not distributed with this file, You can obtain one at
 * https://gebo.ai/gebo-ai-community-version-mozilla-public-license-version-2-0-mpl-2-0-with-data-protection-clauses/
 * and https://mozilla.org/MPL/2.0/.
 * Copyright (c) 2025+ Gebo.ai
 */
/**
 * @file GeboAIPluggableModulesConfigService.ts
 * @description Defines the core services and interfaces for Gebo.ai's pluggable modules architecture.
 * AI generated comments
 */
import { InjectionToken, Injector, Type } from "@angular/core";
import { GeboModuleInfo, GeboModulesConfigControllerService, GProject } from "@Gebo.ai/gebo-ai-rest-api";
import { Observable } from "rxjs";
import { GeboAIEntitiesSettingWizardConfiguration } from "../controls/base-entity-editing-component/entities-modification-wizard";
import { GeboActionPerformedCallback, GeboUIActionRequest, GeboWizardActionPerformedCallback } from "../architecture/actions.model";
import * as i0 from "@angular/core";
/**
 * Injection token for providing pluggable module UI configuration.
 * Used to inject module configurations into services.
 */
export declare const GEBO_AI_PLUGGABLE_MODULE_UI_CONFIG: InjectionToken<unknown>;
/**
 * Interface representing a map of enabled modules where the key is the module ID
 * and the value indicates whether the module is enabled.
 */
export interface GeboAIEnabledModulesMap {
    [key: string]: boolean;
}
/**
 * Interface defining the service contract for pluggable project endpoint modules.
 * Provides methods for finding endpoints by project and creating actions.
 */
export interface GeboAIPluggableProjectEndpointModuleService {
    /**
     * Finds endpoints associated with a specific project by its code
     * @param code The project code to search for
     * @returns Observable of endpoint details
     */
    findByProjectEndpoints(code: string): Observable<{
        code?: string;
        description?: string;
        parentProjectCode?: string;
    }[]>;
    /**
     * Creates an action request for a specific project
     * @param project The project to create an action for
     * @param wizardStepsConfigurations Optional wizard configurations
     * @param actualWizardStepConfigrationId Optional current wizard step ID
     * @returns Action request configuration
     */
    byProjectCreateAction(project: GProject, wizardStepsConfigurations?: GeboAIEntitiesSettingWizardConfiguration[], actualWizardStepConfigrationId?: string): GeboUIActionRequest;
}
/**
 * Interface defining the structure of a pluggable project endpoint module.
 * Contains metadata about the module and a reference to its service implementation.
 */
export interface GeboAIPluggableProjectEndpointModule {
    moduleId: string;
    projecteEndpointClassName: string;
    addProjectEndpointicon: string;
    addProjectEndpointLabel: string;
    addProjectEndpointTitle: string;
    service: Type<GeboAIPluggableProjectEndpointModuleService>;
}
/*****************************************************************************************************
 * Global Gebo.ai UI configuration info with pluggable modules/knowledge base components dynamic infos
 */
export interface GeboAIEnabledModulesConfig {
    installedModulesList: GeboModuleInfo[];
    pluggableProjecteEndpointsModules: GeboAIPluggableProjectEndpointModule[];
    configMap: GeboAIEnabledModulesMap;
}
/**
 * Interface for UI project endpoint options displayed in the knowledge base editor.
 * Provides metadata and actions for each endpoint type.
 */
export interface GeboAIUIProjectEndpointOption {
    projecteEndpointClassName: string;
    addProjectEndpointicon?: string;
    addProjectEndpointLabel: string;
    addProjectEndpointTitle: string;
    actionRequestByProject: (project: GProject, wizardStepsConfigurations?: GeboAIEntitiesSettingWizardConfiguration[], actualWizardStepConfigrationId?: string) => GeboUIActionRequest;
}
/****
 * Service to expose list of installed modules (standard/custom or other nature)
 * their hooks to UI knowledge base browser
 */
export declare class GeboAIPluggableModulesConfigService {
    private geboModulesConfigService;
    private static modules?;
    private modulesConfiguration;
    /**
     * Initializes the pluggable modules configuration service.
     * Fetches all available modules and filters for enabled ones.
     *
     * @param modulesConfiguration Array of pluggable project endpoint module configurations
     * @param geboModulesConfigService Service for accessing module configurations from the backend
     */
    constructor(geboModulesConfigService: GeboModulesConfigControllerService);
    /**
     * Retrieves the current modules configuration.
     * @returns The current enabled modules configuration or undefined if not loaded
     */
    getConfig(): GeboAIEnabledModulesConfig | undefined;
    static ɵfac: i0.ɵɵFactoryDeclaration<GeboAIPluggableModulesConfigService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<GeboAIPluggableModulesConfigService>;
}
/**
 * Service that handles the integration of pluggable project endpoints.
 * Manages the loading, discovery, and configuration of project endpoints from various modules.
 */
export declare class GeboAIPluggableProjectEndpointsService {
    private injector;
    private configService;
    private pluggableUIProjectEndpointServices;
    private classNames;
    private modules;
    /**
     * Initializes the pluggable project endpoints service.
     *
     * @param injector Angular injector for dynamically resolving service instances
     * @param configService Service providing module configuration
     */
    constructor(injector: Injector, configService: GeboAIPluggableModulesConfigService);
    /**
     * Initializes the service structures if they haven't been loaded yet.
     * Loads available modules and their services using the injector.
     */
    private preloadStructures;
    /***
     * Given a project returns the list of data sources exposed by Gebo.ai software modules (standard or custom)
     *
     * @param projectCode The code of the project to find endpoints for
     * @returns Observable of endpoint data with class name and icon information
     */
    findByProjectEndpoints(projectCode: string): Observable<{
        code?: string;
        description?: string;
        parentProjectCode?: string;
        className: string;
        icon: string;
    }[]>;
    /***
     * exports the set of addable data sources in knowledge base editing UI
     *
     * @param project The project to get endpoint options for
     * @param onActionPerformed Callback for when an action is performed
     * @param onWizardActionPerformed Callback for when a wizard action is performed
     * @param wizardStepsConfigurations Optional wizard configurations
     * @param actualWizardStepConfigrationId Optional current wizard step ID
     * @returns Array of UI project endpoint options
     */
    getUIProjectEndpointAddOptions(project: GProject, onActionPerformed?: GeboActionPerformedCallback, onWizardActionPerformed?: GeboWizardActionPerformedCallback, wizardStepsConfigurations?: GeboAIEntitiesSettingWizardConfiguration[], actualWizardStepConfigrationId?: string): GeboAIUIProjectEndpointOption[];
    static ɵfac: i0.ɵɵFactoryDeclaration<GeboAIPluggableProjectEndpointsService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<GeboAIPluggableProjectEndpointsService>;
}
