/**
 * This Source Code is subject to the terms of the
 * Gebo.ai community version Mozilla Public License Version 2.0 (MPL-2.0) — With Data Protection Clauses
 * If a copy of the LICENCE was not distributed with this file, You can obtain one at
 * https://gebo.ai/gebo-ai-community-version-mozilla-public-license-version-2-0-mpl-2-0-with-data-protection-clauses/
 * and https://mozilla.org/MPL/2.0/.
 * Copyright (c) 2025+ Gebo.ai
 */
import { GKnowledgeBase, GProject, KnowledgeBaseControllerService, ProjectsControllerService, VDocumentInfo, VFolderInfo } from "@Gebo.ai/gebo-ai-rest-api";
import { Observable } from "rxjs";
import { EnrichedChild, EnrichedVFilesystemItem } from "./enriched-child";
import { MenuItem } from "primeng/api";
import { GeboAIModulesService } from "./gebo-ai-modules.service";
import { GeboAIPluggableProjectEndpointsService } from "./pluggable-project-endpoint";
import { GeboActionPerformedEvent, GeboUIActionRequest } from "../architecture/actions.model";
import { GeboAIEntitiesSettingWizardConfiguration } from "../controls/base-entity-editing-component/entities-modification-wizard";
import { GeboAITranslationService } from "../controls/field-translation-container/gebo-translation.service";
import * as i0 from "@angular/core";
/**
 * AI generated comments
 * This service provides functionality for navigating and managing knowledge bases, projects, and their endpoints
 * in a tree structure. It handles loading different levels of the knowledge hierarchy, from knowledge bases down to
 * virtual files and folders, and generates context menus for adding new items to projects.
 */
export declare class GeboAIPluggableKnowledgeAdminBaseTreeSearchService {
    private modulesService;
    private knowledgeBaseService;
    private projectService;
    private geboTranslationService;
    private endpointsService;
    /**
     * Initializes the service with required dependencies to access knowledge bases, projects,
     * and project endpoints.
     *
     * @param modulesService Service that provides configuration and module information
     * @param knowledgeBaseService Service for accessing knowledge base data
     * @param projectService Service for managing projects
     * @param endpointsService Service for managing project endpoints
     */
    constructor(modulesService: GeboAIModulesService, knowledgeBaseService: KnowledgeBaseControllerService, projectService: ProjectsControllerService, geboTranslationService: GeboAITranslationService, endpointsService: GeboAIPluggableProjectEndpointsService);
    /**
     * Retrieves all knowledge bases and transforms them into enriched child objects
     * that can be displayed in the tree structure.
     *
     * @returns Observable of enriched knowledge base objects
     */
    loadKnowledgeBases(): Observable<EnrichedChild[]>;
    /**
     * Loads the child projects belonging to a specific knowledge base.
     *
     * @param knowledgebase The knowledge base to retrieve child projects for
     * @returns Observable of enriched project objects that are children of the knowledge base
     */
    loadKnowledgeChilds(knowledgebase: GKnowledgeBase): Observable<EnrichedChild[]>;
    /**
     * Loads both child projects and project endpoints for a given project.
     * Combines the results from multiple services to create a comprehensive list
     * of all children elements.
     *
     * @param project The project to retrieve children for
     * @returns Observable of enriched child objects that are direct descendants of the project
     */
    loadProjectChilds(project: GProject): Observable<EnrichedChild[]>;
    /**
     * Loads root-level virtual folders and documents for a project endpoint.
     * Combines folder and document lists into a single collection of enriched
     * filesystem items.
     *
     * @param item The project endpoint to retrieve root folders and documents for
     * @returns Observable of enriched virtual filesystem items (folders and documents)
     */
    loadRootProjectEndpointChilds(item: EnrichedChild): Observable<(EnrichedVFilesystemItem<VFolderInfo> | EnrichedVFilesystemItem<VDocumentInfo>)[]>;
    /**
     * Loads child folders and documents within a virtual folder.
     * Similar to the root loading function but operates on nested folders.
     *
     * @param item The virtual folder to retrieve children for
     * @returns Observable of enriched virtual filesystem items (folders and documents)
     */
    loadNestedProjectEndpointChilds(item: EnrichedVFilesystemItem<VFolderInfo>): Observable<(EnrichedVFilesystemItem<VFolderInfo> | EnrichedVFilesystemItem<VDocumentInfo>)[]>;
    /**
     * Generates context menu items for adding subprojects or project endpoints to a project.
     * Based on provided configuration, creates a list of menu items with appropriate handlers.
     *
     * @param subProjectAddEnabled Flag indicating if adding subprojects is allowed
     * @param data The project to add items to
     * @param actionConsumer Function that handles action requests
     * @param actionsCallback Callback function for action completion events
     * @param wizardStepsConfigurations Optional configuration for wizard steps
     * @param actualWizardStepConfigrationId Optional ID of the current wizard step
     * @returns Array of menu items for adding content to a project
     */
    generateAddToProjectMenuEnglish(subProjectAddEnabled: boolean, data: GProject, actionConsumer: (action: GeboUIActionRequest) => void, actionsCallback: (event: GeboActionPerformedEvent) => void, wizardStepsConfigurations?: GeboAIEntitiesSettingWizardConfiguration[], actualWizardStepConfigrationId?: string): MenuItem[];
    generateAddToProjectMenu(subProjectAddEnabled: boolean, data: GProject, actionConsumer: (action: GeboUIActionRequest) => void, actionsCallback: (event: GeboActionPerformedEvent) => void, wizardStepsConfigurations?: GeboAIEntitiesSettingWizardConfiguration[], actualWizardStepConfigrationId?: string): Observable<MenuItem[]>;
    static ɵfac: i0.ɵɵFactoryDeclaration<GeboAIPluggableKnowledgeAdminBaseTreeSearchService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<GeboAIPluggableKnowledgeAdminBaseTreeSearchService>;
}
