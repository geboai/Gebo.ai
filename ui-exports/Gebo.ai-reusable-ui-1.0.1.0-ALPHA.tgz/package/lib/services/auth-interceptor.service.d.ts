import { HttpRequest, HttpHandler, HttpEvent, HttpInterceptor } from '@angular/common/http';
import { Observable } from 'rxjs';
import { ActivatedRoute, Router } from '@angular/router';
import { ConfirmationService } from 'primeng/api';
import { GeboBackendListService } from './gebo-backends-list.service';
import * as i0 from "@angular/core";
export declare class AuthInterceptor implements HttpInterceptor {
    private router;
    private actualRoute;
    private confirmService;
    private geboBackendUrlsService;
    private basePath;
    constructor(router: Router, actualRoute: ActivatedRoute, confirmService: ConfirmationService, geboBackendUrlsService: GeboBackendListService, basePath: string);
    intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>>;
    static ɵfac: i0.ɵɵFactoryDeclaration<AuthInterceptor, [null, null, null, null, { optional: true; }]>;
    static ɵprov: i0.ɵɵInjectableDeclaration<AuthInterceptor>;
}
//# sourceMappingURL=auth-interceptor.service.d.ts.map