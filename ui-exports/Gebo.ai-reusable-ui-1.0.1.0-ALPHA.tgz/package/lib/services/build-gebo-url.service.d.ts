import * as i0 from "@angular/core";
export declare class GeboAIBuildUrlService {
    private baseUrl;
    constructor(baseUrl: string);
    buildUrl(...segments: string[]): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<GeboAIBuildUrlService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<GeboAIBuildUrlService>;
}
