import * as i0 from "@angular/core";
import * as i1 from "@angular/common";
/**
 * This module provides file type detection and management capabilities for the application.
 * It imports the CommonModule for access to Angular's common directives and pipes.
 * It registers the GeboAIFileTypeService as a provider, making it available for dependency
 * injection throughout the application.
 *
 * AI generated comments
 */
export declare class GeboAIFileTypesModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<GeboAIFileTypesModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<GeboAIFileTypesModule, never, [typeof i1.CommonModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<GeboAIFileTypesModule>;
}
//# sourceMappingURL=filetypes.module.d.ts.map