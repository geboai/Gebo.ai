/**
 * Interface representing a message received from the Gebo Chat API.
 * Messages can contain different types of content and indicate if they're the last in a sequence.
 */
export interface IGeboChatMessage {
    content?: any;
    contentObjectType?: string;
    lastMessage?: boolean;
}
