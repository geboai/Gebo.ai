import { IGeboChatMessage } from "./gebo-chat-message";
export declare class GeboAIBaseStreamingService {
    /**
         * Core implementation of the streaming chat functionality.
         * Uses the Fetch API with streaming to process server-sent events in real-time.
         *
         * @param apiUrl - The endpoint URL to connect to
         * @param request - The chat request to send
         * @param onMessage - Callback function for handling received messages
         * @param onError - Optional callback function for handling errors
         */
    protected internalStreamChat(apiUrl: string, request: any, onMessage: (msg: IGeboChatMessage | string) => void, onError?: (err: any) => void, onComplete?: () => void): void;
}
