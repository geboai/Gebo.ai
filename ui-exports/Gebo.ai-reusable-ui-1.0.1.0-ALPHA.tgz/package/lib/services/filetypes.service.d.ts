import { IngestionFileTypesLibraryControllerService } from "@Gebo.ai/gebo-ai-rest-api";
import { Observable } from "rxjs";
import * as i0 from "@angular/core";
/**
 * AI generated comments
 * Interface representing a file type in the Gebo.ai system.
 * Defines the structure for file type information with a code identifier,
 * description, and optional treatAs property to indicate how the file should be processed.
 */
export interface GeboAIFileType {
    code: string;
    description: string;
    treatAs?: string;
}
/**
 * Service responsible for managing and retrieving file types in the Gebo.ai application.
 * This service caches file types after the first retrieval to improve performance
 * on subsequent calls. It transforms the API response into a simplified GeboAIFileType format.
 */
export declare class GeboAIFileTypeService {
    private filetypesControllerService;
    /**
     * Static cache of file types to avoid redundant API calls
     */
    private static types;
    /**
     * Initializes the file type service with the controller service for API access
     * @param filetypesControllerService Service used to make API requests for file types
     */
    constructor(filetypesControllerService: IngestionFileTypesLibraryControllerService);
    /**
     * Retrieves all available file types, either from cache or from the API.
     * On first call, it fetches data from the API, processes it to extract individual
     * file extensions, and populates the cache. Subsequent calls return the cached data.
     *
     * @returns Observable emitting an array of GeboAIFileType objects
     */
    getAllFileTypes(): Observable<GeboAIFileType[]>;
    static ɵfac: i0.ɵɵFactoryDeclaration<GeboAIFileTypeService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<GeboAIFileTypeService>;
}
//# sourceMappingURL=filetypes.service.d.ts.map