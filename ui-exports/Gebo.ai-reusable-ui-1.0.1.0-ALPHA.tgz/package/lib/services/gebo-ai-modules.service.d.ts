import { GeboModulesConfigControllerService } from "@Gebo.ai/gebo-ai-rest-api";
import * as i0 from "@angular/core";
/**
 * AI generated comments
 * Constants representing the module IDs used throughout the system.
 * These constants are used to uniquely identify different modules when
 * checking if they are enabled in the configuration.
 */
export declare const SHARED_FILESYSTEM_MODULE = "shared-filesystem-module";
export declare const UPLOADS_MODULE = "uploads-module";
export declare const GIT_MODULE = "git-module";
export declare const GOOGLEDRIVE_MODULE = "google-drive-module";
export declare const CONFLUENCE_MODULE = "confluence-module";
export declare const JIRA_MODULE = "jira-module";
export declare const SHAREPOINT_MODULE = "sharepoint-module";
/**
 * Interface representing the enabled/disabled state of all Gebo.ai modules.
 * Each property corresponds to a module and indicates whether it is enabled (true) or disabled (false).
 */
export interface GeboAIModules {
    filesystemModuleEnabled?: boolean;
    uploadsModuleEnabled?: boolean;
    gitModuleEnabled?: boolean;
    googleDriveModuleEnabled?: boolean;
    confluenceModuleEnabled?: boolean;
    jiraModuleEnabled?: boolean;
    sharepointModuleEnabled?: boolean;
}
/**
 * Service responsible for managing the enabled/disabled state of all Gebo.ai modules.
 * It initializes the module configuration on service instantiation and provides methods
 * to access the configuration.
 */
export declare class GeboAIModulesService {
    private geboModulesConfigService;
    /**
     * Static configuration object that stores the enabled state of all modules.
     * Using static ensures the configuration is shared across all instances of the service.
     */
    private static config?;
    /**
     * Creates an instance of GeboAIModulesService.
     * @param geboModulesConfigService Service to fetch module configuration from the backend
     */
    constructor(geboModulesConfigService: GeboModulesConfigControllerService);
    /**
     * Returns the current configuration of all modules.
     * @returns The current GeboAIModules configuration or undefined if not yet initialized
     */
    getConfig(): GeboAIModules | undefined;
    /**
     * Checks if a specific module is enabled based on its ID.
     * @param moduleId The ID of the module to check
     * @param mods Array of module information objects retrieved from the backend
     * @returns true if the module is enabled, false otherwise
     */
    private isEnabled;
    /**
     * Initializes the module configuration by fetching data from the backend.
     * This method is called during service instantiation and populates the static config.
     * It only runs if the config hasn't been initialized yet.
     */
    private initialize;
    static ɵfac: i0.ɵɵFactoryDeclaration<GeboAIModulesService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<GeboAIModulesService>;
}
//# sourceMappingURL=gebo-ai-modules.service.d.ts.map