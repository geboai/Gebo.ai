import { HttpRequest } from "@angular/common/http";
import * as i0 from "@angular/core";
export declare class GeboBackendListService {
    private basePath;
    private static urls;
    private static publicUrls;
    constructor(basePath: string);
    addBackendServicesBaseUrl(url: string): void;
    addBackendServicesPublicUrl(relativeUrl: string): void;
    isGeboPublicUrl(request: HttpRequest<any>): boolean;
    isGeboBackend(request: HttpRequest<any>): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<GeboBackendListService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<GeboBackendListService>;
}
//# sourceMappingURL=gebo-backends-list.service.d.ts.map