import * as i0 from "@angular/core";
import * as i1 from "./translable.directive";
import * as i2 from "@angular/common";
import * as i3 from "@angular/forms";
/**
 * Angular module that provides translation capabilities to components.
 * This module imports common Angular modules needed for forms processing
 * and declares and exports the GeboAITranslableDirective, making it
 * available for use in any component that imports this module.
 */
export declare class TranslableModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<TranslableModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<TranslableModule, [typeof i1.GeboAITranslableDirective], [typeof i2.CommonModule, typeof i3.ReactiveFormsModule, typeof i3.FormsModule], [typeof i1.GeboAITranslableDirective]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<TranslableModule>;
}
