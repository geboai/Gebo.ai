/**
 * This Source Code is subject to the terms of the
 * Gebo.ai community version Mozilla Public License Version 2.0 (MPL-2.0) — With Data Protection Clauses
 * If a copy of the LICENCE was not distributed with this file, You can obtain one at
 * https://gebo.ai/gebo-ai-community-version-mozilla-public-license-version-2-0-mpl-2-0-with-data-protection-clauses/
 * and https://mozilla.org/MPL/2.0/.
 * Copyright (c) 2025+ Gebo.ai
 */
/**
 * AI generated comments
 * This module provides functionality for handling translations in Angular applications.
 * It includes a directive that can be applied to elements to make them translatable.
 */
import { ElementRef, OnChanges, OnInit, SimpleChanges } from "@angular/core";
import * as i0 from "@angular/core";
/**
 * Directive that marks HTML elements as translatable.
 * When applied to an element with the attribute 'gebo-translable', this directive
 * can process the element for translation purposes. It specifically checks for
 * label elements in ngOnInit but currently doesn't implement full functionality.
 * The directive implements both OnInit and OnChanges lifecycle hooks to handle
 * initialization and updates to the element's attributes.
 */
export declare class GeboAITranslableDirective implements OnInit, OnChanges {
    private el;
    /**
     * Constructor that injects the ElementRef to access the native DOM element
     * that this directive is attached to.
     * @param el Reference to the DOM element this directive is attached to
     */
    constructor(el: ElementRef);
    /**
     * Lifecycle hook that is called after data-bound properties are initialized.
     * Checks if the element is a LABEL tag for potential translation processing.
     * Currently contains placeholder logic for label elements.
     */
    ngOnInit(): void;
    /**
     * Lifecycle hook that is called when any data-bound property of the directive changes.
     * Currently implemented as a placeholder without specific logic.
     * @param changes Simple changes object containing current and previous property values
     */
    ngOnChanges(changes: SimpleChanges): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<GeboAITranslableDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<GeboAITranslableDirective, "[gebo-translable]", never, {}, {}, never, never, false, never>;
}
//# sourceMappingURL=translable.directive.d.ts.map