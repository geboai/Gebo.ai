import * as i0 from '@angular/core';
import { Component, NgModule } from '@angular/core';
import * as i4 from '@angular/forms';
import { FormGroup, FormControl, ReactiveFormsModule, FormsModule } from '@angular/forms';
import * as i9 from '@Gebo.ai/reusable-ui';
import { GEBO_AI_MODULE, fieldHostComponentName, GEBO_AI_FIELD_HOST, GeboAIReusableChatModule, EditableListboxModule, GeboAIFieldTranslationContainerModule, GeboAINotificationsModule } from '@Gebo.ai/reusable-ui';
import * as i1 from '@angular/router';
import { RouterLinkWithHref, RouterModule } from '@angular/router';
import * as i2 from '@Gebo.ai/gebo-ai-rest-api';
import * as i3 from '@angular/common';
import { CommonModule } from '@angular/common';
import * as i5 from 'primeng/api';
import * as i6 from 'primeng/button';
import { ButtonModule } from 'primeng/button';
import * as i7 from 'primeng/blockui';
import { BlockUIModule } from 'primeng/blockui';
import * as i8 from 'primeng/tree';
import { TreeModule } from 'primeng/tree';
import * as i10 from 'primeng/sidebar';
import { SidebarModule } from 'primeng/sidebar';
import * as i11 from 'primeng/popover';
import { PopoverModule } from 'primeng/popover';
import { ProgressSpinnerModule } from 'primeng/progressspinner';
import { ListboxModule } from 'primeng/listbox';
import { ScrollerModule } from 'primeng/scroller';
import { PaginatorModule } from 'primeng/paginator';
import { PanelModule } from 'primeng/panel';
import { ScrollPanelModule } from 'primeng/scrollpanel';

/**
 * This Source Code is subject to the terms of the
 * Gebo.ai community version Mozilla Public License Version 2.0 (MPL-2.0) — With Data Protection Clauses
 * If a copy of the LICENCE was not distributed with this file, You can obtain one at
 * https://gebo.ai/gebo-ai-community-version-mozilla-public-license-version-2-0-mpl-2-0-with-data-protection-clauses/
 * and https://mozilla.org/MPL/2.0/.
 * Copyright (c) 2025+ Gebo.ai
 */
;
function toExtended(chatInfo) {
    const extended = {
        ...chatInfo,
        routerLink: "/ui/chat/" + chatInfo.code + "/load"
    };
    return extended;
}
/* AI generated comments */
/**
 * GeboAiChatSectionComponent is responsible for managing the chat interface section.
 * It handles:
 * - Loading and displaying chat history
 * - Creating new regular or RAG (Retrieval-Augmented Generation) chats
 * - Managing chat profiles and model options
 * - Switching between different chat views
 */
class GeboAiChatSectionComponent {
    /**
     * Computed property to determine if any loading is in progress
     * Returns true if any loading process is active
     */
    get loading() {
        return this.chatsPageLoading || this.chatsModelLoading || this.chatsProfilesLoading || this.chatDataLoading;
    }
    /**
     * Component constructor that injects necessary services
     * @param activatedRoute Service to access the current route information
     * @param geboRagChatControllerService Service for RAG chat operations
     * @param geboChatControllerService Service for regular chat operations
     * @param geboUserChatsControllerService Service for user chat management
     * @param geboChatModelsControllerService Service for accessing chat models
     */
    constructor(cd, actualRouting, router, geboRagChatControllerService, geboUserChatsControllerService, geboChatModelsControllerService) {
        this.cd = cd;
        this.actualRouting = actualRouting;
        this.router = router;
        this.geboRagChatControllerService = geboRagChatControllerService;
        this.geboUserChatsControllerService = geboUserChatsControllerService;
        this.geboChatModelsControllerService = geboChatModelsControllerService;
        /** Flag indicating if the chats page is currently loading */
        this.chatsPageLoading = false;
        /** Flag indicating if the chat models are currently loading */
        this.chatsModelLoading = false;
        /** Flag indicating if the chat profiles are currently loading */
        this.chatsProfilesLoading = false;
        /** Flag controlling the visibility of the chats list and options panel */
        this.chatsListAndOptionsVisible = false;
        /** Flag indicating if a RAG chat is currently open */
        this.openRagChat = false;
        /** Flag indicating if a regular chat is currently open */
        this.openChat = false;
        /** Stores the currently active chat information */
        this.currentChat = {};
        this.chatDataLoading = false;
        /** Pagination configuration for chat history */
        this.page = {
            page: 0,
            pageSize: 100
        };
        /** Form group for RAG chat profile selection */
        this.formGroup = new FormGroup({
            chatProfileCode: new FormControl()
        });
        /** Form group for regular chat model selection */
        this.chatFormGroup = new FormGroup({
            chatModelCode: new FormControl()
        });
        /** Stores available chat profile configurations */
        this.chatProfilesData = [];
        /** Stores available chat models data */
        this.chatModelsData = [];
        this.scrollOptions = {
            onLazyLoad: () => {
                console.log("lazyLoad");
            },
            onScroll: () => {
                console.log("lazyScroll");
            },
            onScrollIndexChange: () => {
                console.log("indexChange");
            }
        };
    }
    routeNewRagChat() {
        const value = this.formGroup.value;
        const chatProfileCode = value.chatProfileCode;
        this.chatDataLoading = true;
        this.geboUserChatsControllerService.createCleanChatByChatProfileCode(chatProfileCode).subscribe({
            next: (chatInfo) => {
                if (chatInfo.code) {
                    this.doOpenRagChat();
                    const route = ["/", "ui", "chat", chatInfo.code, "load"];
                    this.router.navigate(route, { replaceUrl: true, onSameUrlNavigation: "reload" }).then(ok => console.log('Navigation result:', ok)).catch(err => console.error('Navigation error:', err));
                }
            },
            complete: () => {
                this.chatDataLoading = false;
            }
        });
    }
    /**
     * Opens the RAG chat interface and hides other chat views
     */
    doOpenRagChat() {
        this.openRagChat = true;
        this.openChat = false;
        this.chatsListAndOptionsVisible = false;
    }
    routeNewChat() {
        const value = this.chatFormGroup.value;
        const chatModelCode = value.chatModelCode;
        this.geboUserChatsControllerService.createCleanChatByModelCode(chatModelCode).subscribe({
            next: (chatInfo) => {
                if (chatInfo.code) {
                    this.doOpenChat();
                    const route = ["/", "ui", "chat", chatInfo.code, "load"];
                    this.router.navigate(route, { replaceUrl: true, onSameUrlNavigation: "reload" }).then(ok => console.log('Navigation result:', ok)).catch(err => console.error('Navigation error:', err));
                }
            },
            complete: () => {
                this.chatDataLoading = false;
            }
        });
    }
    /**
     * Opens the regular chat interface and hides other chat views
     */
    doOpenChat() {
        this.openChat = true;
        this.openRagChat = false;
        this.chatsListAndOptionsVisible = false;
    }
    scrollIndexChange(indexChange) {
    }
    routeToChat(chat) {
        if (chat.code) {
            const route = ["/", "ui", "chat", chat.code, "load"];
            this.router.navigate(route, { replaceUrl: true, onSameUrlNavigation: "reload" }).then(ok => console.log('Navigation result:', ok)).catch(err => console.error('Navigation error:', err));
        }
    }
    /**
     * Loads the user's chat history with pagination
     * Updates the chatsPage property with the retrieved data
     */
    loadChatList() {
        if (!this.chatsTree) {
            this.chatsTree = [{ label: "Chats", leaf: false, children: [], expanded: true }];
        }
        this.chatsPageLoading = true;
        this.geboUserChatsControllerService.getMyChats().subscribe({
            next: (chats) => {
                const childrens = chats ? chats : [];
                const newItems = childrens.map(x => {
                    const item = {
                        label: x.description,
                        leaf: true,
                        data: toExtended(x),
                        icon: "pi pi-comments"
                    };
                    return item;
                });
                this.chatsTree[0].children = newItems;
            }, error: (err) => {
                this.chatsPageLoading = false;
            },
            complete: () => {
                this.chatsPageLoading = false;
            }
        });
    }
    onUpdatedChat(chatInfo) {
        if (this.chatsTree && this.chatsTree.length !== undefined) {
            const childs = this.chatsTree[0].children;
            if (childs) {
                for (let i = 0; i < childs.length; i++) {
                    if (childs[i]?.data?.code === chatInfo?.code) {
                        childs[i].data = chatInfo;
                    }
                }
            }
        }
        this.loadChatList();
    }
    openChatItem(event) {
        if (event && event.node.data) {
            this.activateChat(event.node.data);
        }
    }
    /**
     * Closes the current chat, returns to the chat list view, and refreshes the chat history
     */
    reloadChatsAndCloseChat() {
        this.chatsListAndOptionsVisible = true;
        this.currentChat = {};
        this.openChat = false;
        this.openRagChat = false;
        this.loadChatList();
    }
    /**
     * Loads available chat profiles and models for selection
     * Updates form controls with default selections when data is loaded
     */
    loadChatOptions() {
        this.chatsProfilesLoading = true;
        this.geboUserChatsControllerService.getUIConfig().subscribe({
            next: (options) => {
                this.chatUIOptions = options;
            }
        });
        this.geboChatModelsControllerService.getRuntimeConfiguredChatModelsLookup().subscribe({
            next: (value) => {
                this.chatModelsData = value;
                if (this.chatFormGroup && this.chatModelsData && this.chatModelsData.length) {
                    this.chatFormGroup.controls["chatModelCode"].setValue(this.chatModelsData[0].code);
                }
            },
            complete: () => {
                this.chatsProfilesLoading = false;
            }
        });
        this.chatsModelLoading = true;
        this.geboRagChatControllerService.getChatProfiles().subscribe({
            next: (value) => {
                this.chatProfilesData = value;
                if (this.formGroup && this.chatProfilesData && this.chatProfilesData.length) {
                    this.formGroup.controls["chatProfileCode"].setValue(this.chatProfilesData[0].code);
                }
            },
            complete: () => {
                this.chatsModelLoading = false;
            }
        });
    }
    /**
     * Angular lifecycle hook that initializes the component
     * Shows the chat list view and loads chat options and history
     */
    ngOnInit() {
        this.chatsTree = [{ label: "Chats", leaf: false, children: [], expanded: true }];
        this.chatsListAndOptionsVisible = true;
        this.loadChatOptions();
        this.loadChatList();
        this.actualRouting.params.subscribe({
            next: (params) => {
                this.id = params["id"];
                if (this.id) {
                    this.chatDataLoading = true;
                    this.geboUserChatsControllerService.getChatInfosByCode(this.id).subscribe({
                        next: (chatInfo) => {
                            this.activateChat(chatInfo);
                        },
                        complete: () => {
                            this.chatDataLoading = false;
                        }
                    });
                }
                if (params["chatProfile"]) {
                    const chatProfileCode = params["chatProfile"];
                    this.chatDataLoading = true;
                    this.geboUserChatsControllerService.createCleanChatByChatProfileCode(chatProfileCode).subscribe({
                        next: (chatInfo) => {
                            this.activateChat(chatInfo);
                        },
                        complete: () => {
                            this.chatDataLoading = false;
                        }
                    });
                }
                if (params["modelCode"]) {
                    const modelCode = params["modelCode"];
                    this.geboUserChatsControllerService.createCleanChatByModelCode(modelCode).subscribe({
                        next: (chatInfo) => {
                            this.activateChat(chatInfo);
                        },
                        complete: () => {
                            this.chatDataLoading = false;
                        }
                    });
                }
            }
        });
    }
    /**
     * Sets the provided chat as the current chat and opens the appropriate interface
     * Opens RAG chat or regular chat based on the chat type
     * @param chat The chat information to activate
     */
    activateChat(chat) {
        this.currentChat = chat;
        if (chat.ragChat === true) {
            this.doOpenRagChat();
        }
        else {
            this.doOpenChat();
        }
    }
    /**
     * Angular lifecycle hook that responds to input property changes
     * @param changes Simple changes object containing current and previous values
     */
    ngOnChanges(changes) {
    }
    /**
     * Handles paginator events for the chat history list
     * Updates pagination settings and reloads the chat list
     * @param evt The paginator state containing page and rows information
     */
    onPageChange(evt) {
        this.page.page = evt.page;
        this.page.pageSize = evt.rows;
        this.loadChatList();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.14", ngImport: i0, type: GeboAiChatSectionComponent, deps: [{ token: i0.ChangeDetectorRef }, { token: i1.ActivatedRoute }, { token: i1.Router }, { token: i2.GeboRagChatControllerService }, { token: i2.GeboUserChatsControllerService }, { token: i2.ChatModelsLookupControllerService }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "19.2.14", type: GeboAiChatSectionComponent, isStandalone: false, selector: "gebo-ai-chat-section-component", providers: [{ provide: GEBO_AI_MODULE, useValue: "GeboAiChatModule", multi: false }, { provide: GEBO_AI_FIELD_HOST, multi: false, useValue: fieldHostComponentName("GeboAiChatSectionComponent") }], usesOnChanges: true, ngImport: i0, template: "<!--\r\n/**\r\n * This Source Code is subject to the terms of the \r\n * Gebo.ai community version Mozilla Public License Version 2.0 (MPL-2.0) \u2014 With Data Protection Clauses\r\n * If a copy of the LICENCE was not distributed with this file, You can obtain one at \r\n * https://gebo.ai/gebo-ai-community-version-mozilla-public-license-version-2-0-mpl-2-0-with-data-protection-clauses/  \r\n * and https://mozilla.org/MPL/2.0/.\r\n * Copyright (c) 2025+ Gebo.ai \r\n */\r\n -->\r\n<p-sidebar [(visible)]=\"chatsListAndOptionsVisible\" (visibleChange)=\"chatsListAndOptionsVisible=$event;\"\r\n  [dismissible]=\"false\" [modal]=\"true\" baseZIndex=\"10000\" styleClass=\"w-30rem\" [showCloseIcon]=\"false\">\r\n  <ng-template pTemplate=\"header\">\r\n    <div class=\"grid w-full\">\r\n      <div class=\"col-11\">\r\n\r\n        <img src=\"assets/Gebo.png\" width=\"240\" height=\"60\">\r\n\r\n      </div>\r\n\r\n      <div class=\"col-1  flex justify-content-end\">\r\n\r\n        <p-button id=\"TimesBtn\" gebo-ai-label icon=\"pi pi-times\" text=\"true\" outlined=\"true\"\r\n          (onClick)=\"chatsListAndOptionsVisible=false;\"></p-button>\r\n\r\n      </div>\r\n    </div>\r\n  </ng-template>\r\n\r\n  <div class=\"grid  w-full\">\r\n    <div class=\"col-12\">\r\n      <p-blockUI id=\"BlockUIIcon\" gebo-ai-label [blocked]=\"loading\">\r\n        <i class=\"pi pi-lock\" style=\"font-size: 3rem\"></i>\r\n      </p-blockUI>\r\n      <p-button icon=\"pi pi-pen-to-square\" id=\"NewRagChatMiniBtn\" label=\"Chat with knowledge base\"\r\n        title=\"Create a new RAG chat with company contents\" *ngIf=\"chatProfilesData?.length\" gebo-ai-label [text]=\"true\"\r\n        (onClick)=\"chatProfilesData.length>1? newRagChatDialog.toggle($event):routeNewRagChat()\"></p-button><br />\r\n      @if (chatUIOptions?.enablePureModelChat===true) {\r\n      <p-button icon=\"pi pi-pen-to-square\" id=\"NewChatMiniBtn\" label=\"Chat\"\r\n        title=\"Create a new chat with large language models\" *ngIf=\"chatModelsData?.length\" gebo-ai-label [text]=\"true\"\r\n        (onClick)=\"chatModelsData.length>1?newChatDialog.toggle($event):routeNewChat()\"></p-button>\r\n      }\r\n      <p-popover #newRagChatDialog>\r\n        <div class=\"grid\">\r\n          <div class=\"col-12\" [formGroup]=\"formGroup\">\r\n            <gebo-ai-field id=\"chatProfileCode\" label=\"Chat with knowledge bases\"\r\n              help=\"Choose the company chat profile to interact with company (and your) documents and LLMs\"\r\n              placeholder=\"Select a chat profile\">\r\n              <geboai-editable-listbox-component formControlName=\"chatProfileCode\" [data]=\"chatProfilesData\"\r\n                [required]=\"true\" gebo-ai-field-element>\r\n              </geboai-editable-listbox-component>\r\n            </gebo-ai-field>\r\n\r\n          </div>\r\n          <div class=\"col-6\">\r\n            <p-button id=\"NewChatBtn\" gebo-ai-label label=\"New chat\" (onClick)=\"routeNewRagChat()\"\r\n              [disabled]=\"formGroup.invalid\" styleClass=\"w-full\" severity=\"success\" [outlined]=\"true\"\r\n              icon=\"pi pi-microchip-ai\"></p-button>\r\n          </div>\r\n        </div>\r\n      </p-popover>\r\n      <p-popover #newChatDialog>\r\n        <div class=\"grid\">\r\n          <div class=\"col-12\" [formGroup]=\"chatFormGroup\">\r\n            <gebo-ai-field id=\"chatModelCode\" label=\"Chat without knowledge bases\"\r\n              help=\"Choose the LLMs for a chat session\"\r\n              placeholder=\"Select a chat model\"><geboai-editable-listbox-component formControlName=\"chatModelCode\"\r\n                [data]=\"chatModelsData\" [required]=\"true\" gebo-ai-field-element>\r\n              </geboai-editable-listbox-component></gebo-ai-field>\r\n\r\n\r\n          </div>\r\n          <div class=\"col-6\">\r\n            <p-button id=\"CreateChatBtn\" gebo-ai-label label=\"New chat\" (onClick)=\"routeNewChat()\"\r\n              [disabled]=\"chatFormGroup.invalid\" styleClass=\"w-full\" severity=\"success\" [outlined]=\"true\"\r\n              icon=\"pi pi-microchip-ai\"></p-button>\r\n          </div>\r\n\r\n        </div>\r\n      </p-popover>\r\n    </div>\r\n    <div class=\"col-12\">\r\n      <p-tree [value]=\"chatsTree\" (onNodeSelect)=\"openChatItem($event)\" styleClass=\"h-full w-full\"\r\n        (onNodeDoubleClick)=\"openChatItem($event)\" [loading]=\"chatsPageLoading\">\r\n        <ng-template let-node pTemplate=\"default\">\r\n\r\n          <a (click)=\"node.data?routeToChat(node.data):false\" href=\"javascript:void(0)\"\r\n            style=\"text-decoration: none;color:black\">{{node.label}}</a>\r\n\r\n        </ng-template>\r\n      </p-tree>\r\n    </div>\r\n  </div>\r\n\r\n</p-sidebar>\r\n<div class=\"gebo-ai-rag-chat-section\">\r\n  <div class=\"gebo-ai-rag-chat-section__menu\">\r\n    <p-button id=\"ChevronLeftBtn\" gebo-ai-label (onClick)=\"chatsListAndOptionsVisible=true;\" [text]=\"true\"\r\n      [outlined]=\"true\" icon=\"pi pi-chevron-left\" title=\"Open chat options section\"></p-button>\r\n  </div>\r\n\r\n  <div class=\"gebo-ai-rag-chat-section__content\">\r\n    <gebo-ai-reusable-chat-component *ngIf=\"openRagChat===true\" [ragsystem]=\"true\" [chatInfo]=\"currentChat\"\r\n      (deleteChatAction)=\"reloadChatsAndCloseChat()\" (addedChatAction)=\"loadChatList()\"\r\n      (updatedChatAction)=\"onUpdatedChat($event)\" [title]=\"currentChat?.description\"></gebo-ai-reusable-chat-component>\r\n    <gebo-ai-reusable-chat-component *ngIf=\"openChat===true\" [ragsystem]=\"false\" [chatInfo]=\"currentChat\"\r\n      (deleteChatAction)=\"reloadChatsAndCloseChat()\" (addedChatAction)=\"loadChatList()\"\r\n      (updatedChatAction)=\"onUpdatedChat($event)\" [title]=\"currentChat?.description\"></gebo-ai-reusable-chat-component>\r\n  </div>\r\n</div>", styles: [".gebo-ai-rag-chat-section__content{margin:auto}@media (min-width: 1400px){.gebo-ai-rag-chat-section__content{width:80%}}@media (min-width: 1800px){.gebo-ai-rag-chat-section__content{width:50%}}@media (min-width: 2700px){.gebo-ai-rag-chat-section__content{width:30%}}\n"], dependencies: [{ kind: "directive", type: i3.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "directive", type: i4.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i4.NgControlStatusGroup, selector: "[formGroupName],[formArrayName],[ngModelGroup],[formGroup],form:not([ngNoForm]),[ngForm]" }, { kind: "directive", type: i4.RequiredValidator, selector: ":not([type=checkbox])[required][formControlName],:not([type=checkbox])[required][formControl],:not([type=checkbox])[required][ngModel]", inputs: ["required"] }, { kind: "directive", type: i4.FormGroupDirective, selector: "[formGroup]", inputs: ["formGroup"], outputs: ["ngSubmit"], exportAs: ["ngForm"] }, { kind: "directive", type: i4.FormControlName, selector: "[formControlName]", inputs: ["formControlName", "disabled", "ngModel"], outputs: ["ngModelChange"] }, { kind: "directive", type: i5.PrimeTemplate, selector: "[pTemplate]", inputs: ["type", "pTemplate"] }, { kind: "component", type: i6.Button, selector: "p-button", inputs: ["type", "iconPos", "icon", "badge", "label", "disabled", "loading", "loadingIcon", "raised", "rounded", "text", "plain", "severity", "outlined", "link", "tabindex", "size", "variant", "style", "styleClass", "badgeClass", "badgeSeverity", "ariaLabel", "autofocus", "fluid", "buttonProps"], outputs: ["onClick", "onFocus", "onBlur"] }, { kind: "component", type: i7.BlockUI, selector: "p-blockUI, p-blockui, p-block-ui", inputs: ["target", "autoZIndex", "baseZIndex", "styleClass", "blocked"] }, { kind: "component", type: i8.Tree, selector: "p-tree", inputs: ["value", "selectionMode", "loadingMode", "selection", "style", "styleClass", "contextMenu", "draggableScope", "droppableScope", "draggableNodes", "droppableNodes", "metaKeySelection", "propagateSelectionUp", "propagateSelectionDown", "loading", "loadingIcon", "emptyMessage", "ariaLabel", "togglerAriaLabel", "ariaLabelledBy", "validateDrop", "filter", "filterInputAutoFocus", "filterBy", "filterMode", "filterOptions", "filterPlaceholder", "filteredNodes", "filterLocale", "scrollHeight", "lazy", "virtualScroll", "virtualScrollItemSize", "virtualScrollOptions", "indentation", "_templateMap", "trackBy", "highlightOnSelect", "virtualNodeHeight"], outputs: ["selectionChange", "onNodeSelect", "onNodeUnselect", "onNodeExpand", "onNodeCollapse", "onNodeContextMenuSelect", "onNodeDoubleClick", "onNodeDrop", "onLazyLoad", "onScroll", "onScrollIndexChange", "onFilter"] }, { kind: "component", type: i9.GeboAIReusableChatComponent, selector: "gebo-ai-reusable-chat-component", inputs: ["maxDisplayedDocs", "streamingTimeout", "useRestOnly", "chatInfo", "title", "subtitle", "modelName", "ragsystem"], outputs: ["cancelAction", "deleteChatAction", "addedChatAction", "updatedChatAction"] }, { kind: "component", type: i9.EditableListboxComponent, selector: "geboai-editable-listbox-component", inputs: ["loading", "onSingleOptionAutomaticallySelect", "placeholder", "readonly", "required", "optionsObservable", "data", "createNewRecordRequest"], outputs: ["selectionChanged"] }, { kind: "component", type: i10.Sidebar, selector: "p-sidebar", inputs: ["appendTo", "blockScroll", "style", "styleClass", "ariaCloseLabel", "autoZIndex", "baseZIndex", "modal", "closeButtonProps", "dismissible", "showCloseIcon", "closeOnEscape", "transitionOptions", "visible", "position", "fullScreen", "maskStyle", "headerTemplate", "footerTemplate", "closeIconTemplate", "headlessTemplate", "contentTemplate"], outputs: ["onShow", "onHide", "visibleChange"] }, { kind: "component", type: i9.GeboAIFieldContainerComponent, selector: "gebo-ai-field", inputs: ["id", "label", "placeholder", "help", "required"] }, { kind: "directive", type: i9.GeboAIFieldContainerDirective, selector: "[gebo-ai-field-element]" }, { kind: "directive", type: i9.GeboAILabelDirective, selector: "[gebo-ai-label]" }, { kind: "directive", type: i9.PButtonLabelTarget, selector: "p-button[gebo-ai-label]" }, { kind: "component", type: i11.Popover, selector: "p-popover", inputs: ["ariaLabel", "ariaLabelledBy", "dismissable", "style", "styleClass", "appendTo", "autoZIndex", "ariaCloseLabel", "baseZIndex", "focusOnShow", "showTransitionOptions", "hideTransitionOptions"], outputs: ["onShow", "onHide"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.14", ngImport: i0, type: GeboAiChatSectionComponent, decorators: [{
            type: Component,
            args: [{ selector: "gebo-ai-chat-section-component", standalone: false, providers: [{ provide: GEBO_AI_MODULE, useValue: "GeboAiChatModule", multi: false }, { provide: GEBO_AI_FIELD_HOST, multi: false, useValue: fieldHostComponentName("GeboAiChatSectionComponent") }], template: "<!--\r\n/**\r\n * This Source Code is subject to the terms of the \r\n * Gebo.ai community version Mozilla Public License Version 2.0 (MPL-2.0) \u2014 With Data Protection Clauses\r\n * If a copy of the LICENCE was not distributed with this file, You can obtain one at \r\n * https://gebo.ai/gebo-ai-community-version-mozilla-public-license-version-2-0-mpl-2-0-with-data-protection-clauses/  \r\n * and https://mozilla.org/MPL/2.0/.\r\n * Copyright (c) 2025+ Gebo.ai \r\n */\r\n -->\r\n<p-sidebar [(visible)]=\"chatsListAndOptionsVisible\" (visibleChange)=\"chatsListAndOptionsVisible=$event;\"\r\n  [dismissible]=\"false\" [modal]=\"true\" baseZIndex=\"10000\" styleClass=\"w-30rem\" [showCloseIcon]=\"false\">\r\n  <ng-template pTemplate=\"header\">\r\n    <div class=\"grid w-full\">\r\n      <div class=\"col-11\">\r\n\r\n        <img src=\"assets/Gebo.png\" width=\"240\" height=\"60\">\r\n\r\n      </div>\r\n\r\n      <div class=\"col-1  flex justify-content-end\">\r\n\r\n        <p-button id=\"TimesBtn\" gebo-ai-label icon=\"pi pi-times\" text=\"true\" outlined=\"true\"\r\n          (onClick)=\"chatsListAndOptionsVisible=false;\"></p-button>\r\n\r\n      </div>\r\n    </div>\r\n  </ng-template>\r\n\r\n  <div class=\"grid  w-full\">\r\n    <div class=\"col-12\">\r\n      <p-blockUI id=\"BlockUIIcon\" gebo-ai-label [blocked]=\"loading\">\r\n        <i class=\"pi pi-lock\" style=\"font-size: 3rem\"></i>\r\n      </p-blockUI>\r\n      <p-button icon=\"pi pi-pen-to-square\" id=\"NewRagChatMiniBtn\" label=\"Chat with knowledge base\"\r\n        title=\"Create a new RAG chat with company contents\" *ngIf=\"chatProfilesData?.length\" gebo-ai-label [text]=\"true\"\r\n        (onClick)=\"chatProfilesData.length>1? newRagChatDialog.toggle($event):routeNewRagChat()\"></p-button><br />\r\n      @if (chatUIOptions?.enablePureModelChat===true) {\r\n      <p-button icon=\"pi pi-pen-to-square\" id=\"NewChatMiniBtn\" label=\"Chat\"\r\n        title=\"Create a new chat with large language models\" *ngIf=\"chatModelsData?.length\" gebo-ai-label [text]=\"true\"\r\n        (onClick)=\"chatModelsData.length>1?newChatDialog.toggle($event):routeNewChat()\"></p-button>\r\n      }\r\n      <p-popover #newRagChatDialog>\r\n        <div class=\"grid\">\r\n          <div class=\"col-12\" [formGroup]=\"formGroup\">\r\n            <gebo-ai-field id=\"chatProfileCode\" label=\"Chat with knowledge bases\"\r\n              help=\"Choose the company chat profile to interact with company (and your) documents and LLMs\"\r\n              placeholder=\"Select a chat profile\">\r\n              <geboai-editable-listbox-component formControlName=\"chatProfileCode\" [data]=\"chatProfilesData\"\r\n                [required]=\"true\" gebo-ai-field-element>\r\n              </geboai-editable-listbox-component>\r\n            </gebo-ai-field>\r\n\r\n          </div>\r\n          <div class=\"col-6\">\r\n            <p-button id=\"NewChatBtn\" gebo-ai-label label=\"New chat\" (onClick)=\"routeNewRagChat()\"\r\n              [disabled]=\"formGroup.invalid\" styleClass=\"w-full\" severity=\"success\" [outlined]=\"true\"\r\n              icon=\"pi pi-microchip-ai\"></p-button>\r\n          </div>\r\n        </div>\r\n      </p-popover>\r\n      <p-popover #newChatDialog>\r\n        <div class=\"grid\">\r\n          <div class=\"col-12\" [formGroup]=\"chatFormGroup\">\r\n            <gebo-ai-field id=\"chatModelCode\" label=\"Chat without knowledge bases\"\r\n              help=\"Choose the LLMs for a chat session\"\r\n              placeholder=\"Select a chat model\"><geboai-editable-listbox-component formControlName=\"chatModelCode\"\r\n                [data]=\"chatModelsData\" [required]=\"true\" gebo-ai-field-element>\r\n              </geboai-editable-listbox-component></gebo-ai-field>\r\n\r\n\r\n          </div>\r\n          <div class=\"col-6\">\r\n            <p-button id=\"CreateChatBtn\" gebo-ai-label label=\"New chat\" (onClick)=\"routeNewChat()\"\r\n              [disabled]=\"chatFormGroup.invalid\" styleClass=\"w-full\" severity=\"success\" [outlined]=\"true\"\r\n              icon=\"pi pi-microchip-ai\"></p-button>\r\n          </div>\r\n\r\n        </div>\r\n      </p-popover>\r\n    </div>\r\n    <div class=\"col-12\">\r\n      <p-tree [value]=\"chatsTree\" (onNodeSelect)=\"openChatItem($event)\" styleClass=\"h-full w-full\"\r\n        (onNodeDoubleClick)=\"openChatItem($event)\" [loading]=\"chatsPageLoading\">\r\n        <ng-template let-node pTemplate=\"default\">\r\n\r\n          <a (click)=\"node.data?routeToChat(node.data):false\" href=\"javascript:void(0)\"\r\n            style=\"text-decoration: none;color:black\">{{node.label}}</a>\r\n\r\n        </ng-template>\r\n      </p-tree>\r\n    </div>\r\n  </div>\r\n\r\n</p-sidebar>\r\n<div class=\"gebo-ai-rag-chat-section\">\r\n  <div class=\"gebo-ai-rag-chat-section__menu\">\r\n    <p-button id=\"ChevronLeftBtn\" gebo-ai-label (onClick)=\"chatsListAndOptionsVisible=true;\" [text]=\"true\"\r\n      [outlined]=\"true\" icon=\"pi pi-chevron-left\" title=\"Open chat options section\"></p-button>\r\n  </div>\r\n\r\n  <div class=\"gebo-ai-rag-chat-section__content\">\r\n    <gebo-ai-reusable-chat-component *ngIf=\"openRagChat===true\" [ragsystem]=\"true\" [chatInfo]=\"currentChat\"\r\n      (deleteChatAction)=\"reloadChatsAndCloseChat()\" (addedChatAction)=\"loadChatList()\"\r\n      (updatedChatAction)=\"onUpdatedChat($event)\" [title]=\"currentChat?.description\"></gebo-ai-reusable-chat-component>\r\n    <gebo-ai-reusable-chat-component *ngIf=\"openChat===true\" [ragsystem]=\"false\" [chatInfo]=\"currentChat\"\r\n      (deleteChatAction)=\"reloadChatsAndCloseChat()\" (addedChatAction)=\"loadChatList()\"\r\n      (updatedChatAction)=\"onUpdatedChat($event)\" [title]=\"currentChat?.description\"></gebo-ai-reusable-chat-component>\r\n  </div>\r\n</div>", styles: [".gebo-ai-rag-chat-section__content{margin:auto}@media (min-width: 1400px){.gebo-ai-rag-chat-section__content{width:80%}}@media (min-width: 1800px){.gebo-ai-rag-chat-section__content{width:50%}}@media (min-width: 2700px){.gebo-ai-rag-chat-section__content{width:30%}}\n"] }]
        }], ctorParameters: () => [{ type: i0.ChangeDetectorRef }, { type: i1.ActivatedRoute }, { type: i1.Router }, { type: i2.GeboRagChatControllerService }, { type: i2.GeboUserChatsControllerService }, { type: i2.ChatModelsLookupControllerService }] });

/**
 * This Source Code is subject to the terms of the
 * Gebo.ai community version Mozilla Public License Version 2.0 (MPL-2.0) — With Data Protection Clauses
 * If a copy of the LICENCE was not distributed with this file, You can obtain one at
 * https://gebo.ai/gebo-ai-community-version-mozilla-public-license-version-2-0-mpl-2-0-with-data-protection-clauses/
 * and https://mozilla.org/MPL/2.0/.
 * Copyright (c) 2025+ Gebo.ai
 */
/**
 * @file GeboAiChatModule
 * AI generated comments
 *
 * This module provides the necessary imports and declarations for the GeboAiChatSection functionality.
 * It serves as a feature module that encapsulates all components, directives, and pipes related to
 * the AI chat interface. This module bundles PrimeNG UI components along with Angular form modules
 * to create a comprehensive chat experience.
 */
/**
 * The GeboAiChatModule provides a self-contained feature module for chat functionality.
 *
 * This module imports various UI components from PrimeNG (buttons, spinners, listboxes, etc.) and
 * Angular modules (forms, common) to support the chat interface. It declares the GeboAiChatSectionComponent
 * which is the main component for rendering the chat interface, and exports it to make it available
 * to other modules that import this module.
 *
 * The UI components include:
 * - Form handling (ReactiveFormsModule, FormsModule)
 * - UI components from PrimeNG (Button, ProgressSpinner, BlockUI, etc.)
 * - Custom Gebo.ai components (EditableListboxModule, GeboAIReusableChatModel)
 */
class GeboAiChatModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.14", ngImport: i0, type: GeboAiChatModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "19.2.14", ngImport: i0, type: GeboAiChatModule, declarations: [GeboAiChatSectionComponent], imports: [CommonModule, ReactiveFormsModule, PaginatorModule, FormsModule, ButtonModule, ProgressSpinnerModule, BlockUIModule, ListboxModule, ScrollerModule, TreeModule, GeboAIReusableChatModule, EditableListboxModule, SidebarModule, PanelModule, GeboAIFieldTranslationContainerModule, ScrollPanelModule, PopoverModule, RouterLinkWithHref, GeboAINotificationsModule], exports: [GeboAiChatSectionComponent] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "19.2.14", ngImport: i0, type: GeboAiChatModule, providers: [{ provide: GEBO_AI_MODULE, useValue: "GeboAiChatModule", multi: false }], imports: [CommonModule, ReactiveFormsModule, PaginatorModule, FormsModule, ButtonModule, ProgressSpinnerModule, BlockUIModule, ListboxModule, ScrollerModule, TreeModule, GeboAIReusableChatModule, EditableListboxModule, SidebarModule, PanelModule, GeboAIFieldTranslationContainerModule, ScrollPanelModule, PopoverModule, GeboAINotificationsModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.14", ngImport: i0, type: GeboAiChatModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [CommonModule, ReactiveFormsModule, PaginatorModule, FormsModule, ButtonModule, ProgressSpinnerModule, BlockUIModule, ListboxModule, ScrollerModule, TreeModule, GeboAIReusableChatModule, EditableListboxModule, SidebarModule, PanelModule, GeboAIFieldTranslationContainerModule, ScrollPanelModule, PopoverModule, RouterLinkWithHref, GeboAINotificationsModule],
                    declarations: [GeboAiChatSectionComponent],
                    exports: [GeboAiChatSectionComponent],
                    providers: [{ provide: GEBO_AI_MODULE, useValue: "GeboAiChatModule", multi: false }]
                }]
        }] });

/**
 * This Source Code is subject to the terms of the
 * Gebo.ai community version Mozilla Public License Version 2.0 (MPL-2.0) — With Data Protection Clauses
 * If a copy of the LICENCE was not distributed with this file, You can obtain one at
 * https://gebo.ai/gebo-ai-community-version-mozilla-public-license-version-2-0-mpl-2-0-with-data-protection-clauses/
 * and https://mozilla.org/MPL/2.0/.
 * Copyright (c) 2025+ Gebo.ai
 */
/**
 * AI generated comments
 *
 * Defines the routing configuration for the Gebo AI Chat feature.
 * This routes array contains a single route definition that maps the empty path ('')
 * to the GeboAiChatSectionComponent with full path matching.
 */
const routes = [
    {
        path: '',
        component: GeboAiChatSectionComponent,
        pathMatch: "full"
    },
    {
        path: ':id/load',
        component: GeboAiChatSectionComponent
    },
    {
        path: ':chatProfile/newRagChat',
        component: GeboAiChatSectionComponent
    },
    {
        path: ':modelCode/newChat',
        component: GeboAiChatSectionComponent
    }
];
/**
 * Routing module for the Gebo AI Chat feature.
 * This NgModule imports the main GeboAiChatModule and sets up the child routes
 * using Angular's RouterModule.forChild() method. The module provides the necessary
 * routing configuration to navigate to the chat section component when the base
 * path is accessed.
 */
class GeboAiChatRoutingModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.14", ngImport: i0, type: GeboAiChatRoutingModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "19.2.14", ngImport: i0, type: GeboAiChatRoutingModule, imports: [GeboAiChatModule, i1.RouterModule] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "19.2.14", ngImport: i0, type: GeboAiChatRoutingModule, imports: [GeboAiChatModule, RouterModule.forChild(routes)] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.14", ngImport: i0, type: GeboAiChatRoutingModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [GeboAiChatModule, RouterModule.forChild(routes)]
                }]
        }] });

/**
 * This Source Code is subject to the terms of the
 * Gebo.ai community version Mozilla Public License Version 2.0 (MPL-2.0) — With Data Protection Clauses
 * If a copy of the LICENCE was not distributed with this file, You can obtain one at
 * https://gebo.ai/gebo-ai-community-version-mozilla-public-license-version-2-0-mpl-2-0-with-data-protection-clauses/
 * and https://mozilla.org/MPL/2.0/.
 * Copyright (c) 2025+ Gebo.ai
 */
/*
 * Public API Surface of gebo-ai-chat-ui
 */

/**
 * Generated bundle index. Do not edit.
 */

export { GeboAiChatModule, GeboAiChatRoutingModule, GeboAiChatSectionComponent };
//# sourceMappingURL=Gebo.ai-chat-ui.mjs.map
