import * as i0 from "@angular/core";
import * as i1 from "./gebo-ai-rag-chat-section.component";
import * as i2 from "@angular/common";
import * as i3 from "@angular/forms";
import * as i4 from "primeng/paginator";
import * as i5 from "primeng/button";
import * as i6 from "primeng/progressspinner";
import * as i7 from "primeng/blockui";
import * as i8 from "primeng/listbox";
import * as i9 from "primeng/scroller";
import * as i10 from "primeng/tree";
import * as i11 from "@Gebo.ai/reusable-ui";
import * as i12 from "primeng/sidebar";
import * as i13 from "primeng/panel";
import * as i14 from "primeng/scrollpanel";
import * as i15 from "primeng/popover";
import * as i16 from "@angular/router";
/**
 * The GeboAiChatModule provides a self-contained feature module for chat functionality.
 *
 * This module imports various UI components from PrimeNG (buttons, spinners, listboxes, etc.) and
 * Angular modules (forms, common) to support the chat interface. It declares the GeboAiChatSectionComponent
 * which is the main component for rendering the chat interface, and exports it to make it available
 * to other modules that import this module.
 *
 * The UI components include:
 * - Form handling (ReactiveFormsModule, FormsModule)
 * - UI components from PrimeNG (Button, ProgressSpinner, BlockUI, etc.)
 * - Custom Gebo.ai components (EditableListboxModule, GeboAIReusableChatModel)
 */
export declare class GeboAiChatModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<GeboAiChatModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<GeboAiChatModule, [typeof i1.GeboAiChatSectionComponent], [typeof i2.CommonModule, typeof i3.ReactiveFormsModule, typeof i4.PaginatorModule, typeof i3.FormsModule, typeof i5.ButtonModule, typeof i6.ProgressSpinnerModule, typeof i7.BlockUIModule, typeof i8.ListboxModule, typeof i9.ScrollerModule, typeof i10.TreeModule, typeof i11.GeboAIReusableChatModule, typeof i11.EditableListboxModule, typeof i12.SidebarModule, typeof i13.PanelModule, typeof i11.GeboAIFieldTranslationContainerModule, typeof i14.ScrollPanelModule, typeof i15.PopoverModule, typeof i16.RouterLink, typeof i11.GeboAINotificationsModule], [typeof i1.GeboAiChatSectionComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<GeboAiChatModule>;
}
//# sourceMappingURL=gebo-ai-rag-chat-section.module.d.ts.map