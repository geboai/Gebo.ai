/**
 * This Source Code is subject to the terms of the
 * Gebo.ai community version Mozilla Public License Version 2.0 (MPL-2.0) — With Data Protection Clauses
 * If a copy of the LICENCE was not distributed with this file, You can obtain one at
 * https://gebo.ai/gebo-ai-community-version-mozilla-public-license-version-2-0-mpl-2-0-with-data-protection-clauses/
 * and https://mozilla.org/MPL/2.0/.
 * Copyright (c) 2025+ Gebo.ai
 */
import { ChangeDetectorRef, OnChanges, OnInit, SimpleChanges } from "@angular/core";
import { ChatModelsLookupControllerService, ChatUIOptions, DataPage, GChatProfileConfiguration, GeboRagChatControllerService, GeboUserChatsControllerService, GUserChatInfo, PageGUserChatInfo } from "@Gebo.ai/gebo-ai-rest-api";
import { FormGroup } from "@angular/forms";
import { PaginatorState } from "primeng/paginator";
import { ScrollerOptions, TreeNode } from "primeng/api";
import { TreeNodeSelectEvent, TreeScrollIndexChangeEvent } from "primeng/tree";
import { ActivatedRoute, Router } from "@angular/router";
import * as i0 from "@angular/core";
/**
 * GeboAiChatSectionComponent is responsible for managing the chat interface section.
 * It handles:
 * - Loading and displaying chat history
 * - Creating new regular or RAG (Retrieval-Augmented Generation) chats
 * - Managing chat profiles and model options
 * - Switching between different chat views
 */
export declare class GeboAiChatSectionComponent implements OnInit, OnChanges {
    private cd;
    private actualRouting;
    private router;
    private geboRagChatControllerService;
    private geboUserChatsControllerService;
    private geboChatModelsControllerService;
    /** Flag indicating if the chats page is currently loading */
    protected chatsPageLoading: boolean;
    /** Flag indicating if the chat models are currently loading */
    protected chatsModelLoading: boolean;
    /** Flag indicating if the chat profiles are currently loading */
    protected chatsProfilesLoading: boolean;
    /** Flag controlling the visibility of the chats list and options panel */
    protected chatsListAndOptionsVisible: boolean;
    /** Flag indicating if a RAG chat is currently open */
    protected openRagChat: boolean;
    /** Flag indicating if a regular chat is currently open */
    protected openChat: boolean;
    /** Stores the current page of chat history */
    protected chatsPage?: PageGUserChatInfo;
    /** Stores the currently active chat information */
    protected currentChat: GUserChatInfo;
    protected chatDataLoading: boolean;
    /**
     * Computed property to determine if any loading is in progress
     * Returns true if any loading process is active
     */
    protected get loading(): boolean;
    /** Pagination configuration for chat history */
    page: DataPage;
    protected chatsTree: TreeNode[];
    protected scrollOptions: ScrollerOptions;
    /** Form group for RAG chat profile selection */
    protected formGroup: FormGroup;
    /** Form group for regular chat model selection */
    protected chatFormGroup: FormGroup;
    /** Stores available chat profile configurations */
    protected chatProfilesData: GChatProfileConfiguration[];
    /** Stores available chat models data */
    protected chatModelsData: {
        code?: string;
        description?: string;
    }[];
    protected chatUIOptions?: ChatUIOptions;
    protected id?: string;
    /**
     * Component constructor that injects necessary services
     * @param activatedRoute Service to access the current route information
     * @param geboRagChatControllerService Service for RAG chat operations
     * @param geboChatControllerService Service for regular chat operations
     * @param geboUserChatsControllerService Service for user chat management
     * @param geboChatModelsControllerService Service for accessing chat models
     */
    constructor(cd: ChangeDetectorRef, actualRouting: ActivatedRoute, router: Router, geboRagChatControllerService: GeboRagChatControllerService, geboUserChatsControllerService: GeboUserChatsControllerService, geboChatModelsControllerService: ChatModelsLookupControllerService);
    protected routeNewRagChat(): void;
    /**
     * Opens the RAG chat interface and hides other chat views
     */
    protected doOpenRagChat(): void;
    protected routeNewChat(): void;
    /**
     * Opens the regular chat interface and hides other chat views
     */
    protected doOpenChat(): void;
    protected scrollIndexChange(indexChange: TreeScrollIndexChangeEvent): void;
    protected routeToChat(chat: GUserChatInfo): void;
    /**
     * Loads the user's chat history with pagination
     * Updates the chatsPage property with the retrieved data
     */
    protected loadChatList(): void;
    protected onUpdatedChat(chatInfo: GUserChatInfo): void;
    protected openChatItem(event: TreeNodeSelectEvent): void;
    /**
     * Closes the current chat, returns to the chat list view, and refreshes the chat history
     */
    protected reloadChatsAndCloseChat(): void;
    /**
     * Loads available chat profiles and models for selection
     * Updates form controls with default selections when data is loaded
     */
    protected loadChatOptions(): void;
    /**
     * Angular lifecycle hook that initializes the component
     * Shows the chat list view and loads chat options and history
     */
    ngOnInit(): void;
    /**
     * Sets the provided chat as the current chat and opens the appropriate interface
     * Opens RAG chat or regular chat based on the chat type
     * @param chat The chat information to activate
     */
    protected activateChat(chat: GUserChatInfo): void;
    /**
     * Angular lifecycle hook that responds to input property changes
     * @param changes Simple changes object containing current and previous values
     */
    ngOnChanges(changes: SimpleChanges): void;
    /**
     * Handles paginator events for the chat history list
     * Updates pagination settings and reloads the chat list
     * @param evt The paginator state containing page and rows information
     */
    onPageChange(evt: PaginatorState): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<GeboAiChatSectionComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<GeboAiChatSectionComponent, "gebo-ai-chat-section-component", never, {}, {}, never, never, false, never>;
}
