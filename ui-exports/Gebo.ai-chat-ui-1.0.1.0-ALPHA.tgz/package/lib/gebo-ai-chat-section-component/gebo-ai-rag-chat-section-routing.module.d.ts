import * as i0 from "@angular/core";
import * as i1 from "./gebo-ai-rag-chat-section.module";
import * as i2 from "@angular/router";
/**
 * Routing module for the Gebo AI Chat feature.
 * This NgModule imports the main GeboAiChatModule and sets up the child routes
 * using Angular's RouterModule.forChild() method. The module provides the necessary
 * routing configuration to navigate to the chat section component when the base
 * path is accessed.
 */
export declare class GeboAiChatRoutingModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<GeboAiChatRoutingModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<GeboAiChatRoutingModule, never, [typeof i1.GeboAiChatModule, typeof i2.RouterModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<GeboAiChatRoutingModule>;
}
