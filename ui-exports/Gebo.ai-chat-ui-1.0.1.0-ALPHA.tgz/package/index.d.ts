/**
 * Generated bundle index. Do not edit.
 */
/// <amd-module name="@Gebo.ai/chat-ui" />
export * from './public-api';
//# sourceMappingURL=Gebo.ai-chat-ui.d.ts.map