import * as i0 from '@angular/core';
import { InjectionToken, ModuleWithProviders } from '@angular/core';
import { HttpClient } from '@angular/common/http';

declare const APIS: never[];

declare const BASE_PATH: InjectionToken<string>;
declare const COLLECTION_FORMATS: {
    csv: string;
    tsv: string;
    ssv: string;
    pipes: string;
};

interface ConfigurationParameters {
    apiKeys?: {
        [key: string]: string;
    };
    username?: string;
    password?: string;
    accessToken?: string | (() => string);
    basePath?: string;
    withCredentials?: boolean;
}
declare class Configuration {
    apiKeys?: {
        [key: string]: string;
    };
    username?: string;
    password?: string;
    accessToken?: string | (() => string);
    basePath?: string;
    withCredentials?: boolean;
    constructor(configurationParameters?: ConfigurationParameters);
    /**
     * Select the correct content-type to use for a request.
     * Uses {@link Configuration#isJsonMime} to determine the correct content-type.
     * If no content type is found return the first found type if the contentTypes is not empty
     * @param contentTypes - the array of content types that are available for selection
     * @returns the selected content-type or <code>undefined</code> if no selection could be made.
     */
    selectHeaderContentType(contentTypes: string[]): string | undefined;
    /**
     * Select the correct accept content-type to use for a request.
     * Uses {@link Configuration#isJsonMime} to determine the correct accept content-type.
     * If no content type is found return the first found type if the contentTypes is not empty
     * @param accepts - the array of content types that are available for selection.
     * @returns the selected content-type or <code>undefined</code> if no selection could be made.
     */
    selectHeaderAccept(accepts: string[]): string | undefined;
    /**
     * Check if the given MIME is a JSON MIME.
     * JSON MIME examples:
     *   application/json
     *   application/json; charset=UTF8
     *   APPLICATION/JSON
     *   application/vnd.company+json
     * @param mime - MIME (Multipurpose Internet Mail Extensions)
     * @return True if the given MIME is JSON, false otherwise.
     */
    isJsonMime(mime: string): boolean;
}

declare class ApiModule {
    static forRoot(configurationFactory: () => Configuration): ModuleWithProviders<ApiModule>;
    constructor(parentModule: ApiModule, http: HttpClient);
    static ɵfac: i0.ɵɵFactoryDeclaration<ApiModule, [{ optional: true; skipSelf: true; }, { optional: true; }]>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ApiModule, never, never, never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ApiModule>;
}

export { APIS, ApiModule, BASE_PATH, COLLECTION_FORMATS, Configuration };
export type { ConfigurationParameters };
//# sourceMappingURL=Gebo.ai-eureka.d.ts.map
