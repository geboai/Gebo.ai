import { HttpClient } from '@angular/common/http';
import * as i0 from '@angular/core';
import { InjectionToken, ModuleWithProviders } from '@angular/core';
import { Observable } from 'rxjs';
import * as i1 from '@Gebo.ai/gateway';
import * as i2 from '@Gebo.ai/eureka';
import * as i3 from '@Gebo.ai/heimdall';
import * as i4 from '@Gebo.ai/brain';
import * as i5 from '@Gebo.ai/vectorizator';
import * as i6 from '@Gebo.ai/graphicator';
import * as i7 from '@Gebo.ai/chunker';
import * as i8 from '@Gebo.ai/git';
import * as i9 from '@Gebo.ai/filesystem';
import * as i10 from '@Gebo.ai/uploads';
import * as i11 from '@Gebo.ai/userspace';
import * as i12 from '@Gebo.ai/sharepoint';
import * as i13 from '@Gebo.ai/confluence';
import * as i14 from '@Gebo.ai/jira';
import * as i15 from '@Gebo.ai/awss3';
import * as i16 from '@Gebo.ai/googledrive';
import * as i17 from '@Gebo.ai/mcpclient';
import * as i18 from '@Gebo.ai/webdav';
import * as i19 from '@Gebo.ai/integration';
import * as i20 from '@Gebo.ai/fulltextor';
import * as i21 from '@Gebo.ai/tyr';

/**
 * This Source Code is subject to the terms of the
 * Gebo.ai community version Mozilla Public License Version 2.0 (MPL-2.0) — With Data Protection Clauses
 * If a copy of the LICENCE was not distributed with this file, You can obtain one at
 * https://gebo.ai/gebo-ai-community-version-mozilla-public-license-version-2-0-mpl-2-0-with-data-protection-clauses/
 * and https://mozilla.org/MPL/2.0/.
 * Copyright (c) 2025+ Gebo.ai
 */
/** Which Gebo.ai installation shape answered the clients-topology call. */
type GeboArchitectureType = 'MONOLITHIC' | 'MICROSERVICES';
/** One entry of the clients topology: what to append to the common base url for one service. */
interface GeboServiceWebContextInfo {
    /** The service this entry addresses, e.g. `brain_gebo_ai`, or `default`. */
    serviceId: string;
    /** The web context to append, e.g. `/brain`; `''` means the service answers at the base url itself. */
    relativeContextUrl: string;
}
/**
 * The answer of `GET <baseUrl>/public/ClientsTopologyProviderController` — how a
 * client completes the one base url it was configured with, per service.
 *
 * Declared here rather than imported from a generated client on purpose: this
 * library must be able to bootstrap against a monolith and a gateway alike,
 * before it knows which one it is talking to, so it cannot depend on either
 * one's stubs for the call that tells it.
 */
interface GeboClientsTopologyInfo {
    architectureType: GeboArchitectureType;
    services: GeboServiceWebContextInfo[];
}
/**
 * The catch-all service id. It is the only entry a monolithic installation
 * publishes, and it carries the empty relative url — so every client of a
 * monolith resolves to the base url itself.
 */
declare const GEBO_DEFAULT_SERVICE_ID = "default";
/**
 * The service ids the Gebo.ai stubs address, in the canonical dot-free form the
 * clients topology keys its entries by (the deployables' `spring.application.name`
 * with `.` replaced by `_`).
 */
declare const GeboMicroservices: {
    readonly GATEWAY: "gateway_gebo_ai";
    readonly EUREKA: "eureka_gebo_ai";
    readonly HEIMDALL: "heimdall_gebo_ai";
    readonly BRAIN: "brain_gebo_ai";
    readonly VECTORIZATOR: "vectorizator_gebo_ai";
    readonly GRAPHICATOR: "graphicator_gebo_ai";
    readonly CHUNKER: "chunker_gebo_ai";
    readonly GIT: "git_gebo_ai";
    readonly FILESYSTEM: "filesystem_gebo_ai";
    readonly UPLOADS: "uploads_gebo_ai";
    readonly USERSPACE: "userspace_gebo_ai";
    readonly SHAREPOINT: "sharepoint_gebo_ai";
    readonly CONFLUENCE: "confluence_gebo_ai";
    readonly JIRA: "jira_gebo_ai";
    readonly AWS_S3: "aws_s3_gebo_ai";
    readonly GOOGLEDRIVE: "googledrive_gebo_ai";
    readonly MCPCLIENT: "mcpclient_gebo_ai";
    readonly WEBDAV: "webdav_gebo_ai";
    readonly INTEGRATION: "integration_gebo_ai";
    readonly FULLTEXTOR: "fulltextor_gebo_ai";
    readonly TYR: "tyr_gebo_ai";
};
/** Any of the {@link GeboMicroservices} ids. */
type GeboMicroserviceId = (typeof GeboMicroservices)[keyof typeof GeboMicroservices];
/** How {@link MicroservicesClientsModule.forRoot} is configured. */
interface GeboMicroservicesClientsOptions {
    /**
     * The ONE base url of the installation — the gateway's public url in a
     * microservices deployment, the server's url in a monolithic one. A trailing
     * slash is stripped. Pass `''` to address the origin the app itself is served
     * from, which is the usual case when Gebo.ai serves the SPA.
     */
    baseUrl: string;
    /**
     * Where the topology is published, appended to {@link baseUrl}. Defaults to
     * `/public/ClientsTopologyProviderController`; override only if the
     * installation is fronted by a proxy that remaps it.
     */
    topologyPath?: string;
}

/**
 * This Source Code is subject to the terms of the
 * Gebo.ai community version Mozilla Public License Version 2.0 (MPL-2.0) — With Data Protection Clauses
 * If a copy of the LICENCE was not distributed with this file, You can obtain one at
 * https://gebo.ai/gebo-ai-community-version-mozilla-public-license-version-2-0-mpl-2-0-with-data-protection-clauses/
 * and https://mozilla.org/MPL/2.0/.
 * Copyright (c) 2025+ Gebo.ai
 */

/** The options {@link MicroservicesClientsModule.forRoot} was given. */
declare const GEBO_MICROSERVICES_CLIENTS_OPTIONS: InjectionToken<GeboMicroservicesClientsOptions>;
/** Where the topology is published, in every installation shape alike. */
declare const GEBO_CLIENTS_TOPOLOGY_PATH = "/public/ClientsTopologyProviderController";
/**
 * Reads the clients topology of the installation once and turns it into the
 * `BASE_PATH` each generated `ApiModule` needs.
 *
 * `load()` is run by the app initializer {@link MicroservicesClientsModule.forRoot}
 * registers, so by the time Angular constructs the first generated service —
 * every one of which reads its base path in its constructor and never again —
 * {@link basePathFor} already has the answer.
 */
declare class GeboClientsTopologyService {
    private readonly http;
    private readonly options;
    private readonly commonBaseUrl;
    private readonly topologyUrl;
    private topology;
    private warnedAboutEarlyAccess;
    constructor(http: HttpClient, options: GeboMicroservicesClientsOptions);
    /** The common base url every client of this installation is built from, with no trailing slash. */
    get baseUrl(): string;
    /** The url the topology is read from. */
    get url(): string;
    /** The topology this installation published, or `null` while {@link load} has not completed. */
    get info(): GeboClientsTopologyInfo | null;
    /**
     * Reads the topology. Called by the app initializer; calling it again re-reads
     * it, but note that services already constructed keep the base path they were
     * given — a re-read only affects services created afterwards.
     *
     * A failed call is NOT an error: it degrades to the monolithic shape (every
     * client points at the base url) and warns. The endpoint was added after the
     * stubs existed, so a Gebo.ai server predating it answers 404 — and those
     * servers were all monoliths, which is exactly what the fallback assumes. A
     * microservices gateway always publishes it.
     */
    load(): Observable<GeboClientsTopologyInfo>;
    /**
     * The complete base path of one service — the value handed to that client
     * library's own `BASE_PATH` token.
     *
     * @param serviceId a service id in either the dotted or the underscore form
     * @throws when a microservices installation publishes no entry for the
     *         service: it has no address behind this base url, and a guessed one
     *         would only turn into a puzzling 404 later. The throw is lazy — it
     *         happens the first time that particular client is injected, so an app
     *         that never touches the service never sees it.
     */
    basePathFor(serviceId: string): string;
    /**
     * The relative web context url published for a service, with the
     * {@link GEBO_DEFAULT_SERVICE_ID} fallback applied.
     *
     * @param serviceId a service id in either form
     */
    relativeContextUrlFor(serviceId: string): string;
    private findRelativeContextUrl;
    /** Mirrors the backend's `GeboMicroservice.normalizeName`: `.` becomes `_`. */
    private static normalizeServiceId;
    /**
     * Brings a published value to the form the module concatenates blindly:
     * either `''` or a leading-slash path with no trailing slash, so
     * `baseUrl + relative` never grows a double or a dangling slash.
     */
    private static normalizeRelativeContextUrl;
    private static stripTrailingSlash;
    private static monolithicFallback;
    static ɵfac: i0.ɵɵFactoryDeclaration<GeboClientsTopologyService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<GeboClientsTopologyService>;
}

/**
 * This Source Code is subject to the terms of the
 * Gebo.ai community version Mozilla Public License Version 2.0 (MPL-2.0) — With Data Protection Clauses
 * If a copy of the LICENCE was not distributed with this file, You can obtain one at
 * https://gebo.ai/gebo-ai-community-version-mozilla-public-license-version-2-0-mpl-2-0-with-data-protection-clauses/
 * and https://mozilla.org/MPL/2.0/.
 * Copyright (c) 2025+ Gebo.ai
 */

/**
 * The one import that connects an Angular app to a Gebo.ai installation,
 * whatever shape it has.
 *
 * ```ts
 * @NgModule({
 *   imports: [
 *     BrowserModule,
 *     HttpClientModule,
 *     MicroservicesClientsModule.forRoot({ baseUrl: environment.geboBaseUrl }),
 *   ],
 * })
 * export class AppModule {}
 * ```
 *
 * From there every generated service is injectable and already points at the
 * right address:
 *
 * ```ts
 * constructor(private chatModels: ChatModelsControllerService) {}   // @Gebo.ai/brain
 * ```
 *
 * ## What it does
 *
 * Each generated client hardcodes the address its spec was scraped from
 * (`http://localhost:13001/brain` and friends) and exposes a `BASE_PATH` token
 * to override it. Which suffix a service actually answers on depends on the
 * deployment: behind a gateway every service owns a web context (`/brain`,
 * `/heimdall`), on a monolith they all answer at the root. So this module asks
 * the installation itself — `/public/ClientsTopologyProviderController`, which
 * every shape publishes at the same relative url — and provides all 21
 * `BASE_PATH` tokens from that answer. The app knows ONE url and nothing else
 * changes between a monolithic and a microservices target.
 *
 * ## Requirements and caveats
 *
 * - `HttpClient` must be provided (`HttpClientModule` / `provideHttpClient()`),
 *   as every generated `ApiModule` already demands.
 * - Import it in the root module ONCE. The generated `ApiModule`s carry their own
 *   "already loaded" guard, and this one is a `forRoot`.
 * - The topology is read by an app initializer, so it is in place before Angular
 *   builds the first client. A client injected from an initializer registered
 *   BEFORE this module's is the one case that can miss it — it falls back to the
 *   bare base url and warns.
 * - The 21 `@Gebo.ai/*` client packages are peer dependencies: the consuming app
 *   installs them, this library only wires them.
 */
declare class MicroservicesClientsModule {
    /**
     * @param options the installation's base url, or the full options object. A
     *        bare string is the same as `{ baseUrl: options }`; `''` addresses the
     *        origin the app itself is served from, which is the usual case when
     *        Gebo.ai serves the SPA.
     */
    static forRoot(options: GeboMicroservicesClientsOptions | string): ModuleWithProviders<MicroservicesClientsModule>;
    constructor(parentModule?: MicroservicesClientsModule);
    static ɵfac: i0.ɵɵFactoryDeclaration<MicroservicesClientsModule, [{ optional: true; skipSelf: true; }]>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<MicroservicesClientsModule, never, [typeof i1.ApiModule, typeof i2.ApiModule, typeof i3.ApiModule, typeof i4.ApiModule, typeof i5.ApiModule, typeof i6.ApiModule, typeof i7.ApiModule, typeof i8.ApiModule, typeof i9.ApiModule, typeof i10.ApiModule, typeof i11.ApiModule, typeof i12.ApiModule, typeof i13.ApiModule, typeof i14.ApiModule, typeof i15.ApiModule, typeof i16.ApiModule, typeof i17.ApiModule, typeof i18.ApiModule, typeof i19.ApiModule, typeof i20.ApiModule, typeof i21.ApiModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<MicroservicesClientsModule>;
}

export { GEBO_CLIENTS_TOPOLOGY_PATH, GEBO_DEFAULT_SERVICE_ID, GEBO_MICROSERVICES_CLIENTS_OPTIONS, GeboClientsTopologyService, GeboMicroservices, MicroservicesClientsModule };
export type { GeboArchitectureType, GeboClientsTopologyInfo, GeboMicroserviceId, GeboMicroservicesClientsOptions, GeboServiceWebContextInfo };
