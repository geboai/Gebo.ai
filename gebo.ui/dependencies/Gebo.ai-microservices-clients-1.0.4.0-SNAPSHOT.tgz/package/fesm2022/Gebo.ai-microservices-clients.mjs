import * as i0 from '@angular/core';
import { InjectionToken, Inject, Injectable, provideAppInitializer, inject, Optional, SkipSelf, NgModule } from '@angular/core';
import { of } from 'rxjs';
import { map, catchError } from 'rxjs/operators';
import * as i1 from '@angular/common/http';
import { BASE_PATH, ApiModule } from '@Gebo.ai/gateway';
import { BASE_PATH as BASE_PATH$1, ApiModule as ApiModule$1 } from '@Gebo.ai/eureka';
import { BASE_PATH as BASE_PATH$2, ApiModule as ApiModule$2 } from '@Gebo.ai/heimdall';
import { BASE_PATH as BASE_PATH$3, ApiModule as ApiModule$3 } from '@Gebo.ai/brain';
import { BASE_PATH as BASE_PATH$4, ApiModule as ApiModule$4 } from '@Gebo.ai/vectorizator';
import { BASE_PATH as BASE_PATH$5, ApiModule as ApiModule$5 } from '@Gebo.ai/graphicator';
import { BASE_PATH as BASE_PATH$6, ApiModule as ApiModule$6 } from '@Gebo.ai/chunker';
import { BASE_PATH as BASE_PATH$7, ApiModule as ApiModule$7 } from '@Gebo.ai/git';
import { BASE_PATH as BASE_PATH$8, ApiModule as ApiModule$8 } from '@Gebo.ai/filesystem';
import { BASE_PATH as BASE_PATH$9, ApiModule as ApiModule$9 } from '@Gebo.ai/uploads';
import { BASE_PATH as BASE_PATH$a, ApiModule as ApiModule$a } from '@Gebo.ai/userspace';
import { BASE_PATH as BASE_PATH$b, ApiModule as ApiModule$b } from '@Gebo.ai/sharepoint';
import { BASE_PATH as BASE_PATH$c, ApiModule as ApiModule$c } from '@Gebo.ai/confluence';
import { BASE_PATH as BASE_PATH$d, ApiModule as ApiModule$d } from '@Gebo.ai/jira';
import { BASE_PATH as BASE_PATH$e, ApiModule as ApiModule$e } from '@Gebo.ai/awss3';
import { BASE_PATH as BASE_PATH$f, ApiModule as ApiModule$f } from '@Gebo.ai/googledrive';
import { BASE_PATH as BASE_PATH$g, ApiModule as ApiModule$g } from '@Gebo.ai/mcpclient';
import { BASE_PATH as BASE_PATH$h, ApiModule as ApiModule$h } from '@Gebo.ai/webdav';
import { BASE_PATH as BASE_PATH$i, ApiModule as ApiModule$i } from '@Gebo.ai/integration';
import { BASE_PATH as BASE_PATH$j, ApiModule as ApiModule$j } from '@Gebo.ai/fulltextor';
import { BASE_PATH as BASE_PATH$k, ApiModule as ApiModule$k } from '@Gebo.ai/tyr';

/**
 * This Source Code is subject to the terms of the
 * Gebo.ai community version Mozilla Public License Version 2.0 (MPL-2.0) — With Data Protection Clauses
 * If a copy of the LICENCE was not distributed with this file, You can obtain one at
 * https://gebo.ai/gebo-ai-community-version-mozilla-public-license-version-2-0-mpl-2-0-with-data-protection-clauses/
 * and https://mozilla.org/MPL/2.0/.
 * Copyright (c) 2025+ Gebo.ai
 */
/**
 * The catch-all service id. It is the only entry a monolithic installation
 * publishes, and it carries the empty relative url — so every client of a
 * monolith resolves to the base url itself.
 */
const GEBO_DEFAULT_SERVICE_ID = 'default';
/**
 * The service ids the Gebo.ai stubs address, in the canonical dot-free form the
 * clients topology keys its entries by (the deployables' `spring.application.name`
 * with `.` replaced by `_`).
 */
const GeboMicroservices = {
    GATEWAY: 'gateway_gebo_ai',
    EUREKA: 'eureka_gebo_ai',
    HEIMDALL: 'heimdall_gebo_ai',
    BRAIN: 'brain_gebo_ai',
    VECTORIZATOR: 'vectorizator_gebo_ai',
    GRAPHICATOR: 'graphicator_gebo_ai',
    CHUNKER: 'chunker_gebo_ai',
    GIT: 'git_gebo_ai',
    FILESYSTEM: 'filesystem_gebo_ai',
    UPLOADS: 'uploads_gebo_ai',
    USERSPACE: 'userspace_gebo_ai',
    SHAREPOINT: 'sharepoint_gebo_ai',
    CONFLUENCE: 'confluence_gebo_ai',
    JIRA: 'jira_gebo_ai',
    AWS_S3: 'aws_s3_gebo_ai',
    GOOGLEDRIVE: 'googledrive_gebo_ai',
    MCPCLIENT: 'mcpclient_gebo_ai',
    WEBDAV: 'webdav_gebo_ai',
    INTEGRATION: 'integration_gebo_ai',
    FULLTEXTOR: 'fulltextor_gebo_ai',
    TYR: 'tyr_gebo_ai',
};

/** The options {@link MicroservicesClientsModule.forRoot} was given. */
const GEBO_MICROSERVICES_CLIENTS_OPTIONS = new InjectionToken('GEBO_MICROSERVICES_CLIENTS_OPTIONS');
/** Where the topology is published, in every installation shape alike. */
const GEBO_CLIENTS_TOPOLOGY_PATH = '/public/ClientsTopologyProviderController';
/**
 * Reads the clients topology of the installation once and turns it into the
 * `BASE_PATH` each generated `ApiModule` needs.
 *
 * `load()` is run by the app initializer {@link MicroservicesClientsModule.forRoot}
 * registers, so by the time Angular constructs the first generated service —
 * every one of which reads its base path in its constructor and never again —
 * {@link basePathFor} already has the answer.
 */
class GeboClientsTopologyService {
    constructor(http, options) {
        this.http = http;
        this.topology = null;
        this.warnedAboutEarlyAccess = false;
        this.options = options;
        this.commonBaseUrl = GeboClientsTopologyService.stripTrailingSlash(options.baseUrl ?? '');
        this.topologyUrl = this.commonBaseUrl + (options.topologyPath ?? GEBO_CLIENTS_TOPOLOGY_PATH);
    }
    /** The common base url every client of this installation is built from, with no trailing slash. */
    get baseUrl() {
        return this.commonBaseUrl;
    }
    /** The url the topology is read from. */
    get url() {
        return this.topologyUrl;
    }
    /** The topology this installation published, or `null` while {@link load} has not completed. */
    get info() {
        return this.topology;
    }
    /**
     * Reads the topology. Called by the app initializer; calling it again re-reads
     * it, but note that services already constructed keep the base path they were
     * given — a re-read only affects services created afterwards.
     *
     * A failed call is NOT an error: it degrades to the monolithic shape (every
     * client points at the base url) and warns. The endpoint was added after the
     * stubs existed, so a Gebo.ai server predating it answers 404 — and those
     * servers were all monoliths, which is exactly what the fallback assumes. A
     * microservices gateway always publishes it.
     */
    load() {
        return this.http.get(this.topologyUrl).pipe(map((fetched) => {
            if (!fetched || !fetched.architectureType || !fetched.services?.length) {
                console.warn(`[gebo] clients topology at ${this.topologyUrl} answered an empty payload; falling back to the` +
                    ` monolithic shape (every client points at ${this.commonBaseUrl || 'the app origin'}).`);
                return GeboClientsTopologyService.monolithicFallback();
            }
            return fetched;
        }), catchError((error) => {
            console.warn(`[gebo] clients topology could not be read from ${this.topologyUrl}; falling back to the monolithic` +
                ` shape (every client points at ${this.commonBaseUrl || 'the app origin'}). Expected against a server` +
                ` predating the endpoint, which is always a monolith — and wrong against a microservices gateway,` +
                ` where the per-service web contexts would then be missing.`, error);
            return of(GeboClientsTopologyService.monolithicFallback());
        }), map((resolved) => {
            this.topology = resolved;
            return resolved;
        }));
    }
    /**
     * The complete base path of one service — the value handed to that client
     * library's own `BASE_PATH` token.
     *
     * @param serviceId a service id in either the dotted or the underscore form
     * @throws when a microservices installation publishes no entry for the
     *         service: it has no address behind this base url, and a guessed one
     *         would only turn into a puzzling 404 later. The throw is lazy — it
     *         happens the first time that particular client is injected, so an app
     *         that never touches the service never sees it.
     */
    basePathFor(serviceId) {
        return this.commonBaseUrl + this.relativeContextUrlFor(serviceId);
    }
    /**
     * The relative web context url published for a service, with the
     * {@link GEBO_DEFAULT_SERVICE_ID} fallback applied.
     *
     * @param serviceId a service id in either form
     */
    relativeContextUrlFor(serviceId) {
        const canonical = GeboClientsTopologyService.normalizeServiceId(serviceId);
        if (!canonical) {
            throw new Error('[gebo] serviceId must not be empty');
        }
        if (!this.topology) {
            // Only reachable when a generated service is injected BEFORE the app
            // initializer has run — e.g. from another initializer registered earlier.
            // Falling back keeps the app alive; the warning names the fix.
            if (!this.warnedAboutEarlyAccess) {
                this.warnedAboutEarlyAccess = true;
                console.warn(`[gebo] a Gebo.ai client for '${canonical}' was injected before the clients topology finished loading,` +
                    ` so it was given the bare base url ${this.commonBaseUrl || 'the app origin'}. Inject it from a` +
                    ` component or a service resolved after bootstrap, not from an APP_INITIALIZER that runs before` +
                    ` MicroservicesClientsModule's own.`);
            }
            return '';
        }
        const own = this.findRelativeContextUrl(canonical);
        if (own !== null) {
            return GeboClientsTopologyService.normalizeRelativeContextUrl(own);
        }
        const fallback = this.findRelativeContextUrl(GEBO_DEFAULT_SERVICE_ID);
        if (fallback !== null) {
            return GeboClientsTopologyService.normalizeRelativeContextUrl(fallback);
        }
        throw new Error(`[gebo] the installation at ${this.commonBaseUrl || 'the app origin'} publishes no clients-topology entry` +
            ` for service '${canonical}' (architecture ${this.topology.architectureType}), and no` +
            ` '${GEBO_DEFAULT_SERVICE_ID}' fallback entry. That service is not reachable through this base url.` +
            ` Published: ${this.topology.services.map((service) => service.serviceId).join(', ')}`);
    }
    findRelativeContextUrl(canonicalServiceId) {
        const match = this.topology?.services.find((service) => GeboClientsTopologyService.normalizeServiceId(service.serviceId) === canonicalServiceId);
        return match ? match.relativeContextUrl : null;
    }
    /** Mirrors the backend's `GeboMicroservice.normalizeName`: `.` becomes `_`. */
    static normalizeServiceId(serviceId) {
        if (!serviceId) {
            return null;
        }
        const trimmed = serviceId.trim();
        return trimmed.length === 0 ? null : trimmed.replace(/\./g, '_');
    }
    /**
     * Brings a published value to the form the module concatenates blindly:
     * either `''` or a leading-slash path with no trailing slash, so
     * `baseUrl + relative` never grows a double or a dangling slash.
     */
    static normalizeRelativeContextUrl(relativeContextUrl) {
        const trimmed = (relativeContextUrl ?? '').trim();
        if (trimmed.length === 0 || trimmed === '/') {
            return '';
        }
        const withLeadingSlash = trimmed.startsWith('/') ? trimmed : '/' + trimmed;
        return GeboClientsTopologyService.stripTrailingSlash(withLeadingSlash);
    }
    static stripTrailingSlash(url) {
        let result = url.trim();
        while (result.length > 1 && result.endsWith('/')) {
            result = result.substring(0, result.length - 1);
        }
        return result === '/' ? '' : result;
    }
    static monolithicFallback() {
        return {
            architectureType: 'MONOLITHIC',
            services: [{ serviceId: GEBO_DEFAULT_SERVICE_ID, relativeContextUrl: '' }],
        };
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: GeboClientsTopologyService, deps: [{ token: i1.HttpClient }, { token: GEBO_MICROSERVICES_CLIENTS_OPTIONS }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: GeboClientsTopologyService }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: GeboClientsTopologyService, decorators: [{
            type: Injectable
        }], ctorParameters: () => [{ type: i1.HttpClient }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [GEBO_MICROSERVICES_CLIENTS_OPTIONS]
                }] }] });

/**
 * This Source Code is subject to the terms of the
 * Gebo.ai community version Mozilla Public License Version 2.0 (MPL-2.0) — With Data Protection Clauses
 * If a copy of the LICENCE was not distributed with this file, You can obtain one at
 * https://gebo.ai/gebo-ai-community-version-mozilla-public-license-version-2-0-mpl-2-0-with-data-protection-clauses/
 * and https://mozilla.org/MPL/2.0/.
 * Copyright (c) 2025+ Gebo.ai
 */
/**
 * Every generated client, paired with the service id the clients topology
 * publishes its web context under.
 *
 * Each library ships its OWN `BASE_PATH` injection token — 21 distinct
 * `InjectionToken` instances that merely share a description string — which is
 * exactly what makes per-service base paths possible in a single injector: they
 * never collide.
 */
const GEBO_CLIENT_BASE_PATH_TOKENS = [
    [BASE_PATH, GeboMicroservices.GATEWAY],
    [BASE_PATH$1, GeboMicroservices.EUREKA],
    [BASE_PATH$2, GeboMicroservices.HEIMDALL],
    [BASE_PATH$3, GeboMicroservices.BRAIN],
    [BASE_PATH$4, GeboMicroservices.VECTORIZATOR],
    [BASE_PATH$5, GeboMicroservices.GRAPHICATOR],
    [BASE_PATH$6, GeboMicroservices.CHUNKER],
    [BASE_PATH$7, GeboMicroservices.GIT],
    [BASE_PATH$8, GeboMicroservices.FILESYSTEM],
    [BASE_PATH$9, GeboMicroservices.UPLOADS],
    [BASE_PATH$a, GeboMicroservices.USERSPACE],
    [BASE_PATH$b, GeboMicroservices.SHAREPOINT],
    [BASE_PATH$c, GeboMicroservices.CONFLUENCE],
    [BASE_PATH$d, GeboMicroservices.JIRA],
    [BASE_PATH$e, GeboMicroservices.AWS_S3],
    [BASE_PATH$f, GeboMicroservices.GOOGLEDRIVE],
    [BASE_PATH$g, GeboMicroservices.MCPCLIENT],
    [BASE_PATH$h, GeboMicroservices.WEBDAV],
    [BASE_PATH$i, GeboMicroservices.INTEGRATION],
    [BASE_PATH$j, GeboMicroservices.FULLTEXTOR],
    [BASE_PATH$k, GeboMicroservices.TYR],
];
/**
 * The one import that connects an Angular app to a Gebo.ai installation,
 * whatever shape it has.
 *
 * ```ts
 * @NgModule({
 *   imports: [
 *     BrowserModule,
 *     HttpClientModule,
 *     MicroservicesClientsModule.forRoot({ baseUrl: environment.geboBaseUrl }),
 *   ],
 * })
 * export class AppModule {}
 * ```
 *
 * From there every generated service is injectable and already points at the
 * right address:
 *
 * ```ts
 * constructor(private chatModels: ChatModelsControllerService) {}   // @Gebo.ai/brain
 * ```
 *
 * ## What it does
 *
 * Each generated client hardcodes the address its spec was scraped from
 * (`http://localhost:13001/brain` and friends) and exposes a `BASE_PATH` token
 * to override it. Which suffix a service actually answers on depends on the
 * deployment: behind a gateway every service owns a web context (`/brain`,
 * `/heimdall`), on a monolith they all answer at the root. So this module asks
 * the installation itself — `/public/ClientsTopologyProviderController`, which
 * every shape publishes at the same relative url — and provides all 21
 * `BASE_PATH` tokens from that answer. The app knows ONE url and nothing else
 * changes between a monolithic and a microservices target.
 *
 * ## Requirements and caveats
 *
 * - `HttpClient` must be provided (`HttpClientModule` / `provideHttpClient()`),
 *   as every generated `ApiModule` already demands.
 * - Import it in the root module ONCE. The generated `ApiModule`s carry their own
 *   "already loaded" guard, and this one is a `forRoot`.
 * - The topology is read by an app initializer, so it is in place before Angular
 *   builds the first client. A client injected from an initializer registered
 *   BEFORE this module's is the one case that can miss it — it falls back to the
 *   bare base url and warns.
 * - The 21 `@Gebo.ai/*` client packages are peer dependencies: the consuming app
 *   installs them, this library only wires them.
 */
class MicroservicesClientsModule {
    /**
     * @param options the installation's base url, or the full options object. A
     *        bare string is the same as `{ baseUrl: options }`; `''` addresses the
     *        origin the app itself is served from, which is the usual case when
     *        Gebo.ai serves the SPA.
     */
    static forRoot(options) {
        const resolved = typeof options === 'string' ? { baseUrl: options } : options;
        return {
            ngModule: MicroservicesClientsModule,
            providers: [
                { provide: GEBO_MICROSERVICES_CLIENTS_OPTIONS, useValue: resolved },
                GeboClientsTopologyService,
                // Runs before the app bootstraps, so the base-path factories below —
                // which are evaluated when a generated service is first injected —
                // always find the topology already resolved.
                provideAppInitializer(() => inject(GeboClientsTopologyService).load()),
                ...GEBO_CLIENT_BASE_PATH_TOKENS.map(([token, serviceId]) => basePathProvider(token, serviceId)),
            ],
        };
    }
    constructor(parentModule) {
        if (parentModule) {
            throw new Error('MicroservicesClientsModule is already loaded. Import MicroservicesClientsModule.forRoot() in your' +
                ' AppModule only.');
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: MicroservicesClientsModule, deps: [{ token: MicroservicesClientsModule, optional: true, skipSelf: true }], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.2.23", ngImport: i0, type: MicroservicesClientsModule, imports: [
            // Importing them here is what makes the app's own module a one-liner: every
            // generated service becomes injectable without the app listing 21 ApiModules
            // whose only purpose is to be given a base path.
            ApiModule,
            ApiModule$1,
            ApiModule$2,
            ApiModule$3,
            ApiModule$4,
            ApiModule$5,
            ApiModule$6,
            ApiModule$7,
            ApiModule$8,
            ApiModule$9,
            ApiModule$a,
            ApiModule$b,
            ApiModule$c,
            ApiModule$d,
            ApiModule$e,
            ApiModule$f,
            ApiModule$g,
            ApiModule$h,
            ApiModule$i,
            ApiModule$j,
            ApiModule$k] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: MicroservicesClientsModule, imports: [
            // Importing them here is what makes the app's own module a one-liner: every
            // generated service becomes injectable without the app listing 21 ApiModules
            // whose only purpose is to be given a base path.
            ApiModule,
            ApiModule$1,
            ApiModule$2,
            ApiModule$3,
            ApiModule$4,
            ApiModule$5,
            ApiModule$6,
            ApiModule$7,
            ApiModule$8,
            ApiModule$9,
            ApiModule$a,
            ApiModule$b,
            ApiModule$c,
            ApiModule$d,
            ApiModule$e,
            ApiModule$f,
            ApiModule$g,
            ApiModule$h,
            ApiModule$i,
            ApiModule$j,
            ApiModule$k] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.23", ngImport: i0, type: MicroservicesClientsModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        // Importing them here is what makes the app's own module a one-liner: every
                        // generated service becomes injectable without the app listing 21 ApiModules
                        // whose only purpose is to be given a base path.
                        ApiModule,
                        ApiModule$1,
                        ApiModule$2,
                        ApiModule$3,
                        ApiModule$4,
                        ApiModule$5,
                        ApiModule$6,
                        ApiModule$7,
                        ApiModule$8,
                        ApiModule$9,
                        ApiModule$a,
                        ApiModule$b,
                        ApiModule$c,
                        ApiModule$d,
                        ApiModule$e,
                        ApiModule$f,
                        ApiModule$g,
                        ApiModule$h,
                        ApiModule$i,
                        ApiModule$j,
                        ApiModule$k,
                    ],
                }]
        }], ctorParameters: () => [{ type: MicroservicesClientsModule, decorators: [{
                    type: Optional
                }, {
                    type: SkipSelf
                }] }] });
/**
 * One client library's `BASE_PATH`, resolved from the topology.
 *
 * A factory rather than a value: it is evaluated the first time that particular
 * client is injected, which is both after the app initializer has run and — for
 * a service the installation does not publish — the point at which throwing is
 * useful rather than fatal to the whole app.
 */
function basePathProvider(token, serviceId) {
    return {
        provide: token,
        useFactory: (topology) => topology.basePathFor(serviceId),
        deps: [GeboClientsTopologyService],
    };
}

/**
 * This Source Code is subject to the terms of the
 * Gebo.ai community version Mozilla Public License Version 2.0 (MPL-2.0) — With Data Protection Clauses
 * If a copy of the LICENCE was not distributed with this file, You can obtain one at
 * https://gebo.ai/gebo-ai-community-version-mozilla-public-license-version-2-0-mpl-2-0-with-data-protection-clauses/
 * and https://mozilla.org/MPL/2.0/.
 * Copyright (c) 2025+ Gebo.ai
 */
/*
 * Public API Surface of gebo-microservices-clients
 *
 * Deliberately narrow: this library WIRES the generated @Gebo.ai/* clients, it
 * does not re-export them. Every one of the 21 ships its own ApiModule,
 * Configuration and BASE_PATH under those same names, so re-exporting would
 * collide 21 ways over; keep importing services from their own package.
 */

/**
 * Generated bundle index. Do not edit.
 */

export { GEBO_CLIENTS_TOPOLOGY_PATH, GEBO_DEFAULT_SERVICE_ID, GEBO_MICROSERVICES_CLIENTS_OPTIONS, GeboClientsTopologyService, GeboMicroservices, MicroservicesClientsModule };
//# sourceMappingURL=Gebo.ai-microservices-clients.mjs.map
